﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : Passwort.aspx.cs
//
// Description  : Login
//
//=============== 1.0.0049 ================================================
//
// Date         : 7.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500063
//                B&I CarveOut - Umstellung auf Lokale Anmeldung 2
//
// ============================================================================
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using System.Data.SqlClient;
using System.Text;

public partial class Allgemein_Passwort : System.Web.UI.Page
{
    private dbBearbeiter Bearb;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.Cookies["LastLogin"] != null)
                UserName.Text = Request.Cookies["LastLogin"].Value;
            else
                UserName.Text = Page.User.Identity.Name;
            Session["pwdChange"] = Bearb = new dbBearbeiter(UserName.Text);
            Session["Passwort"] = ReadPass();
        }
        else
            Bearb = (dbBearbeiter) Session["pwdChange"];
        pnlChangePwd.Enabled = false;
        pnlChangePwd.Visible = false;
        lblInfo.Enabled = true;
        lblInfo.Visible = true;
        lblError.Text = "";
        lblError.ForeColor = System.Drawing.Color.Red;
        try
        {
            string localPwd = ConfigurationManager.AppSettings["UseLocalPWD"];
            string localPwdUser = ConfigurationManager.AppSettings["UserUsedLocalPWD"] != null ? ConfigurationManager.AppSettings["UserUsedLocalPWD"] : ""; //BAN 500060 B&I CarveOut - Umstellung auf Lokale Anmeldung
            if (Bearb != null && (localPwd.Contains(Bearb.Params.MANDANT.Value.ToString()) || localPwdUser.Contains(Bearb.Params.MANDANT.Value.ToString())) && Session["Passwort"].ToString() != "")
            {
                pnlChangePwd.Enabled = true;
                pnlChangePwd.Visible = true;
            }
            else
            {
                lblInfo.Enabled = true;
                lblInfo.Visible = true;
                lblInfo.Text = "Diese Funktion steht nur der TAP Mandanten " + localPwd + " zur Verfügung!"; ;
            }
        }
        catch{ }

    }

    private string ReadPass()
    {
        string ret = "";
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT KWORT FROM LOCAL_USER " + Config.Nolock + " WHERE PERSKEY = " + Bearb.Params.PERSKEY.Value.ToString(), cnx))
                {
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            if (!rd.IsDBNull(0))
                                ret = DeCrypt(rd.GetString(0));
                        }
                        rd.Close();
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return ret;
    }
    protected void btnPwdChande_Click(object sender, EventArgs e)
    {
        if (oldPass.Text != Session["Passwort"].ToString())
        {
            lblError.Text = "Passwort ist falsch";
            lblError.Visible = true;
            return;
        }
        if( newPass.Text != passConfirm.Text )
        {
            lblError.Text = "Wiederholtes Passwort ist ungleich dem neuen Passwort";
            lblError.Visible = true;
            return;
        }

        if (newPass.Text.Length < 6 || newPass.Text.Length > 10)
        {
            lblError.Text = "Passwort muss zwischen 6 und 10 Zeichen lang sein";
            lblError.Visible = true;
            return;
        }

        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                    //update
                using (SqlCommand cmd = new SqlCommand("UPDATE LOCAL_USER " + Config.Rowlock +
                    " SET KWORT = '" + Crypt(newPass.Text) + "', DATKWORT = getdate() WHERE PERSKEY = " + Bearb.Params.PERSKEY.Value.ToString(), cnx))
                {
                    cmd.ExecuteNonQuery();
                    lblError.Text = "Passwort erfolgreich geändert";
                    lblError.ForeColor = System.Drawing.Color.Green;
                    lblError.Visible = true;
                    Session["Passwort"] = newPass.Text;
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
    }
    #region Crypt/DeCrypt/ Registry
    /// <summary>
    /// Crypt-Funktion (nachgebaut aus den TAP-VB-Routinen)
    /// </summary>
    /// <param name="strIn"></param>
    /// <returns></returns>
    private string Crypt(string strIn)
    {
        string strKey = "";
        string strOut = new string(' ', 32);
        int byLC = 0, byCC = 0;

        if (strIn.Length < 1)
            return "";

        strKey = String.Format("{0:x}", strIn.Length).ToString() + strIn + "0123456789abcdef";

        byLC = 0x7F;
        for (int i = 0; i < 16; i++)
        {
            byCC = Convert.ToChar(strKey.Substring((i ^ 3), 1));
            strOut = strOut.Substring(0, (2 * (i ^ 9))) + String.Format("{0:X2}", Convert.ToByte(byCC ^ byLC ^ i)) + strOut.Substring((2 * (i ^ 9)) + 2);
            byLC = byCC;
        }

        return strOut.ToString();
    }

    /// <summary>
    /// DeCrypt-Funktion (nachgebaut aus den TAP-VB-Routinen)
    /// </summary>
    /// <param name="strIn"></param>
    /// <returns></returns>
    public string DeCrypt(string strIn)
    {
        int[] j = new int[16];
        string strOut = new string(' ', 16);
        int byLC = 0;
        int byCC = 0;
        byte[] bytearr = new byte[1];

        if (strIn.Length < 1)
            return "";

        byLC = 0x7F;
        for (int i = 0; i < 16; i++)
        {
            j[i] = Convert.ToByte(strIn.Substring((2 * (i ^ 9)), 2), 16);
        }

        for (int i = 0; i < 16; i++)
        {
            byCC = j[i];
            byLC = (j[i] ^ byLC ^ i);
            bytearr[0] = Convert.ToByte(byLC);
            strOut = strOut.Substring(0, (i ^ 3)) + Encoding.ASCII.GetString(bytearr) + strOut.Substring((i ^ 3) + 1);
        }
        return strOut.Substring(1, Convert.ToByte(strOut.Substring(0, 1), 16));

    }
    #endregion

}
