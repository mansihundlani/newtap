﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : Login.aspx.cs
//
// Description  : Login
//
//=============== 1.2.0030 ================================================
//
// Date         : 19. April 2016
// Author       : Erwin Stambera
// Defect#      : Change Request
//                Umstellung Next Generation Active Directory
//
//=============== 1.2.0014 ================================================
//
// Date         : 29.August 2013
// Author       : Joldic Dzevad
// Defect#      : BA1 500373
//                Update von TAP Montage auf .NET V4.0
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== 1.0.0049 ================================================
//
// Date         : 7.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500063
//                B&I CarveOut - Umstellung auf Lokale Anmeldung 2
//
//=============== 1.0.0048 ================================================
//
// Date         : 17.August 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500060
//                B&I CarveOut - Umstellung auf Lokale Anmeldung
//
//=============== 1.0.0045 ================================================
//
// Date         : 22.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-22
//                Erfasser benachrichtigen wenn EB durch Genehmiger geändert ist
//
//=============== 1.0.0037 ================================================
//
// Date         : 18.Jänner 2008
// Author       : Joldic Dzevad
// Defect#      : 5750
//                EB_Select_SelectedMonat, EB_Select_SelectedProjekt
//                EB_Select_SelectedMonteur sind etfernt aus der Liste der
//                Session Variablen dass nicht gelöscht werden soll nach dem
//                logoff
//
//=============== 1.0.0035 ================================================
//
// Date         : 14.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5617
//                Fehlermeldung nach fehlerhaftem Login ausgeben
//
//=============== 1.0.0028 ================================================
//
// Date         : 14.Juni 2007
// Author       : Adam Kiefer
// Defect#      : 4021
//                Ausgabe von Kurzmeldungen am Login Bildschirm
//
//--------------- 1.0.0028 ----------------------------------------------------
//
// Date         : 24.Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4121
//                Neues Login-Konzept
//
//--------------- 1.0.0020 ----------------------------------------------------
//
// Date         : 20.März 2006
// Author       : GN
// Defect#      : 4358
//                Login beschränkt auf in Web.config eingetragene Mandanten
//
//--------------- 1.0.0016 ----------------------------------------------------
//
// Date         : 19.Dezember 2006
// Author       : Caleb Gebhardt
// Defect#      : 4004
//                Konstanter Benutzer (siehe web.config, key DomainWW300Provider)
//                f. Authentifizierung ausgeschaltet und wird nicht mehr benötigt
//
// ============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Net;
using System.Web.Services;
using System.DirectoryServices;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Default2 : System.Web.UI.Page
{
    dbBearbeiter Bearb;

    protected void Page_Load(object sender, EventArgs e)
    {

        FormsAuthentication.SignOut();
        //string ppp = Server.MapPath("~/Log/");
        //TMLogWriter.WriteLogEntry(TMLogWriter.ErrorLevel.Information, User.Identity.Name, "Info - Info\r\nInfo -Info!", 27, Server.MapPath("~/Log/"));
        // Defect #5750 Begin, EB_Select_SelectedMonat, EB_Select_SelectedProjekt und EB_Select_SelectedMonteur löschen
        // SessionMgr.ClearSession(Page, new string[] { "Bearbeiter", "Baustelle", "Projekt", "MBericht", "EB_Select_SelectedMonat", "EB_Select_SelectedProjekt", "EB_Select_SelectedMonteur", "Monteur", "KGMonat", "KGReiseZeile", "KGAzm" });
        SessionMgr.ClearSession(Page, new string[] { "Bearbeiter", "Baustelle", "Projekt", "MBericht", "Monteur", "KGMonat", "KGReiseZeile", "KGAzm" });
        // Defect #5750 Ende
        Request.Cookies.Remove("PersKey_Login");
        Request.Cookies.Remove("PersKey_Data");
        if (!Page.IsPostBack)
        {
            //Should be: Bearb = new dbBearbeiter(User.Identity.Name.Substring(User.Identity.Name.LastIndexOf("\\") + 1));
            if (Request.Cookies["LastLogin"] != null)
                txtLogin.Text = Request.Cookies["LastLogin"].Value;
            //else
            //  txtLogin.Text = Page.User.Identity.Name;
        }
        else
            Bearb = (dbBearbeiter)Session["Bearbeiter"];

        // Beginn #4121 - Neues Login-Konzept

        if (Session["loginName"] == null)
            Session.Add("loginName", "Gast");
        if (Session["loginAccount"] == null)
            Session.Add("loginAccount", "gast");
        if (Session["loginRole"] == null)
            Session.Add("loginRole", "Gast");
        // Ende #4121

        //BA1 500373 - Clear Sessions bei jeden login
        //Session.Clear();
        //BA1 500373 - falls default.htm login aufruft, dann zurück zum default.htm (damit man sich nicht 2 mal anmelden muss)
        if (Request.QueryString["ReturnURL"] != null)
        {
            var request = Request.QueryString["ReturnURL"].ToString().ToLower();
            if (request.EndsWith("default.htm") || request.EndsWith("tapmontage") || request.EndsWith("tapmontage/"))
                FormsAuthentication.RedirectFromLoginPage(txtLogin.Text, false);
        }

    }

    private string DecryptPWD(string strIn)
    {
        int i, byCC, byLC = 0x7f;
        int[] j = new int[16];
        string strOut = "                                   ";

        if (strIn.Length < 1) return "";

        for (i = 0; i < 16; i++)
        {
            try
            {
                j[i] = Convert.ToInt32(String.Concat("0x", strIn.Substring(2 * (i ^ 9), 2)), 16);
            }
            catch
            {
                return "";
            }
        }
        for (i = 0; i < 16; i++)
        {
            byCC = j[i];
            byLC = Convert.ToByte(j[i] ^ byLC ^ i);
            strOut = strOut.Remove(i ^ 3, 1).Insert(i ^ 3, Convert.ToChar(byLC).ToString());
        }

        i = Convert.ToInt32(String.Concat("0x", strOut[0]), 16);
        return strOut.Substring(1, i);
    }


    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Bearb = new dbBearbeiter(txtLogin.Text);
        bool bauthenticated = false;
        //BAN 500060 +  BAN 500063 beginn
        //eeserv Kennung kommt durch ww300 nicht ... daher wird lokales pwd abgefragt 
        string decrypted = "";
        string localPwd = ConfigurationManager.AppSettings["UseLocalPWD"] != null ? ConfigurationManager.AppSettings["UseLocalPWD"] : ""; //BAN 500060 B&I CarveOut - Umstellung auf Lokale Anmeldung
        string localPwdUser = ConfigurationManager.AppSettings["UserUsedLocalPWD"] != null ? ConfigurationManager.AppSettings["UserUsedLocalPWD"] : ""; //BAN 500060 B&I CarveOut - Umstellung auf Lokale Anmeldung
        string wrongTries = ConfigurationManager.AppSettings["LocalUserWrongTries"] != null ? ConfigurationManager.AppSettings["UserUsedLocalPWD"] : "0"; //BAN 500063 B&I CarveOut - Umstellung auf Lokale Anmeldung - wird aber nicht freigeschaltet
        string PwdValid = ConfigurationManager.AppSettings["LocalUserPwdValid"] != null ? ConfigurationManager.AppSettings["UserUsedLocalPWD"] : "0"; //BAN 500063 B&I CarveOut - Umstellung auf Lokale Anmeldung - wird aber nicht Freigeschaltet
        int FM = 0;

        bool localUser = Bearb.Params.MANDANT.Value != DBNull.Value && (localPwd.Contains(Bearb.Params.MANDANT.Value.ToString()) || localPwdUser.Contains(Bearb.Params.PERSKEY.Value.ToString())) ? true : false;
        bool testApp = (ConfigurationManager.AppSettings["TestApp"] != null);

        if (!testApp)
        {
            if (localUser)
            {
                //Ist User schon in LOCAL_USER Table
                bool insert = true;
                DateTime datKwort = DateTime.Now;
                int wrongtries = 0;
                // using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
                using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        using (SqlCommand cmd = new SqlCommand("SELECT KWORT, DATKWORT, WRONGTRIES FROM LOCAL_USER " + Config.Nolock + " WHERE PERSKEY = " + Bearb.Params.PERSKEY.Value.ToString(), cnx))
                        {
                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                while (rd.Read())
                                {
                                    decrypted = DecryptPWD(rd.GetString(0));
                                    datKwort = rd.GetDateTime(1);
                                    wrongtries = rd.GetInt32(2);
                                    insert = false;
                                }
                                rd.Close();
                            }
                        }
                        if (insert) //user nicht in LOCAL_USER
                        {
                            string kwort = (Bearb.Params.KWORT.Value != DBNull.Value) ? Bearb.Params.KWORT.Value.ToString() : "084F0A090C0B0E0D0011590007561200";
                            string sCmd = "INSERT INTO LOCAL_USER " + Config.Rowlock + " ( PERSKEY, KWORT ) VALUES ( " + Bearb.Params.PERSKEY.Value.ToString() + ", '" + kwort + "')";
                            using (SqlCommand cmd = new SqlCommand(sCmd, cnx))
                            {
                                cmd.ExecuteNonQuery();
                                decrypted = DecryptPWD(kwort);
                            }
                        }
                        bool weiter = true;
                        //PwdValid = "3";
                        //datKwort = datKwort.AddMonths(-3);
                        if (Convert.ToInt32(PwdValid) > 0 && DateTime.Now > datKwort.AddMonths(Convert.ToInt32(PwdValid)))
                        {
                            //Passwort abgelaufen .. ist aber nicht scharf
                            FM = 1;
                            weiter = false;
                        }
                        if (weiter && Convert.ToInt32(wrongTries) > 0 && wrongtries > Convert.ToInt32(wrongTries))
                        {
                            //zu viele Fehlversuche ... ist aber nicht scharf
                            FM = 2;
                            weiter = false;
                        }
                        if (weiter && decrypted.Equals(txtPasswort.Text) && decrypted.Length > 0)
                        {
                            bauthenticated = true;
                            if (Convert.ToInt32(PwdValid) > 0 && DateTime.Now > datKwort.AddMonths(Convert.ToInt32(PwdValid)).AddDays(-10))
                            {
                                //Passwort abgelaufen .. ist aber nicht scharf
                                FM = 4;
                            }
                            if (wrongtries > 0)
                            {
                                try
                                {
                                    using (SqlCommand cmd = new SqlCommand("UPDATE LOCAL_USER " + Config.Rowlock +
                                        " SET WRONGTRIES = 0 WHERE PERSKEY = " + Bearb.Params.PERSKEY.Value.ToString(), cnx))
                                    {
                                        cmd.ExecuteNonQuery();
                                    }

                                }
                                catch
                                { }
                            }
                        }
                        else
                        {
                            if (Convert.ToInt32(Bearb.Params.PERSKEY.Value) > 0)
                                using (SqlCommand cmd = new SqlCommand("UPDATE LOCAL_USER " + Config.Rowlock +
                                    " SET WRONGTRIES = WRONGTRIES + 1 WHERE PERSKEY = " + Bearb.Params.PERSKEY.Value.ToString(), cnx))
                                {
                                    cmd.ExecuteNonQuery();
                                }
                        }
                    }
                    catch
                    { }
                    finally { cnx.Close(); }
                }
            }
            else
                bauthenticated = AuthenticateWW300(txtLogin.Text, txtPasswort.Text);
        }
        //BAN 500060 +  500063 Ende

        ////GN 19.01.2006
        ////Defect 4358 obwohl in der DB nicht als USer eingetragen Aufruf der Absenzen mögl
        ////Der in der Sissi eingetragene Bearbeiter muss einem Mandanten zugeordnet sein, der auch in der Web.config im Schlüssel Mandanten enthalten ist

        ////Änderung start
        //string erlaubteMandanten = ConfigurationManager.AppSettings["Mandanten"];
        //if (!erlaubteMandanten.Contains(Bearb.Params.MANDANT.Value.ToString()) ||
        //     Bearb.Params.MANDANT.Value.Equals(""))
        //{
        //  this.lblError.Text = "Anmeldung fehlgeschlagen, User ist keinem der folgenden Mandanten zugeordnet(" +
        //                       erlaubteMandanten+")"; // Defect 5617
        //  return;
        //}
        ////Änderung Ende

        if ((bauthenticated & ((int)Bearb.Params.PERSKEY.Value > 0)) | (testApp & ((bauthenticated | ((int)Bearb.Params.PERSKEY.Value > 0)))))
        {
            // Beginn Defect 5617
            // Abfrage auf Mandanten erfolgt nach erfolgreicher Authentifizierung
            //GN 19.01.2006
            //Defect 4358 obwohl in der DB nicht als USer eingetragen Aufruf der Absenzen mögl
            //Der in der Sissi eingetragene Bearbeiter muss einem Mandanten zugeordnet sein, der auch in der Web.config im Schlüssel Mandanten enthalten ist

            string erlaubteMandanten = ConfigurationManager.AppSettings["Mandanten"];
            if (!erlaubteMandanten.Contains(Bearb.Params.MANDANT.Value.ToString()) ||
                 Bearb.Params.MANDANT.Value.Equals(""))
            {
                this.lblError.Text = "Anmeldung fehlgeschlagen, " + "<br />" +
                                     "User ist keinem der folgenden Mandanten zugeordnet " + "<br />" +
                                     "(" + erlaubteMandanten + ")"; // Defect 5617
                return;
            }
            // Ende Defect 5617

            //BAN 500060 beginn
            //inaktiver user werden abgewiesen
            int status = 0;
            try
            {
                status = Convert.ToInt32(Bearb.Params.STATUS.Value);
            }
            catch { }

            if (status != 20)
            {
                this.lblError.Text = "Anmeldung fehlgeschlagen, " + "<br />" +
                                     "User ist nicht (mehr) berechtigt TAP Montage zu verwenden";
                return;
            }
            //BAN 500060 Ende

            Session["Bearbeiter"] = Bearb;

            //BAN 500059 Beginn
            if (ConfigurationManager.AppSettings["UseNewHRInterface"] != null &&
                ConfigurationManager.AppSettings["UseNewHRInterface"].Contains(Bearb.Params.MANDANT.Value.ToString()))
                Session["UseNewHRInterface"] = true;
            else
                Session["UseNewHRInterface"] = false;
            //BAN 500059 Ende
            if (Request.QueryString["ReturnURL"] != null)
            {
                FormsAuthentication.RedirectFromLoginPage(txtLogin.Text, false);
            }
            else
            {
                FormsAuthentication.SetAuthCookie(txtLogin.Text, false);
                pnlLogin.Visible = false;
                pnlWelcome.Visible = true;
                // Beginn #4021 - Ausgabe von Kurzmeldungen am Login Bildschirm
                pnlMessage.Visible = true;
                // Ende #4021
            }

            // Beginn #4121 - Neues Login-Konzept
            try
            {
                //Benutzer-rolle(n) definieren bei "atw- Kennung" (BELOGIN),
                //Session-Variable (loginName, loginAccount, loginRole) einstellen:

                SISSITableAdapters.KAUFMANNTableAdapter taKaufmann = new SISSITableAdapters.KAUFMANNTableAdapter();
                SISSI.KAUFMANNDataTable dtKaufmann = taKaufmann.GetDataByBELOGIN(txtLogin.Text);
                SISSI.KAUFMANNRow rowKaufmann = (SISSI.KAUFMANNRow)dtKaufmann.Rows[0];

                SISSITableAdapters.GENEHMIGERTableAdapter taGenehmiger = new SISSITableAdapters.GENEHMIGERTableAdapter();
                SISSI.GENEHMIGERDataTable dtGenehmiger = taGenehmiger.GetDataByBELOGIN(txtLogin.Text);

                SISSITableAdapters.ERFASSERTableAdapter taErfasser = new SISSITableAdapters.ERFASSERTableAdapter();
                SISSI.ERFASSERDataTable dtErfasser = taErfasser.GetDataByBELOGIN(txtLogin.Text);

                Session["loginName"] = String.Format("{0} {1}", rowKaufmann.VORNAME, rowKaufmann.NACHNAME);
                Session["loginAccount"] = txtLogin.Text;

                Session["loginRole"] = "";
                bool mehrAlsEineRolle = false;

                try
                {
                    if (rowKaufmann.TECHGRP == "K")
                    {
                        Session["loginRole"] += "Kaufmann";         /* (Prio 1 Rolle) */
                        mehrAlsEineRolle = true;
                    }
                }
                catch { Session["loginRole"] = ""; }

                try
                {
                    SISSI.GENEHMIGERRow rowGenehmiger = (SISSI.GENEHMIGERRow)dtGenehmiger.Rows[0];
                    if (rowGenehmiger.MITARB_COUNT > 0)
                    {
                        if (mehrAlsEineRolle)
                            Session["loginRole"] += ", ";
                        Session["loginRole"] += "Genehmiger";       /* (Prio 2 Rolle) */
                        mehrAlsEineRolle = true;
                    }
                }
                catch { Session["loginRole"] += ""; }

                try
                {
                    SISSI.ERFASSERRow rowErfasser = (SISSI.ERFASSERRow)dtErfasser.Rows[0];
                    if ((dtErfasser.Rows.Count > 0) && (rowErfasser.PROJECT_COUNT > 0))
                    {
                        if (mehrAlsEineRolle)
                            Session["loginRole"] += ", ";
                        Session["loginRole"] += "Erfasser";         /* (Prio 3 Rolle) */
                    }
                }
                catch { Session["loginRole"] += ""; }

                lbName.Text = String.Format("{0} ({1})", Session["loginName"].ToString(), Session["loginAccount"].ToString());
                lbRole.Text = Session["loginRole"].ToString();

                //TAPM-22 - Anzeigen wenn geänderten EB vorhanden sind
                lblGeaenderteEB.Text = "";
                try
                {
                    if (lbRole.Text.Contains("Erfasser"))
                    {
                        dbMeldungen meldungen = new dbMeldungen();
                        meldungen.deleteOldMessages(testApp);
                        lblGeaenderteEB.Text = meldungen.getAnzahlGeaenderteEB(Session["loginAccount"].ToString());
                    }
                }
                catch { lblGeaenderteEB.Text = ""; }
                if (FM == 4)
                {
                    lblGeaenderteEB.Text += "<br /> Ihr Passwort laüft in weniger als 10 Tage ab !!! ";
                }
            }
            catch
            {
                //Wenn Es gibt ein Exception, default Werte werden eingestellt:

                Session["loginName"] = "Fehler";
                Session["loginAccount"] = "fehler";
                Session["loginRole"] = "Fehler";

                string fehlerMeldung = "<font color=\"#FF0000\"><i>Benutzerinformation nicht erreichbar!</i></font>";
                lbName.Text = fehlerMeldung;
                lbRole.Text = fehlerMeldung;
            }
            // Ende #4121
        }
        // Beginn Defect 5617
        // Fehlermeldung bei falscher Anmeldung
        else
        {
            switch (FM)
            {
                case 0:
                    this.lblError.Text = "Anmeldung fehlgeschlagen, " + "<br />" +
                                 "Username oder Passwort wurde falsch eingegeben!";
                    break;
                case 1:
                    this.lblError.Text = "Anmeldung fehlgeschlagen, " + "<br />" +
                                 "Passwort abgelaufen!";
                    break;
                case 2:
                    this.lblError.Text = "Anmeldung fehlgeschlagen, " + "<br />" +
                                 "Zu viele Fehlversuche!";
                    break;
                default:
                    break;
            }
        }
        // Ende Defect 5617
    }

    // Defect 5617, Code wird nicht verwendet
    //protected void XXXbtnLogin_Click(object sender, EventArgs e)
    //{
    //    TapWebDAC DAC = (TapWebDAC)Page.Cache["WEBDAC"];
    //    SqlDataReader DR = null;
    //    if (DAC.SQLSelectResult("select perskey, nachname, vorname from bearbeit where belogin='" + txtLogin.Text + "'", ref DR) == true)
    //    {
    //        Request.Cookies.Remove("PersKey_Login");
    //        Request.Cookies.Remove("PersKey_Data");
    //        Request.Cookies.Remove("PersKey_MA");
    //        DR.Read();

    //        Response.Cookies.Add(new HttpCookie("PersKey_Login", DR[0].ToString()));
    //        Response.Cookies.Add(new HttpCookie("PersKey_Data", DR[0].ToString()));
    //        Response.Cookies.Add(new HttpCookie("PersKey_MA", DR[0].ToString()));

    //        HttpCookie Cook = new HttpCookie("LastLogin");
    //        Cook.Value = txtLogin.Text;
    //        Cook.Expires = DateTime.Now.AddDays(10);
    //        Response.Cookies.Add(Cook);
    //        pnlLogin.Visible = false;
    //        pnlWelcome.Visible = true;

    //    }
    //    else
    //    {
    //        Request.Cookies.Remove("PersKey_Login");
    //        Request.Cookies.Remove("PersKey_Data");
    //        DAC.PerskeyLogin = 0;
    //        DAC.PerskeyVertretener = 0;
    //    }

    //}

    private bool AuthenticateWW300(string Username, string Password)
    {
        // specify Username and Password in connection in web.config prior to using this statement
        // CG: defect# 4004
        // Konstanter Benutzer (siehe web.config, key DomainWW300Provider) f. Authentifizierung 
        // ausgeschaltet und wird nicht mehr benötigt 
        // MembershipProvider domainWW300 = Membership.Providers["DomainWW300Provider"];
        // return (domainWW300.ValidateUser(Username, Password));

        // ESt Beg
        // return IstBenutzerAuthentifiziert(Username, Password, ConfigurationManager.ConnectionStrings["DomainWW300"].ConnectionString);
        if (ConfigurationManager.ConnectionStrings["DomainName"] != null && ConfigurationManager.AppSettings["DomainName"] != null &&
           IstBenutzerAuthentifiziert(Username, Password, ConfigurationManager.ConnectionStrings["DomainName"].ConnectionString, ConfigurationManager.AppSettings["DomainName"]))
            return true;
        else
        {
            if (ConfigurationManager.ConnectionStrings["DomainWW300"] != null && ConfigurationManager.AppSettings["DomainWW300"] != null &&
               IstBenutzerAuthentifiziert(Username, Password, ConfigurationManager.ConnectionStrings["DomainWW300"].ConnectionString, ConfigurationManager.AppSettings["DomainWW300"]))
                return true;
            else
                return false;
        }
        // ESt End
    }

    private bool IstBenutzerAuthentifiziert(string txtLogin, string txtpwd, string adsPath, string adsName)
    {
        //Response.Write(DateTime.Now + ": " + adsPath + "; " + adsName + "; " + txtLogin + "<br>");
        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "IstBenutzerAuthentifiziert:" + adsPath + "; " + adsName + "; " + txtLogin, null);

        try
        {
            string txtDomainLDAP = adsPath;
            string txtDomainnam = adsName;
            string VollstaendigerBenutzerName = txtDomainnam + "\\" + txtLogin;
            bool RetValSet = false;
            DirectoryEntry Eintrag = new DirectoryEntry(txtDomainLDAP, VollstaendigerBenutzerName, txtpwd);
            try
            {
                Object Objekt = Eintrag.NativeObject;
                DirectorySearcher Suche = new DirectorySearcher(Eintrag);
                Suche.Filter = "(SAMAccountName=" + txtLogin + ")";
                Suche.PropertiesToLoad.Add("cn");
                SearchResult SucheErgebnis = Suche.FindOne();
                string Path = SucheErgebnis.Path;
                if (SucheErgebnis != null)
                {
                    return true;
                }
                else
                {
                    RetValSet = true;
                    //Response.Write(DateTime.Now + ": Benutzer nicht erfolgreich authentifiziert! Bitte überprüfen Ihre Eingabe: Benutzer/Passwort" + "<br>");
                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "IstBenutzerAuthentifiziert: Benutzer nicht erfolgreich authentifiziert (" + txtDomainLDAP + ")! Bitte überprüfen Ihre Eingabe: Benutzer/Passwort", null);
                    throw new Exception("Benutzer nicht erfolgreich authentifiziert! Bitte überprüfen Ihre Eingabe: Benutzer/Passwort");
                }
            }
            catch (Exception Exc)
            {
                if (RetValSet == false)
                {
                    //Response.Write(DateTime.Now + ": Fehler während der Benutzerauthentifizierung: " + Exc.Message + "<br>");
                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "IstBenutzerAuthentifiziert: Fehler während der Benutzerauthentifizierung: " + Exc.Message, null);
                    throw new Exception("Fehler während der Benutzerauthentifizierung: " + Exc.Message);
                }
                return false;
            }
        }
        catch
        {
        }
        return false;
    }
}