﻿//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : Projekt.aspx.cs
//
// Description  : Erstellen und definieren des Projekts
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 05.September 2007
// Author       : Adam Kiefer
// Defect#      : 4780
//                Abgrenzen von Aufträgen
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;

public partial class _Projekt : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    dbProjekt Projekt;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Projekt suchen / bearbeiten</span>";
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        DDLProjekt.SelIndexChanged = ProjektSelectChange;
        DDLKtObj.SelIndexChanged = ProjektSelectChange;
        Filter.TextBoxChangedDelegee = FilterChanged;
        FilterKtoBj.TextBoxChangedDelegee = FilterKOChanged;
        ProjektDetail.SaveClicked = SaveClicked;
        ProjektDetail.CancelClicked = CancelClicked;
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["Restore"] != null)
            {
                Projekt = (dbProjekt)Session["Projekt"];
                panName.Enabled = false;
                DDLProjekt.DDLSelectedValue = Projekt.Params.PROJID.Value.ToString();
                ProjektDetail.ProjektID = (int)Projekt.Params.PROJID.Value;
            }
            else
            {
                Projekt = new dbProjekt(null);
                Session["Projekt"] = Projekt;
            }
            ProjektDetail.Enabled = (Request.QueryString["Restore"] != null);
        }
        else
            Projekt = (dbProjekt)Session["Projekt"];
        BtnBearbeiten.Visible = Bearbeiter.BearbInRole.IstKaufmann;
        BtnCopy.Visible = Bearbeiter.BearbInRole.IstKaufmann;
    }

    public void ProjektSelectChange(object sender, EventArgs e)
    {
        Projekt = new dbProjekt(null);
        Projekt.Params.PROJID.Value = Convert.ToInt32((sender as DropDownList).SelectedValue);
        Projekt.Select();
        Session["Projekt"] = Projekt;
        ProjektDetail.ProjektID = (int)Projekt.Params.PROJID.Value;
        BtnBearbeiten.Enabled = ((int)Projekt.Params.PROJID.Value > 0);
        BtnCopy.Enabled = ((int)Projekt.Params.PROJID.Value > 0);
        // Beginn #4780 - Abgrenzen von Aufträgen
        ProjektDetail.KontierCheckPublic();
        // Ende #4780
    }

    public string FilterChanged(object sender, EventArgs e)
    {
        DDLProjekt.Filter = (sender as TextBox).Text;
        DDLProjekt.DDL.Focus();
        return (sender as TextBox).Text;
    }

    public string FilterKOChanged(object sender, EventArgs e)
    {
        DDLKtObj.Filter = (sender as TextBox).Text;
        DDLKtObj.DDL.Focus();
        return (sender as TextBox).Text;
    }

    protected void BtnBearbeiten_Click(object sender, EventArgs e)
    {
        BtnBearbeiten.Enabled = false;
        BtnCopy.Enabled = false;
        ProjektDetail.Enabled = true;
        panName.Enabled = false;
        panKO.Enabled = false;
    }

    public void CancelClicked()
    {
        BtnBearbeiten.Enabled = true;
        BtnCopy.Enabled = true;
        ProjektDetail.Enabled = false;
        ProjektDetail.SaveMode = true;
        panName.Enabled = true;
        panKO.Enabled = true;
    }

    public void SaveClicked()
    {
        BtnBearbeiten.Enabled = true;
        BtnCopy.Enabled = true;
        ProjektDetail.Enabled = false;
        ProjektDetail.SaveMode = true;
        panName.Enabled = true;
        panKO.Enabled = true;
        DDLProjekt.Filter = Filter.TextBoxText;

    }
    protected void BtnCopy_Click(object sender, EventArgs e)
    {
        BtnBearbeiten.Enabled = false;
        BtnCopy.Enabled = false;
        dbBaustelle b = new dbBaustelle(Bearbeiter);
        Projekt.AllowUpdate = false;
        Projekt.Baustelle = b;
        ProjektDetail.Enabled = true;
        panName.Enabled = false;
        panKO.Enabled = false;

    }
}
