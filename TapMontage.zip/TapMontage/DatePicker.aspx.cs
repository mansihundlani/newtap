﻿//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : DatePicker.aspx.cs
//
// Description  : DatePicker
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 30.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 5190, 5211
//                Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt löschen
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class DatePicker : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #5190, 5211 - Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt löschen
        if (Request.Params["selectedDate"] != null)
        {
            Calendar1.VisibleDate = Convert.ToDateTime(Request.Params["selectedDate"].ToString());
        }
        else
        {
            Calendar1.VisibleDate = DateTime.Now;
        } 
        // Ende #5190, 5211
    }

    protected void Page_Init()
    {

    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        List<string> l = new List<string>();
        string fields = Request.QueryString["backf"];

        while (fields.Contains("@"))
        {
            fields = fields.Substring(fields.IndexOf("@") + 1);
            if (fields.Contains("@"))
            {
                string field = fields.Substring(0, fields.IndexOf('@'));
                l.Add(field);
            }
            else
            {
                l.Add(fields);
            }
        }
        

        LiteralControl tmp = new LiteralControl();
        tmp.Text = "<script type=\"text/javascript\">";

        foreach (string s in l)
        {
            tmp.Text += "if(typeof window.opener." + s + " != 'undefined') {window.opener." + s + ".value = '" + Calendar1.SelectedDate.Date.ToShortDateString() + "';} ";
        }
        tmp.Text += "window.close();";
        tmp.Text += "</Script>";
        PlaceHolder1.Controls.Add(tmp);
    }
}
