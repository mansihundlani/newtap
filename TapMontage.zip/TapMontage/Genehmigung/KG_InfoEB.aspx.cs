//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_InfoEB.aspx.cs
//
// Description  : Kontrolle & Genehmigung - Anzeige Einsatzberichte
//
//=============== V1.2.0017 ===============================================
//
// Date         : 18.November 2013
// Author       : Joldic Dzevad
// Defect#      : TT 6654245
//                Bei @CENT soll decimal anstatt float verwendet werden
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2010
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//                
//=============== V1.0.0041 ===============================================
//
// Date         : 25.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6060
//                KFMBemerkungsfeld angedrucken
//
// Date         : 21.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6005
//                Reiseauslagen im EB �bersicht sind unvollst�ndig
//
// Date         : 19.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6014
//                Bemerkungsfeld wird mehrmals angedruckt
//
//=============== V1.0.0038 ===============================================
//
// Date         : 25.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : 5857
//                Anzeige der EB korrigiert (falsche Auftragsnummer abngezeigt)
//
//=============== V1.0.0037 ===============================================
//
// Date         : 25.Jaenner 2008
// Author       : Joldic Dzevad
// Defect#      : 5779
//                Anzeige der EB korrigiert
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
// Date         : 06.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5589
//                Benutzerdaten im Kopf nicht mehrmals versorgen
//
//=============== V1.0.0034 ===============================================
//
// Date         : 23.Oktober 2007
// Author       : Wolfgang Patrman
// Defect#      : 5569
//                Anzeige Benutzerdaten im Kopf, wird im IE mit angedruckt
//
// Date         : 04.September 2007
// Author       : Wolfgang Patrman
// Defect#      : 5393
//                Selektion der Reiseauslagen aus der Tabelle RAZeile,
//                da diese an SAP �bermittelt wird 
//
//=============== V1.0.0033 ===============================================
//
// Date         : 03.September 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0032 ===============================================
//
// Date         : 02.Agust 2007
// Author       : Adam Kiefer
// Defect#      : 5334
//                Falsche Summe Werten-  Seite: Anzeige - Einsatzberichte
//
//=============== V1.0.0027 ===============================================
//
// Date         : 07.Mai 2007
// Author       : Wolfgang Patrman
// Defect#      : 4822
//                Anzeige der historischen Einsatzberichte aus den
//                gespeicherten EB, Arbeitszeiten erstellen
//
//=============== V1.0.0024 ===============================================
//
// Date         : 17.April 2007
// Author       : Christian Lahofer
// Defect#      : 4728
//                Zus�tzliche Anzeige der Personalnummer im Seitenkopf
//
//=============== V1.0.0024 ===============================================
//
// Date         : 12.April 2007
// Author       : Wolfgang Patrman
// Defect#      : 4755
//                Daten der Einsatzberichte aus Datenbank auslesen
//
//=============== V1.0.0022 ===============================================
//
// Date         : 20.Februar 2007
// Author       : Wolfgang Patrman
// Defect#      : 4655
//                Neuerstellung Anzeige EB und RA
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Genehmigung_KG_InfoEB : System.Web.UI.Page
{
    string RAvorh;
    ArrayList Arbzeiten; // Liste der EB's des Berichtsmonats
    ArrayList RAAuslagen; // Liste der Reise Auslagen
    ArrayList AusZulagen; // Liste der Aus- und Zulagen
    ArrayList SEGLohnarten; // Liste der SEG-Lohnarten
    ArrayList EBBemerkungen; // Liste der EB Bemerkungen
    ArrayList KfmBemerkungen; // Liste der Kfm Bemerkungen
    dbKG_Monat KGMonat;

    protected void Page_Load(object sender, EventArgs e)
    {
        KGMonat = (dbKG_Monat)Session["KGMonat"];
        RAvorh = (string)Session["RAvorh"];

        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Anzeige - Einsatzberichte</span><br /><span style=\"font-size: 12px;\">";
            Session["headData"] += KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
            // Defect 5569, Mitarbeiterinformationen anzeigen
            lbHeadInfo.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString(); // defect 5589
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416
        // Beginn Defect # 4728: Zus�tzliche Anzeige der Personalnummer
        //Label2.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
        // Ende Defect # 4728
    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Liste der Arbeitszeiten, RA Auslagen
            phAZListe.Controls.Add(AZListe());

            // Defect 4755
            // Liste der SEG-Lohnarten aus der Web.config auslesen
            SEGLohnarten = SEGLohnartenListe();

            // Liste der Aus- und Zulagen
            phAusZu.Controls.Add(AusZulageListe());

            // Liste der SEG Zulagen
            phSEG.Controls.Add(SEGListe());

            // Bemerkungen
            phBemerkung.Controls.Add(BemerkungfuerGenehmiger());

            // KfM Bemerkungen
            phKfmBemerkung.Controls.Add(KfmBemerkungfuerGenehmiger());
        }

        if (RAvorh == "false")
        {
            BtnInfoRA.Enabled = false;
        };
    }

    private class tZeile
    {
        // Tageszeile
        public string Datum;
        public string NormStd;
        public string Ue50;
        public string Ue100;
        public string GK;
        public string Lohnart;
        public string AuftrNr;


        public tZeile(DateTime datum, string normstd, string ue50, string ue100, string gk, string lohnart, string auftrnr)
        {
            if (datum.Ticks != ParamVal.Date0.Ticks)
            {
                string[] wTag = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa." };
                Datum = wTag[(int)datum.DayOfWeek] + " " + datum.Day.ToString() + "." + datum.Month.ToString() + ".";
            }
            else
            {
                Datum = "";
            }

            NormStd = normstd;
            Ue50 = ue50;
            Ue100 = ue100;
            GK = gk;
            Lohnart = lohnart;
            AuftrNr = auftrnr;
        }
    }

    private class AZeile
    {
        // Reiseabrechnung Auslagenzeile
        public string Auslage = "";
        public string Anzahl = "";
        public string Betrag = "";

        public AZeile(string auslage, string anzahl, string betrag)
        {
            Auslage = auslage;
            Anzahl = anzahl;
            Betrag = betrag;
        }
    }

    private class RAAuslage
    {
        public string RAkztxt = "";
        public float Anzahl = 0;
        //TT 6654245 use decimal instead of float
        //public float Betrag = 0;
        public Decimal Betrag = 0;
        public DateTime Datum;

        public RAAuslage(string rakztxt, float anzahl, Decimal betrag, DateTime datum)
        {
            RAkztxt = rakztxt;
            Anzahl = anzahl;
            Betrag = betrag;
            Datum = datum;
        }
    }

    private class AusZulage
    {
        public string Lohnart = "";
        public string Lohnarttxt = "";
        public float Anzahl = 0;
        public string Ktobj = "";
        public string SEGPunkte = "";
        public string Basisstunde = "";

        public AusZulage(string lohnart, string lohnarttxt, float anzahl, string ktobj, string segpunkte, string basisstunde)
        {
            Lohnart = lohnart;
            Lohnarttxt = lohnarttxt;
            Anzahl = anzahl;
            Ktobj = ktobj;
            SEGPunkte = segpunkte;
            Basisstunde = basisstunde;
        }
    }

    private class Arbzeit
    {
        // Einsatzberichte inkl. Arbeitszeiten
        public int Ebid = 0;
        public int Normstd = 0;
        public DateTime Datum;
        public DateTime Beginn;
        public DateTime Ende;
        public int Stdabsenzid = 0;
        public string Stdabsenztxt = "";
        public int Uestd50 = 0;
        public int Uestd100 = 0;
        public int GKStd = 0;
        public string Leistart = "";
        public string Auftrnr = "";
        public string GKAuftrnr = "";

        public Arbzeit(int ebid, DateTime datum, int normstd, DateTime beginn, DateTime ende, int stdabsenzid, string stdabsenztxt, int uestd50, int uestd100, int gkstd, string leistart, string auftrnr, string gkauftrnr)
        {
            Ebid = ebid;
            Normstd = normstd;
            Datum = datum;
            Beginn = beginn;
            Ende = ende;
            Stdabsenzid = stdabsenzid;
            Stdabsenztxt = stdabsenztxt;
            Uestd50 = uestd50;
            Uestd100 = uestd100;
            GKStd = gkstd;
            Leistart = leistart;
            Auftrnr = auftrnr;
            GKAuftrnr = gkauftrnr;
        }
    }

    private class EBBemerkung
    {
        // EBBemerkungen
        public int Ebid = 0;
        public string Auftrnr = "";
        public string Ebhist = "";
        public string ProjktName = ""; //Defect 6014 - Projektname wird auch im Bemerkungliste geschrieben

        public EBBemerkung(int ebid, string auftrnr, string ebhist, string projektName)
        {
            Ebid = ebid;
            Auftrnr = auftrnr;
            Ebhist = ebhist;
            ProjktName = projektName;
        }
    }
    //Defect #6060 KfMBemerkung
    private class KfmBemerkung
    {
        // EBBemerkungen
        public int Ebid = 0;
        public string Auftrnr = "";
        public string Bemerkung = "";
        public string ProjktName = ""; //Defect 6014 - Projektname wird auch im Bemerkungliste geschrieben

        public KfmBemerkung(int ebid, string auftrnr, string bemerk, string projektName)
        {
            Ebid = ebid;
            Auftrnr = auftrnr;
            Bemerkung = bemerk;
            ProjktName = projektName;
        }
    }

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align)
    {
        TableCell c = new TableCell();
        Label l = new Label();
        l.Text = LabelText;
        l.Font.Bold = true;
        c.Controls.Add(l);
        c.CssClass = css;
        c.HorizontalAlign = align;
        r.Cells.Add(c);
        return r;
    }

    private Table AZListe()
    {
        //Defect #5779 bis Die Prozedur ist komplet neu geschrieben, der alter code 
        //ist auskommentiert in dem ersten und dritten Teil des #5779 Defects  
        //Begin Defect #5779 1. Teil
        //double SummeNormStd = 0;
        //double SummeGK = 0;
        //double Summe50 = 0;
        //double Summe100 = 0;
        //double SummeProdStd = 0;
        //Ende Defect #5779 1. Teil

        Table tab = new Table();
        tab.Width = Unit.Percentage(100);
        TableRow rh = new TableRow();
        string xss = "TabHeader";
        rh = AddNewCell(rh, "Datum", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "NormStd", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "50%", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "100%", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "davon GK ", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "LA", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "AuftragNr/Abs.", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Auslagen", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Anzahl", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Betrag", xss, HorizontalAlign.Center);

        rh.Cells[rh.Cells.Count - 1].ColumnSpan = 2;
        tab.Rows.Add(rh);
        /* 
       //Begin Defect #5779 2. Teil
       double summeNormStd = 0; // im Monat
       double summe50 = 0; // im Monat
       double summe100 = 0; // im Monat
       double summeGK = 0; // im Monat
       foreach (dbKG_Tag t in KGMonat.Tage)
       {
           double SummeNormStd = 0; // am Tag
           double SummeGK = 0; // am Tag
           double Summe50 = 0; // am Tag
           double Summe100 = 0; // am Tag           
           int nAzeit = 0;

           ArrayList tZeilen = new ArrayList();
           ArrayList tRAzeilen = new ArrayList();
           foreach (dbKG_EB e in t.EBerichte)
           {
               foreach (dbKG_RATag ra in e.ReiseAusl)
               {
                   tRAzeilen.Add(new AZeile(ra.Auslagenart, ra.Anzahl.ToString("N"), ra.Betrag.ToString("N")));
               }
               foreach (object obj in e.ArbZeit)
               {
                   if (obj is dbKG_AZTag)
                   {
                       dbKG_AZTag az = (dbKG_AZTag)obj;
                       SummeNormStd += az.NormStunden;
                       if (az.GK != 0)
                       {
                           SummeNormStd += az.GK - az.NormStunden - az.UE100 - az.UE50;
                       }
                       SummeGK += az.GK;
                       Summe50 += az.UE50;
                       Summe100 += az.UE100;
                       tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), az.UE50.ToString("N"), az.UE100.ToString("N"), az.GK.ToString("N"), az.Lohnart, az.Auftrag));
                       nAzeit++;
                   }
                   if (obj is dbKG_AZTagSTDAbsenz)
                   {
                       dbKG_AZTagSTDAbsenz az = (dbKG_AZTagSTDAbsenz)obj;
                       SummeNormStd += az.NormStunden;
                       switch (az.StdAbsID)
                       {
                           case "10":
                               SummeGK += az.NormStunden;
                               tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), "", "", az.NormStunden.ToString("N"), "", az.StdAbsTxt));
                               break;
                           case "90":
                               tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), "", "", "", "", az.StdAbsTxt));
                               break;
                           case "100":
                               SummeGK += az.NormStunden;
                               tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), "", "", az.NormStunden.ToString("N"), "", az.StdAbsTxt));
                               break;
                           case "110":
                           default:
                               SummeNormStd -= az.NormStunden;
                               tZeilen.Add(new tZeile(t.TagesDatum, "", "", "", "", "", az.StdAbsTxt));
                               break;
                       }
                       nAzeit++;
                   }
               }

           }
           summeNormStd += SummeNormStd;
           summe50 += Summe50;
           summe100 += Summe100;
           summeGK += SummeGK;
           if (tZeilen.Count == 0)
           {   //add 1 tZeile mit TagesDatum
               tZeilen.Add(new tZeile(t.TagesDatum, "", "", "", "", "", ""));
           }
           while (tRAzeilen.Count > tZeilen.Count)
           {
               tZeilen.Add(new tZeile(ParamVal.Date0, "", "", "", "", "", ""));
           }
           if (nAzeit > 1)
           {

               tZeilen.Add(new tZeile(ParamVal.Date0, SummeNormStd.ToString("N"), Summe50.ToString("N"), Summe100.ToString("N"), SummeGK.ToString("N"), "", ""));
               (tZeilen[tZeilen.Count - 1] as tZeile).Datum = "Summe";
           }
           while (tRAzeilen.Count < tZeilen.Count)
           {
               tRAzeilen.Add(new AZeile("", "", ""));
           }
           for (int i = 0; i < tZeilen.Count; i++)
           {
               tab.Rows.Add(AddOneNewRow((tZeile)tZeilen[i], (AZeile)tRAzeilen[i], i, t.TagesDatum));
           }
       }
       TableRow tr = new TableRow();
       tZeile tz = new tZeile(ParamVal.Date0,
           summeNormStd.ToString("N"),
           summe50.ToString("N"),
           summe100.ToString("N"),
           summeGK.ToString("N"),
           "= " + (summeNormStd + summe50 + summe100).ToString("N"),
           "");
       tz.Datum = "Summe";
       AZeile az2 = new AZeile("", "", "");
       tab.Rows.Add(AddOneNewRow(tz, az2, 0, DateTime.Now));
       return tab;
         */
        //Ende Defect #5779 2. Teil
        //Begin Defect #5779 3. Teil
        // Defect 4755
        // Defect #5857 Auslesen der gespeicherten Arbeitszeiten
        double summeNormStd = 0; // im Monat
        double summe50 = 0; // im Monat
        double summe100 = 0; // im Monat
        double summeGK = 0; // im Monat
        Arbzeiten = SelectArbzeiten(KGMonat.MinDatum);
        //Select alle Reise Auslagen aus dem KG Monat
        //Defect #6005 - RAuslagen werden pro EB ermittelt
        RAAuslagen = SelectRAAuslagen();//Defect #6005 - Alle RAuslagen f�r das Monat ermitteln //(e.Ebid, t.Tag);

        foreach (dbKG_Tag t in KGMonat.Tage)
        {
            int nAzeit = 0;
            double NormStdTag = 0;
            double GKStdTag = 0;
            double Uestd50Tag = 0;
            double Uestd100Tag = 0;
            ArrayList tZeilen = new ArrayList(); // Tageszeilen
            ArrayList tRAzeilen = new ArrayList(); // Reiseabrechnung Auslagenzeilen

            // bool RAfirst = true;
            foreach (RAAuslage raausl in RAAuslagen)
            {
                if (raausl.Datum.Day == t.Tag)
                {
                    tRAzeilen.Add(new AZeile(raausl.RAkztxt, raausl.Anzahl.ToString("N"), raausl.Betrag.ToString("N")));
                }
            }
            foreach (Arbzeit e in Arbzeiten)
            {
                //RAAuslagen = SelectRAAuslagen(e.Ebid, t.Tag);

                if (t.Tag == e.Datum.Day)
                {
                    /*Defect #6005 - RAuslagen werden pro EB ermittelt und nicht pro AZ
                    if (RAfirst)
                    {
                        foreach (RAAuslage raausl in RAAuslagen)
                        {
                            if (raausl.Datum.Day == t.Tag)
                            {
                                tRAzeilen.Add(new AZeile(raausl.RAkztxt, raausl.Anzahl.ToString("N"), raausl.Betrag.ToString("N")));
                            }
                        }
                        RAfirst = false;
                    }*/

                    if (e.Stdabsenzid == 0)
                    {
                        NormStdTag += e.Normstd;
                        if (e.GKAuftrnr == e.Auftrnr)
                        {
                            e.GKStd = e.Normstd + e.Uestd50 + e.Uestd100;
                        }
                        GKStdTag += e.GKStd;
                        Uestd50Tag += e.Uestd50;
                        Uestd100Tag += e.Uestd100;
                        tZeilen.Add(new tZeile(
                                                t.TagesDatum,
                                                (Convert.ToDouble(e.Normstd) / 60).ToString("N"),
                                                (Convert.ToDouble(e.Uestd50) / 60).ToString("N"),
                                                (Convert.ToDouble(e.Uestd100) / 60).ToString("N"),
                                                (Convert.ToDouble(e.GKStd) / 60).ToString("N"),
                                                e.Leistart,
                                                e.Auftrnr
                                              )
                                    );
                    }
                    else
                    {
                        switch (e.Stdabsenzid)
                        {
                            case 10:
                                NormStdTag += e.Normstd;
                                GKStdTag += e.Normstd;
                                tZeilen.Add(new tZeile(t.TagesDatum, (Convert.ToDouble(e.Normstd) / 60).ToString("N"), "", "", (Convert.ToDouble(e.Normstd) / 60).ToString("N"), "", e.Stdabsenztxt));
                                break;
                            case 90:
                                NormStdTag += e.Normstd;
                                tZeilen.Add(new tZeile(t.TagesDatum, (Convert.ToDouble(e.Normstd) / 60).ToString("N"), "", "", "", "", e.Stdabsenztxt));
                                break;
                            case 100:
                                NormStdTag += e.Normstd;
                                GKStdTag += e.Normstd;
                                tZeilen.Add(new tZeile(t.TagesDatum, (Convert.ToDouble(e.Normstd) / 60).ToString("N"), "", "", (Convert.ToDouble(e.Normstd) / 60).ToString("N"), "", e.Stdabsenztxt));
                                break;
                            case 120:
                                NormStdTag += e.Normstd;
                                tZeilen.Add(new tZeile(t.TagesDatum, (Convert.ToDouble(e.Normstd) / 60).ToString("N"), "", "", "", "", e.Stdabsenztxt));
                                break;
                            case 110: // ZA
                            default:
                                tZeilen.Add(new tZeile(t.TagesDatum, "", "", "", "", "", e.Stdabsenztxt));
                                break;
                        }

                    }
                    nAzeit++;
                }
            }
            summeNormStd += NormStdTag; // im Monat
            summe50 += Uestd50Tag; // im Monat
            summe100 += Uestd100Tag; // im Monat
            summeGK += GKStdTag; // im Monat
            if (tZeilen.Count == 0)
            {//add 1 tZeile mit TagesDatum
                tZeilen.Add(new tZeile(t.TagesDatum, "", "", "", "", "", ""));
            }
            while (tRAzeilen.Count > tZeilen.Count)
            {
                tZeilen.Add(new tZeile(ParamVal.Date0, "", "", "", "", "", ""));
            }
            if (nAzeit > 1)
            {
                tZeilen.Add(new tZeile(ParamVal.Date0, (Convert.ToDouble(NormStdTag) / 60).ToString("N"), (Convert.ToDouble(Uestd50Tag) / 60).ToString("N"), (Convert.ToDouble(Uestd100Tag) / 60).ToString("N"), (Convert.ToDouble(GKStdTag) / 60).ToString("N"), "", ""));
                (tZeilen[tZeilen.Count - 1] as tZeile).Datum = "Summe";
            }
            while (tRAzeilen.Count < tZeilen.Count)
            {
                tRAzeilen.Add(new AZeile("", "", ""));
            }
            for (int i = 0; i < tZeilen.Count; i++)
            {
                tab.Rows.Add(AddOneNewRow((tZeile)tZeilen[i], (AZeile)tRAzeilen[i], i, t.TagesDatum));
            }
        }
        TableRow tr = new TableRow();
        tZeile tz = new tZeile(ParamVal.Date0,
            (summeNormStd / 60).ToString("N"),
            (summe50 / 60).ToString("N"),
            (summe100 / 60).ToString("N"),
            (summeGK / 60).ToString("N"),
            "= " + ((summeNormStd + summe50 + summe100) / 60).ToString("N"),
            "");
        tz.Datum = "Summe";
        AZeile az2 = new AZeile("", "", "");
        //tab.Rows.Add(AddOneNewRow(tz, az2, 0, DateTime.Now));
        tab.Rows.Add(AddOneNewRow(tz, az2, 0, KGMonat.MaxDatum.Date));
        return tab;
        //Ende Defect #5857
    }

    ArrayList SelectRAAuslagen()//int ebid, int tag)
    {
        ArrayList ra = new ArrayList(); // Reiseabrechnung Auslagenzeilen

        // Selektion der RA Auslagen eines Einsatzberichtes
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();

                // Beginn Defect 5393
                //SqlCommand cmd = new SqlCommand("SELECT y.rakztxt, ra.anzahl, ra.betrag, ra.datum " +
                //                                "FROM raauslage ra, y_rakz y " +
                //                                "WHERE ebid = " + ebid + " " +
                //                                "AND y.rakz = ra.rakz " +
                //                                "ORDER BY ra.datum, ra.raauslageid ASC", cnx);
                // Die Selektion der Reiseauslagen erfolgt aus der Tabelle RAZeile,
                // da diese an SAP �bermittelt wird

                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                /*using (SqlCommand cmd = new SqlCommand("SELECT y.rakztxt, ra.anznaechte, ra.betrag, ra.dat " +
                                                         " FROM razeile ra " + Config.Nolock + ", y_rakz y " + Config.Nolock +
                                                         " WHERE ebid = " + ebid + " " +
                                                         " AND y.rakz = ra.auslart " +
                                                         " ORDER BY ra.dat, ra.raid, ra.lfdnr ASC", cnx)) // Defect 5436, using eingef�hrt */
                //Defect #6005 - DB pro EB aufrufen
                foreach (dbMontBer mber in KGMonat.Monteur.MBerichte)
                {
                    int ebid = (int)mber.Params.EBID.Value;
                    using (SqlCommand cmd = new SqlCommand("SELECT y.rakztxt, ra.anznaechte, ra.betrag, ra.dat " +
                                       " FROM razeile ra " + Config.Nolock + ", y_rakz y " + Config.Nolock +
                                       " WHERE ebid = " + ebid + " " +
                                       " AND y.rakz = ra.auslart " +
                                       " ORDER BY ra.dat, ra.raid, ra.lfdnr ASC", cnx)) // Defect 5436, using eingef�hrt
                    {
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            while (rd.Read())
                            {
                                ra.Add(new RAAuslage(rd.GetString(0), Convert.ToSingle(rd.GetValue(1)), Convert.ToDecimal(rd.GetValue(2)), rd.GetDateTime(3)));
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return ra;
    }

    ArrayList SelectArbzeiten(DateTime berdat)
    {
        ArrayList az = new ArrayList(); // Liste der Arbeitszeiten des Berichtsmonats

        // Selektion der RA Auslagen eines Einsatzberichtes
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("SELECT az.ebid, az.datum, az.normstd, az.beginn, az.ende, az.stdabsenzid, " +
                                                       "(SELECT ys.stdabsenztxt " +
                                                       " FROM   y_stdabsenz ys " + Config.Nolock +
                                                       " WHERE  ys.stdabsenzid = az.stdabsenzid) AS stdabsenztxt, " +
                                                       " az.uestd50, az.uestd100, az.leistart, az.auftrnr, " +
                                                       "(SELECT y.auftrnr" +
                                                       " FROM   y_auftrnrs y " + Config.Nolock + ", bearbeit b " + Config.Nolock +
                                                       " WHERE  b.perskey = az.perskey " +
                                                       " AND    y.mandant = b.mandant " +
                                                       " AND    y.auftrnr = az.auftrnr) AS gkauftrner " +
                                                       " FROM   arbzeit az " + Config.Nolock +
                                                       " WHERE  az.perskey = @PERSKEY " +
                                                       " AND DATEPART(YEAR, az.datum) = @YEAR " +
                                                       " AND DATEPART(MONTH, az.datum) = @MONTH " +
                                                       " AND az.kzaz IN ('A', 'E') " +
                                                       " ORDER BY az.beginn ASC ", cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", berdat.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", berdat.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            int lGKStd = 0;
                            string gkauftrnr = "";
                            string stdabsenztxt = "";
                            string leistArt = "";

                            if (!rd.IsDBNull(6))
                            {
                                stdabsenztxt = rd.GetString(6);
                            }

                            if (!rd.IsDBNull(11))
                            {
                                gkauftrnr = rd.GetString(11);
                            }

                            if (!rd.IsDBNull(9))
                            {
                                leistArt = rd.GetString(9);
                            }

                            az.Add(new Arbzeit(rd.GetInt32(0), rd.GetDateTime(1), rd.GetInt16(2), rd.GetDateTime(3), rd.GetDateTime(4), rd.GetInt16(5), stdabsenztxt, rd.GetInt16(7), rd.GetInt16(8), lGKStd, leistArt /* = rd.GetString(9)*/, rd.GetString(10), gkauftrnr));
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }

            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("SELECT k.ebid, k.datum, y.gtabsenztxt " +
                                                       " FROM   kaltag k " + Config.Nolock + ", y_gtabsenz y " + Config.Nolock +
                                                       " WHERE  k.perskey = @PERSKEY " +
                                                       " AND DATEPART(YEAR, k.datum) = @YEAR " +
                                                       " AND DATEPART(MONTH, k.datum) =  @MONTH " +
                                                       " AND k.gtabsenzid = y.gtabsenzid " +
                                                       " ORDER BY k.datum ASC ", cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", berdat.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", berdat.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            string gtabsenztxt = "";
                            int ebid = 0;

                            if (!rd.IsDBNull(0))
                            {
                                ebid = rd.GetInt32(0);
                            }

                            if (!rd.IsDBNull(2))
                            {
                                gtabsenztxt = rd.GetString(2);
                            }

                            az.Add(new Arbzeit(ebid, rd.GetDateTime(1), 0, rd.GetDateTime(1), rd.GetDateTime(1), 0, "", 0, 0, 0, "", gtabsenztxt, ""));
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return az;
    }

    TableRow AddOneNewRow(tZeile tz, AZeile az, int ind, DateTime Tag)
    {
        TableRow tr = new TableRow();

        if ((tz.Datum.ToUpper().IndexOf("SUM") >= 0)) ind = 0;
        string strCssClassRow = (ind > 0 ? "TabZeile" + CssWE(Tag) : "TabNewDay" + CssWE(Tag));
        TableCell d1 = new TableCell();
        if (ind == 0) d1.Text = tz.Datum;
        d1.HorizontalAlign = HorizontalAlign.Center;
        d1.CssClass = strCssClassRow;
        tr.Cells.Add(d1);

        TableCell d2 = new TableCell();
        d2.Text = (tz.NormStd == "0,00" ? "" : tz.NormStd);
        d2.HorizontalAlign = HorizontalAlign.Center;
        d2.CssClass = strCssClassRow;
        tr.Cells.Add(d2);

        TableCell d3 = new TableCell();
        d3.Text = (tz.Ue50 == "0,00" ? "" : tz.Ue50);
        d3.HorizontalAlign = HorizontalAlign.Center;
        d3.CssClass = strCssClassRow;
        tr.Cells.Add(d3);

        TableCell d4 = new TableCell();
        d4.Text = (tz.Ue100 == "0,00" ? "" : tz.Ue100);
        d4.HorizontalAlign = HorizontalAlign.Center;
        d4.CssClass = strCssClassRow;
        tr.Cells.Add(d4);

        TableCell d5 = new TableCell();
        d5.Text = (tz.GK == "0,00" ? "" : tz.GK);
        d5.HorizontalAlign = HorizontalAlign.Center;
        d5.CssClass = strCssClassRow;
        tr.Cells.Add(d5);

        TableCell d6 = new TableCell();
        d6.Text = tz.Lohnart;
        d6.HorizontalAlign = HorizontalAlign.Center;
        d6.CssClass = strCssClassRow;
        tr.Cells.Add(d6);

        TableCell d7 = new TableCell();
        d7.Text = tz.AuftrNr;
        d7.HorizontalAlign = HorizontalAlign.Center;
        d7.CssClass = strCssClassRow;
        tr.Cells.Add(d7);

        TableCell d8 = new TableCell();
        d8.HorizontalAlign = HorizontalAlign.Center;
        d8.CssClass = strCssClassRow;

        TableCell d9 = new TableCell();
        d9.HorizontalAlign = HorizontalAlign.Center;
        d9.CssClass = strCssClassRow;

        TableCell d10 = new TableCell();
        d10.HorizontalAlign = HorizontalAlign.Center;
        d10.CssClass = strCssClassRow;

        d8.Text = az.Auslage;
        d9.Text = az.Anzahl;
        d10.Text = az.Betrag;
        tr.Cells.Add(d8);
        tr.Cells.Add(d9);
        tr.Cells.Add(d10);

        tabAZListe.Rows.Add(tr);

        return tr;
    }

    protected void BtnPrev_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Genehmigung/KG_Info.aspx");
    }

    protected void BtnInfoRA_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Genehmigung/KG_InfoRA.aspx");
    }

    private string CssWE(DateTime Tag)
    {
        //BAF 530042 Beginn
        if (KGMonat.Monteur.AZMKalenderTage.ContainsKey(Tag))
        {
            if (KGMonat.Monteur.AZMKalenderTage[Tag].IstArbeitstag)
                return "";
            else
                return "WE";
        }//BAF 530042 Ende
        else
        {
            if (KGMonat.Monteur.IstArbeitstag(Tag))
                return "";
            else
                return "WE";
        }
    }

    private Table AusZulageListe()
    {
        TableRow HeaderRow = new TableRow();

        TableCell c1 = new TableCell();
        c1.Text = "Aus/Zulage";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Anzahl";
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        TableCell c3 = new TableCell();
        c3.Text = "AuftragNr";
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);

        tabAusZu.Rows.Add(HeaderRow);

        TableRow tr;

        // Defect 4755
        // Auslesen der gespeicherten Aus- und Zulagen
        AusZulagen = SelectAusZulagen();

        foreach (AusZulage az in AusZulagen)
        {
            bool found = false;

            foreach (string la in SEGLohnarten)
            {
                if (az.Lohnart == la)
                {
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                bool isAusZuRepeat = false;
                string oldANr = "";

                if (oldANr == az.Ktobj)
                {
                    isAusZuRepeat = true;
                }

                string strCssClassRow = (isAusZuRepeat ? "TabZeile" : "TabNewDay");
                tr = new TableRow();
                TableCell d1 = new TableCell();
                d1.Text = az.Lohnart + " " + az.Lohnarttxt;
                d1.HorizontalAlign = HorizontalAlign.Left;
                d1.CssClass = strCssClassRow;
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                d2.Text = (az.Anzahl == 0 ? "" : az.Anzahl.ToString("N"));
                d2.Width = 50;
                d2.HorizontalAlign = HorizontalAlign.Center;
                d2.CssClass = strCssClassRow;
                tr.Cells.Add(d2);

                TableCell d3 = new TableCell();
                if (isAusZuRepeat)
                {
                    d3.Text = "";
                }
                else
                {
                    d3.Text = az.Ktobj;
                }

                d3.CssClass = strCssClassRow;
                d3.HorizontalAlign = HorizontalAlign.Center;
                tr.Cells.Add(d3);

                oldANr = az.Ktobj;
                tabAusZu.Rows.Add(tr);
            }
        }
        return tabAusZu;
    }

    ArrayList SelectEBBemerkungen()
    {
        ArrayList bemerk = new ArrayList(); // Liste der EB Bemerkungen

        // Selektion der Bemerkungen zu den EB's
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                /*using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT e.ebid, az.auftrnr, SUBSTRING(e.ebhist, 1, 500) AS ebhist " +
                                                       " FROM   einsber e " + Config.Nolock + ", arbzeit az " + Config.Nolock +
                                                       " WHERE  e.perskey = @PERSKEY " +
                                                       " AND    datepart(YEAR, e.bermon) = @YEAR " +
                                                       " AND    datepart(MONTH, e.bermon) = @MONTH " +
                                                       " AND    e.ebid = az.ebid ", cnx)) // Defect 5436*/
                // Defect #6014 - Projektname auch auslesen 
                using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT e.ebid, az.auftrnr, SUBSTRING(e.ebhist, 1, 500) AS ebhist, bp.name " +
                                                       "FROM einsber e " + Config.Nolock + ", arbzeit az " + Config.Nolock +
                                                       ", bauprojekt bp " + Config.Nolock +
                                                       " WHERE  e.perskey = @PERSKEY " +
                                                       "AND datepart(YEAR, e.bermon) = @YEAR " +
                                                       "AND datepart(MONTH, e.bermon) = @MONTH " +
                                                       "AND e.projid = bp.projid " +
                                                       "AND e.ebid = az.ebid ", cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", KGMonat.MinDatum.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", KGMonat.MinDatum.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            //Defect #6014 doppelten Eintr�ge verhindern
                            bool exist = false;
                            foreach (EBBemerkung e in bemerk)
                            {
                                if (e.ProjktName == rd.GetString(3))
                                {
                                    if (!e.Auftrnr.Contains(rd.GetString(1)))
                                        e.Auftrnr += " / " + rd.GetString(1);
                                    exist = true;
                                    break;
                                }
                            }
                            if (!exist)
                            {
                                bemerk.Add(new EBBemerkung(rd.GetInt32(0), rd.GetString(1), rd.GetString(2), rd.GetString(3)));
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return bemerk;
    }
    ArrayList SelectKfmBemerkungen()
    {
        ArrayList bemerk = new ArrayList(); // Liste der EB Bemerkungen

        // Selektion der Bemerkungen zu den EB's
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                /*using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT e.ebid, az.auftrnr, SUBSTRING(e.ebhist, 1, 500) AS ebhist " +
                                                       " FROM   einsber e " + Config.Nolock + ", arbzeit az " + Config.Nolock +
                                                       " WHERE  e.perskey = @PERSKEY " +
                                                       " AND    datepart(YEAR, e.bermon) = @YEAR " +
                                                       " AND    datepart(MONTH, e.bermon) = @MONTH " +
                                                       " AND    e.ebid = az.ebid ", cnx)) // Defect 5436*/
                // Defect #6014 - Projektname auch auslesen 
                using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT e.ebid, az.auftrnr, SUBSTRING(e.kfmbemerkung, 1, 255) AS kfmbemerkung, bp.name " +
                                                       "FROM einsber e " + Config.Nolock + ", arbzeit az " + Config.Nolock +
                                                       ", bauprojekt bp " + Config.Nolock +
                                                       " WHERE e.perskey = @PERSKEY " +
                                                       " AND datepart(YEAR, e.bermon) = @YEAR " +
                                                       " AND datepart(MONTH, e.bermon) = @MONTH " +
                                                       " AND e.projid = bp.projid " +
                                                       " AND e.ebid = az.ebid ", cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", KGMonat.MinDatum.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", KGMonat.MinDatum.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            //Defect #6014 doppelten Eintr�ge verfindern
                            bool exist = false;
                            foreach (KfmBemerkung e in bemerk)
                            {
                                if (e.ProjktName == rd.GetString(3))
                                {
                                    if (!e.Auftrnr.Contains(rd.GetString(1)))
                                        e.Auftrnr += " / " + rd.GetString(1);
                                    exist = true;
                                    break;
                                }
                            }
                            if (!exist)
                            {
                                bemerk.Add(new KfmBemerkung(rd.GetInt32(0), rd.GetString(1), rd.GetString(2), rd.GetString(3)));
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return bemerk;
    }

    ArrayList SelectAusZulagen()
    {
        DateTime berdat;
        berdat = KGMonat.MinDatum;

        ArrayList auszu = new ArrayList(); // Liste der Aus- und Zulagen

        // Selektion der Aus- und Zulagen
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                /*using (SqlCommand cmd = new SqlCommand("SELECT y.lohnart, y.lohnarttxt, z.anzahl, b.ktobj " +
                                                       " FROM   zulage z " + Config.Nolock + ", einsber e " + Config.Nolock + ", y_lohnart2 y " + Config.Nolock + ", bauprojekt b " + Config.Nolock +
                                                       " WHERE  e.perskey = @PERSKEY " +
                                                       " AND    z.ebid = e.ebid " +
                                                       " AND    z.lohnart = y.lohnart " +
                                                       " AND    b.projid = e.projid " +
                                                       " AND    e.bermon = @BERMON ", cnx)) // Defect 5436 */
                using (SqlCommand cmd = new SqlCommand("SELECT Y_LOHNART3.LOHNART, Y_LOHNART3.LOHNARTTXT, ZULAGE.ANZAHL, BAUPROJEKT.KTOBJ " +
                                                    " FROM Y_LOHNART3 " + Config.Nolock + " INNER JOIN " +
                                                    " ZULAGE " + Config.Nolock + " ON Y_LOHNART3.LOHNART = ZULAGE.LOHNART INNER JOIN " +
                                                    " EINSBER " + Config.Nolock + " ON Y_LOHNART3.MANDANT = EINSBER.MANDANT AND ZULAGE.EBID = EINSBER.EBID INNER JOIN " + 
                                                    " BAUPROJEKT " + Config.Nolock + " ON EINSBER.PROJID = BAUPROJEKT.PROJID " +
                                                    " WHERE (LEFT(Y_LOHNART3.LOHNARTTXT, 3) <> 'SEG') AND (EINSBER.PERSKEY = @PERSKEY) AND (EINSBER.BERMON = @BERMON) " + 
                                                    " UNION " + 
                                                    " SELECT Y_LOHNART3.LOHNART, Y_LOHNART3.LOHNARTTXT, AUSLAGE.ANZAHL, BAUPROJEKT.KTOBJ " +
                                                    " FROM Y_LOHNART3 " + Config.Nolock + " INNER JOIN " +
                                                    " AUSLAGE " + Config.Nolock + " ON Y_LOHNART3.LOHNART = AUSLAGE.LOHNART INNER JOIN " +
                                                    " EINSBER " + Config.Nolock + " ON Y_LOHNART3.MANDANT = EINSBER.MANDANT AND AUSLAGE.EBID = EINSBER.EBID INNER JOIN " + 
                                                    " BAUPROJEKT " + Config.Nolock + " ON EINSBER.PROJID = BAUPROJEKT.PROJID " +
                                                    " WHERE (LEFT(Y_LOHNART3.LOHNARTTXT, 3) <> 'SEG') AND (EINSBER.PERSKEY = @PERSKEY) AND (EINSBER.BERMON = @BERMON)", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@BERMON", berdat));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            auszu.Add(new AusZulage(rd.GetString(0), rd.GetString(1), Convert.ToSingle(rd.GetValue(2)), rd.GetString(3), "", ""));
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }

            /* wird nicht mehr gebraucht, da bei select von zulagen, auch eine union mit der auslagen gemacht ist.
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("SELECT y.lohnart, y.lohnarttxt, a.anzahl, b.ktobj " +
                                                       " FROM   auslage a " + Config.Nolock + ", einsber e " + Config.Nolock + ", y_lohnart2 y " + Config.Nolock + ", bauprojekt b " + Config.Nolock +
                                                       " WHERE  e.perskey = @PERSKEY " +
                                                       " AND    a.ebid = e.ebid " +
                                                       " AND    a.lohnart = y.lohnart " +
                                                       " AND    b.projid = e.projid " +
                                                       " AND    e.bermon = @BERMON ", cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@BERMON", berdat));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            auszu.Add(new AusZulage(rd.GetString(0), rd.GetString(1), Convert.ToSingle(rd.GetValue(2)), rd.GetString(3), "", ""));
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); } */
        }
        return auszu;
    }

    private ArrayList SEGLohnartenListe()
    {
        ArrayList al = new ArrayList();
        string strSEGLohnarten = "";
        strSEGLohnarten = ConfigurationManager.AppSettings["SEGLohnarten"].ToString();
        while (strSEGLohnarten.Length > 0)
        {
            al.Add(strSEGLohnarten.Substring(0, strSEGLohnarten.IndexOf(";")));
            strSEGLohnarten = strSEGLohnarten.Substring(strSEGLohnarten.IndexOf(";") + 1);
        }
        return al;
    }

    private Table SEGListe()
    {
        TableRow HeaderRow = new TableRow();

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "SEG %";
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        TableCell c3 = new TableCell();
        c3.Text = "SEG Punkte";
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;

        TableCell c4 = new TableCell();
        c4.Text = "Basis Std";
        c4.HorizontalAlign = HorizontalAlign.Center;
        c4.CssClass = "TabHeader";
        c4.Font.Bold = true;

        TableCell c5 = new TableCell();
        c5.Text = "SEG-Zulage";
        c5.HorizontalAlign = HorizontalAlign.Center;
        c5.CssClass = "TabHeader";
        c5.Font.Bold = true;

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c4);
        HeaderRow.Cells.Add(c5);

        tabSEG.Rows.Add(HeaderRow);

        TableRow tr;

        foreach (AusZulage az in AusZulagen)
        {
            bool found = false;

            // Schleife �ber die SEG Lohnarten
            foreach (string la in SEGLohnarten)
            {
                if (az.Lohnart == la)
                {
                    // SEG Lohnart gefunden, daher in Spalte SEG Zulagen darstellen
                    found = true;
                    break;
                }
            }

            if (found)
            {
                tr = new TableRow();
                TableCell d1 = new TableCell();
                d1.Text = az.Ktobj;
                d1.HorizontalAlign = HorizontalAlign.Center;
                d1.CssClass = "TabNewDay";
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                d2.Text = "100,00%";
                d2.HorizontalAlign = HorizontalAlign.Center;
                d2.CssClass = "TabNewDay";
                tr.Cells.Add(d2);

                TableCell d3 = new TableCell();
                d3.Text = (az.SEGPunkte == "0" ? "" : az.SEGPunkte);
                d3.CssClass = "TabNewDay";
                d3.HorizontalAlign = HorizontalAlign.Center;
                tr.Cells.Add(d3);

                TableCell d4 = new TableCell();
                d4.Text = (az.Basisstunde == "0,00" ? "" : az.Basisstunde);
                d4.HorizontalAlign = HorizontalAlign.Center;
                d4.CssClass = "TabNewDay";
                tr.Cells.Add(d4);

                TableCell d5 = new TableCell();

                d5.Text = "";
                if (az.Anzahl > 0)
                {
                    d5.Text = az.Anzahl.ToString("N");
                }

                d5.HorizontalAlign = HorizontalAlign.Center;
                d5.CssClass = "TabNewDay";
                tr.Cells.Add(d5);

                tabSEG.Rows.Add(tr);
            }
        }
        return tabSEG;
    }

    private Table BemerkungfuerGenehmiger()
    {
        TableRow HeaderRow = new TableRow();

        // Defect #6014 - Projektname anzeigen
        TableCell c0 = new TableCell();
        c0.Text = "Projekt";
        c0.HorizontalAlign = HorizontalAlign.Center;
        c0.CssClass = "TabHeader";
        c0.Font.Bold = true;

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Interne Bemerkung";
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c0);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;

        // Defect 4755
        // Auslesen der in den Einsatzberichten gespeicherten Bemerkungen
        EBBemerkungen = SelectEBBemerkungen();

        foreach (EBBemerkung e in EBBemerkungen)
        {
            string hBemerk = e.Ebhist.Trim();
            if (hBemerk != null &&
                hBemerk != "")
            {
                HeaderRow.Visible = true;// Defect #6014 Zeige Header wenn Bemerkung nicht leer ist
                string strCssClassRow = "Auftnr_neu";
                tr = new TableRow();

                TableCell tc0 = new TableCell();
                Label l0 = new Label();
                l0.Width = 200;
                l0.Text = e.ProjktName;
                tc0.HorizontalAlign = HorizontalAlign.Left;
                tc0.CssClass = strCssClassRow;
                tc0.Controls.Add(l0);
                tr.Cells.Add(tc0);

                TableCell tc1 = new TableCell();
                Label l1 = new Label();
                l1.Width = 150;
                l1.Text = e.Auftrnr;
                tc1.HorizontalAlign = HorizontalAlign.Left;
                tc1.CssClass = strCssClassRow;
                tc1.Controls.Add(l1);
                tr.Cells.Add(tc1);

                TableCell tc2 = new TableCell();
                Label l2 = new Label();
                l2.Width = 687;
                l2.Text = e.Ebhist;
                tc2.HorizontalAlign = HorizontalAlign.Left;
                tc2.ForeColor = System.Drawing.Color.Black;
                tc2.CssClass = strCssClassRow;
                tc2.Controls.Add(l2);
                tr.Cells.Add(tc2);
                tabBem.Rows.Add(tr);
            }
        }
        return tabBem;
        /*TableRow HeaderRow = new TableRow();
        TableCell c1 = new TableCell();

        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.Width = 200;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Bemerkungen";
        c2.Width = 700;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;

        // Defect 4755
        // Auslesen der in den Einsatzberichten gespeicherten Bemerkungen
        EBBemerkungen = SelectEBBemerkungen();

        foreach (EBBemerkung e in EBBemerkungen)
        {
          string hBemerk = e.Ebhist.Trim();
          if (hBemerk != null &&
              hBemerk != "")
          {
            string strCssClassRow = "Auftnr_neu";
            tr = new TableRow();
            TableCell d1 = new TableCell();
            d1.Width = 150;
            d1.Text = e.Auftrnr;
            d1.HorizontalAlign = HorizontalAlign.Left;
            d1.CssClass = strCssClassRow;
            tr.Cells.Add(d1);

            TableCell d2 = new TableCell();
            //d2.Width = 3000;
            d2.Text = e.Ebhist;
            d2.HorizontalAlign = HorizontalAlign.Left;
            d2.ForeColor = System.Drawing.Color.Black;
            d2.CssClass = strCssClassRow;
            tr.Cells.Add(d2);
            tabBem.Rows.Add(tr);
          }
        }
        return tabBem;*/
    }
    private Table KfmBemerkungfuerGenehmiger()
    {
        TableRow HeaderRow = new TableRow();

        // Defect #6014 - Projektname anzeigen
        TableCell c0 = new TableCell();
        c0.Text = "Projekt";
        c0.HorizontalAlign = HorizontalAlign.Center;
        c0.CssClass = "TabHeader";
        c0.Font.Bold = true;

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Bemerkung f�r Kunden";
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c0);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;

        // Defect 4755
        // Auslesen der in den Einsatzberichten gespeicherten Bemerkungen
        KfmBemerkungen = SelectKfmBemerkungen();

        foreach (KfmBemerkung e in KfmBemerkungen)
        {
            string hBemerk = e.Bemerkung.Trim();
            if (hBemerk != null &&
                hBemerk != "")
            {
                HeaderRow.Visible = true;// Defect #6014 Zeige Header wenn Bemerkung nicht leer ist
                string strCssClassRow = "Auftnr_neu";
                tr = new TableRow();

                TableCell tc0 = new TableCell();
                Label l0 = new Label();
                l0.Width = 200;
                l0.Text = e.ProjktName;
                tc0.HorizontalAlign = HorizontalAlign.Left;
                tc0.CssClass = strCssClassRow;
                tc0.Controls.Add(l0);
                tr.Cells.Add(tc0);

                TableCell tc1 = new TableCell();
                Label l1 = new Label();
                l1.Width = 150;
                l1.Text = e.Auftrnr;
                tc1.HorizontalAlign = HorizontalAlign.Left;
                tc1.CssClass = strCssClassRow;
                tc1.Controls.Add(l1);
                tr.Cells.Add(tc1);

                TableCell tc2 = new TableCell();
                Label l2 = new Label();
                l2.Width = 687;
                l2.Text = e.Bemerkung;
                tc2.HorizontalAlign = HorizontalAlign.Left;
                tc2.ForeColor = System.Drawing.Color.Black;
                tc2.CssClass = strCssClassRow;
                tc2.Controls.Add(l2);
                tr.Cells.Add(tc2);
                tabBem.Rows.Add(tr);
            }
        }
        return tabBem;
    }
}
