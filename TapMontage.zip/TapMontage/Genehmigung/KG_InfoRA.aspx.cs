//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_InfoRA.aspx.cs
//
// Description  : Kontrolle & Genehmigung - Anzeige Reiseabrechnung
//
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//                
//=============== 1.0.0050 ================================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== V1.0.0041 ===============================================
//
// Date         : 25.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6060
//                KFMBemerkungsfeld angedrucken
//
// Date         : 19.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6014
//                Bemerkungsfeld wird mehrmals angedruckt
//
//=============== V1.0.0037 ===============================================
//
// Date         : 10.Jaenner 2008
// Author       : Norbert Krizek
// Defect#      : 5704
//                Autom. gen. R�ckreise am Monatsanfang -> falsche Baustelle genommen
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 13.Dezember 2007
// Author       : Georg Nebehay
// Defect#      : 5697
//                Vermeidung von falscher Berechnung von Standortwechseln
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
// Date         : 06.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5589
//                Benutzerdaten im Kopf nicht mehrmals versorgen
//
//=============== V1.0.0034 ===============================================
//
// Date         : 23.Oktober 2007
// Author       : Wolfgang Patrman
// Defect#      : 5569
//                Anzeige Benutzerdaten im Kopf, wird im IE mit angedruckt
//
// Date         : 04.September 2007
// Author       : Wolfgang Patrman
// Defect#      : 5393
//                Selektion der Reiseauslagen aus der Tabelle RAZeile,
//                da diese an SAP �bermittelt wird 
//
//=============== V1.0.0033 ===============================================
//
// Date         : 03.September 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0027 ===============================================
//
// Date         : 07.Mai 2007
// Author       : WP
// Defect#      : 4822
//                Korr. Anzeige Reiseabrechnung, Daten aus DB richtig
//                auslesen, T Zeilen die durch die K�rzung des
//                N�chtigungsgeldes entstehen werden farbig hinterlegt
//
//=============== V1.0.0024 ===============================================
//
// Date         : 17.April 2007
// Author       : CL
// Defect#      : 4728
//                Zus�tzliche Anzeige der Personalnummer im Seitenkopf
//
//=============== V1.0.0024 ===============================================
//
// Date         : 10.April 2007
// Author       : Georg Nebehay
// Defect#      : 4933
//                Bei Teilabrechnungen wird keine Zeit mehr angezeigt.
//
//=============== V1.0.0022 ===============================================
//
// Date         : 21.Februar 2007
// Author       : WP
// Defect#      : 4655
//                Neuerstellung Anzeige EB und RA
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;

public partial class Genehmigung_KG_InfoRA : System.Web.UI.Page
{
    dbKG_Monat KGMonat;
    string EBvorh;
    ArrayList Reisen; // Liste der Reisezeilen des Berichtsmonats
    ArrayList EBBemerkungen; // Liste der EB Bemerkungen
    ArrayList RAAuslagen; // Liste der Reise Auslagen
    ArrayList Arbzeiten; // Liste der EB's des Berichtsmonats
    ArrayList KfmBemerkungen; // Liste der Kfm Bemerkungen

    protected void Page_Load(object sender, EventArgs e)
    {
        KGMonat = (dbKG_Monat)Session["KGMonat"];
        EBvorh = (string)Session["EBvorh"];

        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Anzeige - Reiseabrechnung</span><br /><span style=\"font-size: 12px;\">";
            Session["headData"] += KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
            // Defect 5569, Mitarbeiterinformationen anzeigen
            lbHeadInfo.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString(); // Defect 5589
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416
        // Beginn Defect # 4728: Zus�tzliche Anzeige der Personalnummer
        //Label2.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
        // Ende Defect # 4728
    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Liste der Arbeitszeiten, RA Auslagen
            phRabTab.Controls.Add(RabTab());

            // Bemerkungen
            phBemerkung.Controls.Add(BemerkungfuerGenehmiger());

            // Kfm Bemerkung
            phKfmBemerkung.Controls.Add(KfmBemerkungfuerGenehmiger());
        }

        if (EBvorh == "false")
        {
            BtnInfoEB.Enabled = false;
        }
        //BAN 500059 Beginn
        if (Session["UseNewHRInterface"] == null || (bool)Session["UseNewHRInterface"] == false)
            BtnSAP.Visible = false;
        //BAN 500059 Ende
    }

    protected void BtnPrev_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Genehmigung/KG_Info.aspx");
    }

    //BAN 500059 Beginn
    protected void BtnSAP_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Genehmigung/KG_SAP_RA.aspx?RetUrl=" + Request.RawUrl);
        Session["ChangeSAPTrips"] = false; //nur Anzeige
    }
    //BAN 500059 Ende

    protected void BtnInfoEB_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Genehmigung/KG_InfoEB.aspx");
    }

    private class EBBemerkung
    {
        // EBBemerkungen
        public int Ebid = 0;
        public string Auftrnr = "";
        public string Ebhist = "";
        public string ProjktName = ""; //Defect 6014 - Projektname wird auch im Bemerkungliste geschrieben

        public EBBemerkung(int ebid, string auftrnr, string ebhist, string projektName)
        {
            Ebid = ebid;
            Auftrnr = auftrnr;
            Ebhist = ebhist;
            ProjktName = projektName;
        }
    }
    //Defect #6060 KfMBemerkung
    private class KfmBemerkung
    {
        // EBBemerkungen
        public int Ebid = 0;
        public string Auftrnr = "";
        public string Bemerkung = "";
        public string ProjktName = ""; //Defect 6014 - Projektname wird auch im Bemerkungliste geschrieben

        public KfmBemerkung(int ebid, string auftrnr, string bemerk, string projektName)
        {
            Ebid = ebid;
            Auftrnr = auftrnr;
            Bemerkung = bemerk;
            ProjktName = projektName;
        }
    }


    private class RZeile
    {
        public string Datum = "";
        public string SummeStd = "";
        public string ReiseStd = "";
        public string AuftragNr = "";
        public string VonNach = "";
        public string AbAn = "";
        public string VM = "";
        public string BS = ""; // Breitstellungstext
        public string Km = "";
        public string Zid = "";
        public string anzahl = "";
        public string betrag = "";
        public string auslagen = "";
        public bool isBarauslage = false;
        public string Reiseart = "";
        public string Tooltip = "";


        public RZeile(string datum, string summeStd, string reiseStd, string auftragNr, string vonNach, string abAn, string vM, string bs, string km, string zid, string auslagen, string anzahl, string betrag, string reiseart, string tooltip)
        {
            Datum = datum;
            SummeStd = summeStd;
            ReiseStd = reiseStd;
            AuftragNr = auftragNr;
            VonNach = vonNach;
            AbAn = abAn;
            VM = vM;
            BS = bs;
            Km = km;
            Zid = zid;
            this.anzahl = anzahl;
            this.auslagen = auslagen;
            this.betrag = betrag;
            Reiseart = reiseart;
            Tooltip = tooltip;
        }
    }

    private class AZeile
    {
        public string Auslage = "";
        public string Anzahl = "";
        public string Betrag = "";
        public AZeile(string auslage, string anzahl, string betrag)
        {
            Auslage = auslage;
            Anzahl = anzahl;
            Betrag = betrag;
        }
    }

    private class RAAuslage
    {
        public string RAkztxt = "";
        public string Anzahl = "";
        public string Betrag = "";
        public DateTime Datum;

        public RAAuslage(string rakztxt, string anzahl, string betrag, DateTime datum)
        {
            RAkztxt = rakztxt;
            Anzahl = anzahl;
            Betrag = betrag;
            Datum = datum;
        }
    }

    private class Reise
    {
        // Einsatzberichte inkl. Arbeitszeiten
        public int Ebid = 0;
        public int NormStd;
        public DateTime Datum;
        public DateTime Ab;
        public DateTime An;
        public string Zeilenkz = "";
        public int Uestd50 = 0;
        public int Uestd100 = 0;
        public int GKStd = 0;
        public string VM_rakztxt = "";
        public string Auftrnr = "";
        public string BS_rakztxt = "";
        public string Gefkm = "";
        public string Reiseart = "";
        public string Tooltip = "";

        public Reise(int ebid, DateTime datum, int normstd,
                     DateTime ab, DateTime an, string zeilenkz,
                     int uestd50, int uestd100, int gkstd,
                     string vm_rakztxt, string auftrnr, string bs_rakztxt, string gefkm, string reiseart, string tooltip)
        {
            Ebid = ebid;
            NormStd = normstd;
            Datum = datum;
            Ab = ab;
            An = an;
            Zeilenkz = zeilenkz;
            Uestd50 = uestd50;
            Uestd100 = uestd100;
            GKStd = gkstd;
            VM_rakztxt = vm_rakztxt;
            Auftrnr = auftrnr;
            BS_rakztxt = bs_rakztxt;
            Gefkm = gefkm;
            Reiseart = reiseart;
            Tooltip = tooltip;
        }
    }

    private class Arbzeit
    {
        // Einsatzberichte inkl. Arbeitszeiten
        public int Ebid = 0;
        public int Normstd = 0;
        public DateTime Datum;
        public DateTime Beginn;
        public DateTime Ende;
        public int Stdabsenzid = 0;
        public int Uestd50 = 0;
        public int Uestd100 = 0;
        public int GKStd = 0;
        public string Leistart = "";
        public string Auftrnr = "";
        public string GKAuftrnr = "";
        public string Kzaz = "";

        public Arbzeit(int ebid, DateTime datum, int normstd, DateTime beginn, DateTime ende, int stdabsenzid, int uestd50, int uestd100, int gkstd, string leistart, string auftrnr, string gkauftrnr, string kzaz)
        {
            Ebid = ebid;
            Normstd = normstd;
            Datum = datum;
            Beginn = beginn;
            Ende = ende;
            Stdabsenzid = stdabsenzid;
            Uestd50 = uestd50;
            Uestd100 = uestd100;
            GKStd = gkstd;
            Leistart = leistart;
            Auftrnr = auftrnr;
            GKAuftrnr = gkauftrnr;
            Kzaz = kzaz;
        }
    }

    private Table RabTab()
    {
        Table RATable = new Table();

        RATable.Width = Unit.Percentage(100);
        TableRow rh = new TableRow();
        string xss = "TabHeader";
        rh = AddNewCell(rh, "Datum", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Summe Std.", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "+Std. Reise", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Auftrag-Nr.", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Von - Nach", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Ab - An", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Verkehrsm.", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Bereitst.", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "km", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Auslagen", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Anzahl", xss, HorizontalAlign.NotSet);
        rh = AddNewCell(rh, "Betrag", xss, HorizontalAlign.NotSet);

        rh.Cells[rh.Cells.Count - 1].ColumnSpan = 2;
        RATable.Rows.Add(rh);

        // Defect 4822
        // Auslesen der gespeicherten Reisezeilen
        Reisen = SelectReisen(KGMonat.MinDatum);
        // Auslesen der gespeicherten RA-Auslagen
        RAAuslagen = SelectRAAuslagen(KGMonat.MinDatum);
        // Auslesen der gespeicherten Arbeitszeiten
        Arbzeiten = SelectArbzeiten(KGMonat.MinDatum);

        foreach (dbKG_Tag t in KGMonat.Tage)
        {
            double NormStdTag = 0;
            double SummeStd = 0;

            ArrayList rZeilen = new ArrayList(); // Tageszeilen
            ArrayList tRAzeilen = new ArrayList(); // Reiseabrechnung Auslagenzeilen

            foreach (Arbzeit az in Arbzeiten)
            {
                double NormStd = 0;
                double Uestd50 = 0;
                double Uestd100 = 0;

                if (t.Tag == az.Datum.Day)
                {
                    if (az.Kzaz.Equals("A"))
                    {
                        if (az.Stdabsenzid != 0)
                        {
                            NormStd = Convert.ToDouble(az.Normstd) / 60.0;
                            NormStdTag += NormStd;
                            Uestd50 = Convert.ToDouble(az.Uestd50) / 60.0;
                            NormStdTag += Uestd50;
                            Uestd100 = Convert.ToDouble(az.Uestd100) / 60.0;
                            NormStdTag += Uestd100;
                            SummeStd += NormStd;
                        }
                        else
                        {
                            NormStd = Convert.ToDouble(az.Normstd) / 60.0;
                            NormStdTag += NormStd;
                            Uestd50 = Convert.ToDouble(az.Uestd50) / 60.0;
                            NormStdTag += Uestd50;
                            Uestd100 = Convert.ToDouble(az.Uestd100) / 60.0;
                            NormStdTag += Uestd100;
                            SummeStd += NormStd;
                        }
                    }
                }
            }

            //bool RAfirst = true;

            foreach (Reise r in Reisen)
            {
                if (t.Tag == r.Datum.Day)
                {
                    //if (RAfirst)
                    //{
                    //  foreach (RAAuslage raausl in RAAuslagen)
                    //  {
                    //    if (raausl.Datum.Day == t.Tag)
                    //    {
                    //      tRAzeilen.Add(new AZeile(raausl.RAkztxt, raausl.Anzahl, raausl.Betrag));
                    //    }
                    //  }
                    //  RAfirst = false;
                    //}

                    double ReiseStd = 0;

                    // Arbeitszeit erg�nzen

                    foreach (Arbzeit az in Arbzeiten)
                    {
                        if (az.Kzaz.Equals("W") &&
                            (az.Beginn == r.Ab ||
                             az.Ende == r.An))
                        {

                            //Defect 5697
                            //GN 13.12.2007
                            //Vermeidung falscher Stundenberechnung
                            if (r.Ab.Ticks != r.An.Ticks)
                            {
                                ReiseStd += Convert.ToDouble(az.Normstd) / 60.0 +
                                    Convert.ToDouble(az.Uestd50) / 60.0 +
                                    Convert.ToDouble(az.Uestd100) / 60.0;
                            }
                        }

                        if (az.Kzaz.Equals("R") &&
                            (az.Beginn == r.Ab ||
                             az.Ende == r.An))
                        {

                            //Defect 5697
                            //GN 13.12.2007
                            //Vermeidung falscher Stundenberechnung
                            if (r.Ab.Ticks != r.An.Ticks)
                            {
                                ReiseStd += Convert.ToDouble(az.Normstd) / 60.0 +
                                            Convert.ToDouble(az.Uestd50) / 60.0 +
                                            Convert.ToDouble(az.Uestd100) / 60.0;
                            }
                        }
                    }

                    // Bei Teilabrechnung keine Ab, An Zeit anzeigen
                    string strAbAn = "";

                    if (r.Zeilenkz != dbKG_ReiseZeilenKZ.GetKZ(dbKG_ReiseZeilenTyp.Teilabrechnung))
                    {
                        strAbAn = r.Ab.ToShortTimeString() + " - " + r.An.ToShortTimeString();
                    }

                    rZeilen.Add(new RZeile(DayDate(t.TagesDatum),
                                           NormStdTag.ToString("N"), ReiseStd.ToString("N"), r.Auftrnr,
                                           dbKG_ReiseZeilenKZ.GetKZText(dbKG_ReiseZeilenKZ.GetTyp(r.Zeilenkz)),
                        //r.Ab.ToShortTimeString() + " - " + r.An.ToShortTimeString(),
                                           strAbAn,
                                           r.VM_rakztxt, r.BS_rakztxt, r.Gefkm, "", "", "", "", r.Reiseart, r.Tooltip));
                }
            }

            foreach (RAAuslage raausl in RAAuslagen)
            {
                if (raausl.Datum.Day == t.Tag)
                {
                    tRAzeilen.Add(new AZeile(raausl.RAkztxt, raausl.Anzahl, raausl.Betrag));
                }
            }

            if (rZeilen.Count == 0)
            {
                string dstring = "";
                rZeilen.Add(new RZeile(DayDate(t.TagesDatum), dstring, "", "", "", "", "", "", "", "", "", "", "", "", ""));
            }

            while (rZeilen.Count < tRAzeilen.Count)
            {
                rZeilen.Add(new RZeile("", "", "", "", "", "", "", "", "", "", "", "", "", "", ""));
            }

            while (tRAzeilen.Count < rZeilen.Count)
            {
                tRAzeilen.Add(new AZeile("", "", ""));
            }

            bool first = true;

            for (int i = 0; i < rZeilen.Count; i++)
            {
                if (!first)
                {
                    ((RZeile)rZeilen[i]).Datum = "";
                    ((RZeile)rZeilen[i]).SummeStd = "";
                }

                RATable.Rows.Add(AddOneNewRow((RZeile)rZeilen[i], (AZeile)tRAzeilen[i], i, t.TagesDatum));
                first = false;
            }
        }

        return RATable;
    }

    ArrayList SelectArbzeiten(DateTime berdat)
    {
        ArrayList az = new ArrayList(); // Liste der Arbeitszeiten des Berichtsmonats

        // Selektion der RA Auslagen eines Einsatzberichtes
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("SELECT az.ebid, az.datum, az.normstd, az.beginn, az.ende, az.stdabsenzid, az.uestd50, az.uestd100, az.leistart, az.auftrnr, " +
                                                       "(SELECT y.auftrnr " +
                                                       " FROM y_auftrnrs y " + Config.Nolock + ", bearbeit b " + Config.Nolock +
                                                       " WHERE  b.perskey = az.perskey " +
                                                       " AND    y.mandant = b.mandant " +
                                                       " AND y.auftrnr = az.auftrnr) AS gkauftrner, " +
                                                       " az.kzaz " +
                                                       " FROM arbzeit az " + Config.Nolock +
                                                       " WHERE az.perskey = @PERSKEY " +
                                                       " AND DATEPART(YEAR, az.datum) = @YEAR " +
                                                       " AND DATEPART(MONTH, az.datum) = @MONTH " +
                                                       " ORDER BY az.beginn ASC ", cnx)) // Defect 5436, using eingef�hrt
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", berdat.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", berdat.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            int lGKStd = 0;
                            string gkauftrnr = "";
                            string leistArt = "";
                            if (!rd.IsDBNull(8)) //leistart
                                leistArt = rd.GetString(8);

                            if (!rd.IsDBNull(10))
                            {
                                gkauftrnr = rd.GetValue(10).ToString();
                            }

                            az.Add(new Arbzeit(rd.GetInt32(0), rd.GetDateTime(1), rd.GetInt16(2), rd.GetDateTime(3), rd.GetDateTime(4), rd.GetInt16(5), rd.GetInt16(6), rd.GetInt16(7), lGKStd, leistArt, rd.GetString(9), gkauftrnr, rd.GetString(11)));
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return az;
    }

    ArrayList SelectReisen(DateTime berdat)
    {
        ArrayList az = new ArrayList(); // Liste der Reisezeilen des Berichtsmonats

        // Selektion der RA Zeilen
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("SELECT r.ebid, r.dat, r.an, r.ab, r.zeilenkz, " +
                                                       "(SELECT y1.rakztxt " +
                                                       " FROM y_rakz y1 " + Config.Nolock +
                                                       " WHERE y1.rakzid = 'VM' " +
                                                       " AND y1.rakz = r.verkehrsmittel) AS vm, " +
                                                       "(SELECT y2.rakztxt " +
                                                       " FROM y_rakz y2 " + Config.Nolock +
                                                       " WHERE y2.rakzid = 'B' " +
                                                       " AND y2.rakz = r.bereitst) AS bs, " +
                                                       " r.gefkm, " +
                                                       " r.beschreib, " +
                                                       " r.reiseart, " +
                                                       " r.ABORT, r.ANORT " + //f�r tooltip
                    // defect 5704 beginn Anzeige aller Reisen des Berichtsmonats ohne Ber�cksichtigung des EB-Berichtsmonats
                                                       " FROM razeile r " + Config.Nolock + " , rakopf k " + Config.Nolock +
                                                       " WHERE k.perskey = @PERSKEY and k.raid = r.raid " +
                                                       " and DATEPART(year,r.dat ) = @YEAR " +
                                                       " and DATEPART(month, r.dat) = @MONTH " +
                    /*
                    " WHERE r.ebid in " +
                    "(SELECT ebid " +
                    " FROM einsber " + Config.Rowlock +
                    " WHERE perskey = @PERSKEY " +
                    " AND DATEPART(year, bermon) = @YEAR " +
                    " AND DATEPART(month, bermon) = @MONTH) " +
                   defect 5704 ende */
                                                       " AND r.zeilenkz IS NOT NULL " +
                                                       " ORDER BY r.dat, r.ab, r.an ", cnx)) // Defect 5436 // defect 5704 weiter sorieren zur sicherheit auch mit AB und An-zeiten
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", berdat.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", berdat.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            DateTime ab = new DateTime();
                            DateTime an = new DateTime();
                            string zeilenkz = "";
                            string VM_text = "";
                            string BS_text = "";
                            string auftrnr = "";
                            string gefkm = "";
                            string reiseart = "";
                            string tooltip = "";

                            if (!rd.IsDBNull(2))
                            {
                                an = Convert.ToDateTime(rd.GetValue(2));
                            }

                            if (!rd.IsDBNull(3))
                            {
                                ab = Convert.ToDateTime(rd.GetValue(3));
                            }

                            if (!rd.IsDBNull(4))
                            {
                                zeilenkz = rd.GetValue(4).ToString();
                            }

                            if (!rd.IsDBNull(5))
                            {
                                VM_text = rd.GetValue(5).ToString();
                            }

                            if (!rd.IsDBNull(6))
                            {
                                BS_text = rd.GetValue(6).ToString();
                            }

                            if (!rd.IsDBNull(7))
                            {
                                gefkm = rd.GetValue(7).ToString();
                            }

                            if (!rd.IsDBNull(8))
                            {
                                auftrnr = rd.GetValue(8).ToString();
                            }

                            if (!rd.IsDBNull(9))
                            {
                                reiseart = rd.GetValue(9).ToString();
                            }

                            //tooltip - von - nach
                            if (!rd.IsDBNull(10))
                            {
                                tooltip += rd.GetValue(10).ToString();
                            }
                            if (!rd.IsDBNull(11))
                            {
                                tooltip += " -> " + rd.GetValue(11).ToString() + " [Typ " + reiseart + "]";
                            }

                            if (zeilenkz.ToString() == "T")
                            {
                                tooltip = "[Typ " + reiseart + "]";
                            }


                            az.Add(new Reise(rd.GetInt32(0), // ebid
                                             rd.GetDateTime(1), // dat
                                             0, // NormStd
                                             ab, // ab
                                             an, // an
                                             zeilenkz, // zeilenkz
                                             0, // uestd50
                                             0, // uestd100
                                             0, // gkstd
                                             VM_text, // Verkehrsmittel rakztxt
                                             auftrnr, // auftrnr
                                             BS_text, // Bereitstellungstext
                                             gefkm, // gefKM
                                             reiseart, // reiseart
                                             tooltip)); //tooltip - von-nach
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return az;
    }

    private string DayDate(DateTime d)
    {
        string[] wTag = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa." };
        return wTag[(int)d.DayOfWeek] + " " + d.Day.ToString() + "." + d.Month.ToString() + ".";
    }

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align)
    {
        TableCell c = new TableCell();
        Label l = new Label();
        l.Text = LabelText;
        c.Controls.Add(l);
        c.CssClass = css;
        c.HorizontalAlign = align;
        r.Cells.Add(c);
        return r;
    }
    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align, string tooltip)
    {
        TableCell c = new TableCell();
        Label l = new Label();
        l.Text = LabelText;
        c.Controls.Add(l);
        c.CssClass = css;
        c.HorizontalAlign = align;
        r.Cells.Add(c);
        r.ToolTip = tooltip;
        return r;
    }

    ArrayList SelectRAAuslagen(/*int ebid,*/ DateTime berdat)
    {
        ArrayList ra = new ArrayList(); // Reiseabrechnung Auslagenzeilen

        // Selektion der RA Auslagen eines Einsatzberichtes
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();

                // Beginn Defect 5393

                //SqlCommand cmd = new SqlCommand("SELECT y.rakztxt, ra.anzahl, ra.betrag, ra.datum " +
                //                                "FROM raauslage ra, y_rakz y, einsber e " +
                //                                //"WHERE ebid = " + ebid + " " +
                //                                "WHERE e.perskey = @PERSKEY " +
                //                                "AND e.ebid = ra.ebid " +
                //                                "AND DATEPART(year, e.bermon) = @YEAR " +
                //                                "AND DATEPART(month, e.bermon) = @MONTH " +
                //                                "AND y.rakz = ra.rakz " +
                //                                "ORDER BY ra.datum, ra.raauslageid ASC", cnx);
                // Die Selektion der Reiseauslagen erfolgt aus der Tabelle RAZeile,
                // da diese an SAP �bermittelt wird

                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("SELECT y.rakztxt, ra.anznaechte, ra.betrag, ra.dat " +
                                                       " FROM razeile ra " + Config.Nolock + ", y_rakz y " + Config.Nolock + ", einsber e " + Config.Nolock +
                                                       " WHERE e.perskey = @PERSKEY " +
                                                       " AND e.ebid = ra.ebid " +
                                                       " AND DATEPART(year, e.bermon) = @YEAR " +
                                                       " AND DATEPART(month, e.bermon) = @MONTH " +
                                                       " AND y.rakz = ra.auslart " +
                                                       " ORDER BY ra.dat, ra.raid, ra.lfdnr ASC", cnx)) // Defect 5436
                {
                    // Ende Defect 5393
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", berdat.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", berdat.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            ra.Add(new RAAuslage(rd.GetString(0), Convert.ToSingle(rd.GetValue(1)).ToString("N"), Convert.ToSingle(rd.GetValue(2)).ToString("N"), rd.GetDateTime(3)));
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return ra;
    }

    private Table BemerkungfuerGenehmiger()
    {
        TableRow HeaderRow = new TableRow();

        // Defect #6014 - Projektname anzeigen
        TableCell c0 = new TableCell();
        c0.Text = "Projekt";
        c0.HorizontalAlign = HorizontalAlign.Center;
        c0.CssClass = "TabHeader";
        c0.Font.Bold = true;

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Interne Bemerkung";
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c0);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;

        // Defect 4755
        // Auslesen der in den Einsatzberichten gespeicherten Bemerkungen
        EBBemerkungen = SelectEBBemerkungen();

        foreach (EBBemerkung e in EBBemerkungen)
        {
            string hBemerk = e.Ebhist.Trim();
            if (hBemerk != null &&
                hBemerk != "")
            {
                HeaderRow.Visible = true;// Defect #6014 Zeige Header wenn Bemerkung nicht leer ist
                string strCssClassRow = "Auftnr_neu";
                tr = new TableRow();

                TableCell tc0 = new TableCell();
                Label l0 = new Label();
                l0.Width = 200;
                l0.Text = e.ProjktName;
                tc0.HorizontalAlign = HorizontalAlign.Left;
                tc0.CssClass = strCssClassRow;
                tc0.Controls.Add(l0);
                tr.Cells.Add(tc0);

                TableCell tc1 = new TableCell();
                Label l1 = new Label();
                l1.Width = 150;
                l1.Text = e.Auftrnr;
                tc1.HorizontalAlign = HorizontalAlign.Left;
                tc1.CssClass = strCssClassRow;
                tc1.Controls.Add(l1);
                tr.Cells.Add(tc1);

                TableCell tc2 = new TableCell();
                Label l2 = new Label();
                l2.Width = 742;
                l2.Text = e.Ebhist;
                tc2.HorizontalAlign = HorizontalAlign.Left;
                tc2.ForeColor = System.Drawing.Color.Black;
                tc2.CssClass = strCssClassRow;
                tc2.Controls.Add(l2);
                tr.Cells.Add(tc2);
                tabBem.Rows.Add(tr);
            }
        }
        return tabBem;

        /*
      TableRow HeaderRow = new TableRow();
      TableCell c1 = new TableCell();

      c1.Text = "AuftragNr";
      c1.HorizontalAlign = HorizontalAlign.Center;
      c1.Width = 200;
      c1.CssClass = "TabHeader";
      c1.Font.Bold = true;

      TableCell c2 = new TableCell();
      c2.Text = "Bemerkungen";
      c2.Width = 700;
      c2.HorizontalAlign = HorizontalAlign.Center;
      c2.CssClass = "TabHeader";
      c2.Font.Bold = true;

      HeaderRow.Cells.Add(c1);
      HeaderRow.Cells.Add(c2);
      tabBem.Rows.Add(HeaderRow);

      HeaderRow.Visible = false;
      TableRow tr;

      // Defect 4822
      // Auslesen der in den Einsatzberichten gespeicherten Bemerkungen
      EBBemerkungen = SelectEBBemerkungen();

      foreach (EBBemerkung e in EBBemerkungen)
      {
        string hBemerk = e.Ebhist.Trim();
        if (hBemerk != null &&
            hBemerk != "")
        {
          string strCssClassRow = "Auftnr_neu";
          tr = new TableRow();
          TableCell d1 = new TableCell();
          d1.Width = 150;
          d1.Text = e.Auftrnr;
          d1.HorizontalAlign = HorizontalAlign.Left;
          d1.CssClass = strCssClassRow;
          tr.Cells.Add(d1);

          TableCell d2 = new TableCell();
          //d2.Width = 700;
          d2.Text = e.Ebhist;
          d2.HorizontalAlign = HorizontalAlign.Left;
          d2.ForeColor = System.Drawing.Color.Black;
          d2.CssClass = strCssClassRow;
          tr.Cells.Add(d2);
          tabBem.Rows.Add(tr);
        }
      }
      return tabBem;
         * */
    }

    ArrayList SelectEBBemerkungen()
    {
        ArrayList bemerk = new ArrayList(); // Liste der EB Bemerkungen

        // Selektion der Bemerkungen zu den EB's
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                /*using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT e.ebid, az.auftrnr, SUBSTRING(e.ebhist, 1, 500) AS ebhist " +
                                                       " FROM   einsber e " + Config.Nolock + ", arbzeit az " + Config.Nolock +
                                                       " WHERE  e.perskey = @PERSKEY " +
                                                       " AND    datepart(YEAR, e.bermon) = @YEAR " +
                                                       " AND    datepart(MONTH, e.bermon) = @MONTH " +
                                                       " AND    e.ebid = az.ebid ", cnx)) // Defect 5436*/
                // Defect #6014 - Projektname auch auslesen 
                using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT e.ebid, az.auftrnr, SUBSTRING(e.ebhist, 1, 500) AS ebhist, bp.name " +
                                                       " FROM einsber e " + Config.Nolock + ", arbzeit az " + Config.Nolock +
                                                       ", bauprojekt bp " + Config.Nolock +
                                                       " WHERE e.perskey = @PERSKEY " +
                                                       "AND datepart(YEAR, e.bermon) = @YEAR " +
                                                       "AND datepart(MONTH, e.bermon) = @MONTH " +
                                                       "AND e.projid = bp.projid " +
                                                       "AND e.ebid = az.ebid ", cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", KGMonat.MinDatum.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", KGMonat.MinDatum.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            //Defect #6014 doppelten Eintr�ge verfindern
                            bool exist = false;
                            foreach (EBBemerkung e in bemerk)
                            {
                                if (e.ProjktName == rd.GetString(3))
                                {
                                    if (!e.Auftrnr.Contains(rd.GetString(1)))
                                        e.Auftrnr += " / " + rd.GetString(1);
                                    exist = true;
                                    break;
                                }
                            }
                            if (!exist)
                            {
                                bemerk.Add(new EBBemerkung(rd.GetInt32(0), rd.GetString(1), rd.GetString(2), rd.GetString(3)));
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return bemerk;
    }
    ArrayList SelectKfmBemerkungen()
    {
        ArrayList bemerk = new ArrayList(); // Liste der EB Bemerkungen

        // Selektion der Bemerkungen zu den EB's
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                /*using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT e.ebid, az.auftrnr, SUBSTRING(e.ebhist, 1, 500) AS ebhist " +
                                                       " FROM   einsber e " + Config.Nolock + ", arbzeit az " + Config.Nolock +
                                                       " WHERE  e.perskey = @PERSKEY " +
                                                       " AND    datepart(YEAR, e.bermon) = @YEAR " +
                                                       " AND    datepart(MONTH, e.bermon) = @MONTH " +
                                                       " AND    e.ebid = az.ebid ", cnx)) // Defect 5436*/
                // Defect #6014 - Projektname auch auslesen 
                using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT e.ebid, az.auftrnr, SUBSTRING(e.kfmbemerkung, 1, 255) AS kfmbemerkung, bp.name " +
                                                       " FROM einsber e " + Config.Nolock + ", arbzeit az " + Config.Nolock +
                                                       ", bauprojekt bp " + Config.Nolock +
                                                       " WHERE e.perskey = @PERSKEY " +
                                                       "AND datepart(YEAR, e.bermon) = @YEAR " +
                                                       "AND datepart(MONTH, e.bermon) = @MONTH " +
                                                       "AND e.projid = bp.projid " +
                                                       "AND e.ebid = az.ebid ", cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", KGMonat.MinDatum.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", KGMonat.MinDatum.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        while (rd.Read())
                        {
                            //Defect #6014 doppelten Eintr�ge verfindern
                            bool exist = false;
                            foreach (KfmBemerkung e in bemerk)
                            {
                                if (e.ProjktName == rd.GetString(3))
                                {
                                    if (!e.Auftrnr.Contains(rd.GetString(1)))
                                        e.Auftrnr += " / " + rd.GetString(1);
                                    exist = true;
                                    break;
                                }
                            }
                            if (!exist)
                            {
                                bemerk.Add(new KfmBemerkung(rd.GetInt32(0), rd.GetString(1), rd.GetString(2), rd.GetString(3)));
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return bemerk;
    }

    private string CssWE(DateTime Tag)
    {
        //BAF 530042 Beginn
        if (KGMonat.Monteur.AZMKalenderTage.ContainsKey(Tag))
        {
            if (KGMonat.Monteur.AZMKalenderTage[Tag].IstArbeitstag)
                return "";
            else
                return "WE";
        }//BAF 530042 Ende
        else
        {
            if (KGMonat.Monteur.IstArbeitstag(Tag))
                return "";
            else
                return "WE";
        }
    }

    private TableRow AddOneNewRow(RZeile rz, AZeile az, int ind, DateTime Tag)
    {
        string strCssClassRow;
        TableRow r = new TableRow();

        if (rz.Reiseart == "D" ||
            rz.Reiseart == "E")
        {
            strCssClassRow = (ind > 0 ? "TabZeileKursiv" + CssWE(Tag) : "TabNewDayKursiv" + CssWE(Tag));
        }
        else
        {
            strCssClassRow = (ind > 0 ? "TabZeile" + CssWE(Tag) : "TabNewDay" + CssWE(Tag));
        }

        r = AddNewCell(r, rz.Datum, strCssClassRow, HorizontalAlign.Left);
        r = AddNewCell(r, rz.SummeStd, strCssClassRow, HorizontalAlign.Right);
        r = AddNewCell(r, rz.ReiseStd, strCssClassRow, HorizontalAlign.Right);
        r = AddNewCell(r, rz.AuftragNr, strCssClassRow, HorizontalAlign.Right);
        r = AddNewCell(r, rz.VonNach, strCssClassRow, HorizontalAlign.Left, rz.Tooltip);
        r = AddNewCell(r, rz.AbAn, strCssClassRow, HorizontalAlign.Center);
        r = AddNewCell(r, rz.VM, strCssClassRow, HorizontalAlign.Left);
        r = AddNewCell(r, rz.BS, strCssClassRow, HorizontalAlign.Left);
        r = AddNewCell(r, rz.Km, strCssClassRow, HorizontalAlign.Right);

        r = AddNewCell(r, az.Auslage, strCssClassRow, HorizontalAlign.Left);
        r = AddNewCell(r, az.Anzahl, strCssClassRow, HorizontalAlign.Right);
        r = AddNewCell(r, az.Betrag, strCssClassRow, HorizontalAlign.Right);

        return r;
    }
    private Table KfmBemerkungfuerGenehmiger()
    {
        TableRow HeaderRow = new TableRow();

        // Defect #6014 - Projektname anzeigen
        TableCell c0 = new TableCell();
        c0.Text = "Projekt";
        c0.HorizontalAlign = HorizontalAlign.Center;
        c0.CssClass = "TabHeader";
        c0.Font.Bold = true;

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Bemerkung f�r Kunden";
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c0);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;

        // Defect 4755
        // Auslesen der in den Einsatzberichten gespeicherten Bemerkungen
        KfmBemerkungen = SelectKfmBemerkungen();

        foreach (KfmBemerkung e in KfmBemerkungen)
        {
            string hBemerk = e.Bemerkung.Trim();
            if (hBemerk != null &&
                hBemerk != "")
            {
                HeaderRow.Visible = true;// Defect #6014 Zeige Header wenn Bemerkung nicht leer ist
                string strCssClassRow = "Auftnr_neu";
                tr = new TableRow();

                TableCell tc0 = new TableCell();
                Label l0 = new Label();
                l0.Width = 200;
                l0.Text = e.ProjktName;
                tc0.HorizontalAlign = HorizontalAlign.Left;
                tc0.CssClass = strCssClassRow;
                tc0.Controls.Add(l0);
                tr.Cells.Add(tc0);

                TableCell tc1 = new TableCell();
                Label l1 = new Label();
                l1.Width = 150;
                l1.Text = e.Auftrnr;
                tc1.HorizontalAlign = HorizontalAlign.Left;
                tc1.CssClass = strCssClassRow;
                tc1.Controls.Add(l1);
                tr.Cells.Add(tc1);

                TableCell tc2 = new TableCell();
                Label l2 = new Label();
                l2.Width = 687;
                l2.Text = e.Bemerkung;
                tc2.HorizontalAlign = HorizontalAlign.Left;
                tc2.ForeColor = System.Drawing.Color.Black;
                tc2.CssClass = strCssClassRow;
                tc2.Controls.Add(l2);
                tr.Cells.Add(tc2);
                tabBem.Rows.Add(tr);
            }
        }
        return tabBem;
    }
}

 
