// =============================================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_Dispo_aspx.cs
//
// Description  : Dispo-Schirm
//
//=============== V1.0.0034 ===============================================
//
// Date         : 23.Oktober 2007
// Author       : Wolfgang Patrman
// Defect#      : 5569
//                Anzeige Benutzerdaten im Kopf, wird im IE mit angedruckt
//
//--------------- V1.0.0029 --------------------------------------------------------------------
//
// Date         : 19.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 4726
//                name mitarbeiter auf �berstundendisposition fehlt
//
//=============== V1.0.0020 ====================================================================
//
// Date         : 27.J�nner 2007
// Author       : Gebhardt
// Defect#      : 4401
//                Validierung d. Beuntzereingabe im Dispodialog  
//
//              : 28.J�nner 2007
//              : �nderungen doch nicht f. Version V1.0.0020 --> bis auf weiteres ausbauen 
//
//=============== V1.0.0019 ====================================================================
//
// Date         : 10.J�nner 2007
// Author       : Nebehay Georg
// Defect#      : 4281 (4277)
//                KG_Dispo wurde ausgebessert
//
//=============== V1.0.0018 ====================================================================
//
// Date         : 10.J�nner 2007
// Author       : Nebehay Georg
// Defect#      : 4232
//                Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
//
//=============== V1.0.0003 ====================================================================
//
// Date         : 19.Oktober 2006
// Author       : Gebhardt
// Defect#      : 3387
//                Nullsetzen von Feldern nach Aktualisieren.
//
// ============================================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Genehmigung_KG_Dispo : System.Web.UI.Page
{
    dbKG_AZM KGAzm;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #4726 - name mitarbeiter auf �berstundendisposition fehlt
        try
        {
            lbUserName.Text = "";
            if (Request.Params["userName"] != null)
            {
                lbUserName.Text = " - " + Request.Params["userName"].ToString();
            }
        }
        catch
        { } 
        // Ende #4726

        KGAzm = (dbKG_AZM)Session["KGAzm"];
        KGAzm.page = Page;

        // Defect 5569, Mitarbeiterinformationen anzeigen
        lbUserName.Text += " - " + KGAzm.KGMonat.MonatText + " " + KGAzm.KGMonat.MinDatum.Year.ToString();

        if (!Page.IsPostBack)
            FillTable();
        if (KGAzm.DMStatus != 1)
            BtnDispo.Enabled = false;

        //Find MA Name!!
    }
    
    // defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    //              Bef�llen der Tabelle, Validierungen, Anzeige der Daten
    private void FillTable()
    {
        Label11.Text = KGAzm.DM50.ToString("N");                //defect 4232
        Label61.Text = KGAzm.DM50.ToString("N");                //defect 4232
        //Label4.Text = KGAzm.DSteuerfrei100.ToString("N");
        Label41.Text = "";                                      //defect 4232
        Label21.Text = KGAzm.DM100.ToString("N");               //defect 4232
        Label71.Text = KGAzm.DM100.ToString("N");               //defect 4232
        Label51.Text = KGAzm.DSteuerfrei100.ToString("N");      //defect 4232
        Label31.Text = KGAzm.DMTeilzeit.ToString("N");          //defect 4232
        Label81.Text = KGAzm.DMTeilzeit.ToString("N");          //defect 4232
        //defect 4232 beginn neu
        if (KGAzm.AZMDispo.AuslandsDispo != null)
        {
            Label12.Text = KGAzm.AuslDM50.ToString("N");
            Label62.Text = KGAzm.AuslDM50.ToString("N");
            //Label4.Text = KGAzm.DSteuerfrei100.ToString("N");
            Label42.Text = "";
            Label22.Text = KGAzm.AuslDM100.ToString("N");
            Label72.Text = KGAzm.AuslDM100.ToString("N");
            Label52.Text = KGAzm.AuslDSteuerfrei100.ToString("N");
            Label32.Text = KGAzm.AuslDMTeilzeit.ToString("N");
            Label82.Text = KGAzm.AuslDMTeilzeit.ToString("N");
        }
        else
        {
            // Defect 4281 
            //  KG_Dispo wurde ausgebessert 
            //      bei MA die nur im Ausland oder im In-/Ausland arbeiten werden sowohl Inlands- als auch 
            //      Auslands�berstunden angezeigt, bei MA im Inland werden die �berstunden im Inland bei 
            //      der Disposition angezeigt
            Label12.Text = "0,00";
            Label22.Text = "0,00";                  //Defect 4281
            Label32.Text = "0,00";
            MehrarbeitAusland.Visible = false;      //Defect 4281
        }
        //defect 4232 ende neu
    }

    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void BtnDispo_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //Kommunikation mit AZM
            SetDispo setDispo = new SetDispo(1, Convert.ToInt32(Convert.ToDouble(tb11.Text) * 60), Convert.ToInt32(Convert.ToDouble(tb31.Text) * 60), Convert.ToInt32(Convert.ToDouble(tb21.Text) * 60), Convert.ToInt32(Convert.ToDouble(tb41.Text) * 60), Convert.ToInt32(Convert.ToDouble(Label61.Text) * 60), Convert.ToInt32(Convert.ToDouble(Label71.Text) * 60), KGAzm.AZMDispo.Steuerfrei100, Convert.ToInt32(Convert.ToDouble(tb51.Text) * 60), 0, "G");   //defect 4232
            //defect 4232 beginn neu
            SetDispo auslandsDispo = null;
            if (KGAzm.AZMDispo.AuslandsDispo != null)
            {
                auslandsDispo = new SetDispo(1, Convert.ToInt32(Convert.ToDouble(tb12.Text) * 60), Convert.ToInt32(Convert.ToDouble(tb32.Text) * 60), Convert.ToInt32(Convert.ToDouble(tb22.Text) * 60), Convert.ToInt32(Convert.ToDouble(tb42.Text) * 60), Convert.ToInt32(Convert.ToDouble(Label62.Text) * 60), Convert.ToInt32(Convert.ToDouble(Label72.Text) * 60), KGAzm.AZMDispo.Steuerfrei100, Convert.ToInt32(Convert.ToDouble(tb52.Text) * 60), 0, "G");
            }
            setDispo.AuslandsSetDispo = auslandsDispo;
            //defect 4232 ende neu
            KGAzm.SetDispo(setDispo);
            Response.Redirect("~/Genehmigung/KG_Main.aspx");
        }
    }

    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void BtnLoad_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //
            //    4401 - �nderungen doch nicht f. Version V1.0.0020 --> bis auf weiteres ausbauen  
            //

            // double dsum;                // 4401 - �nderungen doch nicht f. Version V1.0.0020 --> bis auf weiteres ausbauen  
            // Beginn Defect # 3387: Nullsetzen von Feldern nach Aktualisierung
            double x = 0;
            // Ende Defect # 3387
            tb11.Text = Convert.ToDouble(tb11.Text.Replace(".", ",")).ToString("N");    //defect 4232
            tb21.Text = Convert.ToDouble(tb21.Text.Replace(".", ",")).ToString("N");    //defect 4232
            tb31.Text = Convert.ToDouble(tb31.Text.Replace(".", ",")).ToString("N");    //defect 4232
            tb41.Text = Convert.ToDouble(tb41.Text.Replace(".", ",")).ToString("N");    //defect 4232
            tb51.Text = Convert.ToDouble(tb51.Text.Replace(".", ",")).ToString("N");    //defect 4232

            // 4401 - �nderungen doch nicht f. Version V1.0.0020 --> bis auf weiteres ausbauen  
            // dsum = Convert.ToDouble(tb11.Text.Replace(".", ",")) + Convert.ToDouble(tb21.Text.Replace(".", ","));//defect 4401
            // ende 4401
            x = KGAzm.DM50 - Convert.ToDouble(tb11.Text.Replace(".", ","));             //defect 4232
            // 4401 -
//            x = KGAzm.DM50 - dsum;             //defect 4401
            // Ende
            Label61.Text = x.ToString("N");                                             //defect 4232
            //  CG defect 4401 - validierung 
            //  dsum = Convert.ToDouble(tb31.Text.Replace(".", ",")) + Convert.ToDouble(tb41.Text.Replace(".", ","));//defect 4401
            //x = KGAzm.DM100 - dsum;                                                                                //defect 4401   

            x = KGAzm.DM100 - (Convert.ToDouble(tb31.Text.Replace(".", ",")));          //defect 4232
            Label71.Text = x.ToString("N");                                             //defect 4232
            x = KGAzm.DMTeilzeit - Convert.ToDouble(tb51.Text.Replace(".", ","));       //defect 4232
            Label81.Text = x.ToString("N");                                             //defect 4232
            //defect 4232 beginn neu
            if (KGAzm.AZMDispo.AuslandsDispo != null)
            {
                x = 0;
                tb12.Text = Convert.ToDouble(tb12.Text.Replace(".", ",")).ToString("N");
                tb22.Text = Convert.ToDouble(tb22.Text.Replace(".", ",")).ToString("N");
                tb32.Text = Convert.ToDouble(tb32.Text.Replace(".", ",")).ToString("N");
                tb42.Text = Convert.ToDouble(tb42.Text.Replace(".", ",")).ToString("N");
                tb52.Text = Convert.ToDouble(tb52.Text.Replace(".", ",")).ToString("N");
                //  CG defect 4401 - validierung 
                x = KGAzm.AuslDM50 - Convert.ToDouble(tb12.Text.Replace(".", ","));
                // dsum = Convert.ToDouble(tb12.Text.Replace(".", ",")) + Convert.ToDouble(tb22.Text.Replace(".", ","));//defect 4401
                // x = KGAzm.AuslDM50 - dsum;
                Label62.Text = x.ToString("N");
                //  CG defect 4401 - validierung 
                x = KGAzm.AuslDM100 - Convert.ToDouble(tb32.Text.Replace(".", ","));
                //dsum = Convert.ToDouble(tb32.Text.Replace(".", ",")) + Convert.ToDouble(tb42.Text.Replace(".", ","));//defect 4401
                //x = KGAzm.AuslDM100 - dsum;                                                                          //defect 4401
                Label72.Text = x.ToString("N");
                x = KGAzm.AuslDMTeilzeit - Convert.ToDouble(tb52.Text.Replace(".", ","));
                Label82.Text = x.ToString("N");
            }
        }
    }

    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        //CG - Defect 4401: Validierung d. horizontalen Summe - Variable sumNOK
        //bool sumNOK = Convert.ToDouble(tb11.Text.Replace(".", ",")) +  Convert.ToDouble(tb21.Text.Replace(".", ",")) > KGAzm.DM50;    
        
//        if (!RangeCheck.IsNumeric(tb11.Text) || sumNOK)       //defect 4232, 4401
        if (!RangeCheck.IsNumeric(tb11.Text))                   //defect 4232
        args.IsValid = false;
        else
            if (Convert.ToDouble(tb11.Text.Replace(".", ",")) > Convert.ToDouble(Label11.Text))      //defect 4232
                args.IsValid = false;
    }

    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator2_ServerValidate(object source, ServerValidateEventArgs args)
    {
        //CG - Defect 4401: Validierung d. horizontalen Summe - Variable sumNOK
        // bool sumNOK = Convert.ToDouble(tb11.Text.Replace(".", ",")) + Convert.ToDouble(tb21.Text.Replace(".", ",")) > KGAzm.DM50; //Defect 4401
        //if (!RangeCheck.IsNumeric(tb21.Text) || sumNOK)        //defect 4232, 4401
        if (!RangeCheck.IsNumeric(tb21.Text))        //defect 4232
            args.IsValid = false;
        else
            if (Convert.ToDouble(tb21.Text.Replace(".", ",")) > Convert.ToDouble(Label11.Text))    //defect 4232
                args.IsValid = false;
    }

    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator3_ServerValidate(object source, ServerValidateEventArgs args)
    {
        //CG - Defect 4401: Validierung d. horizontalen Summe - Variable sumNOK
        // bool sumNOK = Convert.ToDouble(tb31.Text.Replace(".", ",")) + Convert.ToDouble(tb41.Text.Replace(".", ",")) > KGAzm.DM100; //Defect 4401
        // if (!RangeCheck.IsNumeric(tb31.Text) || sumNOK)       //defect 4232, 4401
        if (!RangeCheck.IsNumeric(tb31.Text))       //defect 4232
            args.IsValid = false;
        else
            if (Convert.ToDouble(tb31.Text.Replace(".", ",")) > Convert.ToDouble(Label21.Text))     //defect 4232
                args.IsValid = false;
    }
    
    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator4_ServerValidate(object source, ServerValidateEventArgs args)
    {
        //CG - Defect 4401: Validierung d. horizontalen Summe - Variable sumNOK
        // bool sumNOK = Convert.ToDouble(tb31.Text.Replace(".", ",")) + Convert.ToDouble(tb41.Text.Replace(".", ",")) > KGAzm.DM100; //Defect 4401
        // if (!RangeCheck.IsNumeric(tb41.Text) || sumNOK)    //defect 4232, 4401
        if (!RangeCheck.IsNumeric(tb41.Text))    //defect 4232
            args.IsValid = false;
        else
            if (Convert.ToDouble(tb41.Text.Replace(".", ",")) > Convert.ToDouble(Label21.Text))     //defect 4232
                args.IsValid = false;
    }
    
    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator5_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (!RangeCheck.IsNumeric(tb51.Text))       //defect 4232
        //defect 4232 beginn neu
            args.IsValid = false;
        else
            if (Convert.ToDouble(tb51.Text.Replace(".", ",")) > Convert.ToDouble(Label31.Text))
                args.IsValid = false;
    }
    
    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator6_ServerValidate(object source, ServerValidateEventArgs args)
    {
        // CG - Defect 4401: Validierung d. horizontalen Summe - Variable sumNOK
        // bool sumNOK = Convert.ToDouble(tb12.Text.Replace(".", ",")) + Convert.ToDouble(tb22.Text.Replace(".", ",")) > KGAzm.DM50; //Defect 4401
        // if (!RangeCheck.IsNumeric(tb12.Text) || sumNOK) //defect 4232, 4401
        if (!RangeCheck.IsNumeric(tb12.Text)) //defect 4232
            args.IsValid = false;
        else
            if (Convert.ToDouble(tb12.Text.Replace(".", ",")) > Convert.ToDouble(Label12.Text))
                args.IsValid = false;
    }
    
    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator7_ServerValidate(object source, ServerValidateEventArgs args)
    {
        // bool sumNOK = Convert.ToDouble(tb12.Text.Replace(".", ",")) + Convert.ToDouble(tb22.Text.Replace(".", ",")) > KGAzm.DM50; //Defect 4401
        // if (!RangeCheck.IsNumeric(tb22.Text) || sumNOK) // Defect 4401
        if (!RangeCheck.IsNumeric(tb22.Text))
            args.IsValid = false;
        else
            if (Convert.ToDouble(tb22.Text.Replace(".", ",")) > Convert.ToDouble(Label12.Text))
                args.IsValid = false;
    }

    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator8_ServerValidate(object source, ServerValidateEventArgs args)
    {
        //CG - Defect 4401: Validierung d. horizontalen Summe - Variable sumNOK
        // bool sumNOK = Convert.ToDouble(tb32.Text.Replace(".", ",")) + Convert.ToDouble(tb42.Text.Replace(".", ",")) > KGAzm.DM50; //Defect 4401
        //if (!RangeCheck.IsNumeric(tb32.Text) || sumNOK) // defect 4401
        if (!RangeCheck.IsNumeric(tb32.Text))
                args.IsValid = false;
        else
            if (Convert.ToDouble(tb32.Text.Replace(".", ",")) > Convert.ToDouble(Label22.Text))
                args.IsValid = false;
    }

    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator9_ServerValidate(object source, ServerValidateEventArgs args)
    {
        //CG - Defect 4401: Validierung d. horizontalen Summe - Variable sumNOK
        //bool sumNOK = Convert.ToDouble(tb32.Text.Replace(".", ",")) + Convert.ToDouble(tb42.Text.Replace(".", ",")) > KGAzm.DM50; // Defect 4401
        //if (!RangeCheck.IsNumeric(tb42.Text) || sumNOK) // Defect 4401
        if (!RangeCheck.IsNumeric(tb42.Text))
                args.IsValid = false;
        else
            if (Convert.ToDouble(tb42.Text.Replace(".", ",")) > Convert.ToDouble(Label22.Text))
                args.IsValid = false;
    }

    //defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    protected void CustomValidator10_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (!RangeCheck.IsNumeric(tb52.Text))
        //defect 4232 ende neu
            args.IsValid = false;
        else
            if (Convert.ToDouble(tb52.Text.Replace(".", ",")) > Convert.ToDouble(Label32.Text))             //defect 4232
                args.IsValid = false;
    }
}
