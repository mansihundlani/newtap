//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_Zeiten.aspx.cs
//
// Description  : Anzeige Arbeitszeiten f�r Genehmigung
//
//=============== V1.2.0017 ===============================================
//
// Date         : 18.November 2013
// Author       : Joldic Dzevad
// Defect#      : TT 6654245
//                Bei @CENT soll decimal anstatt float verwendet werden
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2010
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//
//=============== V1.2.0015 ===============================================
//
// Date         : 04.September 2013
// Author       : Joldic Dzevad
// Defect#      : 
//                SAP Connector ausgelagert in eigenes Projekt 
//
//=============== V1.2.0011 ===================================================
//
// Date         : 27.September 2011
// Author       : Joldic Dzevad
// Defect#      : KMS BAN 500256 TAP-Montage: Erweiterte Zulagenpr�fung
//                Darstellun von zulagen ge�ndert
//                Warnnung ausgeben falls Anzahl gr�sser als HR erlaubt
//
//=============== V1.2.0008 ===============================================
//
// Date         : 10.November 2010
// Author       : Joldic Dzevad
// Defect#      : BAF xxxxxx
//                Session Variable BackFromAZM zur�cksetzen
//                
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//                
//=============== V1.2.0005 ===============================================
//
// Date         : 05.Mai 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530037
//                SQL Select angepasst (Bei identischen Buchungen, zweite 
//                w�rde ignoriert)
//
//=============== V1.2.0002 ===============================================
//
// Date         : 10.M�rz 2010
// Author       : Joldic Dzevad
// Defect#      : 
//                Anbindung an TapSapConnection
//
//=============== V1.2.0001 ===============================================
//
// Date         : 23.Februar 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530031
//                LA Anzeige bei STD Absenz unterdrucken
//                Tooltip BAUNAME - PROJEKTNAME  am EB �bersicht anzeigen (Quick-Info)
//
//=============== V1.0.0047 ===============================================
//
// Date         : 13.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-44
//                Erweiterung der Pr�fung auf kontierbares PS-Element mit 
//                Erlaubnis zur Kostenkontierung "KONT"
// Defect#      : TAPM-45
//                B&I CarveOut
//
//=============== V1.0.0041 ===============================================
//
// Date         : 21.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6060
//                KFMBemerkungsfeld angedrucken
//
// Date         : 19.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6014
//                Bemerkungsfeld wird mehrmals angedruckt
//
//=============== V1.0.0038 ===============================================
//
// Date         : 19.M�rz 2008
// Author       : Joldic Dzevad
// Defect#      : 5940
//                Zulage bei ZA ganzt�gig bei B&I (MG) 
//
//=============== V1.0.0036 ===============================================
//
// Date         : 11.Dezember 2007
// Author       : Joldic Dzevad
// Defect#      : 5706
//                Summe Absenz & GK-Stunden im Einsatzbericht falsch
//
//=============== V1.0.0035 ===============================================
//
// Date         : 06.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5589
//                Benutzerdaten im Kopf nicht mehrmals versorgen
//
//--------------- V1.0.0034 -----------------------------------------------
//
// Date         : 23.Oktober 2007
// Author       : Wolfgang Patrman
// Defect#      : 5569
//                Anzeige Benutzerdaten im Kopf, wird im IE mit angedruckt
//
//--------------- V1.0.0033 ---------------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 16.August 2007
// Author       : Adam Kiefer
// Defect#      : 5355,5373
//                Exception bei Erfassen von Barauslage zu bereits geschl. Projekt
//                Projekt nicht mehr sichtbar
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 09.August 2007
// Author       : Adam Kiefer
// Defect#      : 5367
//                Wenn nur GK-Stunden wird Arbeitszeit  immer rot markiert (auch <= 10)
//
//--------------- V1.0.0029 ---------------------------------------------------
//
// Date         : 18.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 4083, 5215
//                Lohnarten bei SEG-Zulagen, Einsatzbericht - Anzeige SEG Punkte
//
//--------------- V1.0.0029 ---------------------------------------------------
//
// Date         : 25.Juni 2007
// Author       : Adam Kiefer
// Defect#      : 4678
//                Hinweis bei Arbeitszeiten mehr als 10 stunden
//
//--------------- V1.0.0024 ---------------------------------------------------
//
// Date         : 17.April 2007
// Author       : CL
// Defect#      : 4728
//                Zus�tzliche Anzeige der Personalnummer im Seitenkopf
//
//--------------- V1.0.0024 ---------------------------------------------------
//
// Date         : 02. April 2007
// Author       : CL
// Defect#      : 4756
//                Applikationseigene 'Zur�ck'-Funktionalit�t:
//                Ansicht / �nderung einzelner Einsatzbericht, danach zur�ck
//                zur Zeiten�bersicht.
//
//--------------- V1.0.0004 ---------------------------------------------------
//
// Date         : 31.Dezember 2006
// Author       : Caleb Gebhardt
// Defect#      : 3392
//                Bemerkung aus Einsatzbericht dem Genehmiger beim Genehmigen anzeigen
//
//-----------------------------------------------------------------------------

using System;
using System.Data;
//***
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;
using System.Diagnostics;
using System.Collections.Generic;

public partial class Genehmigung_KG_Zeiten : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    dbKG_Monat KGMonat;
    DateTime timer = ParamVal.Date0;
    ArrayList auftrnrs = new ArrayList();

    string Argument = "";

    protected void Page_PreRender(object sender, EventArgs e)
    {
        /*
        Debug.WriteLine("KG_Zeiten:Page_PreRender start at " + DateTime.Now.ToLongTimeString());
        LabelTimer.Text = "Diese Seite ist in " + new TimeSpan(DateTime.Now.Ticks - timer.Ticks).Seconds + " Sekunden aufgebaut";
        DateTime dtbeginn = (DateTime)Session["GenehmigungsDauer"];
        LabelGesamtDauer.Text = "Gesamtdauer bis jetzt ist " + new TimeSpan(DateTime.Now.Ticks - dtbeginn.Ticks).TotalSeconds + " Sekunden.";
        Debug.WriteLine("KG_Zeiten:Page_PreRender end at " + DateTime.Now.ToLongTimeString());
         */
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Debug.WriteLine("KG_Zeiten:PageLoad Beginn at " + DateTime.Now.ToLongTimeString());
        timer = DateTime.Now;
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        KGMonat = (dbKG_Monat)Session["KGMonat"];
        Session["fromAZM"] = false;
        auftrnrs = new ArrayList();
        Dictionary<string, float> roteLohnarten = new Dictionary<string, float>();  
        /* Beginn Defect # 4756: Falls diese Zeiten�bersicht mittels des
         * 'Zur�ck'-Buttons in der EB-Einzelansicht aufgerufen wurde, m�ssen
         * die Einsatzberichtsdaten neuerlich gelesen werden, damit der
         * Genehmiger eine aktuelle Datenansicht erh�lt.
         * */
        // KGMonat.Tage = null; // Defect # 4756: Verursacht falsche Pausenberechnung
        try
        {
            if (Session["BackFromEB"] == null)
            {
                Session["BackFromEB"] = false;
            }
        }
        catch (Exception ex)
        {
            string strErrorMessage = ex.Message;
        }

        bool blnBackFromEB = (bool)Session["BackFromEB"];
        if (blnBackFromEB)
        {
            Session["BackFromEB"] = false;  // Reset flag
            int intPerskey = (int)(KGMonat.Monteur.Params.PERSKEY.Value);
            int intBerMon = KGMonat.Monteur.BerichtsMonat;
            dbBearbeiter Monteur = new dbBearbeiter(intPerskey);
            Monteur.Select(false);
            Monteur.BerichtsMonat = intBerMon;
            KGMonat = new dbKG_Monat(Monteur, intBerMon);
            KGMonat.Genehmiger = Bearbeiter.BearbInRole;
            Session["KGMonat"] = (dbKG_Monat)KGMonat;
        }
        // Ende Defect # 4756

        bool bSAPObjValid = true;
        string statusErrTxt = "";
        LabelError.Visible = false;
        BtnNext.Enabled = true;

        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Kontrolle & Genehmigung - Einsatzberichte</span><br /><span style=\"font-size: 12px;\">";
            Session["headData"] += KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
            // Defect 5569, Mitarbeiterinformationen anzeigen
            lbHeadInfo.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString(); // Defect 5589
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        // Beginn Defect # 4728: Zus�tzliche Anzeige der Personalnummer
        //Label2.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
        // Ende Defect # 4728
        //KMS xxxxxx - alte PostBackInsteadPageLoad abfragen l�schen weil diese funktionieren seit ein paar Versionen
        //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
        //{
        phAZListe.Controls.Add(AZListeNeu());
        //}
        //else
        //{
        //    phAZListe.Controls.Add(AZListe());
        //}

        foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
        {
            if (!mb.Projekt.KontierbarInSAP())
            {
                statusErrTxt += mb.Projekt.Params.KTOBJ.Value.ToString() + " ";
                if (bSAPObjValid) bSAPObjValid = false;
            }
        }

        if (!bSAPObjValid)
        {
            LabelError.Text = "Folgendes nicht bebuchbares Objekt ist diesem Einsatzbericht zugeordnet, " +
                               "daher Abbruch der Bearbeitung : " + statusErrTxt;
            LabelError.Visible = true;
            BtnNext.Enabled = false;
        }
        phAusZu.Controls.Add(AusZulageListe(ref roteLohnarten));
        phSEG.Controls.Add(SEGListe());
        // Defect 3392
        // Control eingef�gt um die Bemerkung aus dem Einsatzbericht dem Genehmiger anzuzeigen
        phBemerkung.Controls.Add(BemerkungfuerGenehmiger());
        //Defect #6060 - KFMBemerkung
        phKfmBemerkung.Controls.Add(KfmBemerkungfuerGenehmiger());

        if (roteLohnarten.Count > 0)
        {
            string ask = "Achtung !!! \\n";
            foreach( string s in roteLohnarten.Keys )
            {
                ask += "Anzahl der Zulage " + s + " hat ihre Obergrenze von " + roteLohnarten[s].ToString() + " �berschrieten.\\n";
            }
            ask += "Wollen Sie trotzdem weiter gehen ?";
            this.BtnNext.Attributes.Add("onclick", "if( confirm('"+ ask + "')){ DisableButton(); return true;} else return false;");
        }
        else
        {
            BtnNext.Click -= new EventHandler(BtnNext_Click);
            BtnNext.PostBackUrl = "~/Genehmigung/KG_PostBackPage.aspx?Command=GoToAZM&Argument=" + KGMonat.IstFremdPersonal.ToString();
            //this.LinkButton1.PostBackUrl = "~/Genehmigung/KG_PostBackPage.aspx?Command=GoToAZM&Argument=" + KGMonat.IstFremdPersonal.ToString();
            BtnNext.Attributes.Add("onclick", "DisableButton()");
        }
        if (KGMonat.IstFremdPersonal)
            BtnNext.Text = ">> o.k., weiter zur Arbeitszeit�bersicht";
        else
            BtnNext.Text = ">> o.k., weiter zur Reiseabrechnung";
        
        Debug.WriteLine("KG_Zeiten:PageLoad Ende at " + DateTime.Now.ToLongTimeString());
    }

    private Table AZListeNeu()
    {
        Table tab = new Table();
        tab.Width = Unit.Percentage(100);
        TableRow rh = new TableRow();
        string xss = "TabHeader";
        rh = AddNewCell(rh, "Datum", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "NormStd", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "50%", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "100%", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "davon GK", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "LA", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "AuftragNr/Abs.", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Auslagen", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Anzahl", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Betrag", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "", xss, HorizontalAlign.Center);
        rh.Cells[rh.Cells.Count - 1].ColumnSpan = 2;
        tab.Rows.Add(rh);
        // Begin Defect #5706
        // double Summestdabs = 0;
        double summeNormStd = 0; // im Monat
        double summe50 = 0; // im Monat
        double summe100 = 0; // im Monat
        double summeGK = 0; // im Monat
        double tsummeNormStd = 0; // am Tag
        double tsumme50 = 0; // am Tag
        double tsumme100 = 0; // am Tag
        double tsummeGK = 0; // am Tag
        int anzahlZAGT = 0; // Defect #5940 - Anzahl der ZA Tagen errechnen

        DateTime dtVon = KGMonat.MinDatum;
        DateTime dtBis = KGMonat.MaxDatum.Date;
        ArrayList tZeilen = new ArrayList();
        ArrayList tRAzeilen = new ArrayList();
        

        string sql =
            // BAF 530037 - a.beginn hinzuf�gt damit man alle Stunden auswerten (Union blokt doppelte eintr�ge)
            "select 'KV' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, '' ,null, null, null, a.ebid, s.stdabsenztxt, '', '', a.beginn " +
            "from arbzeit a " + Config.Nolock + "join einsber e " + Config.Nolock + " on e.perskey = @pk and e.bermon = @dt and e.ebid = a.ebid " +
            "join y_stdabsenz s " + Config.Nolock + " on a.stdabsenzid = s.stdabsenzid where a.stdabsenzid = 120 " +
            "union " +
            //"select 'GK' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, a.leistart ,null, null, null, a.ebid, s.stdabsenztxt " +
            //"select 'GK' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, '' ,null, null, null, a.ebid, s.stdabsenztxt, '', '' " +
            // BAF 530037 - a.beginn hinzuf�gt damit man alle Stunden auswerten (Union blokt doppelte eintr�ge)
            "select 'GK' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, '' ,null, null, null, a.ebid, s.stdabsenztxt, '', '', a.beginn " +
            "from arbzeit a " + Config.Nolock + "join einsber e " + Config.Nolock + " on e.perskey = @pk and e.bermon = @dt and e.ebid = a.ebid " +
            "join y_stdabsenz s " + Config.Nolock + " on a.stdabsenzid = s.stdabsenzid where a.stdabsenzid = 10 or a.stdabsenzid = 100 " +
            "union " +
            //"select 'ZA' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, a.leistart ,null, null, null, a.ebid, s.stdabsenztxt " +
            //"select 'ZA' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, '' ,null, null, null, a.ebid, s.stdabsenztxt, '', ''" +
            "select 'ZA' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, '' ,null, null, null, a.ebid, s.stdabsenztxt, '', '', a.beginn " +
            "from arbzeit a " + Config.Nolock + "join einsber e " + Config.Nolock + " on e.perskey = @pk and e.bermon = @dt and e.ebid = a.ebid " +
            "join y_stdabsenz s " + Config.Nolock + " on a.stdabsenzid = s.stdabsenzid where a.stdabsenzid = 110 " +
            "union " +
            //"select 'ER' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, a.leistart ,null, null, null, a.ebid, s.stdabsenztxt " +
            //"select 'ER' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, '' ,null, null, null, a.ebid, s.stdabsenztxt, '', '' " +
            "select 'ER' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, '' ,null, null, null, a.ebid, s.stdabsenztxt, '', '', a.beginn " +
            "from arbzeit a " + Config.Nolock + "join einsber e " + Config.Nolock + " on e.perskey = @pk and e.bermon = @dt and e.ebid = a.ebid " +
            "join y_stdabsenz s " + Config.Nolock + " on a.stdabsenzid = s.stdabsenzid where a.stdabsenzid = 90 " +
            "union " +
            "select 'AZ' as art, a.datum as datum, a.normstd, a.uestd50, a.uestd100, a.kzaz, a.auftrnr, a.leistart ,null, null, null, a.ebid, null " +
            //", bp.name, bau.name " +
            ", bp.name, bau.name, a.beginn " + 
            "from arbzeit a " + Config.Nolock + " join einsber e " + Config.Nolock + " on e.perskey = @pk and e.bermon = @dt and e.ebid = a.ebid " +
            "join bauprojekt bp " + Config.Nolock + " on bp.projid = e.projid " + 
            "join baustelle bau " + Config.Nolock + " on bau.bauid = bp.bauid " +
            "where a.stdabsenzid = 0 " + 
            "union " +
            //"select 'GT' as art, k.datum as datum, null, null, null, null, g.gtabsenztxt,null,null, null , null, k.ebid, null, '', '' " +
            "select 'GT' as art, k.datum as datum, null, null, null, null, g.gtabsenztxt,null,null, null , null, k.ebid, null, '', '', null " +
            "from kaltag k " + Config.Nolock + " join y_gtabsenz g " + Config.Nolock + " on g.gtabsenzid = k.gtabsenzid " +
            "where k.perskey = @pk and k.datum >=  @dt and k.datum <  @dt2 " +
            "union " +
            //"select 'RA' as art, r.datum as datum, null, null,null,null,null,null, y.rakztxt, r.anzahl, r.betrag, r.ebid, null, '', '' " +
            "select 'RA' as art, r.datum as datum, null, null,null,null,null,null, y.rakztxt, r.anzahl, r.betrag, r.ebid, null, '', '', null " + 
            "from raauslage r " + Config.Nolock + " join y_rakz y " + Config.Nolock + " on y.rakzid = 'AAI' and y.rakz = r.rakz " +
            "where r.datum >=  @dt and r.datum <  @dt2 and r.perskey = @pk order by datum";
        //BAF 530037 Ende

        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand(sql, cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@pk", KGMonat.Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@dt", KGMonat.MinDatum));
                    cmd.Parameters.Add(new SqlParameter("@dt2", KGMonat.MaxDatum));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();
                        bool tagErfasst = false;
                        int nAzeit = 0;
                        while (rd.Read())
                        {
                            string tooltip = "";
                            try
                            {
                                tooltip = rd.GetString(13) + " - " + rd.GetString(14);
                            }
                            catch
                            {
                            }
                            while (dtVon < rd.GetDateTime(1))
                            {
                                if (tagErfasst)
                                {
                                    //Summe Schreiben
                                    if (nAzeit > 1)
                                    {
                                        tZeilen.Add(new tZeile(ParamVal.Date0, tsummeNormStd.ToString("N"), tsumme50.ToString("N"), tsumme100.ToString("N"), tsummeGK.ToString("N"), "", "", "", "", ""));
                                        (tZeilen[tZeilen.Count - 1] as tZeile).Datum = "Summe";
                                    }
                                    while (tZeilen.Count > tRAzeilen.Count)
                                    {
                                        tRAzeilen.Add(new AZeile("", "", "", "", ""));
                                    }
                                    while (tRAzeilen.Count > tZeilen.Count)
                                    {
                                        tZeilen.Add(new tZeile(ParamVal.Date0, "", "", "", "", "", "", "", "", ""));
                                    }
                                    for (int i = 0; i < tZeilen.Count; i++)
                                    {
                                        tab.Rows.Add(AddOneNewRow((tZeile)tZeilen[i], (AZeile)tRAzeilen[i], i, dtVon, nAzeit));
                                    }
                                    dtVon = dtVon.AddDays(1);
                                    tagErfasst = false;
                                }
                                else
                                {
                                    tZeilen.Add(new tZeile(dtVon.Date, "", "", "", "", "", "", "", "", ""));
                                    tRAzeilen.Add(new AZeile("", "", "", "", ""));
                                    tab.Rows.Add(AddOneNewRow((tZeile)tZeilen[0], (AZeile)tRAzeilen[0], 0, dtVon.Date, 0));
                                    dtVon = dtVon.AddDays(1);
                                }
                                //Listen leeren
                                nAzeit = 0;
                                tsummeNormStd = 0;
                                tsumme50 = 0;
                                tsumme100 = 0;
                                tsummeGK = 0;
                                tZeilen.Clear();
                                tRAzeilen.Clear();
                            }
                            double nStd = rd.IsDBNull(2) ? 0 : Convert.ToDouble(rd.GetInt16(2)) / 60;
                            double ue50Std = rd.IsDBNull(3) ? 0 : Convert.ToDouble(rd.GetInt16(3)) / 60;
                            double ue100Std = rd.IsDBNull(4) ? 0 : Convert.ToDouble(rd.GetInt16(4)) / 60;
                            double summe = nStd + ue50Std + ue100Std;

                            //if( KGMonat.Monteur.Commons.GK_Auftrag
                            string art = rd.GetString(0);
                            if (!"ZA,GT,RA".Contains(art))
                            {
                                summeNormStd += nStd;
                                summe50 += ue50Std;
                                summe100 += ue100Std;
                                tsummeNormStd += nStd;
                                tsumme50 += ue50Std;
                                tsumme100 += ue100Std;
                                foreach (ValuePair vp in KGMonat.Monteur.Commons.GK_Auftrag)
                                {
                                    if (vp.Value == rd.GetString(6))
                                    {
                                        art = "GK";
                                        break;
                                    }
                                }
                                /*if(!rd.IsDBNull(6) && lAuftragNrs.BinarySearch(rd.GetString(6)) == -1)
                                {
                                    lAuftragNrs.Add(rd.GetString(6));
                                }*/
                            }

                            if ("GK".Contains(art))
                            {
                                tsummeGK += summe;
                                summeGK += summe;
                            }

                            switch (art)
                            {
                                case "ZA":
                                    tZeilen.Add(new tZeile(dtVon.Date, "", "", "", "", "", rd.IsDBNull(12) ? "" : rd.GetString(12), rd.GetInt32(11).ToString(), "", ""));
                                    nAzeit++;
                                    break;
                                case "KV":
                                    tZeilen.Add(new tZeile(dtVon.Date, nStd.ToString("N"), ue50Std.ToString("N"), ue100Std.ToString("N"), "", rd.IsDBNull(7) ? "" : rd.GetString(7), rd.GetString(12), rd.GetInt32(11).ToString(), "", ""));
                                    nAzeit++;
                                    break;
                                case "GK":
                                    if( rd.IsDBNull(12) )
                                        tZeilen.Add(new tZeile(dtVon.Date, nStd.ToString("N"), ue50Std.ToString("N"), ue100Std.ToString("N"), summe.ToString("N"), rd.IsDBNull(7) ? "" : rd.GetString(7), rd.IsDBNull(6) ? "" : rd.GetString(6), rd.GetInt32(11).ToString(), tooltip, ""));
                                    else
                                        tZeilen.Add(new tZeile(dtVon.Date, nStd.ToString("N"), ue50Std.ToString("N"), ue100Std.ToString("N"), summe.ToString("N"), rd.IsDBNull(7) ? "" : rd.GetString(7), rd.GetString(12), rd.GetInt32(11).ToString(), "", ""));
                                    tagErfasst = true;
                                    nAzeit++;
                                    break;
                                case "ER":
                                    tZeilen.Add(new tZeile(dtVon.Date, nStd.ToString("N"), ue50Std.ToString("N"), ue100Std.ToString("N"), "", rd.IsDBNull(7) ? "" : rd.GetString(7), rd.IsDBNull(12) ? "" : rd.GetString(12), rd.GetInt32(11).ToString(), "", ""));
                                    tagErfasst = true;
                                    nAzeit++;
                                    break;
                                case "AZ":
                                    tZeilen.Add(new tZeile(dtVon.Date, nStd.ToString("N"), ue50Std.ToString("N"), ue100Std.ToString("N"), "", rd.IsDBNull(7) ? "" : rd.GetString(7), rd.IsDBNull(6) ? "" : rd.GetString(6), rd.GetInt32(11).ToString(), tooltip, ""));
                                    tagErfasst = true;
                                    nAzeit++;
                                    break;
                                case "GT":
                                    if (!rd.IsDBNull(6) && rd.GetString(6) == "ZA ganzt�gig") anzahlZAGT++; 
                                    tZeilen.Add(new tZeile(dtVon.Date, "", "", "", "", "", rd.IsDBNull(6) ? "" : rd.GetString(6), rd.IsDBNull(11) ? "" : rd.GetInt32(11).ToString(), "", ""));
                                    tRAzeilen.Add(new AZeile("", "", "", "", ""));
                                    tab.Rows.Add(AddOneNewRow((tZeile)tZeilen[0], (AZeile)tRAzeilen[0], 0, dtVon.Date, 0));
                                    tZeilen.Clear();
                                    tRAzeilen.Clear();
                                    tagErfasst = true;
                                    break;
                                case "RA":
                                    //TT -6654245 -> use decimal instead of GetDouble
                                    //tRAzeilen.Add(new AZeile(rd.IsDBNull(8) ? "" : rd.GetString(8), rd.IsDBNull(9) ? "" : rd.GetDouble(9).ToString("N"), rd.IsDBNull(10) ? "" : rd.GetDouble(10).ToString("N"), rd.IsDBNull(11) ? "" : rd.GetInt32(11).ToString(), tooltip));
                                    tRAzeilen.Add(new AZeile(rd.IsDBNull(8) ? "" : rd.GetString(8), rd.IsDBNull(9) ? "" : rd.GetDouble(9).ToString("N"), rd.IsDBNull(10) ? "" : rd.GetDecimal(10).ToString("N"), rd.IsDBNull(11) ? "" : rd.GetInt32(11).ToString(), tooltip));
                                    break;
                                default:
                                    break;
                            }
                        }
                        //letzte Zeile gelesen f�hlen bis ende des Montas
                        do
                        {
                            if (tagErfasst)
                            {
                                //Summe Schreiben
                                if (nAzeit > 1)
                                {
                                    tZeilen.Add(new tZeile(ParamVal.Date0, tsummeNormStd.ToString("N"), tsumme50.ToString("N"), tsumme100.ToString("N"), tsummeGK.ToString("N"), "", "", "", "", ""));
                                    (tZeilen[tZeilen.Count - 1] as tZeile).Datum = "Summe";
                                }
                                while (tZeilen.Count > tRAzeilen.Count)
                                {
                                    tRAzeilen.Add(new AZeile("", "", "", "", ""));
                                }
                                while (tRAzeilen.Count > tZeilen.Count)
                                {
                                    tZeilen.Add(new tZeile(ParamVal.Date0, "", "", "", "", "", "", "", "", ""));
                                }
                                for (int i = 0; i < tZeilen.Count; i++)
                                {
                                    tab.Rows.Add(AddOneNewRow((tZeile)tZeilen[i], (AZeile)tRAzeilen[i], i, dtVon, nAzeit));
                                }
                                tagErfasst = false;
                            }
                            else
                            {
                                tZeilen.Clear();
                                tRAzeilen.Clear();
                                tZeilen.Add(new tZeile(dtVon.Date, "", "", "", "", "", "", "", "", ""));
                                tRAzeilen.Add(new AZeile("", "", "", "", ""));
                                tab.Rows.Add(AddOneNewRow((tZeile)tZeilen[0], (AZeile)tRAzeilen[0], 0, dtVon.Date, 0));
                            }
                            dtVon = dtVon.AddDays(1);

                        } while (dtVon <= dtBis);
                        //nun noch gesamt Summe
                        tZeile tz = new tZeile(ParamVal.Date0,
                                    summeNormStd.ToString("N"),
                                    summe50.ToString("N"),
                                    summe100.ToString("N"),
                                    summeGK.ToString("N"),
                                    "= " + (summeNormStd + summe50 + summe100).ToString("N"),
                                    "", "", "", "");
                        // Ende Defect #5706
                        tz.Datum = "Summe";
                        AZeile az2 = new AZeile("", "", "", "", "");
                        //tab.Rows.Add(AddOneNewRow(tz, az2, 0, DateTime.Now, 1));
                        tab.Rows.Add(AddOneNewRow(tz, az2, 0, dtBis, 1));
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        if (KGMonat.Genehmiger.Mandant.MANDANT == "MG")
        {
            bool zulageVorhanden = false;
            foreach (dbKG_AusZulProjekt zulageProjekt in KGMonat.AusZulagenProjekte)
            {
                foreach (dbKG_PMAusZulage zulageBericht in zulageProjekt.AusZulagen)
                {
                    //if (zulageBericht.Lohnart == "9310")
                    if (zulageBericht.Lohnart == "3700")
                    {
                        // zulage 9310 ist als Aus/zulage vorhanden, entfernen von SEGListe, falls vorhanden
                        // zulage 3700 ist als Aus/zulage vorhanden, entfernen von SEGListe, falls vorhanden
                        foreach (dbKG_SEGZulage seg in KGMonat.SEGZulagen)
                        {
                            if (seg.lohnArt == "3700") //if (seg.lohnArt == "9310")
                            {
                                KGMonat.SEGZulagen.Remove(seg);
                                break;
                            }
                        }
                        zulageVorhanden = true;
                        break;
                    }
                }
            }
            if (!zulageVorhanden)
            {
                // suchen nach '9310' in SEG Liste
                foreach (dbKG_SEGZulage seg in KGMonat.SEGZulagen)
                {
                    if (seg.lohnArt == "3700") //if (seg.lohnArt == "9310")
                    {
                        zulageVorhanden = true;
                        // falls vorhanden, aktualisieren anzahl der Tagen
                        if (anzahlZAGT == 0)
                            KGMonat.SEGZulagen.Remove(seg);
                        else
                            seg.AnzTage = anzahlZAGT;
                        break;
                    }
                }
                if (!zulageVorhanden && anzahlZAGT > 0)
                {
                    // falls '9310' noch noch nicht inder SEG Liste ist
                    dbMontBer montBer = (dbMontBer)KGMonat.Monteur.MBerichte[0];
                    dbKG_SEGZulage segZulage = new dbKG_SEGZulage(montBer);
                    segZulage.lohnArt = "3700";  //segZulage.lohnArt = "9310";
                    segZulage.AnzTage = anzahlZAGT;
                    segZulage.Perskey = Convert.ToInt32(KGMonat.Genehmiger.Params.PERSKEY.Value);
                    KGMonat.SEGZulagen.Add(segZulage);
                }
            }
            // Ende Defect #5940
        }
        return tab;
    }

    private class tZeile
    {
        public string Datum;
        public string NormStd;
        public string Ue50;
        public string Ue100;
        public string GK;
        public string Lohnart;
        public string Argument;
        // Beginn #5355,5373 - Exception bei Erfassen von Barauslage zu bereits geschl. Projekt
        public string KTOBJ;
        public DateTime Full_Datum;
        // Ende #5355,5373

        public string AuftrNr;
        public string ToolTip;

        // Beginn #5355,5373 - Exception bei Erfassen von Barauslage zu bereits geschl. Projekt
        public tZeile(DateTime datum, string normstd, string ue50, string ue100, string gk, string lohnart, string auftrnr, string argument, string tooltip, string ktobj)
        // Ende #5355,5373
        {
            if (datum.Ticks != ParamVal.Date0.Ticks)
            {
                string[] wTag = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa." };
                Datum = wTag[(int)datum.DayOfWeek] + " " + datum.Day.ToString() + "." + datum.Month.ToString() + ".";
            }
            else
                Datum = "";
            NormStd = normstd;
            Ue50 = ue50;
            Ue100 = ue100;
            GK = gk;
            Lohnart = lohnart;
            AuftrNr = auftrnr;
            Argument = argument;
            // Beginn #5355,5373 - Exception bei Erfassen von Barauslage zu bereits geschl. Projekt
            KTOBJ = ktobj;
            Full_Datum = datum;
            // Ende #5355,5373
            ToolTip = tooltip;
        }

    }
    private class AZeile
    {
        public string Auslage = "";
        public string Anzahl = "";
        public string Betrag = "";
        public string Argument = "";
        public string ToolTip = "";

        public AZeile(string auslage, string anzahl, string betrag, string argument, string tooltip)
        {
            Auslage = auslage;
            Anzahl = anzahl;
            Betrag = betrag;
            Argument = argument;
            ToolTip = tooltip;
        }
    }

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align)
    {
        TableCell c = new TableCell();
        Label l = new Label();
        l.Text = LabelText;
        l.Font.Bold = true;
        c.Controls.Add(l);
        c.CssClass = css;
        c.HorizontalAlign = align;
        r.Cells.Add(c);
        return r;
    }

    private Table AZListe()
    {
        Table tab = new Table();
        tab.Width = Unit.Percentage(100);
        TableRow rh = new TableRow();
        string xss = "TabHeader";
        rh = AddNewCell(rh, "Datum", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "NormStd", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "50%", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "100%", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "davon GK", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "LA", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "AuftragNr/Abs.", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Auslagen", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Anzahl", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "Betrag", xss, HorizontalAlign.Center);
        rh = AddNewCell(rh, "", xss, HorizontalAlign.Center);
        rh.Cells[rh.Cells.Count - 1].ColumnSpan = 2;
        tab.Rows.Add(rh);
        // Begin Defect #5706
        // double Summestdabs = 0;
        double summeNormStd = 0; // im Monat
        double summe50 = 0; // im Monat
        double summe100 = 0; // im Monat
        double summeGK = 0; // im Monat
        int anzahlZAGT = 0; // Defect #5940 - Anzahl der ZA Tagen errechnen
        foreach (dbKG_Tag t in KGMonat.Tage)
        {
            double SummeNormStd = 0; // am Tag
            double SummeGK = 0; // am Tag
            double Summe50 = 0; // am Tag
            double Summe100 = 0; // am Tag           
            // Summestdabs += t.StdAbsenz;
            int nAzeit = 0;

            ArrayList tZeilen = new ArrayList();
            ArrayList tRAzeilen = new ArrayList();
            foreach (dbKG_EB e in t.EBerichte)
            {
                foreach (dbKG_RATag ra in e.ReiseAusl)
                {
                    tRAzeilen.Add(new AZeile(ra.Auslagenart, ra.Anzahl.ToString("N"), ra.Betrag.ToString("N"), e.MBericht.Params.EBID.Value.ToString(), e.MBericht.Projekt.Params.NAME.Value.ToString() + " - " + e.MBericht.Projekt.Baustelle.Params.NAME.Value.ToString()));
                }
                foreach (object obj in e.ArbZeit)
                {
                    if (obj is dbKG_AZTag)
                    {
                        dbKG_AZTag az = (dbKG_AZTag)obj;
                        SummeNormStd += az.NormStunden;
                        if (az.GK != 0)
                        {
                            SummeNormStd += az.GK - az.NormStunden - az.UE100 - az.UE50;
                        }
                        SummeGK += az.GK;
                        Summe50 += az.UE50;
                        Summe100 += az.UE100;
                        tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), az.UE50.ToString("N"), az.UE100.ToString("N"), az.GK.ToString("N"), az.Lohnart, az.Auftrag, e.MBericht.Params.EBID.Value.ToString(), e.MBericht.Projekt.Params.NAME.Value.ToString() + " - " + e.MBericht.Projekt.Baustelle.Params.NAME.Value.ToString(), e.MBericht.Projekt.Params.KTOBJ.Value.ToString()));
                        if (az.Auftrag == "ZA ganzt�gig")
                            anzahlZAGT++;
                        nAzeit++;
                    }
                    if (obj is dbKG_AZTagSTDAbsenz)
                    {
                        dbKG_AZTagSTDAbsenz az = (dbKG_AZTagSTDAbsenz)obj;
                        SummeNormStd += az.NormStunden;
                        switch (az.StdAbsID)
                        {
                            case "10":
                                SummeGK += az.NormStunden;
                                tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), "", "", az.NormStunden.ToString("N"), "", az.StdAbsTxt, e.MBericht.Params.EBID.Value.ToString(), e.MBericht.Projekt.Params.NAME.Value.ToString() + " - " + e.MBericht.Projekt.Baustelle.Params.NAME.Value.ToString(), e.MBericht.Projekt.Params.KTOBJ.Value.ToString()));
                                break;
                            case "90":
                                tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), "", "", "", "", az.StdAbsTxt, e.MBericht.Params.EBID.Value.ToString(), e.MBericht.Projekt.Params.NAME.Value.ToString() + " - " + e.MBericht.Projekt.Baustelle.Params.NAME.Value.ToString(), e.MBericht.Projekt.Params.KTOBJ.Value.ToString()));
                                break;
                            case "100":
                                SummeGK += az.NormStunden;
                                tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), "", "", az.NormStunden.ToString("N"), "", az.StdAbsTxt, e.MBericht.Params.EBID.Value.ToString(), e.MBericht.Projekt.Params.NAME.Value.ToString() + " - " + e.MBericht.Projekt.Baustelle.Params.NAME.Value.ToString(), e.MBericht.Projekt.Params.KTOBJ.Value.ToString()));
                                break;
                            case "110":
                            default:
                                SummeNormStd -= az.NormStunden;
                                tZeilen.Add(new tZeile(t.TagesDatum, "", "", "", "", "", az.StdAbsTxt, e.MBericht.Params.EBID.Value.ToString(), e.MBericht.Projekt.Params.NAME.Value.ToString() + " - " + e.MBericht.Projekt.Baustelle.Params.NAME.Value.ToString(), e.MBericht.Projekt.Params.KTOBJ.Value.ToString()));
                                break;
                        }
                        // tZeilen.Add(new tZeile(t.TagesDatum, az.NormStunden.ToString("N"), "", "", "", "", az.StdAbsTxt, e.MBericht.Params.EBID.Value.ToString(), e.MBericht.Projekt.Params.NAME.Value.ToString() + " - " + e.MBericht.Projekt.Baustelle.Params.NAME.Value.ToString(), e.MBericht.Projekt.Params.KTOBJ.Value.ToString()));
                        nAzeit++;
                    }
                }

            }
            summeNormStd += SummeNormStd;
            summe50 += Summe50;
            summe100 += Summe100;
            summeGK += SummeGK;
            if (tZeilen.Count == 0)
            {//add 1 tZeile mit TagesDatum
                tZeilen.Add(new tZeile(t.TagesDatum, "", "", "", "", "", "", "", "", ""));
            }
            while (tRAzeilen.Count > tZeilen.Count)
            {
                tZeilen.Add(new tZeile(ParamVal.Date0, "", "", "", "", "", "", "", "", ""));
            }
            if (nAzeit > 1)
            {

                tZeilen.Add(new tZeile(ParamVal.Date0, SummeNormStd.ToString("N"), Summe50.ToString("N"), Summe100.ToString("N"), SummeGK.ToString("N"), "", "", "", "", ""));
                (tZeilen[tZeilen.Count - 1] as tZeile).Datum = "Summe";
            }
            while (tRAzeilen.Count < tZeilen.Count)
            {
                tRAzeilen.Add(new AZeile("", "", "", "", ""));
            }
            for (int i = 0; i < tZeilen.Count; i++)
            {
                tab.Rows.Add(AddOneNewRow((tZeile)tZeilen[i], (AZeile)tRAzeilen[i], i, t.TagesDatum, nAzeit));
            }
        }
        TableRow tr = new TableRow();
        //tZeile tz = new tZeile(ParamVal.Date0, KGMonat.NormStunden.ToString("N"), KGMonat.UE50.ToString("N"), KGMonat.UE100.ToString("N"), KGMonat.GK.ToString("N"), "= " + KGMonat.SummeProduktiveStunden.ToString("N"), "", "", "");
        //tZeile tz = new tZeile(ParamVal.Date0, KGMonat.NormStundenMitStdAbsenz.ToString("N"), KGMonat.UE50.ToString("N"), KGMonat.UE100.ToString("N"), KGMonat.GK.ToString("N"), "= " + KGMonat.SummeProduktiveStundenMitStdAbsenzen.ToString("N"), "", "", "", "");
        tZeile tz = new tZeile(ParamVal.Date0,
            summeNormStd.ToString("N"),
            summe50.ToString("N"),
            summe100.ToString("N"),
            summeGK.ToString("N"),
            "= " + (summeNormStd + summe50 + summe100).ToString("N"),
            "", "", "", "");
        // Ende Defect #5706
        tz.Datum = "Summe";
        AZeile az2 = new AZeile("", "", "", "", "");
        tab.Rows.Add(AddOneNewRow(tz, az2, 0, DateTime.Now, 1));

        //Defect #5940 - autogen von Zulage '9310' als SEG Zulage aber abgespeichert wird in DB als
        //ganz normale Aus/Zulage. Autogen von '9310' wird nur bei Mandant B&I (MG) gemacht. Alle anderen m�ssen
        //die Zulage beim Projekt definieren und im EB erfassen
        //Update 21.12.2009 - Nach Ausgliederung SAP 9310 wird zu DPW 3700
        if (KGMonat.Genehmiger.Mandant.MANDANT == "MG")
        {
            bool zulageVorhanden = false;
            foreach (dbKG_AusZulProjekt zulageProjekt in KGMonat.AusZulagenProjekte)
            {
                foreach (dbKG_PMAusZulage zulageBericht in zulageProjekt.AusZulagen)
                {
                    if (zulageBericht.Lohnart == "3700") //if (zulageBericht.Lohnart == "9310")
                    {
                        // zulage 9310 ist als Aus/zulage vorhanden, entfernen von SEGListe, falls vorhanden
                        foreach (dbKG_SEGZulage seg in KGMonat.SEGZulagen)
                        {
                            if (seg.lohnArt == "3700") //if (seg.lohnArt == "9310")
                            {
                                KGMonat.SEGZulagen.Remove(seg);
                                break;
                            }
                        }
                        zulageVorhanden = true;
                        break;
                    }
                }
            }
            if (!zulageVorhanden)
            {
                // suchen nach '9310' in SEG Liste
                // '9310' wird nicht mehr verwendet sonder '3700' 
                foreach (dbKG_SEGZulage seg in KGMonat.SEGZulagen)
                {
                    if (seg.lohnArt == "3700")  // if (seg.lohnArt == "9310")
                    {
                        zulageVorhanden = true;
                        // falls vorhanden, aktualisieren anzahl der Tagen
                        if (anzahlZAGT == 0)
                            KGMonat.SEGZulagen.Remove(seg);
                        else
                            seg.AnzTage = anzahlZAGT;
                        break;
                    }
                }
                if (!zulageVorhanden && anzahlZAGT > 0)
                {
                    // falls '9310' noch noch nicht inder SEG Liste ist
                    // falls '3700' noch noch nicht inder SEG Liste ist
                    dbMontBer montBer = (dbMontBer)KGMonat.Monteur.MBerichte[0];
                    dbKG_SEGZulage segZulage = new dbKG_SEGZulage(montBer);
                    segZulage.lohnArt = "3700";  //segZulage.lohnArt = "9310";
                    segZulage.AnzTage = anzahlZAGT;
                    segZulage.Perskey = Convert.ToInt32(KGMonat.Genehmiger.Params.PERSKEY.Value);
                    KGMonat.SEGZulagen.Add(segZulage);
                }
            }
            // Ende Defect #5940
        }

        return tab;
    }

    TableRow AddOneNewRow(tZeile tz, AZeile az, int ind, DateTime Tag, int linesInDay)
    {
        // Beginn #5367 - Wenn nur GK-Stunden wird Arbeitszeit  immer rot markiert (auch <= 10)
        // Beginn #4678 - Hinweis bei arbeitszeiten mehr als 10 stunden        
        double SummeStunden = 0;

        try
        {
            SummeStunden = Convert.ToDouble(tz.NormStd) + Convert.ToDouble(tz.Ue50) + Convert.ToDouble(tz.Ue100);
        }
        catch
        {
            SummeStunden = 0;
        }
        // Ende #4678
        // Ende #5367

        TableRow tr = new TableRow();

        Argument = tz.Argument;
        if ((tz.Datum.ToUpper().IndexOf("SUM") >= 0)) ind = 0;
        string strCssClassRow = (ind > 0 ? "TabZeile" + CssWE(Tag) : "TabNewDay" + CssWE(Tag));
        // Beginn #5367 - Wenn nur GK-Stunden wird Arbeitszeit  immer rot markiert (auch <= 10)
        // Beginn #4678 - Hinweis bei arbeitszeiten mehr als 10 stunden
        bool ueStunden = false;
        if (((SummeStunden > 10.0) && (linesInDay == 1) && (tz.Datum != "Summe")) || ((SummeStunden > 10.0) && (linesInDay > 1) && (tz.Datum == "Summe")))
        {
            ueStunden = true;
        }
        // Ende #4678
        // Ende #5367
        TableCell d1 = new TableCell();
        if (ind == 0) d1.Text = tz.Datum;
        d1.HorizontalAlign = HorizontalAlign.Center;
        d1.CssClass = strCssClassRow;
        tr.Cells.Add(d1);

        TableCell d2 = new TableCell();
        d2.Text = (tz.NormStd == "0,00" ? "" : tz.NormStd);
        d2.HorizontalAlign = HorizontalAlign.Center;
        // Beginn #5367 - Wenn nur GK-Stunden wird Arbeitszeit  immer rot markiert (auch <= 10)
        if (ueStunden)
            d2.CssClass = "TabNewDay_MAUe10St";
        // Ende #5367
        else
            d2.CssClass = strCssClassRow;
        tr.Cells.Add(d2);

        TableCell d3 = new TableCell();
        d3.Text = (tz.Ue50 == "0,00" ? "" : tz.Ue50);
        d3.HorizontalAlign = HorizontalAlign.Center;
        // Beginn #5367 - Wenn nur GK-Stunden wird Arbeitszeit  immer rot markiert (auch <= 10)
        if (ueStunden)
            d3.CssClass = "TabNewDay_MAUe10St";
        // Ende #5367
        else
            d3.CssClass = strCssClassRow;
        tr.Cells.Add(d3);

        TableCell d4 = new TableCell();
        d4.Text = (tz.Ue100 == "0,00" ? "" : tz.Ue100);
        d4.HorizontalAlign = HorizontalAlign.Center;
        // Beginn #5367 - Wenn nur GK-Stunden wird Arbeitszeit  immer rot markiert (auch <= 10)
        if (ueStunden)
            d4.CssClass = "TabNewDay_MAUe10St";
        // Ende #5367
        else
            d4.CssClass = strCssClassRow;
        tr.Cells.Add(d4);

        TableCell d5 = new TableCell();
        d5.Text = (tz.GK == "0,00" ? "" : tz.GK);
        d5.HorizontalAlign = HorizontalAlign.Center;
        // Beginn #5367 - Wenn nur GK-Stunden wird Arbeitszeit  immer rot markiert (auch <= 10)
        if (ueStunden)
            d5.CssClass = "TabNewDay_MAUe10St";
        // Ende #5367
        else
            d5.CssClass = strCssClassRow;
        tr.Cells.Add(d5);

        TableCell d6 = new TableCell();
        //d6.Text = a.Lohnart;
        if (tz.Lohnart != "")
        {
            if ((tz.Datum.ToUpper().IndexOf("SUM") >= 0)) d6.Text = tz.Lohnart;
            else
            {
                string toolt = "Eintrag bearbeiten";
                if (tz.ToolTip != "") toolt = tz.ToolTip;
                LinkButton lnkbtn = NewTaskButton(tz.Lohnart, "Edit", tz.Argument, toolt, TaskButton_Click);
                d6.Controls.Add(lnkbtn);
            }
        }
        else
            d6.Text = tz.Lohnart;
        d6.HorizontalAlign = HorizontalAlign.Center;
        d6.CssClass = strCssClassRow;
        tr.Cells.Add(d6);

        // Beginn #5355,5373 - Exception bei Erfassen von Barauslage zu bereits geschl. Projekt

        bool SAP_Kontierbar = false;
        string SAPFehlerMeldung = "SAP Fehler: Kont-Object existiert nicht!";

        #region CheckSAP-G�ltigkeit
        if ((ConfigurationManager.AppSettings["NoSAPUsage"] != null) || (tz.KTOBJ == ""))
        {
            SAP_Kontierbar = true;
        }
        else
        {
            if (auftrnrs.Contains(tz.KTOBJ.ToUpper()))
            {
                SAP_Kontierbar = true;
            }
            else
            {
                //string Err = "";
                string connStr = ConfigurationManager.AppSettings["SAPConnectionString"];
                //TAPM-45 ist ein SAPConnectionStringMx in Web.Config definiert, dann wird diese f�r
                //SAP Connection verwendet. Default ist SAPConnectionString.
                if (ConfigurationManager.AppSettings["SAPConnectionString" + KGMonat.Genehmiger.Mandant.MANDANT] != null)
                    connStr = ConfigurationManager.AppSettings["SAPConnectionString" + KGMonat.Genehmiger.Mandant.MANDANT];

                string Err = "";
                string Ktobj = "";
                string Inact = "";
                string Autyp = "";
                string Objid = "";
                string Belkz = "";

                try
                {
                    SAPconnector.SAPcheck.GetKontoInfo(connStr, tz.KTOBJ.ToUpper(), ref Err, ref Ktobj, ref Inact, ref Autyp, ref Objid, ref Belkz);
                    bool kont = true;
                    if (Objid == "PR" && Belkz == "")
                        kont = false;
                    if (Inact == "" && kont && Err == "00")
                    {
                        SAP_Kontierbar = true;
                        auftrnrs.Add(tz.KTOBJ.ToUpper());
                    }
                }
                catch (Exception ex)
                {
                    SAP_Kontierbar = false;
                    SAPFehlerMeldung = ex.Message;
                }
                //TAP_SAPProxy SapCon = new TAP_SAPProxy();
                //SapCon.Connection = SAP.Connector.SAPConnectionPool.GetConnectionFromPool(connStr);
                //SapCon.Connection.Open();
                //SIE_SSA_CS_KONT_TAPTable retTable = new SIE_SSA_CS_KONT_TAPTable();

                //try
                //{
                //    SapCon.Sie_Ssa_Cs_Check_Kont_Objects(tz.KTOBJ.ToUpper(), out Err, ref retTable);
                //}
                //finally
                //{
                //    SapCon.Connection.Close();
                //    SAP.Connector.SAPConnectionPool.ReturnConnection(SapCon.Connection);
                //}

                //foreach (SIE_SSA_CS_KONT_TAP x in retTable)
                //{
                //    //TAPM-44 - Belkz und Err zus�tlich �berpr�fen
                //    bool kont = true;
                //    if (x.Objid == "PR" && x.Belkz == "")
                //        kont = false;
                //    if (x.Objid != "" && kont && Err == "00")
                //    {
                //        SAP_Kontierbar = true;
                //        auftrnrs.Add(tz.KTOBJ.ToUpper());
                //    }
                //}

                //if (retTable.Count > 1)
                //{
                //    SAP_Kontierbar = false;
                //    SAPFehlerMeldung = "SAP Fehler: Eindeutigkeit bei Kont-Objekt nicht gegeben!";
                //}
            }
        }
        #endregion

        TableCell d7 = new TableCell();

        if (!SAP_Kontierbar) // Nicht g�ltiges Projekt
        {
            lbSAPFehler.Text = SAPFehlerMeldung;
            lbSAPFehler.Visible = true;
            if (tz.Lohnart != "")
            {
                string toolt = "Eintrag bearbeiten";
                if (tz.ToolTip != "") toolt = tz.ToolTip;
                LinkButton lnkbtn = NewTaskButton(tz.AuftrNr, "Edit", tz.Argument, toolt, TaskButton_Click);
                d7.Controls.Add(lnkbtn);
            }
            else d7.Text = tz.AuftrNr; //GTAbsenz.
            d7.HorizontalAlign = HorizontalAlign.Center;
            d7.CssClass = "TabNewDay_InvalidProject";
            tr.Cells.Add(d7);

            BtnNext.Enabled = false;
        }
        else // G�ltiges Projekt
        {
            if (tz.Lohnart != "")
            {
                string toolt = "Eintrag bearbeiten";
                if (tz.ToolTip != "") toolt = tz.ToolTip;
                LinkButton lnkbtn = NewTaskButton(tz.AuftrNr, "Edit", tz.Argument, toolt, TaskButton_Click);
                d7.Controls.Add(lnkbtn);
            }
            else
                d7.Text = tz.AuftrNr; //GTAbsenz.
            d7.HorizontalAlign = HorizontalAlign.Center;
            d7.CssClass = strCssClassRow;
            tr.Cells.Add(d7);
        }

        // Ende #5355,5373

        TableCell d8 = new TableCell();
        d8.HorizontalAlign = HorizontalAlign.Center;
        d8.CssClass = strCssClassRow;

        TableCell d9 = new TableCell();
        d9.HorizontalAlign = HorizontalAlign.Center;
        d9.CssClass = strCssClassRow;

        TableCell d10 = new TableCell();
        d10.HorizontalAlign = HorizontalAlign.Center;
        d10.CssClass = strCssClassRow;

        d8.Text = az.Auslage;
        d9.Text = az.Anzahl;
        d10.Text = az.Betrag;
        tr.Cells.Add(d8);
        tr.Cells.Add(d9);
        tr.Cells.Add(d10);

        TableCell d11 = new TableCell();
        if (az.Auslage != "")
        {
            string toolt = "Eintrag bearbeiten";
            if (az.ToolTip != "") toolt = az.ToolTip;
            LinkButton lnkbtn = NewTaskButton("bearbeiten", "Edit", az.Argument, toolt, TaskButton_Click);
            d11.Controls.Add(lnkbtn);
        }
        d11.HorizontalAlign = HorizontalAlign.Center;
        d11.CssClass = strCssClassRow;
        tr.Cells.Add(d11);

        tabAZListe.Rows.Add(tr);


        return tr;
    }


    private string CssWE(DateTime Tag)
    {
        //BAF 530042 Beginn
        if (KGMonat.Monteur.AZMKalenderTage.ContainsKey(Tag))
        {
            if (KGMonat.Monteur.AZMKalenderTage[Tag].IstArbeitstag)
                return "";
            else
                return "WE";
        }//BAF 530042 Ende
        else
        {
            if (KGMonat.Monteur.IstArbeitstag(Tag))
                return "";
            else
                return "WE";
        }
        //if (KGMonat.Monteur.IstArbeitstag(Tag)) return "";
        //else return "WE";
    }

    private Table AusZulageListe(ref Dictionary<string, float> roteLohnarten)
    {
        xxID = 100000;
        TableRow HeaderRow = new TableRow();

        TableCell c1 = new TableCell();
        c1.Text = "Aus/Zulage ";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Anzahl ";
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        TableCell c3 = new TableCell();
        c3.Text = "AuftragNr ";
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;

        TableCell c4 = new TableCell();
        c4.CssClass = "TabHeader";

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c4);

        tabAusZu.Rows.Add(HeaderRow);

        LinkButton lnkbtn;
        TableRow tr;
        Dictionary<string, float> gesAnzahlZulagen = new Dictionary<string, float>();
         

        foreach (dbKG_AusZulProjekt az in KGMonat.AusZulagenProjekte)
        {
            foreach (dbKG_PMAusZulage pm in az.AusZulagen)
            {
                if (gesAnzahlZulagen.ContainsKey(pm.Lohnart))
                    gesAnzahlZulagen[pm.Lohnart] += pm.Anzahl;
                else
                    gesAnzahlZulagen.Add(pm.Lohnart, pm.Anzahl);
                if (pm.MaxAnzahl > 0f && gesAnzahlZulagen[pm.Lohnart] > pm.MaxAnzahl && !roteLohnarten.ContainsKey(pm.Lohnart))
                {
                    roteLohnarten.Add(pm.Lohnart, pm.MaxAnzahl);
                }
            }
        }


        foreach (dbKG_AusZulProjekt az in KGMonat.AusZulagenProjekte)
        {
            bool isAusZuRepeat = false;
            string oldANr = "";
            Argument = az.MBericht.Params.EBID.Value.ToString();
            foreach (dbKG_PMAusZulage pm in az.AusZulagen)
            {
                if (oldANr == az.AuftragNr)
                    isAusZuRepeat = true;
                string strCssClassRow = (isAusZuRepeat ? "TabZeile" : "TabNewDay");
                tr = new TableRow();
                TableCell d1 = new TableCell();
                d1.Text = pm.Lohnart + " " + pm.Text + "&nbsp;";
                d1.HorizontalAlign = HorizontalAlign.Left;
                d1.CssClass = strCssClassRow;
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                //TextBox tb = new TextBox();
                //tb.Enabled = false;
                //tb.Width = 30;
                Label l = new Label();
                //tb.Text = (pm.Anzahl.ToString("N") == "0,00" ? "" : pm.Anzahl.ToString("N"));
                l.Text = (pm.Anzahl.ToString("N") == "0,00" ? "" : pm.Anzahl.ToString("N")) + "&nbsp;";
                d2.HorizontalAlign = HorizontalAlign.Center;
                //d2.Controls.Add(tb);
                d2.Controls.Add(l);
                d2.CssClass = strCssClassRow;
                tr.Cells.Add(d2);

                TableCell d3 = new TableCell();
                if (isAusZuRepeat)
                    d3.Text = "&nbsp;";
                else
                    d3.Text = az.AuftragNr + "&nbsp;";

                d3.CssClass = strCssClassRow;
                d3.HorizontalAlign = HorizontalAlign.Center;
                tr.Cells.Add(d3);

                TableCell d4 = new TableCell();
                lnkbtn = NewTaskButton("bearbeiten&nbsp;", "Edit", Argument, "Eintrag bearbeiten", TaskButton_Click);
                if (isAusZuRepeat)
                    d4.Text = "&nbsp;";
                else
                    d4.Controls.Add(lnkbtn);

                d4.HorizontalAlign = HorizontalAlign.Center;
                d4.CssClass = strCssClassRow;
                tr.Cells.Add(d4);

                oldANr = az.AuftragNr;
                if (pm.Anzahl > 0f && roteLohnarten.ContainsKey(pm.Lohnart))
                    tr.Cells[0].CssClass = tr.Cells[1].CssClass = "TabZeileRed";
                tabAusZu.Rows.Add(tr);
            }
        }

        return tabAusZu;
    }

    private Table SEGListe()
    {
        TableRow HeaderRow = new TableRow();

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        // Beginn #4083, 5215 - Lohnarten bei SEG-Zulagen, Einsatzbericht - Anzeige SEG Punkte
        TableCell c1_5 = new TableCell();
        c1_5.Text = "Lohnart";
        c1_5.HorizontalAlign = HorizontalAlign.Center;
        c1_5.CssClass = "TabHeader";
        c1_5.Font.Bold = true;
        // Ende #4083, 5215

        TableCell c2 = new TableCell();
        c2.Text = "SEG %";
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        TableCell c3 = new TableCell();
        c3.Text = "SEG Punkte";
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;

        TableCell c4 = new TableCell();
        c4.Text = "Basis Std";
        c4.HorizontalAlign = HorizontalAlign.Center;
        c4.CssClass = "TabHeader";
        c4.Font.Bold = true;

        TableCell c5 = new TableCell();
        c5.Text = "SEG-Zulage";
        c5.HorizontalAlign = HorizontalAlign.Center;
        c5.CssClass = "TabHeader";
        c5.Font.Bold = true;

        HeaderRow.Cells.Add(c1);
        // Beginn #4083, 5215 - Lohnarten bei SEG-Zulagen, Einsatzbericht - Anzeige SEG Punkte
        HeaderRow.Cells.Add(c1_5);
        // Ende #4083, 5215
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c4);
        HeaderRow.Cells.Add(c5);

        tabSEG.Rows.Add(HeaderRow);

        TableRow tr;
        foreach (dbKG_SEGZulage s in KGMonat.SEGZulagen)
        {
            tr = new TableRow();
            TableCell d1 = new TableCell();
            d1.Text = s.AuftragNr;
            d1.HorizontalAlign = HorizontalAlign.Center;
            d1.CssClass = "TabNewDay";
            tr.Cells.Add(d1);

            // Beginn #4083, 5215 - Lohnarten bei SEG-Zulagen, Einsatzbericht - Anzeige SEG Punkte
            TableCell d1_5 = new TableCell();
            // Beginn #5940 - Nachdem der SEGPKT nicht �berschreibar sind, Lohnarttxt kann 
            // mit hilfe von s.lohnArt ausgelesen werden 
            s.Perskey = Convert.ToInt32(KGMonat.Genehmiger.Params.PERSKEY.Value);
            d1_5.Text = "Nicht erreichbar!";
            if (s.lohnArt != "")
            {
                /*try
                {
                    SISSITableAdapters.Y_LOHNART2TableAdapter taLOHNART = new SISSITableAdapters.Y_LOHNART2TableAdapter();
                    SISSI.Y_LOHNART2DataTable dtLOHNART = taLOHNART.GetLohnartTextByLohnArt(s.lohnArt);
                    SISSI.Y_LOHNART2Row rowLOHNART = (SISSI.Y_LOHNART2Row)dtLOHNART.Rows[0];
                    d1_5.Text = s.lohnArt + " - " + rowLOHNART.LOHNARTTXT;
                }
                catch
                {
                    d1_5.Text = "Nicht erreichbar!";
                }*/
                foreach (ValuePair vp in Bearbeiter.Commons.Projekt_AusZulagen)
                {
                    if (vp.Value == s.lohnArt)
                    {
                        d1_5.Text = s.lohnArt + " - " + vp.Text;
                        break;
                    }
                }
            }
            else
            {
                /*
                try
                {
                    SISSITableAdapters.Y_LOHNART2TableAdapter taLOHNART = new SISSITableAdapters.Y_LOHNART2TableAdapter();
                    SISSI.Y_LOHNART2DataTable dtLOHNART = taLOHNART.GetLohnartTextByLohnArt(s.SEGPKT);
                    SISSI.Y_LOHNART2Row rowLOHNART = (SISSI.Y_LOHNART2Row)dtLOHNART.Rows[0];
                    d1_5.Text = s.SEGPKT + " - " + rowLOHNART.LOHNARTTXT;
                }
                catch
                {
                    d1_5.Text = "Nicht erreichbar!";
                }*/
                foreach (ValuePair vp in Bearbeiter.Commons.SEGPunkte)
                {
                    if (vp.Value == s.SEGPKT)
                    {
                        d1_5.Text = s.lohnArt + " - " + vp.Text;
                        break;
                    }
                }
            }
            d1_5.HorizontalAlign = HorizontalAlign.Center;
            d1_5.CssClass = "TabNewDay";
            tr.Cells.Add(d1_5);
            // Ende #4083, 5215

            TableCell d2 = new TableCell();
            //d2.Text = (s.Prozent.ToString("N") == "0,00" ? "" : s.Prozent.ToString("N") + "%");
            d2.Text = "100,00%"; // Momentan wird fix 100% eingetragen.
            d2.HorizontalAlign = HorizontalAlign.Center;
            d2.CssClass = "TabNewDay";
            tr.Cells.Add(d2);

            TableCell d3 = new TableCell();
            d3.Text = (s.Punkte == "0" ? "" : s.Punkte);
            d3.CssClass = "TabNewDay";
            d3.HorizontalAlign = HorizontalAlign.Center;
            tr.Cells.Add(d3);

            TableCell d4 = new TableCell();
            if (s.lohnArt != "")
                d4.Text = (s.AnzTage.ToString("N") == "0" ? "" : s.AnzTage.ToString("N"));
            else
                d4.Text = (s.BasisStunden.ToString("N") == "0,00" ? "" : s.BasisStunden.ToString("N"));
            d4.HorizontalAlign = HorizontalAlign.Center;
            d4.CssClass = "TabNewDay";
            tr.Cells.Add(d4);

            TableCell d5 = new TableCell();
            //todo: remove ?
            if (s.lohnArt != "")
                d5.Text = (s.AnzTage.ToString("N") == "0" ? "" : s.AnzTage.ToString("N"));
            else
                d5.Text = (s.Zulage.ToString("N") == "0,00" ? "" : s.Zulage.ToString("N"));
            //Ende #5940
            d5.HorizontalAlign = HorizontalAlign.Center;
            d5.CssClass = "TabNewDay";
            tr.Cells.Add(d5);

            tabSEG.Rows.Add(tr);
        }
        return tabSEG;
    }

    // Beginn Defect 3392
    // Funktion um die Bemerkung aus Einsatzbericht dem Genehmiger beim Genehmigen anzeigen
    private Table BemerkungfuerGenehmiger()
    {
        TableRow HeaderRow = new TableRow();
        // Defect #6014 - neue Spalte hinzuf�gen - Projektname
        TableCell c3 = new TableCell();
        c3.Text = "Projekt";
        c3.Width = 200;
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.Width = 150;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Interne Bemerkung";
        c2.Width = 687;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;
        //string OldAuftNr = "-";
        //string AuftNr = "0";


        //Defect #6014 - pro EB eine Zeile in der Bemerkungstabelle schreiben
        foreach (dbMontBer mber in KGMonat.Monteur.MBerichte)
        {
            string interneBemerkung = mber.Params.EBHIST.Value.ToString().Trim();
            string projektName = mber.Projekt.Params.NAME.Value.ToString().Trim();

            if (interneBemerkung != null && interneBemerkung != "" && projektName != null && projektName != "")
            {
                HeaderRow.Visible = true;
                ArrayList listAuftrag = new ArrayList();
                string auftragNr = "";
                foreach (dbArbTag at in mber.Tage)
                {
                    foreach (dbArbZeit az in at.Zeiten)
                    {
                        if (az.Params is dbAZ_KALTAGParams)
                            continue;
                        if (az.GKAuftragNR != ""
                            && Convert.ToInt32((az.Params as dbAZ_ARBZEITParams).EBID.Value) == Convert.ToInt32(mber.Params.EBID.Value)
                            && listAuftrag.BinarySearch(az.GKAuftragNR) < 0)
                        {
                            listAuftrag.Add(az.GKAuftragNR);
                            listAuftrag.Sort();
                        }
                    }
                }
                foreach (string s in listAuftrag)
                {
                    if (auftragNr != "")
                        auftragNr += " / ";
                    auftragNr += s;
                }

                string strCssClassRow = "Auftnr_neu";
                tr = new TableRow();

                TableCell d3 = new TableCell();
                //TextBox tb3 = new TextBox();
                Label tb3 = new Label();
                tb3.Width = 200;
                tb3.Text = projektName;
                d3.HorizontalAlign = HorizontalAlign.Left;
                d3.CssClass = strCssClassRow;
                //d3.Enabled = false;
                //d3.Font.Bold = true;
                d3.Controls.Add(tb3);
                tr.Cells.Add(d3);

                TableCell d1 = new TableCell();
                //TextBox tb1 = new TextBox();
                Label tb1 = new Label();
                tb1.Width = 150;
                tb1.Text = auftragNr;
                d1.HorizontalAlign = HorizontalAlign.Left;
                d1.CssClass = strCssClassRow;
                //d1.Enabled = false;
                //d1.Font.Bold = true;
                d1.Controls.Add(tb1);
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                //TextBox tb = new TextBox();
                Label tb = new Label();
                //d2.Text = interneBemerkung;
                tb.Width = 687;
                tb.Text = interneBemerkung;
                d2.HorizontalAlign = HorizontalAlign.Left;
                //d2.Font.Bold = true;
                //d2.Enabled = false;
                d2.ForeColor = System.Drawing.Color.Black;
                d2.Controls.Add(tb);
                d2.CssClass = strCssClassRow;
                tr.Cells.Add(d2);
                tabBem.Rows.Add(tr);
            }
        }

        return tabBem;
        /*
            foreach (dbKG_Tag t in KGMonat.Tage)
            {
              foreach (dbKG_EB e in t.EBerichte)
              {
                foreach (object obj in e.ArbZeit)
                {
                  if (obj is dbKG_AZTag)
                  {
                    AuftNr = ((dbKG_AZTag)obj).Auftrag;
                    break;
                  }
                }
                if (OldAuftNr != AuftNr && AuftNr != "0")
                {
                  string hBemerk = e.MBericht.Params.EBHIST.Value.ToString().Trim();
                  if (hBemerk != null && hBemerk != "")
                  {
                    string strCssClassRow = "Auftnr_neu";
                    tr = new TableRow();
                    TableCell d1 = new TableCell();
                    TextBox tb1 = new TextBox();
                    tb1.Width = 200;
                    tb1.Text = AuftNr;
                    d1.HorizontalAlign = HorizontalAlign.Left;
                    d1.CssClass = strCssClassRow;
                    d1.Enabled = false;
                    d1.Font.Bold = true;
                    d1.Controls.Add(tb1);
                    tr.Cells.Add(d1);

                    TableCell d2 = new TableCell();
                    TextBox tb = new TextBox();
                    tb.Width = 700;

                    tb.Text = e.MBericht.Params.EBHIST.Value.ToString();
                    d2.HorizontalAlign = HorizontalAlign.Left;
                    d2.Font.Bold = true;
                    d2.Enabled = false;
                    d2.ForeColor = System.Drawing.Color.Black;
                    d2.Controls.Add(tb);
                    d2.CssClass = strCssClassRow;
                    tr.Cells.Add(d2);
                    tabBem.Rows.Add(tr);
                  }
                  OldAuftNr = AuftNr;
                }
              }
            }
            return tabBem;*/
    }
    //Defect #6060 - KFMBemerkung
    private Table KfmBemerkungfuerGenehmiger()
    {
        TableRow HeaderRow = new TableRow();
        // Defect #6014 - neue Spalte hinzuf�gen - Projektname
        TableCell c3 = new TableCell();
        c3.Text = "Projekt";
        c3.Width = 200;
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;

        TableCell c1 = new TableCell();
        c1.Text = "AuftragNr";
        c1.HorizontalAlign = HorizontalAlign.Center;
        c1.Width = 150;
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;

        TableCell c2 = new TableCell();
        c2.Text = "Bemerkung f�r Kunden";
        c2.Width = 687;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;

        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        tabBem.Rows.Add(HeaderRow);

        HeaderRow.Visible = false;
        TableRow tr;
        //string OldAuftNr = "-";
        //string AuftNr = "0";


        //Defect #6014 - pro EB eine Zeile in der Bemerkungstabelle schreiben
        foreach (dbMontBer mber in KGMonat.Monteur.MBerichte)
        {
            string interneBemerkung = mber.Params.KFMBEMERKUNG.Value.ToString().Trim();
            string projektName = mber.Projekt.Params.NAME.Value.ToString().Trim();

            if (interneBemerkung != null && interneBemerkung != "" && projektName != null && projektName != "")
            {
                HeaderRow.Visible = true;
                ArrayList listAuftrag = new ArrayList();
                string auftragNr = "";
                foreach (dbArbTag at in mber.Tage)
                {
                    foreach (dbArbZeit az in at.Zeiten)
                    {
                        if (az.Params is dbAZ_KALTAGParams)
                            continue;
                        if (az.GKAuftragNR != ""
                            && Convert.ToInt32((az.Params as dbAZ_ARBZEITParams).EBID.Value) == Convert.ToInt32(mber.Params.EBID.Value)
                            && listAuftrag.BinarySearch(az.GKAuftragNR) < 0)
                        {
                            listAuftrag.Add(az.GKAuftragNR);
                            listAuftrag.Sort();
                        }
                    }
                }
                foreach (string s in listAuftrag)
                {
                    if (auftragNr != "")
                        auftragNr += " / ";
                    auftragNr += s;
                }

                string strCssClassRow = "Auftnr_neu";
                tr = new TableRow();

                TableCell d3 = new TableCell();
                //TextBox tb3 = new TextBox();
                Label tb3 = new Label();
                tb3.Width = 200;
                tb3.Text = projektName;
                d3.HorizontalAlign = HorizontalAlign.Left;
                d3.CssClass = strCssClassRow;
                //d3.Enabled = false;
                //d3.Font.Bold = true;
                d3.Controls.Add(tb3);
                tr.Cells.Add(d3);

                TableCell d1 = new TableCell();
                //TextBox tb1 = new TextBox();
                Label tb1 = new Label();
                tb1.Width = 150;
                tb1.Text = auftragNr;
                d1.HorizontalAlign = HorizontalAlign.Left;
                d1.CssClass = strCssClassRow;
                //d1.Enabled = false;
                //d1.Font.Bold = true;
                d1.Controls.Add(tb1);
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                //TextBox tb = new TextBox();
                Label tb = new Label();
                tb.Width = 687;
                tb.Text = interneBemerkung;
                d2.HorizontalAlign = HorizontalAlign.Left;
                //d2.Font.Bold = true;
                //d2.Enabled = false;
                d2.ForeColor = System.Drawing.Color.Black;
                d2.Controls.Add(tb);
                d2.CssClass = strCssClassRow;
                tr.Cells.Add(d2);
                tabBem.Rows.Add(tr);
            }
        }

        return tabBem;
    }
    // Ende Defect 3392

    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler)
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        //KMS xxxxxx - alte PostBackInsteadPageLoad abfragen l�schen weil diese funktionieren seit ein paar Versionen
        //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
        btn.PostBackUrl = "~/Genehmigung/KG_PostBackPage.aspx?Command=" + Command + "&Argument=" + Argument;
        //else
        //    btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        //cList.Add(btn);
        return btn;
    }

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }
    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        switch (cmd)
        {
            case "Edit":
                int iEbid = Convert.ToInt32(arg);
                foreach (dbMontBer m in KGMonat.Monteur.MBerichte)
                    if ((int)m.Params.EBID.Value == iEbid)
                    {
                        Session["MBericht"] = m;
                        Session["Monteur"] = KGMonat.Monteur;
                        Session["Projekt"] = m.Projekt;
                        Session["FromGenehmigung"] = true;
                        Response.Redirect("~/Einsatzbericht/EditEB.aspx?RetUrl=" + Request.RawUrl);
                    }
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;

        }
    }

    protected void BtnNext_Click(object sender, EventArgs e)
    {
        if (KGMonat.IstFremdPersonal)
        {
            Session["KGMonat"] = KGMonat;
            Response.Redirect("~/Genehmigung/KG_AZM.aspx");
        }
        else
        {
            //save captured content 
            Response.Redirect("~/Genehmigung/KG_RA.aspx");
        }
    }
}
