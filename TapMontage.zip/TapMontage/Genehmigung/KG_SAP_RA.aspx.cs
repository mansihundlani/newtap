﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_SAP_RA.aspx.cs
//
// Description  : SAP Reisenübersicht
//
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt ständige AZM abfragen
//                
//=============== V1.2.0005 ===============================================
//
// Date         : 10.März 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530037
//                Auftragnummer korrigieren wenn Reisebuchung auf KST erfasst ist
//
//=============== V1.2.0002 ===============================================
//
// Date         : 10.März 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530037
//                INTF_ID korrigiert
//
//=============== V1.2.0000 ===============================================
//
// Date         : 25.Februar 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530031 
//                INTF_ID bei Reisezeilen nicht versorgt - wird bei 
//                PROD_SAP überprüfft
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.Oktober 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=========================================================================
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using Tap.Schnittstellen.TAP_RA;
using System.Data.SqlClient;
using System.Diagnostics;
using TapMontage.Misc;


public partial class Genehmigung_KG_SAP_RA : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    dbKG_Monat KGMonat;
    dbSapReise SapReisen;
    DateTime timer = ParamVal.Date0;


    protected void Page_PreRender(object sender, EventArgs e)
    {
        /*
        Debug.WriteLine("KG_SAP_RA:Page_PreRender start at " + DateTime.Now.ToLongTimeString());
        LabelTimer.Text = "Diese Seite ist in " + new TimeSpan(DateTime.Now.Ticks - timer.Ticks).Seconds + " Sekunden aufgebaut";
        DateTime dtbeginn = (DateTime)Session["GenehmigungsDauer"];
        LabelGesamtDauer.Text = "Gesamtdauer bis jetzt ist " + new TimeSpan(DateTime.Now.Ticks - dtbeginn.Ticks).TotalSeconds + " Sekunden.";
        Debug.WriteLine("KG_SAP_RA:Page_PreRender end at " + DateTime.Now.ToLongTimeString());
        */
    }
    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        if (Session["SetFocus"] != null)
        {
            try
            {
                Object o = (Object)Session["SetFocus"];
                if (o is Button)
                    SetFocus((Button)Session["SetFocus"]);
                else
                    if (o is TextBox)
                        SetFocus((TextBox)Session["SetFocus"]);
            }
            catch
            {
            }
            finally
            {
                Session["SetFocus"] = null;
            }

        }
        ArrayList myCtrls = (ArrayList)Session["MyCtrls"];
        BtnNext.Enabled = true;
        BtnGen.Enabled = true;
        int anzalReise = myCtrls.Count;
        int anzahlGenehmigteReisen = 0;
        foreach (UserControlSapReise ctrl in myCtrls)
        {
            try
            {
                if (Session["BuildTablesNew"] != null && ctrl == (UserControlSapReise)Session["BuildTablesNew"])
                {
                    ctrl.xxID = 0;
                    ctrl.BuildTables();
                    Session["BuildTablesNew"] = null;
                }
            }
            catch
            {

            }
            ctrl.btnSimEnabled = false;
            if (ctrl.RASTAT != 30)
                BtnGen.Enabled = false;
            
            if (ctrl.SapNummer.Trim('0').Length == 0 || ctrl.RASTAT < 80)
                BtnNext.Enabled = false;

            if (ctrl.RASTAT >= 30)
            {
                if( ctrl.SapNummer.Trim('0').Length != 0 )
                    ctrl.btnSimEnabled = true;
                ctrl.btnSendTripEnabled = false;
            }
            else
                ctrl.btnSendTripEnabled = true;
            if (ctrl.RASTAT == 80) anzahlGenehmigteReisen++;
        }

        if (anzahlGenehmigteReisen == anzalReise) BtnGen.Enabled = false;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Debug.WriteLine("KG_SAP_RA:PageLoad Beginn at " + DateTime.Now.ToLongTimeString());
        timer = DateTime.Now;
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        KGMonat = (dbKG_Monat)Session["KGMonat"];
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Kontrolle & Genehmigung - TAP / SAP Reisenübersicht</span><br /><span style=\"font-size: 12px;\">";
            Session["headData"] += KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
        }
        catch
        {/* Nicht behandelt! */}
        if (!Page.IsPostBack)
        {
            //Leeren ReiseZeiten ... diese werden mit dem neuen objekt ausgeliefert
            foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
                foreach (dbArbTag at in mb.ReiseTage)
                    at.Zeiten.Clear();
        }
        
        SapReisen = new dbSapReise((int)(KGMonat.Monteur.Params.PERSKEY.Value), KGMonat.MinDatum, KGMonat.Monteur.Params.MANDANT.Value.ToString());
        ArrayList tapReisen = SapReisen.GetTapReisen();
        ArrayList myCtrls = new ArrayList();
        int TableId = 4; //keine Ahnung warum im html ctr_TableId mit 04 anfängt
        foreach (string s in tapReisen)
        {
            UserControlSapReise ctrl = new UserControlSapReise();
            ctrl = Page.LoadControl("..\\UserControls\\SapReise.ascx") as UserControlSapReise;
            string[] split = s.Split(',');
            //ctrl.TapNummer = i;
            ctrl.TapNummer = Convert.ToInt32(split[0]);
            ctrl.RASTAT = Convert.ToInt16(split[1]);
            ctrl.TableId = TableId++;
            if (s == tapReisen[0].ToString())
                ctrl.istErsteReiseImMonat = true;
            if (s == tapReisen[tapReisen.Count - 1].ToString())
                ctrl.istLetzteReiseImMonat = true;
            if (Session["ChangeSAPTrip"] != null && (bool)Session["ChangeSAPTrip"] && ctrl.RASTAT < 80)
                ctrl.IstAenderbar = true;
            if (Session["SendTripsToSAP"] != null && (bool)Session["SendTripsToSAP"])
            {
               LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "KG_SAP_RA::SendTripToSAP:\n\rPerskey=" + KGMonat.Monteur.Params.PERSKEY.Value.ToString() + "\r\nMandant=" + KGMonat.Monteur.Params.MANDANT.Value.ToString() + "\r\nRAID=" + split[0].ToString(), null);
               try
               {
                  RFCReise rfcReise = new RFCReise();
                  RueckgabeAnClient ret = new RueckgabeAnClient();
                  /*rfcReise.SendTripToSAPVB6((int)(KGMonat.Monteur.Params.PERSKEY.Value), 
                      KGMonat.Monteur.Params.MANDANT.Value.ToString(),
                      split[0], 
                      false,
                      out ret.SapReisennummer,
                      out ret.SapReturn,
                      out ret.TapReturn);*/
                  ret = rfcReise.SendTripToSAP((int)(KGMonat.Monteur.Params.PERSKEY.Value),
                      KGMonat.Monteur.Params.MANDANT.Value.ToString(),
                      split[0],
                      false);
                  //reise erfolgreich in sap initialisiert
                  ctrl.SapNummer = ret.SapReisennummer;
                  if (ret.SapReisennummer.Trim('0').Length == 0)
                  {
                     //error
                     ctrl.ErrorText = ret.SapReturn.Length > 0 ? ret.SapReturn : ret.TapReturn;
                     ctrl.ErrorTextColorRed = true;
                     //RASTAT bleibt 10
                  }
                  else
                  {
                     //no error
                     if (ctrl.UpdateRaKopf(Convert.ToInt32(split[0]), dbRaKopf.RaStati.Freigegeben))
                     {
                        ctrl.RASTAT = 30;
                        ctrl.btnSendTripEnabled = false;
                     }
                     ctrl.ErrorText = ret.SapReturn.Length > 0 ? ret.SapReturn : ret.TapReturn;
                     ctrl.ErrorTextColorRed = false;
                     //UpdateDB RASTAT -> 30
                  }
               }
               catch (Exception ex)
               {
                  LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "KG_SAP_RA::SendTripToSAP:EXCEPTION", null);
                  LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, ex.Message, null);
                  ctrl.ErrorText = ex.Message;
                  ctrl.ErrorTextColorRed = true;
               }
               
            }
            else
            {
                ctrl.ErrorText = split[2];
                ctrl.ErrorTextColorRed = false;
            }
            /*
            if (split[2] == "40")
                ctrl.btnBarcodeEnabled = true;
            else
                ctrl.btnBarcodeEnabled = false;
            */
            //panelReisen.Controls.Add(ctrl);
            PlaceHolderReisen.Controls.Add(ctrl);
            myCtrls.Add(ctrl);
        }
        Session["MyCtrls"] = myCtrls;
        Session["SendTripsToSAP"] = null;
        BtnGen.PostBackUrl = "~/Genehmigung/KG_PostBackPage.aspx?Command=Genehmigen&Argument=";
        BtnPrev.PostBackUrl = "~/Genehmigung/KG_Zeiten.aspx";
        if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
        {
            BtnNext.Click -= new EventHandler(BtnNext_Click); 
            BtnNext.PostBackUrl = "~/Genehmigung/KG_PostBackPage.aspx?Command=GoToAZMfromRA&Argument=" + Bearbeiter.Params.PERSKEY.Value.ToString(); ;
        }
        if (Session["ChangeSAPTrip"] != null && (bool)Session["ChangeSAPTrip"] == true)
        {
            BtnBack.Visible = false;
            TabEdit.Visible = true;
        }
        else
        {
            BtnBack.Visible = true;
            TabEdit.Visible = false;
        }
        //KGMonat.Rabrech.Reisen
        Debug.WriteLine("KG_SAP_RA:PageLoad End at " + DateTime.Now.ToLongTimeString());
    }
    protected void BtnPrev_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Genehmigung/KG_Zeiten.aspx");
    }

    protected void BtnNext_Click(object sender, EventArgs e)
    {
        //nun Reisezeilen fürs AZM auswerten
        ArrayList myCtrls = (ArrayList)Session["MyCtrls"];
        KGMonat.RZalsAZ = new ArrayList();
        foreach (UserControlSapReise ctrl in myCtrls)
        {
            ArrayList rzList = ctrl.LeseAlleRAZeilen(ctrl.TapNummer);
            foreach (dbRaZeile_Params z in rzList)
            {
                //hier sollte Zeile aufgeteilt, falls reise über mitternacht stattfindet
                //code
                if (z.ZEILENKZ.Value != DBNull.Value && "HRS".Contains(z.ZEILENKZ.Value.ToString()))
                {
                    if( Convert.ToDateTime(z.AB.Value).Day != Convert.ToDateTime(z.AN.Value).Day )
                    {
                        ConvertRZtoAZ(Convert.ToDateTime(z.AB.Value), ParamVal.Date0, z, ref KGMonat.RZalsAZ);
                        ConvertRZtoAZ(ParamVal.Date0, Convert.ToDateTime(z.AN.Value), z, ref KGMonat.RZalsAZ);
                    }
                    else
                        ConvertRZtoAZ(Convert.ToDateTime(z.AB.Value), Convert.ToDateTime(z.AN.Value), z, ref KGMonat.RZalsAZ);
                }
            }

        }
        Session["KGMonat"] = KGMonat;
        Response.Redirect("~/Genehmigung/KG_AZM.aspx");
    }

    private void ConvertRZtoAZ(DateTime dateTime, DateTime dateTime_2, dbRaZeile_Params z, ref ArrayList dbAZARBZEITParams)
    {
        dbAZ_ARBZEITParams az = new dbAZ_ARBZEITParams();

        az.MANDANT.Value = KGMonat.Monteur.Params.MANDANT.Value.ToString();
        az.EBID.Value = Convert.ToInt32(z.EBID.Value);
        az.PERSKEY.Value = Convert.ToInt32(KGMonat.Monteur.Params.PERSKEY.Value);
        az.DATUM.Value = (dateTime != ParamVal.Date0) ? new DateTime(dateTime.Year, dateTime.Month, dateTime.Day): new DateTime(dateTime_2.Year, dateTime_2.Month, dateTime_2.Day);
        az.BEGINN.Value = (dateTime != ParamVal.Date0) ? dateTime : az.DATUM.Value;
        az.ENDE.Value = (dateTime_2 != ParamVal.Date0) ? dateTime_2 : Convert.ToDateTime(az.DATUM.Value).AddHours(23).AddMinutes(59);
        az.AUFTRNR.Value = z.BESCHREIB.Value.ToString();
        az.DATNEU.Value = DateTime.Now;
        az.AENPERSKEY.Value = Bearbeiter.Params.PERSKEY.Value;
        az.DATUGORK.Value = DBNull.Value;
        az.DATUGEOS.Value = DBNull.Value;
        az.DATUGBEMO.Value = DBNull.Value;
        az.DATUGKORAM.Value = DBNull.Value;
        az.DATUGRUECKM.Value = DBNull.Value;

        foreach (dbMontBer monber in KGMonat.Monteur.MBerichte)
        {
            if (Convert.ToInt32(monber.Params.EBID.Value) == Convert.ToInt32(az.EBID.Value))
            {
                //BAF 530037 - KST kann nicht produktiviert werde, diese Funktion hilft PSP Element/SD Ausftrag zu ermitteln
                if (az.AUFTRNR.Value.ToString() == "10" + KGMonat.Monteur.TechParams.KST.Value.ToString())
                    az.AUFTRNR.Value = monber.Projekt.Params.KTOBJ.Value.ToString();
                //BAF 530037 - Ende
                if (monber.Projekt.Params.KTOBJ.Value.ToString() != az.AUFTRNR.Value.ToString())
                {
                    string StrAuftrag = monber.Projekt.Params.KTOBJ.Value.ToString();
                    monber.Projekt.Params.KTOBJ.Value = az.AUFTRNR.Value.ToString();
                    if (monber.Projekt.CheckSAP())
                    {
                        az.INTF_ID.Value = Convert.ToInt16(monber.Projekt.INTF_ID);
                    }
                    else
                    {
                        //FM Ausgeben .. aber wie ?
                    }
                    if (StrAuftrag != "")
                        monber.Projekt.Params.KTOBJ.Value = StrAuftrag;
                }
                else
                    az.INTF_ID.Value = Convert.ToInt16(monber.Params.INTF_ID.Value);
                break;
            }
        }
        int dayOfWeek = (int)Convert.ToDateTime(az.BEGINN.Value).DayOfWeek;
        DateTime nBeg = ParamVal.Date0;
        DateTime nEnd = ParamVal.Date0;
        DateTime datum = Convert.ToDateTime(az.DATUM.Value);
        // BAF 530042 Beginn
        if (KGMonat.Monteur.AZMKalenderTage.ContainsKey(datum))
        {
            nBeg = Convert.ToDateTime(Convert.ToDateTime(az.BEGINN.Value).ToShortDateString() + " " + KGMonat.Monteur.AZMKalenderTage[datum].AZ_Begin.ToShortTimeString());
            nEnd = Convert.ToDateTime(Convert.ToDateTime(az.ENDE.Value).ToShortDateString() + " " + KGMonat.Monteur.AZMKalenderTage[datum].AZ_Ende.ToShortTimeString());
            if (KGMonat.Monteur.AZMKalenderTage[datum].AZ_SollarbeitStd == 0)
            {
                nBeg = KGMonat.Monteur.AZMKalenderTage[datum].AZ_Ende.AddMinutes(1);
                nEnd = KGMonat.Monteur.AZMKalenderTage[datum].AZ_Ende.AddMinutes(2);
            }
        }//BAF 530042 Ende
        else
        {
            dbAZTag azt = (KGMonat.Monteur.AZModell.AZTage[dayOfWeek] as dbAZTag);
            nBeg = Convert.ToDateTime(Convert.ToDateTime(az.BEGINN.Value).ToShortDateString() + " " + Convert.ToDateTime(azt.Params.AZ_Begin.Value).ToShortTimeString());
            nEnd = Convert.ToDateTime(Convert.ToDateTime(az.ENDE.Value).ToShortDateString() + " " + Convert.ToDateTime(azt.Params.AZ_Ende.Value).ToShortTimeString());
            //TAPM-35 Beginn
            try
            {
                if (ConfigurationManager.AppSettings["TAPM35"] == "true")
                {
                    //TAPM-35 - nBeg und nEnd aktualisieren, an dem Tag wo die Reise statgefunden hat war ein anderes AZM als der aktuelle
                    dbAZTag aztTAPM35 = new dbAZModell(KGMonat.Monteur, Convert.ToDateTime(az.BEGINN.Value)).AZTage[dayOfWeek] as dbAZTag;
                    nBeg = Convert.ToDateTime(Convert.ToDateTime(az.BEGINN.Value).ToShortDateString() + " " + Convert.ToDateTime(aztTAPM35.Params.AZ_Begin.Value).ToShortTimeString());
                    nEnd = Convert.ToDateTime(Convert.ToDateTime(az.ENDE.Value).ToShortDateString() + " " + Convert.ToDateTime(aztTAPM35.Params.AZ_Ende.Value).ToShortTimeString());
                }
            }
            catch
            {
                // do nothing
            }
            if (Convert.ToDecimal(azt.Params.AZ_SollarbeitStd.Value.ToString()) == 0)
            {
                // wir reisen an einem nichtarbeitstag dh nbeg und nend seten wir künslich....
                nBeg = Convert.ToDateTime(az.ENDE.Value).AddMinutes(1);
                nEnd = Convert.ToDateTime(az.ENDE.Value).AddMinutes(2);
            }
        }
        TimeSpan vorher = new TimeSpan(nBeg.Ticks - Convert.ToDateTime(az.BEGINN.Value).Ticks);
        TimeSpan dazwischen = new TimeSpan(Math.Min(Convert.ToDateTime(az.ENDE.Value).Ticks, nEnd.Ticks) - Math.Max(Convert.ToDateTime(az.BEGINN.Value).Ticks, nBeg.Ticks));
        TimeSpan nachher = new TimeSpan(Convert.ToDateTime(az.ENDE.Value).Ticks - nEnd.Ticks);

        DateTime kommen = Convert.ToDateTime(az.BEGINN.Value);
        DateTime gehen = Convert.ToDateTime(az.ENDE.Value);
        if (vorher.TotalMinutes > 0)
        {
            az.KZAZ.Value = "R";
            if (dazwischen.TotalMinutes > 0)
            {
                az.ENDE.Value = nBeg;
            }
            CalcWorkTime(ref az, Convert.ToDateTime(az.BEGINN.Value), Convert.ToDateTime(az.ENDE.Value));
            dbAZARBZEITParams.Add(Copy(az));
        }
        if (dazwischen.TotalMinutes > 0)
        {
            az.KZAZ.Value = "W";
            if (vorher.TotalMinutes > 0)
            {
                az.BEGINN.Value = nBeg;
                az.ENDE.Value = gehen;
            }
            if (nachher.TotalMinutes > 0)
            {
                az.ENDE.Value = nEnd;
            }
            CalcWorkTime(ref az, Convert.ToDateTime(az.BEGINN.Value), Convert.ToDateTime(az.ENDE.Value));
            dbAZARBZEITParams.Add(Copy(az));
        }
        if (nachher.TotalMinutes > 0)
        {
            az.KZAZ.Value = "R";
            if (dazwischen.TotalMinutes > 0)
            {
                az.BEGINN.Value = nEnd;
                az.ENDE.Value = gehen;
            }
            CalcWorkTime(ref az, Convert.ToDateTime(az.BEGINN.Value), Convert.ToDateTime(az.ENDE.Value));
            dbAZARBZEITParams.Add(az);
        }
    }

    private dbAZ_ARBZEITParams Copy(dbAZ_ARBZEITParams az)
    {
        dbAZ_ARBZEITParams copy = new dbAZ_ARBZEITParams();
        foreach (SqlParameter s in az.List)
        {
            foreach (SqlParameter sc in copy.List)
            {
                if( sc.ParameterName == s.ParameterName )
                {
                    sc.Value = s.Value;
                    break;
                }
            }
        }
        return copy;
    }

    private void CalcWorkTime(ref dbAZ_ARBZEITParams az, DateTime kommen, DateTime gehen)
    {
        bool aztag_gelesen = false;
        bool a100_valid = true;
        bool a50_valid = true;
        bool e50_valid = true;
        
        DateTime AZ_Begin = ParamVal.Date0;
        DateTime AZ_Ende = ParamVal.Date0;

        DateTime attd = Convert.ToDateTime(az.DATUM.Value);
        TimeSpan ts = new TimeSpan(gehen.Ticks - kommen.Ticks);
        dbMandantAZModellTag azt = (dbMandantAZModellTag)KGMonat.Monteur.Mandant.AZModell.Tage[(int)attd.DayOfWeek];
        //BAF 530042 Beginn
        if (KGMonat.Monteur.AZMKalenderTage.ContainsKey(attd))
        {
            AZ_Begin = KGMonat.Monteur.AZMKalenderTage[attd].AZ_Begin;
            AZ_Ende = KGMonat.Monteur.AZMKalenderTage[attd].AZ_Ende;
            if (AZ_Begin != ParamVal.Date0)
                aztag_gelesen = true;
            if (KGMonat.Monteur.AZMKalenderTage[attd].IstFeiertag && !KGMonat.Monteur.AZMKalenderTage[attd].IstFenstertag)
            {
                azt = (dbMandantAZModellTag)KGMonat.Monteur.Mandant.AZModell.Tage[0]; //wie Sonntag
                AZ_Begin = ParamVal.Date0; //wie Sonntag
                AZ_Ende = ParamVal.Date0;
                aztag_gelesen = false; //TAPM-35 ... BAZ wird nicht korrigiert
            }
        }//BAF 530042 Ende
        else
        {
            if (Bearbeiter.IstFeiertag(attd) && !Bearbeiter.IstFenstertag(attd))
                azt = (dbMandantAZModellTag)KGMonat.Monteur.Mandant.AZModell.Tage[0]; //wie Sonntag
            dbAZTag maAzt = (dbAZTag)KGMonat.Monteur.AZModell.AZTage[(int)attd.DayOfWeek];
            AZTag_Aktualizieren(ref maAzt, ref aztag_gelesen, attd.ToString("yyyy-MM-dd"));
            if (Bearbeiter.IstFeiertag(attd) && !Bearbeiter.IstFenstertag(attd))
            {
                maAzt = (dbAZTag)KGMonat.Monteur.AZModell.AZTage[0]; //wie Sonntag
                aztag_gelesen = false;
            }
        }
        DateTime a100 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100BEG1.Value).ToShortTimeString());
        DateTime a50 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50BEG1.Value).ToShortTimeString());
        //DateTime aNorm = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(maAzt.Params.AZ_Begin.Value).ToShortTimeString());
        //DateTime eNorm = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(maAzt.Params.AZ_Ende.Value).ToShortTimeString());
        DateTime aNorm = Convert.ToDateTime(attd.ToShortDateString() + " " + AZ_Begin.ToShortTimeString());
        DateTime eNorm = Convert.ToDateTime(attd.ToShortDateString() + " " + AZ_Ende.ToShortTimeString());
        DateTime e50 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50END2.Value).ToShortTimeString());
        if (Convert.ToDateTime(azt.Params.UESTD50END2.Value).Ticks == ParamVal.Date0.Ticks)
            e50 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50END1.Value).ToShortTimeString());
        DateTime e100 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100END2.Value).ToShortTimeString());
        if (Convert.ToDateTime(azt.Params.UESTD100END2.Value).Ticks == ParamVal.Date0.Ticks)
            e100 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100END1.Value).ToShortTimeString());
        //if (e100.Ticks < e50.Ticks)//Ende um 00:00 Uhr -> Add 1 Day
        e100 = e100.AddDays(1);
        try
        {
            if (ConfigurationManager.AppSettings["TAPM35"] == "true" && aztag_gelesen)
            {
                //TAPM-35 a100 ist immer Mitternacht, falls AZ um Mitternacht beginnt, dann ist a100 invalid
                if (aNorm == a100)
                    a100_valid = false;
                //TAPM-35 AZ beginnt zwischen 00:00 und 06:00
                if (aNorm > a100 && aNorm <= a50)
                {
                    a50 = aNorm; // TAPM-35 wegen Berechnung der a100 Stunden
                    a50_valid = false; // Es gibt keine a50 Stunden
                }
                //TAPM-35 AZ endet nach e50, also e50 ist invalid
                if (eNorm >= e50)
                {
                    e50_valid = false;
                    e50 = eNorm; //TAP-35 wegen Berechnung der e100 Stunden
                }
                //TAPM-35 Abfrage ob eNorm == e100 ist nicht notwendig, weil bei AZM der Tag ändert 23:59:59 und nicht um 00:00
            }
        }
        catch
        {
            //do nothing
        }//TAPM-35 Ende
        TimeSpan tsm100 = new TimeSpan();
        if (a100_valid) //TAPM-35 falls NAZ um 00:00 berginnen sollte, dann gibt es keine a100 ÜSTD
        {
            //100%ÜS Morgens: Frühere(Ende,Zeitgrenze50% morgens)-Spätere(Anfang, Zeitgrenze 100% Morgens)
            tsm100 = new TimeSpan(Math.Min(gehen.Ticks, a50.Ticks) - Math.Max(kommen.Ticks, a100.Ticks));
            if (tsm100.TotalMinutes < 0) tsm100 = new TimeSpan(); //ausnullen falls negativ
        }

        TimeSpan tsm50 = new TimeSpan();
        if (a50_valid)
        {
            //50%ÜS Morgens: Frühere(Ende,Zeitgrenze Beginn Normal) - Spätere(Anfang, Zeitgrenze50% morgens)
            tsm50 = new TimeSpan(Math.Min(gehen.Ticks, aNorm.Ticks) - Math.Max(kommen.Ticks, a50.Ticks));
            if (tsm50.TotalMinutes < 0) tsm50 = new TimeSpan();
        }
        //Normalarbeitszeit: Frühere(Ende, Zeitgrenze Ende Normal) - Spätere(Anfang, Zeitgrenze Beginn Normal)
        TimeSpan tsnorm = new TimeSpan(Math.Min(gehen.Ticks, eNorm.Ticks) - Math.Max(kommen.Ticks, aNorm.Ticks));
        if (tsnorm.TotalMinutes < 0) tsnorm = new TimeSpan();

        TimeSpan tsa50 = new TimeSpan();
        if (e50_valid)
        {
            //50%ÜS Abends: Frühere(Ende, Zeitgrenze50% Abends) - spätere(Anfang, apätere(Zeitgrenze Ende Normal, Anfang 50[falls keine NormAZ an diesem Tag]))
            tsa50 = new TimeSpan(Math.Min(gehen.Ticks, e50.Ticks) - Math.Max(kommen.Ticks, Math.Max(eNorm.Ticks, a50.Ticks)));
            if (tsa50.TotalMinutes < 0) tsa50 = new TimeSpan();
        }
        //100%ÜS Abends: Frühere(Ende, Zeitgrenze100% Abends) - spätere(Anfang, Zetgrenze50% Abends)
        TimeSpan tsa100 = new TimeSpan(Math.Min(gehen.Ticks, e100.Ticks) - Math.Max(kommen.Ticks, e50.Ticks));
        if (tsa100.TotalMinutes < 0) tsa100 = new TimeSpan();
        az.PAUSE.Value = 0;
        az.NORMSTD.Value = tsnorm.TotalMinutes;
        az.UESTD50.Value = tsa50.TotalMinutes + tsm50.TotalMinutes;
        az.UESTD100.Value = tsa100.TotalMinutes + tsm100.TotalMinutes;

    }

    private void AZTag_Aktualizieren(ref dbAZTag maAzt, ref bool aztag_gelesen, string vTag)
    {
        string vPersNum = KGMonat.Monteur.Params.PERSNR.Value.ToString().Substring(2, KGMonat.Monteur.Params.PERSNR.Value.ToString().Length-2);
        string vMAName = KGMonat.Monteur.Params.NACHNAME.Value.ToString();
        string vMAVorame = KGMonat.Monteur.Params.VORNAME.Value.ToString();
        if (vTag != "1900-01-01")
        {
            using (SqlConnection AZMConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
            {
                AZMConnection.Open();
                string AZMSqlCommandText = "SELECT AZ_Begin, AZ_Ende, AZ_SollarbeitStd FROM AZ_Tag " + Config.Nolock +
                                           " WHERE AZ_Modell_Nummer = (" +
                                           " SELECT AZ_Modell_Nummer FROM MA_AZ_Modell " + Config.Nolock +
                                           " WHERE (MA_AZ_gültig_von <= '" + vTag + "') AND (MA_AZ_gültig_bis >= '" + vTag + "') AND (MA_PersNummer = '" + vPersNum +
                                           "')  AND (MA_FKN = (SELECT MA_FKN FROM MA_Stamm " + Config.Nolock + " WHERE MA_PersNummer = '" + vPersNum + "' AND MA_Name = '" + vMAName + "' AND MA_Vorname = '" + vMAVorame + "'))" +
                                           " ) AND AZ_Wochentag = DATEPART(w , '" + vTag + "')  ";
                // Ende #5320

                using (SqlCommand AZMSqlCommand = new SqlCommand(AZMSqlCommandText, AZMConnection)) // Defect 5436
                {
                    using (SqlDataReader AZMReader = AZMSqlCommand.ExecuteReader()) // Defect 5436
                    {
                        while (AZMReader.Read())
                        {
                            try
                            {
                                DateTime fromTime = Convert.ToDateTime(AZMReader.GetValue(0).ToString());
                                DateTime toTime = Convert.ToDateTime(AZMReader.GetValue(1).ToString());

                                /* Zeiten aktualisieren */

                                maAzt.Params.AZ_Begin.Value = fromTime;
                                maAzt.Params.AZ_Ende.Value = toTime;
                                aztag_gelesen = true;
                            }
                            catch { }
                        }
                        AZMReader.Close();
                        AZMConnection.Close();
                    }
                }
            }
        }
    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["RetUrl"] != null)
        {
            Response.Redirect(Request.QueryString["RetUrl"].ToString());
        }

    }
}
