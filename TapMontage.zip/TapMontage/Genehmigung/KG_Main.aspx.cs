//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_Main.aspx.cs
//
// Description  : Einstiegsmaske Kontrolle, Genehmigung,
//                Mitarbeiterliste des Genehmigers
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.Oktober 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
// Date         : 10.J�nner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5757
//                Das Deckblatt kann f�r genehmigte EB's gedruckt werden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
// Date         : 11.Dezember 2007
// Author       : Wolfgang Patrman / Joldic Dzevad
// Defect#      : 5706_5687
//                Summe Absenz & GK-Stunden in Genehmigungs�bersicht falsch
//
// Date         : 10.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5716
//                Zuletzt eingestellte Werte f�r Berichtsmonat, Status und
//                Seite in der Session merken
//
// Date         : 30.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5678
//                Firmenkennung des Mitarbeiters selektieren
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
// Date         : 12.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 4081
//                Anzeige Status vollst�ndig korrigiert
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 03.September 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0032 ===============================================
//
// Date         : 1.August 2007
// Author       : Georg Nebehay
// Defect#      : 4608
//                Es werden nur mehr Mitarbeiter im Status 20 angezeigt
//
//=============== V1.0.0029 ===============================================
//
// Date         : 19.Juli 2007
// Author       : WP
// Defect#      : 5224
//                Ausgabe einer Fehlermeldung, wenn Personalnummer = null
//
//=============== V1.0.0028 ===============================================
//
// Date         : 30.Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4079
//                Liste aller zu genehmigenden Mitarbeiter
//
//=============== V1.0.0028 ===============================================
//
// Date         : 30.Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4077
//                Abrechnungsmonat und Liste Mitarbeiter sofort anzeigen
//
//=============== V1.0.0028 ===============================================
//
// Date         : 24.Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4121
//                Neues Login-Konzept
//
//=============== V1.0.0023 ===============================================
//
// Date         : 21. M�rz 2007
// Author       : CL
// Defect#      : 4827
//
// Ber�cksichtigung von Religionskennzeichen des Mitarbeiters und
// Feiertags-Kennzeichen (Gesetzlich - Religi�s) beim Lesen der Feiertage
//
//=============== V1.0.0022 ===============================================
//
// Date         : 15.Februar 2007
// Author       : CL
// Defect#      : 4524
//                'Kontrollieren'-Button ist disabled, falls der  
//                Mitarbeiter noch nicht alle EB freigegeben hat.
//                
// Author       : WP
// Defect#      : 3689
//                Performanceverbesserung 
//
//=============== V1.0.0021 ===============================================
//
// Date         : 2.Februar 2007
// Author       : Patrman Wolfgang
// Defect#      : 4268
//                Korr. static Variablen durch Session Variablen ersetzt
//
//=============== V1.0.0020 ===============================================
//
// Date         : 23.J�nner 2007
// Author       : Patrman Wolfgang
// Defect#      : 4268
//
// Datenversorgung Auswahl Mitarbeiter f�r Bereiche von 20 Mitarbeiter durchf�hren,
// neue Buttons zum direkten Anw�hlen der Seiten mit jeweils 20 Mitarbeitern
//
//=============== V1.0.0003 ===============================================
//
// Date         : 30.Oktober 2006
// Author       : Wieland Erwin
// Defect#      : 3415
//                Korrektes Aufsummieren der GT-Absenzen f�r die �bersicht
//
//=============== V1.0.0001 ===============================================
//
// Date         : 20.Oktober 2006
// Author       : Wieland Erwin
// Defect#      : 3361
//                Richtige Darstellung des Status EB f�r die �bersicht
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient; // Defect 4268
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.Pdf;
using TapMontage.dbObjects;
using TapMontage.Misc;
using System.Diagnostics;

public partial class Genehmigung_KG_Main : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    string Argument = "";
    // Defect 4268 Beginn
    int SelMAVon = 0; // Startindex in MAListe f�r Selektion der Mitarbeiter
    int SelMABis = 0; // Endeindex in MAListe f�r Selektion der Mitarbeiter
    string lastSelMonat = ""; // zuletzt selektiertes Monat
    // Defect 4268 Ende
    DateTime timer = ParamVal.Date0;

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        Debug.WriteLine("KG_Main:Page_LoadComplete Beginn at " + DateTime.Now.ToLongTimeString());
        Debug.WriteLine("KG_Main:Page_LoadComplete Ende at " + DateTime.Now.ToLongTimeString());

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        // Defect 4268 (V1.0.0021)
        // SessionMgr.ClearSession(Page, new string[] { "Bearbeiter" });
        // Beginn #4121 - Neues Login-Konzept
        // SessionMgr.ClearSession(Page, new string[] { "Bearbeiter", "SelMAVon", "SelMABis", "lastSelMonat", "loginName", "loginAccount", "loginRole" }); Defect 5716, Code �berfl�ssig
        // Ende #4121
        timer = DateTime.Now;
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        Debug.WriteLine("KG_Main:PageLoad Beginn at " + DateTime.Now.ToLongTimeString());
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Kontrolle & Genehmigung - Auswahl Mitarbeiter</span>";
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        // Defect 4268
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        //KMS xxxxxx - alte PostBackInsteadPageLoad abfragen l�schen weil diese funktionieren seit ein paar Versionen
        //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
        //{
        DDLMonatNeu.Visible = true;
        Label1.Visible = true;
        DDLStatusEBs.Visible = true;
        Label3.Visible = true;
        DDLMonat.Visible = false;
        DDLStatusFilter.Visible = false;
        if (DDLMonatNeu.Items.Count == 0)
        {
            DDLMonatNeu.Items.Add(new ListItem(DateTime.Now.AddMonths(-3).Month.ToString() + "/" + DateTime.Now.AddMonths(-3).Year.ToString(), DateTime.Now.AddMonths(-3).ToShortDateString()));
            DDLMonatNeu.Items.Add(new ListItem(DateTime.Now.AddMonths(-2).Month.ToString() + "/" + DateTime.Now.AddMonths(-2).Year.ToString(), DateTime.Now.AddMonths(-2).ToShortDateString()));
            DDLMonatNeu.Items.Add(new ListItem(DateTime.Now.AddMonths(-1).Month.ToString() + "/" + DateTime.Now.AddMonths(-1).Year.ToString(), DateTime.Now.AddMonths(-1).ToShortDateString()));
            DDLMonatNeu.Items.Add(new ListItem(DateTime.Now.Month.ToString() + "/" + DateTime.Now.Year.ToString(), DateTime.Now.ToShortDateString()));
            DDLMonatNeu.SelectedIndex = 2;
        }

        if (Session["lastSelMonat"] != null && !Page.IsPostBack)
        {
            DDLMonatNeu.SelectedValue = Session["lastSelMonat"].ToString();
        }
        Session["lastSelMonat"] = DDLMonatNeu.SelectedValue;

        if (Session["SelStatus"] != null && !Page.IsPostBack)
        {
            DDLStatusEBs.SelectedValue = Session["SelStatus"].ToString();
        }
        Session["SelStatus"] = DDLStatusEBs.SelectedValue;
        /*}
        else
        {

            DDLMonatNeu.Visible = false;
            Label1.Visible = false;
            DDLStatusEBs.Visible = false;
            Label3.Visible = false;
            DDLMonat.Visible = true;
            DDLStatusFilter.Visible = true;
            // Beginn Defect 5716, Code �berfl�ssig
            //// Defect 4268 (V1.0.0021) Beginn
            //if (Session["lastSelMonat"] == null)
            //{
            //  lastSelMonat = "";
            //}
            //else
            //{
            //  lastSelMonat = (string)Session["lastSelMonat"];
            //}
            //// Defect 4268 Ende
            // Ende Defect 5716

            DDLMonat.SelIndexChanged = DDLMonat_SelectedIndexChanged;

            // Beginn #4079 - Liste aller zu genehmigenden Mitarbeiter
            DDLStatusFilter.SelIndexChanged = DDLStatusFilter_SelectedIndexChanged;
            // Ende #4079
        }*/
        // Beginn Defect 5716, Initialisierung erfolgt im Page_PreRender Event
        //// Defect 4268 Beginn
        //// Initialisierung bei Monatswechsel und Genehmigerwechsel (neuer logon)
        //if (lastSelMonat != DDLMonat.DDL.SelectedValue ||
        //   DDLMonat.DDL.SelectedIndex < 0)
        //{
        //  // Es werden die Mitarbeiter 1 - 20 angezeigt
        //  SelMAVon = 1;
        //  SelMABis = 20;
        //  // Defect 4268 (V1.0.0021) Beginn
        //  Session["SelMAVon"] = SelMAVon;
        //  Session["SelMABis"] = SelMABis;
        //  // Defect 4268 Ende
        //  lastSelMonat = DDLMonat.DDL.SelectedValue; // Defect 5716
        //  Session["lastSelMonat"] = lastSelMonat; // Defect 4268 (V1.0.0021), 5716
        //}
        //// Defect 4268 Ende
        // Ende Defect 5716

        //KMS xxxxxx - alte PostBackInsteadPageLoad abfragen l�schen weil diese funktionieren seit ein paar Versionen
        //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null )
        //{
        if (DDLMonatNeu.SelectedIndex >= 0)
        {
            SelMAVon = Session["SelMAVon"] != null ? (int)Session["SelMAVon"] : 1;
            SelMABis = Session["SelMABis"] != null ? (int)Session["SelMABis"] : 20;
            phMAListe.Controls.Clear();
            phMAListe.Controls.Add(MAUebersicht());
        }
        /*}
        else
        {
            if (DDLMonat.DDL.SelectedIndex >= 0)
            {
                //phMAListe.Controls.Clear();
                //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "000100" + "Page_Load()", null);
                // Defect 4268 (V1.0.0021) Beginn
                SelMAVon = (int)Session["SelMAVon"]; // Defect 5716, Code �berfl�ssig
                SelMABis = (int)Session["SelMABis"]; // Defect 5716, Code �berfl�ssig
                // Defect 4268 Ende

                phMAListe.Controls.Clear();
                phMAListe.Controls.Add(MAUebersicht());  // Defect 3689 (V1.0.0022), neue Funktion MAUebersicht()
                //phMAListe.Controls.Add(MAListe(SelMAVon, SelMABis));  // Defect 3689 (V1.0.0022), Code entfernt

                //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "000200" + "Page_Load()", null);
            }
        }*/
        Debug.WriteLine("KG_Main:PageLoad Ende at " + DateTime.Now.ToLongTimeString());
    }

    // Beginn #4077 - Abrechnungsmonat und Liste Mitarbeiter sofort anzeigen    
    /// <summary>
    /// Page_PreRender() lauft wenn alle UserControls sind eingeladen und initializiert.
    /// </summary>
    protected void Page_PreRender(object sender, EventArgs e)
    {
        Debug.WriteLine("KG_Main:Page_PreRender Beginn at " + DateTime.Now.ToLongTimeString());
        //KMS xxxxxx - alte PostBackInsteadPageLoad abfragen l�schen weil diese funktionieren seit ein paar Versionen
        //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
        //{
            if (Session["SelMAVon"] != null)
            {
                SelMAVon = (int)Session["SelMAVon"];
            }
            else
            {
                // Es werden die Mitarbeiter 1 - 20 angezeigt
                SelMAVon = 1;
                Session["SelMAVon"] = SelMAVon;
            }

            if (Session["SelMABis"] != null)
            {
                SelMABis = (int)Session["SelMABis"];
            }
            else
            {
                // Es werden die Mitarbeiter 1 - 20 angezeigt
                SelMABis = 20;
                Session["SelMABis"] = SelMABis;
            }
        /*}
        else
        {
            // Beginn #4079 - Liste aller zu genehmigenden Mitarbeiter
            try
            {
                // StatusFilter = DDLStatusFilter.DDL.SelectedValue; Defect 5716
                StatusFilter = (string)Session["SelStatus"]; // Defect 5716, gespeicherten Wert aus Session Variable nehmen
                DDLStatusFilter.DDL.SelectedValue = StatusFilter; // Defect 5716, als Selektion setzen
            }
            catch
            {
                StatusFilter = "alle";
            }
            // Ende #4079

            // Beginn Defect 5716,
            // zuletzt selektiertes Berichtsmonat aus Session Variable nehmen und in DropDown Liste setzen
            try
            {
                if (Session["lastSelMonat"] != null)
                {
                    lastSelMonat = (string)Session["lastSelMonat"];
                    DDLMonat.DDL.SelectedValue = lastSelMonat;
                }
                else
                {
                    lastSelMonat = DDLMonat.DDL.SelectedValue;
                }
            }
            catch
            {
                lastSelMonat = "";
            }

            if (Session["SelMAVon"] != null)
            {
                SelMAVon = (int)Session["SelMAVon"];
            }
            else
            {
                // Es werden die Mitarbeiter 1 - 20 angezeigt
                SelMAVon = 1;
                Session["SelMAVon"] = SelMAVon;
            }

            if (Session["SelMABis"] != null)
            {
                SelMABis = (int)Session["SelMABis"];
            }
            else
            {
                // Es werden die Mitarbeiter 1 - 20 angezeigt
                SelMABis = 20;
                Session["SelMABis"] = SelMABis;
            }
            // Ende Defect 5716
            try
            {
                DDLMonat_SelectedIndexChanged(Page, null);
            }
            catch {}
        }*/
        Debug.WriteLine("KG_Main:Page_PreRender Ende at " + DateTime.Now.ToLongTimeString());
        //LabelTimer.Text = "Diese Seite ist in " + new TimeSpan(DateTime.Now.Ticks - timer.Ticks).TotalSeconds + " Sekunden aufgebaut";
    }
    // Ende #4077

    // Beginn #4079 - Liste aller zu genehmigenden Mitarbeiter
    public string StatusFilter;
    public void DDLStatusFilter_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            StatusFilter = DDLStatusFilter.DDL.SelectedValue;
            Session["SelStatus"] = StatusFilter; // Defect 5716, selektierten Status in Session Variable merken
        }
        catch
        {
            StatusFilter = "alle";
        }
    }
    // Ende #4079

    public void DDLMonat_SelectedIndexChanged(object sender, EventArgs e)
    {
        Debug.WriteLine("KG_Main:DDLMonat_SelectedIndexChanged Beginn at " + DateTime.Now.ToLongTimeString());
        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "003110" + "DDLMonat_SelectedIndexChanged() Start", null);
        DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
        Bearbeiter.BerichtsMonat = d.Year * 100 + d.Month;
        //Bearbeiter.Mitarbeiter = null; Defect 5436, wird nicht verwendet
        Bearbeiter.MBerichte = null;
        Label2.Visible = true;

        // Defect 4268 (V1.0.0021) Beginn
        // SelMAVon = (int)Session["SelMAVon"]; // Defect 5716, Code �berfl�ssig
        // SelMABis = (int)Session["SelMABis"]; // Defect 5716, Code �berfl�ssig
        // Beginn Defect 5716,
        // selektiertes Berichtsmonat in Session Variable merken
        try
        {
            lastSelMonat = DDLMonat.DDL.SelectedValue;
            Session["lastSelMonat"] = lastSelMonat;
        }
        catch
        {
            lastSelMonat = "alle";
        }
        //lastSelMonat = (string)Session["lastSelMonat"];
        // Ende Defect 5716
        // Defect 4268 Ende

        phMAListe.Controls.Clear();
        //phMAListe.Controls.Add(MAListe(SelMAVon, SelMABis));  // Defect 3689 (V1.0.0022)
        phMAListe.Controls.Add(MAUebersicht());  // Defect 3689 (V1.0.0022), neue Funktion MAUebersicht()

        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "003210" + "DDLMonat_SelectedIndexChanged(): Ende", null);
        Session["Bearbeiter"] = Bearbeiter;
        Debug.WriteLine("KG_Main:DDLMonat_SelectedIndexChanged Ende at " + DateTime.Now.ToLongTimeString());
    }

    // Beginn Defect 3689 (V1.0.0022)
    // Klasse zur Darstellung einer Zeile in MAUebersicht
    private class MAUebersichtZeile
    {
        public DateTime Berichtsmonat;
        public DateTime SelectedMonth;
        public DateTime MonatMin;
        public DateTime MonatMax;
        public int Perskey;
        public string Nachname;
        public string Vorname;
        public string Persnr;
        public double NormStunden = 0;
        public double SummeStunden = 0;
        public double UE50 = 0;
        public double UE100 = 0;
        public double DavonGK;
        public int GTAbsenzen;
        public string EBStatusText;
        public string EBLinktext;
        public bool EBerichteGenehmigt;
        public bool EBerichteOK;
        public string Firmenkennung;
        public string Mandant;
        public bool blnEBWithStat10;
        public bool blnBtnStatus;
        public ArrayList KtobjListe = new ArrayList();
        public ArrayList ATage = new ArrayList();

        private const String strRelFtFlag = "R"; // Defect #4827: Flag f�r religi�sen Feiertag
        public const String strFehlt = "fehlt"; // Defect 5678
        public const String strGenehmigt = "genehmigt"; // Defect 5678
        private const String strKontrollieren = "kontrollieren"; // Defect 5678
        private const String strvollst�ndig = "vollst�ndig"; // Defect 5678
        private const String strunvollst�ndig = "unvollst�ndig"; // Defect 5678

        public MAUebersichtZeile(int perskey, string nachname, string vorname, string persnr, DateTime selMonth, DateTime bermon, string firmenkennung, string mandant)
        {
            Perskey = perskey;
            Nachname = nachname;
            Vorname = vorname;
            Persnr = persnr;
            Berichtsmonat = bermon;
            SelectedMonth = selMonth;
            Firmenkennung = firmenkennung;
            Mandant = mandant;
            MonatMin = Convert.ToDateTime("01-" + this.SelectedMonth.Month.ToString() + "-" + this.SelectedMonth.Year.ToString());
            MonatMax = MonatMin.AddMonths(1).AddSeconds(-1);

            for (int i = MonatMin.Day; i <= MonatMax.Day; i++)
            {
                ATage.Add(new ATag(i));
            }
        }

        private class ATag
        {
            public int Tag;
            public bool ok;

            public ATag(int iTag)
            {
                Tag = iTag;
                ok = true;
            }
        }

        public ArrayList SelectAllKtobjs()
        {
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    /* string sql = "SELECT b.ktobj " +
                               "FROM einsber e, bauprojekt b " +
                               "WHERE e.perskey = @PERSKEY " +
                               "AND e.bermon = @BERMON " +
                               "AND b.projid = e.projid"; */
                    // Begin Defect #5706_5687 1.Teil
                    // wir selektieren alle GK Konten aus
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    string sql = "SELECT AUFTRNR FROM Y_AUFTRNRS a " + Config.Nolock +
                                 " JOIN y_tabnumkz t " + Config.Nolock + " on(t.tabkztxt = a.auftrnr and t.mandant = a.mandant) " +
                                 " JOIN BEARBTECH b " + Config.Nolock + " on (substring(tabid, 3, 4) = b.kst) " +
                                 " where t.status = 20 AND t.MANDANT = @MANDANT and perskey = @PERSKEY";
                    // Ende Defect #5706_5687 1.Teil
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436, using eingef�hrt
                    {
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", this.Perskey));
                        cmd.Parameters.Add(new SqlParameter("@MANDANT", this.Mandant));
                        //cmd.Parameters.Add(new SqlParameter("@BERMON", this.Berichtsmonat));
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005000" + "SelectAllKtobjs(): " + cmd.CommandText, null);

                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005001" + "SelectAllKtobjs(): ", null);
                            while (rd.Read())
                            {
                                KtobjListe.Add(rd.GetString(0));
                            }
                            KtobjListe.Sort();
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return KtobjListe;
        }

        public void ComputeStd()
        {
            bool eb_vorhanden = false;

            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("SELECT wochentag " +
                                                           " FROM y_azmodell " + Config.Nolock +
                                                           " WHERE mandant = @MANDANT " +
                                                           " AND nazbeg IS NOT NULL", cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", this.Perskey));
                        cmd.Parameters.Add(new SqlParameter("@MANDANT", this.Mandant));
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005010" + "ComputeStd(): " + cmd.CommandText, null);

                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005011" + "ComputeStd(): ", null);

                            while (rd.Read())
                            {
                                foreach (ATag a in this.ATage)
                                {
                                    if ((int)this.MonatMin.AddDays(a.Tag - 1).DayOfWeek == ((int)rd.GetInt16(0) - 1))
                                    {
                                        a.ok = false;
                                    }
                                }
                            }
                            rd.Close();
                        }
                    }

                    // Berechnung der Normalstunden und Ueberstunden
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("SELECT SUM(normstd) AS normstd, SUM(uestd50) AS uestd50, SUM(uestd100) AS uestd100, auftrnr " +
                                                           " FROM arbzeit " + Config.Nolock +
                                                           " WHERE datum >= @VON " +
                                                           " AND datum <= @BIS " +
                                                           " AND kzaz = 'A' " +
                                                           " AND perskey = @PERSKEY " +
                                                           " GROUP BY auftrnr", cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", this.Perskey));
                        cmd.Parameters.Add(new SqlParameter("@VON", this.MonatMin));
                        cmd.Parameters.Add(new SqlParameter("@BIS", this.MonatMax));
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005020" + "ComputeStd(): " + cmd.CommandText + " von: " + MonatMin.ToString() + " bis: " + MonatMax.ToString() + " perskey: " + Perskey, null);

                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005021" + "ComputeStd(): ", null);

                            while (rd.Read())
                            {
                                this.NormStunden += Convert.ToDouble(rd.GetInt32(0)) / 60;
                                this.UE50 += Convert.ToDouble(rd.GetInt32(1)) / 60;
                                this.UE100 += Convert.ToDouble(rd.GetInt32(2)) / 60;
                                this.SummeStunden = this.NormStunden + this.UE50 + this.UE100;

                                // GK Stunden berechnen
                                if (rd.GetString(3).Trim() != "") // ktobj (auftrnr) pruefen ob leer
                                {
                                    // Begin Defect #5706_5687 2.Teil
                                    // einfach pr�fen ob Konto in der Liste aller GK Kontos vorhanden ist
                                    if (KtobjListe.BinarySearch(rd.GetString(3).Trim()) >= 0)
                                    {
                                        this.DavonGK += Convert.ToDouble(rd.GetInt32(0) + rd.GetInt32(1) + rd.GetInt32(2)) / 60;
                                    }
                                    // Ende Defect #5706_5687 2.Teil
                                    /*
                                  bool bistgk = true;
                                  // Schleife ueber alle ktobj 
                                  foreach (string ktobj in this.KtobjListe) //TODO: Sonderfall: Reisezeit aus Vormaonat wird hier leider als GK ausgegeben, wir l�sen das sp�ter (Tritt so gut wie nie auf!)
                                  {
                                    if (ktobj == rd.GetString(3).Trim() && schonAddiert == false )
                                    {
                                        bistgk = false;
                                    }
                                  }
                    
                                  if (bistgk)
                                  {
                                    this.DavonGK += this.SummeStunden; // Defect 5687, hier nicht die Summe sondern die Einzelwerte aufsummieren
                                  }*/
                                }
                            }
                            rd.Close();
                        }
                    }
                    // Begin Defect #5706_5687 3.Teil
                    // Berechnung der GK Stunden von Absenzen, da der Konto der Prod.Stunden dahinten steht
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("SELECT stdabsenzid, normstd, pause, kzaz " +
                                                           " FROM arbzeit " + Config.Nolock +
                                                           " WHERE datum >= @VON " +
                                                           " AND datum <= @BIS " +
                                                           " AND perskey = @PERSKEY ", cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", this.Perskey));
                        cmd.Parameters.Add(new SqlParameter("@VON", this.MonatMin));
                        cmd.Parameters.Add(new SqlParameter("@BIS", this.MonatMax));
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005020" + "ComputeStd(): " + cmd.CommandText + " von: " + MonatMin.ToString() + " bis: " + MonatMax.ToString() + " perskey: " + Perskey, null);

                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005021" + "ComputeStd(): ", null);

                            while (rd.Read())
                            {
                                // Pflegefreistellung & Sonstiges
                                if ((rd.GetInt16(0) == 10 || rd.GetInt16(0) == 100) && rd.GetString(3).CompareTo("A") == 0)
                                    this.DavonGK += Convert.ToDouble(rd.GetInt16(1)) / 60;
                                // Ersatzruhe
                                if (rd.GetInt16(0) == 90 && rd.GetString(3).CompareTo("E") == 0)
                                    this.SummeStunden += Convert.ToDouble(rd.GetInt16(1)) / 60;
                                // Zeitausgleich
                                if (rd.GetInt16(0) == 110 && rd.GetString(3).CompareTo("A") == 0)
                                    this.SummeStunden -= Convert.ToDouble(rd.GetInt16(1)) / 60;
                            }
                            rd.Close();
                        }
                    }
                    // Ende Defect #5706_5687 3.Teil
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("SELECT ebstat, ebid " +
                                                           " FROM einsber " + Config.Nolock +
                                                           " WHERE bermon = @VON " +
                                                           " AND perskey = @PERSKEY " +
                                                           " ORDER BY ebid", cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", this.Perskey));
                        cmd.Parameters.Add(new SqlParameter("@VON", this.MonatMin));
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005030" + "ComputeStd(): " + cmd.CommandText, null);

                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005031" + "ComputeStd(): ", null);

                            int iRecCount = 0;
                            string ebstat;
                            // Beginn Defect # 3361: Richtige Statusdarstellung f�r �bersicht
                            this.EBerichteOK = true;
                            this.EBerichteGenehmigt = true;

                            // Beginn Defect #4524: Alle EB auf Status 10 durchsuchen
                            // und gegebenenfalls Flag setzen
                            blnEBWithStat10 = false;
                            while (rd.Read())
                            // while ((EBerichteOK || EBerichteGenehmigt) && rd.Read())
                            // Ende Defect #4524
                            {
                                ++iRecCount;
                                eb_vorhanden = true;
                                ebstat = rd.GetValue(0).ToString();
                                // Beginn Defect #4524: Pr�fung auf EB-Status 10
                                if (Int32.Parse(ebstat) == 10)
                                {
                                    blnEBWithStat10 = true;
                                }
                                // Ende Defect #4524
                                if (Int32.Parse(ebstat) < 30)
                                {
                                    EBerichteOK = false;
                                }
                                if (Int32.Parse(ebstat) < 40)
                                {
                                    EBerichteGenehmigt = false;
                                }
                            }

                            if (iRecCount == 0)
                            {
                                this.EBerichteOK = false;
                                this.EBerichteGenehmigt = false;
                            }
                            // Ende Defect # 3361

                            rd.Close();
                        }
                    }

                    if (this.EBerichteOK)
                    {
                        // Defect 5725, Config.Rowlock eingef�hrt
                        // Defect 5771, Config.Nolock eingef�hrt
                        using (SqlCommand cmd = new SqlCommand("SELECT datum " +
                                                               " FROM kaltag " + Config.Nolock +
                                                               " WHERE datum >= @VON " +
                                                               " AND datum <= @BIS " +
                                                               " AND perskey = @PERSKEY", cnx)) // Defect 5436
                        {
                            cmd.Parameters.Add(new SqlParameter("@PERSKEY", this.Perskey));
                            cmd.Parameters.Add(new SqlParameter("@VON", this.MonatMin));
                            cmd.Parameters.Add(new SqlParameter("@BIS", this.MonatMax));
                            //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005040" + "ComputeStd(): " + cmd.CommandText, null);

                            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                            {
                                //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005041" + "ComputeStd(): ", null);

                                while (rd.Read())
                                {
                                    // Beginn Defect # 3415: Korrektes Summieren der GT-Absenzen
                                    this.GTAbsenzen++;
                                    // Ende Defect # 3415
                                    DateTime d = rd.GetDateTime(0);
                                    (this.ATage[d.Day - 1] as ATag).ok = true;
                                }
                                rd.Close();
                            }
                        }
                        // Defect 5725, Config.Rowlock eingef�hrt
                        // Defect 5771, Config.Nolock eingef�hrt
                        using (SqlCommand cmd = new SqlCommand("SELECT COUNT(datum), datum " +
                                                               " FROM arbzeit " + Config.Nolock +
                                                               " WHERE datum >= @VON " +
                                                               " AND datum <= @BIS " +
                                                               " AND perskey = @PERSKEY " +
                                                               " GROUP BY datum", cnx)) // Defect 5436
                        {
                            cmd.Parameters.Add(new SqlParameter("@PERSKEY", this.Perskey));
                            cmd.Parameters.Add(new SqlParameter("@VON", this.MonatMin));
                            cmd.Parameters.Add(new SqlParameter("@BIS", this.MonatMax));
                            //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005050" + "ComputeStd(): " + cmd.CommandText, null);

                            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                            {
                                //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005051" + "ComputeStd(): ", null);

                                while (rd.Read())
                                {
                                    DateTime d = rd.GetDateTime(1);
                                    (this.ATage[d.Day - 1] as ATag).ok = true;
                                }
                                rd.Close();
                            }
                        }

                        using (SqlConnection cnx2 = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                        {
                            try
                            {
                                cnx2.Open();
                                /* Beginn Defect #4827: Ber�cksichtigung der religi�sen Feiertage
                                 * und des Religionskennzeichens des Mitarbeiter in MA_STAMM
                                SqlCommand cmd2 = new SqlCommand("SELECT allg_datum " +
                                                                 "FROM allg_feiertage " +
                                                                 "WHERE allg_datum >= @VON " +
                                                                 "AND allg_datum <= @BIS " +
                                                                 "AND kal_id = (SELECT ma_kal_id FROM ma_stamm WHERE ma_persnummer = @PERSNR AND ma_fkn = @MA_FKN)", cnx2);
                                 * */

                                // Defect 5725, Config.Rowlock eingef�hrt
                                // Defect 5771, Config.Nolock eingef�hrt
                                using (SqlCommand cmd2 = new SqlCommand(
                                      " SELECT af.allg_datum, af.allg_bezeichnung, " +
                                      " ma.ma_rel_feiertag FROM allg_feiertage af " + Config.Nolock + ", ma_stamm ma " + Config.Nolock +
                                      " WHERE af.ALLG_Datum >= @VON and " +
                                      " af.ALLG_Datum <= @BIS " +
                                      " and af.KAL_ID = ma.ma_kal_id " +
                                      " AND ma.MA_Persnummer = @PERSNR" +
                                      " and ma.MA_FKN = @MA_FKN", cnx2)) // Defect 5436
                                {
                                    // Ende Defect #4827
                                    cmd2.Parameters.Add(new SqlParameter("@PERSNR", this.Persnr.Substring(2)));
                                    cmd2.Parameters.Add(new SqlParameter("@MA_FKN", this.Firmenkennung));
                                    cmd2.Parameters.Add(new SqlParameter("@VON", this.MonatMin));
                                    cmd2.Parameters.Add(new SqlParameter("@BIS", this.MonatMax));
                                    //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005060" + "ComputeStd(): " + cmd2.CommandText, null);

                                    using (SqlDataReader rd2 = cmd2.ExecuteReader()) // Defect 5436
                                    {
                                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005061" + "ComputeStd(): ", null);

                                        while (rd2.Read())
                                        {
                                            /* Beginn Defect #4827: Die religi�sen Feiertage werden nur
                                             * bei Mitarbeitern mit Rel-Flag = 1 ber�cksichtigt */
                                            if ((rd2.GetString(1) != strRelFtFlag) ||
                                                (rd2.GetString(1) == strRelFtFlag && rd2.GetBoolean(2) == true))
                                            {
                                                DateTime d = rd2.GetDateTime(0);
                                                (this.ATage[d.Day - 1] as ATag).ok = true;
                                            } // Ende Defect #4827
                                        }
                                        rd2.Close();
                                    }
                                }
                            }
                            catch (Exception xx) { throw xx; }
                            finally { cnx2.Close(); }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }

                // Beginn Defect 5678
                blnBtnStatus = false; // Kontrollieren Button disabled

                if (this.EBerichteOK)
                {
                    blnBtnStatus = true; // Kontrollieren Button enabled
                }
                // Ende Defect 5678

                foreach (ATag a in this.ATage)
                {
                    this.EBerichteOK = this.EBerichteOK & a.ok;
                }

                //blnBtnStatus = true; // Button enabled 4081

                if (this.EBerichteOK)
                {
                    this.EBStatusText = strvollst�ndig;
                }
                else
                {
                    this.EBStatusText = strunvollst�ndig;
                    //blnBtnStatus = false; Defect 5678
                }

                //blnBtnStatus = true; // Button enabled 4081
                if (this.EBerichteGenehmigt)
                {
                    //if (this.EBerichteOK)
                    //{
                    this.EBLinktext = strGenehmigt;
                    blnBtnStatus = false; // Button disabled
                    //}
                    //else
                    //{
                    //  this.EBLinktext = strFehlt;
                    //  blnBtnStatus = false; // Button disabled
                    //}
                }
                else
                {
                    if (eb_vorhanden == false && this.EBerichteOK == false)
                    {
                        this.EBLinktext = strFehlt;
                        blnBtnStatus = false; // Button disabled
                    }
                    else
                    {
                        this.EBLinktext = strKontrollieren;
                    }
                }
            }
        }
    }
    // Ende Defect 3689 (V1.0.0022)

    // Beginn Defect 3689 (V1.0.0022)
    // Erzeugung der Uebersichtsmaske mit allen Mitarbeitern
    private Table MAUebersicht()
    {
        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "001210" + "MAUebersicht(): Start", null);

        xxID = 0;

        tabListe.Rows.Clear();

        tabListe.Width = Unit.Percentage(100);
        TableRow HeaderRow = new TableRow();
        TableCell c1 = new TableCell();
        c1.CssClass = "TabHeader";
        c1.Text = "Name";
        c1.Font.Bold = true;
        c1.HorizontalAlign = HorizontalAlign.Center;
        TableCell c2 = new TableCell();
        c2.Text = "Vorname";
        c2.Font.Bold = true;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        TableCell c3 = new TableCell();
        c3.Text = "Personalnummer";
        c3.Font.Bold = true;
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        TableCell c4 = new TableCell();
        c4.Text = "SummeStd";
        c4.Font.Bold = true;
        c4.HorizontalAlign = HorizontalAlign.Center;
        c4.CssClass = "TabHeader";
        TableCell c5 = new TableCell();
        c5.Text = "davon GK Std.";
        c5.Font.Bold = true;
        c5.HorizontalAlign = HorizontalAlign.Center;
        c5.CssClass = "TabHeader";
        TableCell c6 = new TableCell();
        c6.Text = "GT.Absenz";
        c6.Font.Bold = true;
        c6.HorizontalAlign = HorizontalAlign.Center;
        c6.CssClass = "TabHeader";
        TableCell c7 = new TableCell();
        c7.Text = "Einsatzberichte";
        c7.Font.Bold = true;
        c7.HorizontalAlign = HorizontalAlign.Center;
        c7.CssClass = "TabHeader";
        TableCell c8 = new TableCell();
        c8.Text = "Status";
        c8.Font.Bold = true;
        c8.HorizontalAlign = HorizontalAlign.Center;
        c8.CssClass = "TabHeader";

        TableCell c9 = new TableCell();
        c9.Text = "Deckblatt";
        c9.Font.Bold = true;
        c9.HorizontalAlign = HorizontalAlign.Center;
        c9.CssClass = "TabHeader";

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c4);
        HeaderRow.Cells.Add(c5);
        HeaderRow.Cells.Add(c6);
        HeaderRow.Cells.Add(c7);
        HeaderRow.Cells.Add(c8);
        HeaderRow.Cells.Add(c9);

        tabListe.Rows.Add(HeaderRow);
        LinkButton lnkbtn;

        ArrayList AllMA = new ArrayList(); // enthaelt alle Mitarbiter, auch die die momentan nicht angezeigt werden

        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                // Selektieren aller Mitarbeiter des angemeldeten Genehmigers
                //Defect 4608: GN 1.8.2007 - Nur Mitarbeiter mit Status 20 werden angezeigt
                //using (SqlCommand cmd = new SqlCommand("SELECT b.perskey, b.persnr, b.mandant, b.vorname, b.nachname " +
                //                                "FROM bearbeit b, bearborg bo " +
                //                                "WHERE b.perskey = bo.perskey " +
                //                                "AND b.status = 20 " + //4608 status 20 eingef�gt
                //                                "AND orgkz ='V' " +
                //                                "AND perskey_org = @PERSKEY " +
                //                                "ORDER BY nachname, vorname", cnx)) // Defect 5436
                // Defect 5678, Firmenkennung wird f�r den Mitarbeiter richtig selektiert
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("SELECT b.perskey, b.persnr, b.mandant, b.vorname, b.nachname, (select Firmapers from x_con_fkz " + Config.Nolock + " where firmenkz = substring(b.persnr,1,2)) as fk " +
                                                       "FROM bearbeit b " + Config.Nolock + ", bearborg bo " + Config.Nolock +
                                                       "WHERE b.perskey = bo.perskey " +
                                                       "AND b.status = 20 " + //4608 status 20 eingef�gt
                                                       "AND orgkz ='V' " +
                                                       "AND perskey_org = @PERSKEY " +
                                                       "ORDER BY nachname, vorname", cnx)) // Defect 5436
                {

                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", Bearbeiter.Params.PERSKEY.Value));
                    //cmd.Parameters.Add(Bearbeiter.Params.PERSKEY);
                    //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005070" + "ComputeStd(): " + cmd.CommandText, null);

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005071" + "ComputeStd(): ", null);

                        //cmd.Parameters.Remove(Bearbeiter.Params.PERSKEY);
                        cmd.Parameters.Clear();
                        DateTime d = ParamVal.Date0;
                        //KMS xxxxxx - alte PostBackInsteadPageLoad abfragen l�schen weil diese funktionieren seit ein paar Versionen
                        //if( ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null )
                        d = Convert.ToDateTime(DDLMonatNeu.SelectedValue);
                        //else
                        //    d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
                        int iCnt = 0;
                        lblError.Text = ""; // Defect 5224
                        lblError.Visible = false; // Defect 5224

                        while (rd.Read())
                        {
                            iCnt++;
                            // Beginn Defect 5224:
                            // MA mit persnr = null nicht anzeigen
                            if (rd.IsDBNull(1))
                            {
                                lblError.Text = "Der Mitarbeiter " +
                                                rd.GetString(3) + " " + rd.GetString(4) +
                                                " kann nicht angezeigt werden, da seine Personalnummer nicht versorgt ist.";
                                lblError.Visible = true;
                                continue;
                            }
                            // Ende Defect 5224

                            // In das Array wird jeder Mitarbeiter aufgenommnen
                            //MAUebersichtZeile MAZeile = new MAUebersichtZeile(rd.GetInt32(0), rd.GetString(4), rd.GetString(3), rd.GetString(1), d, Convert.ToDateTime("01-" + d.Month.ToString() + "-" + d.Year.ToString() + " 00:00:00"), Bearbeiter.Firmenkennung, rd.GetString(2));
                            MAUebersichtZeile MAZeile = new MAUebersichtZeile(rd.GetInt32(0), rd.GetString(4), rd.GetString(3), rd.GetString(1), d, Convert.ToDateTime("01-" + d.Month.ToString() + "-" + d.Year.ToString() + " 00:00:00"), rd.GetString(5), rd.GetString(2)); // Defect 5678

                            AllMA.Add(MAZeile);

                            if ((SelMABis > -1 && SelMAVon > -1) &&
                                (SelMABis >= SelMAVon))
                            {
                                if (iCnt < SelMAVon ||
                                    iCnt > SelMABis)
                                {
                                    // nur Mitarbeiter im selektierten Bereich anzeigen
                                    continue;
                                }
                            }

                            MAZeile.SelectAllKtobjs(); // kontierbare Objekte (Auftragsnummer) ermitteln
                            MAZeile.ComputeStd();
                            //Argument = rd.GetInt32(0) + "-" + Convert.ToString(d.Year * 100 + d.Month); // im Format perskey-yyyymm

                            // Beginn #4079 - Liste aller zu genehmigenden Mitarbeiter
                            try
                            {
                            //    if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
                                StatusFilter = DDLStatusEBs.SelectedValue;
                            //    else
                            //        StatusFilter = DDLStatusFilter.DDL.SelectedValue;
                            }
                            catch
                            {
                                StatusFilter = "alle";
                            }
                            if ((MAZeile.EBLinktext == StatusFilter) || (StatusFilter == "alle"))
                            {
                                Argument = rd.GetInt32(0) + "-" + Convert.ToString(d.Year * 100 + d.Month); // im Format perskey-yyyymm
                                // Ende #4079

                                TableRow tr = new TableRow();
                                TableCell d1 = new TableCell();
                                d1.Text = rd.GetString(4); // Nachname Mitarbeiter
                                d1.HorizontalAlign = HorizontalAlign.Center;
                                d1.CssClass = "TabNewDay";
                                tr.Cells.Add(d1);

                                TableCell d2 = new TableCell();
                                d2.Text = rd.GetString(3); // Vorname Mitarbeiter
                                d2.HorizontalAlign = HorizontalAlign.Center;
                                d2.CssClass = "TabNewDay";
                                tr.Cells.Add(d2);

                                TableCell d3 = new TableCell();
                                d3.Text = rd.GetString(1); // Persnr Mitarbeiter;
                                d3.HorizontalAlign = HorizontalAlign.Center;
                                d3.CssClass = "TabNewDay";
                                tr.Cells.Add(d3);

                                TableCell d4 = new TableCell();
                                d4.Text = (MAZeile.SummeStunden.ToString("N") == "0,00" ? "" : MAZeile.SummeStunden.ToString("N"));
                                d4.HorizontalAlign = HorizontalAlign.Center;
                                d4.CssClass = "TabNewDay";
                                tr.Cells.Add(d4);

                                TableCell d5 = new TableCell();
                                d5.Text = (MAZeile.DavonGK.ToString("N") == "0,00" ? "" : MAZeile.DavonGK.ToString("N"));
                                d5.HorizontalAlign = HorizontalAlign.Center;
                                d5.CssClass = "TabNewDay";
                                tr.Cells.Add(d5);

                                TableCell d6 = new TableCell();
                                d6.Text = (MAZeile.GTAbsenzen.ToString() == "0" ? "" : MAZeile.GTAbsenzen.ToString());
                                d6.HorizontalAlign = HorizontalAlign.Center;
                                d6.CssClass = "TabNewDay";
                                tr.Cells.Add(d6);

                                TableCell d7 = new TableCell();
                                d7.Text = MAZeile.EBStatusText;
                                d7.HorizontalAlign = HorizontalAlign.Center;
                                d7.CssClass = "TabNewDay";
                                tr.Cells.Add(d7);

                                TableCell d8 = new TableCell();
                                lnkbtn = NewTaskButton(MAZeile.EBLinktext, "EditKG", Argument, "Klicken Sie hier um den Eintrag zu kontrollieren und zu genehmigen.", TaskButton_Click);
                                //lnkbtn.Enabled = !MAZeile.EBerichteGenehmigt;
                                lnkbtn.Enabled = MAZeile.blnBtnStatus;
                                // Beginn Defect #4524: Falls EB mit Status 10 vorhanden ist, 
                                // wird Button disabled.
                                if (MAZeile.blnEBWithStat10)
                                {
                                    lnkbtn.Enabled = false;
                                    lnkbtn.ToolTip = "Mitarbeiter hat noch nicht alle EB freigegeben!";
                                }
                                // Ende Defect #4524

                                // Beginn Defect 5678
                                if (lnkbtn.Text == MAUebersichtZeile.strFehlt)
                                {
                                    lnkbtn.ToolTip = "F�r diesen Mitarbeiter wurde noch kein EB erfasst!";
                                }
                                if (lnkbtn.Text == MAUebersichtZeile.strGenehmigt)
                                {
                                    lnkbtn.ToolTip = "Die Einsatzberichte f�r diesen Mitarbeiter sind genehmigt.";
                                }
                                // Ende Defect 5678

                                d8.Controls.Add(lnkbtn);
                                d8.HorizontalAlign = HorizontalAlign.Center;
                                d8.CssClass = "TabNewDay";
                                tr.Cells.Add(d8);

                                TableCell d9 = new TableCell();
                                //if (MAZeile.EBerichteGenehmigt && MAZeile.EBerichteOK) Defect 5757
                                if (MAZeile.EBerichteGenehmigt) // Das Deckblatt kann f�r genehmigte EB's gedruckt werden, Defect 5757
                                {
                                    LinkButton l1 = NewTaskButton("Drucken", "printKG", Argument, "Klicken Sie hier um ein Deckblatt f�r die Reiseabrechnung zu drucken.", PrintButton_Click);
                                    d9.Controls.Add(l1);
                                }
                                d9.HorizontalAlign = HorizontalAlign.Center;
                                d9.CssClass = "TabNewDay";
                                tr.Cells.Add(d9);

                                tabListe.Rows.Add(tr);
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }

        // Es werden die Buttons zur Selektion der Mitarbeiter (jeweils 20) erzeugt
        Table2.Controls.Clear();
        int SeiteMAVon = 0;
        int SeiteMABis = 0;

        TableRow trSeite = new TableRow();

        for (int Index = 1, IndexS = 1; Index <= AllMA.Count; Index += 20, IndexS++)
        {
            // Button f�r Selektion der Seite erzeugen
            // 1 Button selektiert 20 Mitarbeiter
            LinkButton btn = new LinkButton();
            btn.ID = "Seite" + Index;
            btn.SkinID = "";
            btn.Width = Unit.Percentage(100);
            SeiteMAVon = Index;
            SeiteMABis = Index + 19 > AllMA.Count ? AllMA.Count : Index + 19;

            btn.Text = IndexS + " ";
            btn.Font.Size = 14;
            btn.CommandName = "Select";
            btn.CommandArgument = SeiteMAVon + "-" + SeiteMABis;
            // Im Tooltip den ersten und letzten Nachnamen des Mitarbeiters anzeigen
            btn.ToolTip = ((MAUebersichtZeile)AllMA[SeiteMAVon - 1]).Nachname + " - " + ((MAUebersichtZeile)AllMA[SeiteMABis - 1]).Nachname;
            //KMS xxxxxx - alte PostBackInsteadPageLoad abfragen l�schen weil diese funktionieren seit ein paar Versionen
            //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
                btn.PostBackUrl = "~/Genehmigung/KG_PostBackPage.aspx?Command=Select&Argument=" + btn.CommandArgument;
            //else
            //    btn.Command += new CommandEventHandler(TaskSeiteButton_Click);
            TableCell d1Seite = new TableCell();
            d1Seite.Text = btn.Text;
            d1Seite.Controls.Add(btn);
            trSeite.Controls.Add(d1Seite);
        }
        Table2.Rows.Add(trSeite);

        // Button um die Gesamtliste anzuzeigen (f�r Genehmiger mit wenigen Mitarbeitern
        LinkButton btnG = new LinkButton();
        btnG.ID = "Gesamt";
        btnG.SkinID = "";
        btnG.Width = Unit.Percentage(100);
        SeiteMAVon = 1;
        SeiteMABis = AllMA.Count;
        btnG.Text = "Gesamtliste";
        btnG.Font.Size = 14;
        btnG.CommandName = "Select";
        btnG.CommandArgument = SeiteMAVon + "-" + SeiteMABis;
        btnG.ToolTip = "";
        //KMS xxxxxx - alte PostBackInsteadPageLoad abfragen l�schen weil diese funktionieren seit ein paar Versionen
        //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
        btnG.PostBackUrl = "~/Genehmigung/KG_PostBackPage.aspx?Command=Select&Argument=" + btnG.CommandArgument;
        //else
        //    btnG.Command += new CommandEventHandler(TaskSeiteButton_Click);

        TableCell d1Gesamt = new TableCell();
        d1Gesamt.Text = btnG.Text;
        d1Gesamt.Controls.Add(btnG);
        trSeite.Controls.Add(d1Gesamt);
        Table2.Rows.Add(trSeite);

        // merkiere die Aktuelle ausgew�hlte Seitennummer
        for (int j = 0; j < ((TableRow)Table2.Controls[0]).Cells.Count; j++)
        {
            LinkButton cell = (LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0];
            if (cell.CommandArgument == SelMAVon.ToString() + "-" + SelMABis.ToString())
            {
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Bold = true;
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Underline = true;
                //continue;
            }
            else
            {
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Bold = false;
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Underline = false;
            }
        }
        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "001310" + "MAUebersicht(): Ende", null);

        return tabListe;
    }
    // Ende Defect 3689 (V1.0.0022)

    // Beginn Defect 3689 (V1.0.0022)
    // MAListe entfernt
    /*private Table MAListe(int MAVon, int MABis)
    {
      xxID = 0;

      tabListe.Rows.Clear();

      tabListe.Width = Unit.Percentage(100);
      TableRow HeaderRow = new TableRow();
      TableCell c1 = new TableCell();
      c1.CssClass = "TabHeader";
      c1.Text = "Name";
      c1.Font.Bold = true;
      c1.HorizontalAlign = HorizontalAlign.Center;
      TableCell c2 = new TableCell();
      c2.Text = "Vorname";
      c2.Font.Bold = true;
      c2.HorizontalAlign = HorizontalAlign.Center;
      c2.CssClass = "TabHeader";
      TableCell c3 = new TableCell();
      c3.Text = "Personalnummer";
      c3.Font.Bold = true;
      c3.HorizontalAlign = HorizontalAlign.Center;
      c3.CssClass = "TabHeader";
      TableCell c4 = new TableCell();
      c4.Text = "SummeStd";
      c4.Font.Bold = true;
      c4.HorizontalAlign = HorizontalAlign.Center;
      c4.CssClass = "TabHeader";
      TableCell c5 = new TableCell();
      c5.Text = "GK.Std";
      c5.Font.Bold = true;
      c5.HorizontalAlign = HorizontalAlign.Center;
      c5.CssClass = "TabHeader";
      TableCell c6 = new TableCell();
      c6.Text = "GT.Absenz";
      c6.Font.Bold = true;
      c6.HorizontalAlign = HorizontalAlign.Center;
      c6.CssClass = "TabHeader";
      TableCell c7 = new TableCell();
      c7.Text = "Einsatzberichte";
      c7.Font.Bold = true;
      c7.HorizontalAlign = HorizontalAlign.Center;
      c7.CssClass = "TabHeader";
      TableCell c8 = new TableCell();
      c8.Text = "Status";
      c8.Font.Bold = true;
      c8.HorizontalAlign = HorizontalAlign.Center;
      c8.CssClass = "TabHeader";

      TableCell c9 = new TableCell();
      c9.Text = "Deckblatt";
      c9.Font.Bold = true;
      c9.HorizontalAlign = HorizontalAlign.Center;
      c9.CssClass = "TabHeader";

      HeaderRow.Cells.Add(c1);
      HeaderRow.Cells.Add(c2);
      HeaderRow.Cells.Add(c3);
      HeaderRow.Cells.Add(c4);
      HeaderRow.Cells.Add(c5);
      HeaderRow.Cells.Add(c6);
      HeaderRow.Cells.Add(c7);
      HeaderRow.Cells.Add(c8);
      HeaderRow.Cells.Add(c9);

      tabListe.Rows.Add(HeaderRow);
      LinkButton lnkbtn;

      // Defect 4268
      // in dieser Schleife werden nur genau die vom Genehmiger selektierten Mitarbeiter gesucht
      // die Selektion erfolgt �ber Buttons. Mit jeem Button k�nnen 20 seiner Mitarbeiter aufgeblendet werden.
      // Die Anzahl der Butons ergibt sich aus der Gesamtanzahl der Mitarbeiter,
      // f�r die der Genehmiger zust�ndig ist
      LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "010200" + " MAListe(): Before Loop ueber alle Mitarbeiter", null);

      Bearbeiter.SetSelMAVon(MAVon); // Performance 4268
      Bearbeiter.SetSelMABis(MABis); // Performance 4268

      if (MABis > Bearbeiter.Mitarbeiter.Count) MABis = Bearbeiter.Mitarbeiter.Count;
      for (int lIndex = MAVon; MAVon <= lIndex && MABis >= lIndex; lIndex++)
      {
        LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "010210" + " MAListe(): Alle Mitarbeiter", null);

        dbMitarbeiter b = (dbMitarbeiter)Bearbeiter.Mitarbeiter[lIndex - 1];

        // bisherige Schleife �ber alle Mitarbeiter entfernt
        // foreach (dbMitarbeiter b in Bearbeiter.Mitarbeiter)
        // {
        // Defect 4268 Ende
        DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
        Argument = b.Perskey.ToString() + "-" + b.Berichtsmonat.ToString();
        TableRow tr = new TableRow();
        TableCell d1 = new TableCell();
        d1.Text = b.Nachname;
        d1.HorizontalAlign = HorizontalAlign.Center;
        d1.CssClass = "TabNewDay";
        tr.Cells.Add(d1);

        TableCell d2 = new TableCell();
        d2.Text = b.Vorname;
        d2.HorizontalAlign = HorizontalAlign.Center;
        d2.CssClass = "TabNewDay";
        tr.Cells.Add(d2);

        TableCell d3 = new TableCell();
        d3.Text = b.PersNr;
        d3.HorizontalAlign = HorizontalAlign.Center;
        d3.CssClass = "TabNewDay";
        tr.Cells.Add(d3);

        TableCell d4 = new TableCell();
        //d4.Text = b.KGMonat.NormStunden.ToString("N");//(a.NormStunden.ToString("N") == "0,00" ? "" : a.NormStunden.ToString("N"))
        d4.Text = (b.SummeStunden.ToString("N") == "0,00" ? "" : b.SummeStunden.ToString("N"));
        d4.HorizontalAlign = HorizontalAlign.Center;
        d4.CssClass = "TabNewDay";
        tr.Cells.Add(d4);

        TableCell d5 = new TableCell();
        d5.Text = (b.DavonGK.ToString("N") == "0,00" ? "" : b.DavonGK.ToString("N"));
        d5.HorizontalAlign = HorizontalAlign.Center;
        d5.CssClass = "TabNewDay";
        tr.Cells.Add(d5);

        TableCell d6 = new TableCell();
        d6.Text = (b.GTAbsenzen.ToString() == "0" ? "" : b.GTAbsenzen.ToString());
        d6.HorizontalAlign = HorizontalAlign.Center;
        d6.CssClass = "TabNewDay";
        tr.Cells.Add(d6);

        TableCell d7 = new TableCell();
        d7.Text = b.EBStatusText;
        d7.HorizontalAlign = HorizontalAlign.Center;
        d7.CssClass = "TabNewDay";
        tr.Cells.Add(d7);

        TableCell d8 = new TableCell();
        lnkbtn = NewTaskButton(b.EBLinktext, "EditKG", Argument, "Klicken Sie hier um den Eintrag zu kontrollieren und zu genehmigen.", TaskButton_Click);
        lnkbtn.Enabled = !b.EBerichteGenehmigt;
        d8.Controls.Add(lnkbtn);
        d8.HorizontalAlign = HorizontalAlign.Center;
        d8.CssClass = "TabNewDay";
        tr.Cells.Add(d8);

        TableCell d9 = new TableCell();
        if (b.EBerichteGenehmigt && b.EBerichteOK)
        {
          LinkButton l1 = NewTaskButton("Drucken", "printKG", Argument, "Klicken Sie hier um ein Deckblatt f�r die Reiseabrechnung zu drucken.", PrintButton_Click);
          d9.Controls.Add(l1);
        }
        d9.HorizontalAlign = HorizontalAlign.Center;
        d9.CssClass = "TabNewDay";
        tr.Cells.Add(d9);

        tabListe.Rows.Add(tr);
      }

      // Defect 4268 Beginn
      // Es werden die Buttons zur Selektion der Mitarbeiter (jeweils 20) erzeugt
      Table2.Controls.Clear();
      int SeiteMAVon = 0;
      int SeiteMABis = 0;

      TableRow trSeite = new TableRow();

      for (int Index = 1, IndexS = 1; Index <= Bearbeiter.Mitarbeiter.Count; Index += 20, IndexS++)
      {
        // Button f�r Selektion der Seite erzeugen
        // 1 Button selektiert 20 Mitarbeiter
        LinkButton btn = new LinkButton();
        btn.ID = "Seite" + Index;
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        SeiteMAVon = Index;
        SeiteMABis = Index + 19 > Bearbeiter.Mitarbeiter.Count ? Bearbeiter.Mitarbeiter.Count : Index + 19;

        btn.Text = IndexS + " ";
        btn.Font.Size = 14;
        btn.CommandName = "Select";
        btn.CommandArgument = SeiteMAVon + "-" + SeiteMABis;
        // Im Tooltip den ersten und letzten Nachnamen des Mitarbeiters anzeigen
        btn.ToolTip = ((dbMitarbeiter)Bearbeiter.Mitarbeiter[SeiteMAVon - 1]).Nachname + " - " + ((dbMitarbeiter)Bearbeiter.Mitarbeiter[SeiteMABis - 1]).Nachname;
        btn.Command += new CommandEventHandler(TaskSeiteButton_Click);
        TableCell d1Seite = new TableCell();
        d1Seite.Text = btn.Text;
        d1Seite.Controls.Add(btn);
        trSeite.Controls.Add(d1Seite);
      }
      Table2.Rows.Add(trSeite);

      // Button um die Gesamtliste anzuzeigen (f�r Genehmiger mit wenigen Mitarbeitern
      LinkButton btnG = new LinkButton();
      btnG.ID = "Gesamt";
      btnG.SkinID = "";
      btnG.Width = Unit.Percentage(100);
      SeiteMAVon = 1;
      SeiteMABis = Bearbeiter.Mitarbeiter.Count;
      btnG.Text = "Gesamtliste";
      btnG.Font.Size = 14;
      btnG.CommandName = "Select";
      btnG.CommandArgument = SeiteMAVon + "-" + SeiteMABis;
      btnG.ToolTip = "";
      btnG.Command += new CommandEventHandler(TaskSeiteButton_Click);
      TableCell d1Gesamt = new TableCell();
      d1Gesamt.Text = btnG.Text;
      d1Gesamt.Controls.Add(btnG);
      trSeite.Controls.Add(d1Gesamt);
      Table2.Rows.Add(trSeite);
      // Defect 4268 Ende

      return tabListe;
    }*/
    // Ende Defect 3689 (V1.0.0022)

    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler)
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
        btn.PostBackUrl = "~/Genehmigung/KG_PostBackPage.aspx?Command=" + Command + "&Argument=" + Argument;
        //else
        //    btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        return btn;
    }

    // Defect 4268 Beginn
    // Ereignis, wenn Button zur Anzeige der Mitarbeiterliste gedr�ckt wird
    // SelMAVon enth�lt Startindex in MAListe, SelMABis den Endeindex 
    void TaskSeiteButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        switch (cmd)
        {
            case "Select":
                SelMAVon = Convert.ToInt32(arg.Substring(0, arg.IndexOf("-")));
                SelMABis = Convert.ToInt32(arg.Substring(arg.IndexOf("-") + 1, arg.Length - (arg.IndexOf("-") + 1)));
                // Defect 4268 (V1.0.0021) Beginn
                // Korrektur: falsche Mitarbeiterdaten werden angezeigt (vormals wurde eine static Variable verwendet)
                Session["SelMAVon"] = SelMAVon;
                Session["SelMABis"] = SelMABis;
                // Defect 4268 Ende
                DateTime d = ParamVal.Date0;
                //if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
                d = Convert.ToDateTime(DDLMonatNeu.SelectedValue);
                //else
                //    d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
                Bearbeiter.BerichtsMonat = d.Year * 100 + d.Month;
                //Bearbeiter.Mitarbeiter = null; Defect 5436, wird nicht verwendet
                Bearbeiter.MBerichte = null;
                Label2.Visible = true;

                phMAListe.Controls.Clear();
                //phMAListe.Controls.Add(MAListe(SelMAVon, SelMABis)); // Defect 3689 (V1.0.0022), Code entfernt
                phMAListe.Controls.Add(MAUebersicht()); // Defect 3689 (V1.0.0022), neue Funktion MAUebersicht()

                Session["Bearbeiter"] = Bearbeiter;
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;
        }
    }
    // Defect 4268 Ende

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }

    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        switch (cmd)
        {
            case "EditKG":
                int iPkey = Convert.ToInt32(arg.Substring(0, arg.IndexOf("-")));
                dbBearbeiter Monteur = new dbBearbeiter(iPkey);
                Monteur.Select(false);
                int d = Convert.ToInt32(arg.Substring(arg.IndexOf("-") + 1, arg.Length - (arg.IndexOf("-") + 1)));
                Monteur.BerichtsMonat = d;
                dbKG_Monat kgmonat = new dbKG_Monat(Monteur, d);
                kgmonat.Genehmiger = Bearbeiter.BearbInRole;
                Session["KGMonat"] = kgmonat;
                Debug.WriteLine("KG_Main:Redirect to KG_Zeiten at " + DateTime.Now.ToLongTimeString());
                Response.Redirect("~/Genehmigung/KG_Zeiten.aspx");
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;
        }
    }

    void PrintButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;

        int iPkey = Convert.ToInt32(arg.Substring(0, arg.IndexOf("-")));
        dbBearbeiter Monteur = new dbBearbeiter(iPkey);
        Monteur.Select(false);
        int d = Convert.ToInt32(arg.Substring(arg.IndexOf("-") + 1, arg.Length - (arg.IndexOf("-") + 1)));
        Monteur.BerichtsMonat = d;
        dbKG_Monat kgmonat = new dbKG_Monat(Monteur, d);
        kgmonat.Genehmiger = Bearbeiter.BearbInRole;


        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
        {
            //BAN 500059 Beginn
            bool neuReportLaden = true;
            dbSapReise sapReisen = new dbSapReise(iPkey, kgmonat.MinDatum, Bearbeiter.Params.MANDANT.Value.ToString());
            ArrayList reisen = sapReisen.GetTapReisen();
            if (reisen.Count > 0)
            {
                string ralist = "";
                foreach (string s in reisen)
                {
                    string[] split = s.Split(',');
                    if (split[3] == "40")
                    {
                        if (ralist.Length == 0)
                            ralist = split[0];
                        else
                            ralist += "," + split[0];
                    }
                    else
                    {
                        if (split[3] == "0")
                        {
                            //Reise ist nicht mit der neue Schnittstelle nach SAP versendet
                            //dann altes Blatt laden
                            neuReportLaden = false;
                            //man muss weiter nichts machen
                            break;
                        }
                    }
                }
                if( neuReportLaden)
                    Response.Redirect("~/Genehmigung/KG_ReisenDeckblatt.aspx?perskey=" + iPkey.ToString()
                        + "&mandant=" + Bearbeiter.Params.MANDANT.Value.ToString()
                        + "&raids=" + ralist);
                else
                    Root.Reports.RT.ResponsePDF(new pdfTravelCover(Monteur, kgmonat), this);//Response);
            }
        }
        else
            Root.Reports.RT.ResponsePDF(new pdfTravelCover(Monteur, kgmonat), this );//Response);
        //BAN 500059 Ende
    }
}
