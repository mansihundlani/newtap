//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_AZM.aspx.cs
//
// Description  : Abschlussmaske Kontrolle, Genehmigung,
//                Senden der Daten an AZM, Speichern von EB und RA
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2010
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//
//=============== V1.2.0011 ===================================================
//
// Date         : 27.September 2011
// Author       : Joldic Dzevad
// Defect#      : KMS BAN 500256 TAP-Montage: Erweiterte Zulagenpr�fung
//                Auch Liste der Zulagen wird angezeigt  
//
//=============== V1.2.0008 ===============================================
//
// Date         : 10.November 2010
// Author       : Joldic Dzevad
// Defect#      : BAF xxxxxx
//                Anpassung f�r user "UseNewHRInterface" wenn keine RZalsAZ
//                beinhalten (z.B. Lehrlinge)
//                
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//                
//=============== 1.0.0050 ================================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== V1.0.0044 ===============================================
//
// Date         : 03.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-34
//                Reisen nach manuellen �ndern von RNG aktualisieren
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.J�nner 2008
// Author       : Joldic Dzevad
// Defect#      : 5620
//                Korrektur f�r AUTOIVZ �bertragung von stundenweise Absenzen
//
//=============== V1.0.0036 ===============================================
//
// Date         : 13.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
// Date         : 13.Dezember 2007
// Author       : Joldic Dzevad
// Defect#      : 5705
//                Summen GK-Stunden falsch angezigt
//
//=============== V1.0.0035 ===============================================
//
// Date         : 29.November 2007
// Author       : Joldic Dzevad
// Defect#      : 5460
//                Anzeige der Absenz Std. fehlt
//
// Date         : 06.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5589
//                Benutzerdaten im Kopf nicht mehrmals versorgen
//
// Date         : 09.November 2007
// Author       : Norbert Krizek
// Defect#      : 5621
//                Fehler "Falsches Reisemonat" bei Hrn Niederhametner 67726
//
//=============== V1.0.0034 ===============================================
//
// Date         : 23.Oktober 2007
// Author       : Wolfgang Patrman
// Defect#      : 5569
//                Anzeige Benutzerdaten im Kopf, wird im IE mit angedruckt
//
// Date         : 27.August 2007
// Author       : Norbert Krizek
// Defect#      : 5363
//                Update von bereits in SAP eingetragenen Reisezeilen aus Vormonat
//                pruefen ob berichtsmonat mit reise passt
//
//=============== V1.0.0033 ===============================================
//
// Date         : 11.September 2007
// Author       : Wolfgang Patrman
// Defect#      : 5456
//                Mehrarbeitsh�ckchen f�r Mandant 'ME' aktivieren
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//--------------- V1.0.0029 ------------------------------------------------------------------------
//
// Date         : 19.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 4726
//                name mitarbeiter auf �berstundendisposition fehlt
//
//--------------- V1.0.0028 ------------------------------------------------------------------------ 
//
// Date         : 21. Juni 2007
// Author       : Caleb Gebhardt 
// Defect#      : 4300, 4947 
//
// Die Reisezeit innerhalb der Normalarbeitszeit muss in der Summe der 
// Normalstunde (in der Anzeige "Kontrolle & Genehmigung - Arbeitszeiten" )
// dazugerechnet werden. 
//
//--------------- V1.0.0027 ------------------------------------------------------------------------ 
//
// Date         : 24. Mai 2007
// Author       : Georg Nebehay
// Defect#      : 5107
//
// Die �berleitung an AZM von Fremdpersonal kann jetzt mandantenabh�ngig verhindert werden. 
//
//--------------- V1.0.0025 ------------------------------------------------------------------------
//
// Date         : 24. April 2007
// Author       : CG
// Defect#      : 4993
//
// Auswertung/Behandlung des Monatstatus (AZM-R�ckgabewert bei d. EB-Genehmigung):
// Dispo-wert 0 (Monat notReadyfordispo) bzw. 2 (Dispo bereits freigegeben).  
// Setfreigabe - Befehl nicht mehr ben�tigt.
// Monat zur�cksetzen vor jeder �bertragung der AZ-Stempel 
//
//--------------- V1.0.0024 ------------------------------------------------------------------------
//
// Date         : 17.April 2007
// Author       : CL
// Defect#      : 4728
//                Zus�tzliche Anzeige der Personalnummer im Seitenkopf
//
// -------------- V1.0.0023 ------------------------------------------------------------------------
//
// Date         : 20.M�rz 2007
// Author       : GN
// Defect#      : 4801
//
// Deadlocks beim Genehmigen:
// Beim Setzen der Leistungsarten ergibt sich gelegentlich eine Deadlocksituation. 
// Diese wurde durch ein applikationsseitiges MutEx behoben.
//
//
// Date         : 19.M�rz 2007
// Author       : GN
// Defect#      : 4777
//
// AZM-Kommunikation vor Datenbankspeicherung:
// Die Reihenfolge der Datensicherung wurde ver�ndert, um Inkonsistenzen Sissi <-> AZM zu verhindern.
// In der jetzigen L�sung werden die Sissidaten erst committed, wenn die AZM-Kommunikation erfolgreich ist.
// Sollte schon bei der Datenbankkommunikation ein Fehler auftreten, kommt es gar nicht mehr zu AZM-Kommunikation.
//
//
// Date         : 08.M�rz 2007
// Author       : GN
// Defect#      : 4695_4763_4779_4792
//
// Bei allen Defects kam es zu Timeouts beim Genehmigen von Fremdmitarbeitern.
// Der Grund f�r den Defect lag darin, dass die Arbeitszeiten der Mitarbeiter mittels Lazy-Loading geladen werden. 
// Bei herk�mmlichen MA wurden die Zeiten bei der Ansicht der Reisen geladen, bei
// Fremdmitarbeitern gibt es aber keine Reiseabrechnung, weswegen die Zeiten erst beim Dr�cken des
// Buttons �Genehmigen� auf der n�chsten Seite geladen wurden. Das war auch nie ein Problem, bis
// die Transaktion eingef�hrt wurde. Das Abfragen der Zeiten fand dann n�mlich innerhalb der Transaktion
// statt und ungl�cklicherweise sperrt der MSSQL-Server (unserer jedenfalls) meistens auf Tableebene,
// weswegen die Transaktion und die Abfrage der Zeiten sich gegenseitig sperrten.
//
//
// Date         : 28.Februar 2007
// Author       : WP
// CR#          : 4690
//                Die Checkboxen f�r Mehrarbeit sind f�r die EEI (Mandant �ME�) nicht anw�hlbar.
//
// -------------- V1.0.0022 ------------------------------------------------------------------------
//
// Date         : 27.Februar 2007
// Author       : CL
// Defect#      : 4684
//
// Das Speichern der SEG-Zulagen in die DB-Tabelle 'Zulage' muss ebenfalls an der DB-Transaktion teilnehmen. 
// Die Transaktion wird als Parameter an die Funktion 'SaveSEG' �bergeben.
//
//
// Date         : 24.Februar 2007
// Author       : GN
// Defect#      : 4625
//                Wir haben in der Datenbank f�r Berichtsmonat J�nner ca. 800 R/W Zeilen ohne Leistungsart.
//                Transaktionsthema
//
// -------------- V1.0.0021 ------------------------------------------------------------------------
//
// Date         : 3.Februar 2007
// Author       : CL
// Defect#      : 4493
//                Auch die SEG-Zulagen werden in die DB-Tabelle 'Zulage' gespeichert.
//
// -------------- V1.0.0016 ------------------------------------------------------------------------
//
// Date         : 13.Dezember 2006
// Author       : GN
// Defect#      : 3647
//         
// Bei Reisezeit au�erhalb NAZ die Leistungsart eintragen; Reisezeiten innerhalb der NAZ 
// sind in der AZ-Zeile mit "W" zu hinterlegen.
//                
//                3984
//                Funktionalit�t von Aktualisieren eingef�gen
//
// -------------- V1.0.0010 ------------------------------------------------------------------------
//
// Date         : 26.November 2006
// Author       : GN
// Defect#      : 3647
//                
// Bei Reisezeit au�erhalb NAZ die Leistungsart eintragen; Reisezeiten innerhalb der NAZ 
// sind in der AZ-Zeile mit "W" zu hinterlegen.
//
//--------------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;
using System.Collections.Generic;

public partial class Genehmigung_KG_AZM : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    dbKG_Monat KGMonat;
    dbKG_AZM KGAzm;

    private int CtrlIDMo = 0;
    private int CtrlIDAb = 0;

    private string NextIDMo()
    {
        CtrlIDMo++;
        return "ctrlMo-" + CtrlIDMo.ToString();
    }

    private string NextIDAb()
    {
        CtrlIDAb++;
        return "ctrlAb-" + CtrlIDAb.ToString();
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        bool bValid = true;
        bool bErrAzm = true;
        bool bSAPObjValid = true;
        string statusErrTxt = "";
        ArrayList PRJList = new ArrayList();


        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        KGMonat = (dbKG_Monat)Session["KGMonat"];
        KGAzm = (dbKG_AZM)Session["KGAzm"];
        bool UseNewHRInterface = false;
        if (Session["UseNewHRInterface"] != null)
            UseNewHRInterface = (bool)Session["UseNewHRInterface"];
        if (!IsPostBack) KGAzm = null;
        if (KGAzm == null)
        {
            KGAzm = new dbKG_AZM(KGMonat, Page, UseNewHRInterface);
            Session["KGAzm"] = KGAzm;
        }
        KGAzm.page = Page;
        // Beginn Defect # 4728: Zus�tzliche Anzeige der Personalnummer
        //Label2.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
        // Ende Defect # 4728

        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Kontrolle & Genehmigung - Arbeitszeiten</span><br /><span style=\"font-size: 12px;\">";
            Session["headData"] += KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString();
            // Defect 5569, Mitarbeiterinformationen anzeigen
            lbHeadInfo2.Text = lbHeadInfo.Text = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ") " + KGMonat.MonatText + " " + KGMonat.MinDatum.Year.ToString(); // Defect 5589
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        phAZListe.Controls.Add(AZListe());
        phAusZu.Controls.Add(ZulagenListe());

        if (KGAzm.ErrorMsg.Length > 0)
        {
            Label3.Text = KGAzm.ErrorMsg + ". Bitte aktualisieren Sie die Mehrarbeit.";
            bErrAzm = false;
            BtnLoad.Focus();
        }

        foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
        {
            if (!mb.Projekt.KontierbarInSAP())
            {
                statusErrTxt += mb.Projekt.Params.KTOBJ.Value.ToString() + " ";
                if (bSAPObjValid) bSAPObjValid = false;
            }
        }

        foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
        {
            bool EBStatf = Convert.ToInt32(mb.Params.EBSTAT.Value) == (int)dbMontBer.EBStat.freigegeben;
            if (EBStatf)
            {
                PRJList.Add(mb.Params.PROJID.Value);
            }
            if (bValid) bValid = (EBStatf) & bValid;
        }
        BtnNext.Enabled = bSAPObjValid & bValid & bErrAzm;

        if (!bSAPObjValid)
        {
            Label4.Text = "Folgende nicht bebuchbare Objekte sind diesem Einsatzbericht zugeordnet, daher Abbruch der Bearbeitung: " + statusErrTxt;
        }
        else
        {
            if (!bValid)
            {
                if (PRJList.Count > 0)
                {
                    for (int p = 0; p < PRJList.Count; p++)
                    {
                        foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
                        {
                            if (mb.Projekt.Params.PROJID.Value.ToString() == PRJList[p].ToString())
                            {
                                statusErrTxt += mb.Projekt.Params.KTOBJ.Value.ToString() + " ";
                                break;
                            }
                        }
                    }
                    Label4.Text = "WARNUNG- F�r folgende kontierbare Objekte sind alle Einsatzberichte nicht freigegeben: " + statusErrTxt;
                }
            }
        }
        if (KGMonat.IstFremdPersonal)
            BtnPrev.Text = "Zur�ck zu den Einsatzberichten <<";
        else
            BtnPrev.Text = "zur Reiseabrechnung <<";

        if (ConfigurationManager.AppSettings["PostBackInsteadPageLoad"] != null)
        {
            BtnPrev.Click -= new EventHandler(BtnPrev_Click);
            if (KGMonat.IstFremdPersonal)
                BtnPrev.PostBackUrl = "~/Genehmigung/KG_Zeiten.aspx";
            else
            {
                if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                {
                    BtnPrev.PostBackUrl = "~/Genehmigung/KG_SAP_RA.aspx";
                }
                else
                {
                    try
                    {
                        Session["fromAZM"] = true;
                    }
                    catch
                    { }
                    BtnPrev.PostBackUrl = "~/Genehmigung/KG_RA.aspx";
                }
            }
        }
    }

    private Control ZulagenListe()
    {
        Table tabZulageListe = new Table();
        tabZulageListe.Width = Unit.Percentage(60);

        TableRow rh;
        string xss = "TabHeader";

        rh = new TableRow();
        rh = AddNewCell(rh, "Zulage ", xss, HorizontalAlign.Left, 0, 0, true);
        rh = AddNewCell(rh, "Beschreibung ", xss, HorizontalAlign.Left, 0, 0, true);
        rh = AddNewCell(rh, "Anzahl ", xss, HorizontalAlign.Left, 0, 0, true);
        rh = AddNewCell(rh, "Status ", xss, HorizontalAlign.Left, 10, 0, false);
        
        List<zZeile> zulagen = new List<zZeile>();

        foreach (dbKG_AusZulProjekt azp in KGMonat.AusZulagenProjekte)
            foreach (dbKG_PMAusZulage az in azp.AusZulagen)
            {
                if (az.Anzahl > 0)
                { 
                    bool found = false;
                    foreach (zZeile auszu in zulagen)
                        if (auszu.Zulage == az.Lohnart)
                        {
                            auszu.Anzahl += az.Anzahl;
                            found = true;
                            break;
                        }
                    if (!found) zulagen.Add(new zZeile(az.Lohnart, az.Text, az.Anzahl, az.MaxAnzahl));
                }
            }

        if (zulagen.Count > 0)
        {
            tabZulageListe.Rows.Add(rh); //header
            foreach (zZeile z in zulagen)
            {
                rh = new TableRow();
                rh = AddNewCell(rh, z.Zulage + "&nbsp;", z.Css, HorizontalAlign.Left, 0, 0, true);
                rh = AddNewCell(rh, z.Beschreibung + "&nbsp;", z.Css, HorizontalAlign.Left, 0, 0, true);
                rh = AddNewCell(rh, z.Anzahl.ToString("N") + "&nbsp;", z.Css, HorizontalAlign.Left, 0, 0, true);
                rh = AddNewCell(rh, z.Status + "&nbsp;", z.Css, HorizontalAlign.Left, 10, 0, false);
                tabZulageListe.Rows.Add(rh);
            }
        }
        return tabZulageListe;
    }
    private class zZeile
    {
        public string Zulage;
        public string Beschreibung;
        public float MaxAnzahl;
        public string Status;
        public string Css;
        private float anzahl = 0f;
        public float Anzahl
        {
            get { return this.anzahl; }
            set
            {
                this.anzahl = value;
                if (this.MaxAnzahl > 0f && value > this.MaxAnzahl)
                {
                    this.Status = "Anzahl Zulagen liegt �ber den Grenzwert von " + this.MaxAnzahl.ToString();
                    this.Css = "TabNewDayRed";
                }
                else
                {
                    this.Status = "OK";
                    this.Css = "TabNewDay";
                }
            }
        }

        public zZeile(string zulage, string beschreibung, float lanzahl, float maxAnzahl)
        {
            this.Zulage = zulage;
            this.Beschreibung = beschreibung;
            this.MaxAnzahl = maxAnzahl;
            this.Anzahl = lanzahl;
        }
    }
    private class tZeile
    {
        //Tap Daten
        public string Datum;
        public string Von;
        public string Bis;
        public string TNormStd;
        public string TUe50;
        public string TUe100;
        public string TGNormStd;
        public string TGUe50;
        public string TGUe100;
        public string TStdAbsenz;
        public String TKVStd;
        public string TSumme;

        public string GTAbsenzID;
        public bool GTAbsenz;
        public string GTAbsenzText;
        public string StdAbsenzText;

        //AZM Daten
        public string AStatus;
        public string ABemerk;
        public string ASoll;
        public string AIst;
        public string ANorm;
        public string AUe50;
        public string AUe100;
        public string ATSaldo;
        public string AGSaldo;
        public string AGuthaben;
        public bool Morgens;
        public bool Abends;
        public bool MAMorgens;
        public bool MAAbends;


        public tZeile(DateTime datum, DateTime von, DateTime bis, string tnormstd, string tue50, string tue100, string tgnormstd, string tgue50, string tgue100, string tstdabsenz, string tsumme, string gtabsenzid, bool gtabsenz, string gtabsenztext, string stdabsenztext,
                        string astatus, string abemerk, string asoll, string aist, string anorm, string aue50, string aue100, string atsaldo, string agsaldo, string aguthaben, bool morgens, bool abends, bool maMorgens, bool maAbends, string kvStd)
        {
            if (datum.Ticks != ParamVal.Date0.Ticks)
            {
                string[] wTag = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa." };
                Datum = wTag[(int)datum.DayOfWeek] + " " + datum.Day.ToString() + "." + datum.Month.ToString() + ".";
            }
            else
                Datum = "";

            if (von.Ticks != ParamVal.Date0.Ticks)
            {
                Von = von.ToShortTimeString();
            }
            else
                Von = "";

            if (bis.Ticks != ParamVal.Date0.Ticks)
            {
                Bis = bis.ToShortTimeString();
            }
            else
                Bis = "";

            TNormStd = tnormstd;
            TUe50 = tue50;
            TUe100 = tue100;
            TGNormStd = tgnormstd;
            TGUe50 = tgue50;
            TGUe100 = tgue100;
            TStdAbsenz = tstdabsenz;
            TSumme = tsumme;
            GTAbsenzID = gtabsenzid;
            GTAbsenz = gtabsenz;
            GTAbsenzText = gtabsenztext;
            StdAbsenzText = stdabsenztext;
            AStatus = astatus;
            ABemerk = abemerk;
            ASoll = asoll;
            AIst = aist;
            ANorm = anorm;
            AUe50 = aue50;
            AUe100 = aue100;
            ATSaldo = atsaldo;
            AGSaldo = agsaldo;
            AGuthaben = aguthaben;
            Morgens = morgens;
            Abends = abends;
            MAMorgens = maMorgens;
            MAAbends = maAbends;
            TKVStd = kvStd;
        }

    }

    private Table AZListe()
    {
        Table tabAZListe = new Table();
        tabAZListe.Width = Unit.Percentage(100);

        TableRow rh;
        string xss = "TabHeader";

        rh = new TableRow();
        rh = AddNewCell(rh, "", "", HorizontalAlign.Center, 0, 0, true);
        rh = AddNewCell(rh, "", "", HorizontalAlign.Center, 0, 0, true);
        rh = AddNewCell(rh, "", "", HorizontalAlign.Center, 0, 0, true);
        //rh = AddNewCell(rh, "TAP-Daten", "BoldOnly", HorizontalAlign.NotSet, 10, 0, false);
        rh = AddNewCell(rh, "TAP-Daten", "BoldOnly", HorizontalAlign.NotSet, 11, 0, false);
        rh = AddNewCell(rh, "AZM-Daten", "BoldOnly", HorizontalAlign.NotSet, 8, 0, false);
        tabAZListe.Rows.Add(rh);

        rh = new TableRow();
        rh = AddNewCell(rh, "", "", HorizontalAlign.Center, 0, 0, true);
        rh = AddNewCell(rh, "", "", HorizontalAlign.Center, 0, 0, true);
        rh = AddNewCell(rh, "", "", HorizontalAlign.Center, 0, 0, true);
        rh = AddNewCell(rh, "Prod.Stunden", xss, HorizontalAlign.Center, 3, 0, false);
        rh = AddNewCell(rh, "GK Stunden", xss, HorizontalAlign.Center, 3, 0, false);
        rh = AddNewCell(rh, "", "", HorizontalAlign.NotSet, 3, 0, true);
        rh = AddNewCell(rh, "Mehrarbeit", xss, HorizontalAlign.Center, 2, 0, true);
        rh = AddNewCell(rh, "", "", HorizontalAlign.Center, 8, 0, false);
        tabAZListe.Rows.Add(rh);

        rh = new TableRow();
        rh = AddNewCell(rh, "Datum", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Von", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Bis", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Norm", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "50%", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "100%", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Norm", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "50%", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "100%", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "FZ lt. KV", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Absenz", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Summe", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "MO", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "AB", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Stat.", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Bemerk.", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Soll", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "Ist", xss, HorizontalAlign.Center, 0, 0, false);
        //rh = AddNewCell(rh, "Norm", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "50%", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "100%", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "TSaldo", xss, HorizontalAlign.Center, 0, 0, false);
        rh = AddNewCell(rh, "GSaldo", xss, HorizontalAlign.Center, 0, 0, false);
        //rh = AddNewCell(rh, "Guthaben", xss, HorizontalAlign.Center, 0, 0, false);
        //rh.Cells[rh.Cells.Count - 1].ColumnSpan = 2;
        tabAZListe.Rows.Add(rh);
        int nAzeit = 0;
        CtrlIDMo = 0;
        CtrlIDAb = 0;
        // Beginn Defect # 5460 ( 1. von 4 )
        double alleAbsenzNorStd = 0;
        double alleAbsenzGKStd = 0;
        double alleKVStd = 0.0;
        // Ende Defect # 5460 ( 1. von 4 )
        // Begin Defect #5705 1. Teil
        double alleGKNormStd = 0.0;
        double alleGK50Std = 0.0;
        double alleGK100Std = 0.0;
        double alleReiseNormStd = 0.0;
        // Ende Defect #5705 1. Teil
        foreach (dbKG_AZMTag az in KGAzm.AnzTage)
        {
            //CG - Defects 4300, 4947
            //  die Reisezeit innerhalb der normalarbeitzeit mu� zu der Summe der 
            //  Normalstunde dazugerechnet werden.
            //  beginn Defect 
            double ReiseNormStd = 0;
            double absenzNorStd = 0;
            double absenzGKStd = 0;
            // Begin Defect #5705 2. Teil
            double GKNorStd = 0.0;
            double GK50Std = 0.0;
            double GK100Std = 0.0;
            double KVStd = 0.0;
            // Ende Defect #5705 2. Teil
            //int j = 0;
            foreach (dbKG_AZMZeit azt in az.Zeiten)
            {
                // Ermittle die Zeitstempel f�r die sog. "W" - Zeile
                if (azt.IstReiseZeit & (azt.ReiseTyp == dbArbZeit.ArbZeitType.ReiseInDienstzeit))
                {
                    // Reise innerhalb der Arbeitzeit
                    ReiseNormStd += azt.NormStd;
                }
                // Beginn Defect # 5460 ( 2. von 4 )
                switch (azt.StdAbsID)
                {
                    case "":
                        break;
                    case "10":
                        // Pflegefreistellung
                        // absenzGKStd += az.TStdAbsenz;
                        // Defect #5620, �bertragung der Einzelwerte anstatt der Summe
                        absenzGKStd += Convert.ToDouble(azt.NormStd) / 60;
                        break;
                    case "90":
                        // Ersatzruhe -> NormalStd
                        // Defect #5620
                        absenzNorStd += Convert.ToDouble(azt.NormStd) / 60;
                        break;
                    case "100":
                        // Sonstiges
                        // Defect #5620
                        absenzGKStd += Convert.ToDouble(azt.NormStd) / 60;
                        break;
                    case "110":
                        // do nothing
                        break;
                    case "120":
                        KVStd += Convert.ToDouble(azt.NormStd) / 60;
                        break;
                    default:
                        break;
                }
                // Ende Defect # 5460 ( 2. von 4 )
                // Begin Defect #5705 3. Teil
                GKNorStd += Convert.ToDouble(azt.GNormStd) / 60;
                GK50Std += Convert.ToDouble(azt.GUe50) / 60;
                GK100Std += Convert.ToDouble(azt.GUe100) / 60;
                // Ende Defect #5705 3. Teil
            }

            // Beginn Defect # 5460 ( 3. von 4 )
            alleAbsenzNorStd += absenzNorStd;
            alleAbsenzGKStd += absenzGKStd;
            alleKVStd += KVStd;
            // Ende Defect # 5460 ( 3. von 4 )
            // Begin Defect #5705 4. Teil
            alleGKNormStd += GKNorStd;
            alleGK50Std += GK50Std;
            alleGK100Std += GK100Std;
            alleReiseNormStd += ReiseNormStd / 60;
            // Ende Defect #5705 4. Teil
            // Ende 4300, 4947
            ArrayList tZeilen = new ArrayList();
            /*
            tZeilen.Add(new tZeile(az.TagesDatum, az.Kommen, az.Gehen,
                                  ((az.TNormal + ReiseNormStd) / 60).ToString("N"),                         // Defect 4300, 4947
                                  (az.T50 / 60).ToString("N"), (az.T100 / 60).ToString("N"),
                                  (az.TGNormal / 60).ToString("N"), (az.TG50 / 60).ToString("N"),
                                  (az.TG100 / 60).ToString("N"), (az.TStdAbsenz / 60).ToString("N"),
                                  ((az.TSumme + ReiseNormStd) / 60).ToString("N"),                         // Defect 4300, 4947
                                   az.GTAbsenzID.ToString(), az.GTAbsenz, az.GTAbsenzText, az.StdAbsenzText,
                                   az.AStatus, az.ABemerk, (az.ASoll / 60).ToString("N"), (az.AIst / 60).ToString("N"),
                                  (az.ANorm / 60).ToString("N"), (az.AUe50 / 60).ToString("N"), (az.AUe100 / 60).ToString("N"),
                                  (az.ATSaldo / 60).ToString("N"), (az.AGSaldo / 60).ToString("N"), (az.AGuthaben / 60).ToString("N"),
                                  az.Morgens, az.Abends, az.MAMorgens, az.MAAbends)
                                  );
            */
            // Beginn Defect # 5460 ( 4. von 4 )
            /*
            tZeilen.Add(new tZeile(az.TagesDatum, az.Kommen, az.Gehen,
                                  ((az.TNormal + ReiseNormStd + absenzNorStd*60) / 60).ToString("N"),                         // Defect 4300, 4947
                                  (az.T50 / 60).ToString("N"), (az.T100 / 60).ToString("N"),
                                  ((az.TGNormal + absenzGKStd*60) / 60).ToString("N"), (az.TG50 / 60).ToString("N"),
                                  (az.TG100 / 60).ToString("N"), (az.TStdAbsenz / 60).ToString("N"),
                                  ((az.TSumme + ReiseNormStd + absenzGKStd*60 + absenzNorStd*60) / 60).ToString("N"),                         // Defect 4300, 4947
                                   az.GTAbsenzID.ToString(), az.GTAbsenz, az.GTAbsenzText, az.StdAbsenzText, 
                                   az.AStatus, az.ABemerk, (az.ASoll / 60).ToString("N"), (az.AIst / 60).ToString("N"), 
                                  (az.ANorm / 60).ToString("N"),(az.AUe50 / 60).ToString("N"), (az.AUe100 / 60).ToString("N"), 
                                  (az.ATSaldo / 60).ToString("N"),(az.AGSaldo / 60).ToString("N"), (az.AGuthaben / 60).ToString("N"), 
                                  az.Morgens, az.Abends,az.MAMorgens, az.MAAbends)
                                  );
             */
            // Ende Defect # 5460 ( 4. von 4 )
            // Begin Defect #5705 5. Teil
            tZeilen.Add(new tZeile(az.TagesDatum, az.Kommen, az.Gehen,
                                  ((az.TNormal + ReiseNormStd + absenzNorStd * 60) / 60).ToString("N"),                         // Defect 4300, 4947
                                  (az.T50 / 60).ToString("N"), 
                                  (az.T100 / 60).ToString("N"),
                                  (GKNorStd + absenzGKStd).ToString("N"),
                                  GK50Std.ToString("N"),
                                  GK100Std.ToString("N"),
                                  (az.TStdAbsenz / 60).ToString("N"),
                                  ((az.TSumme + ReiseNormStd + absenzGKStd * 60 + absenzNorStd * 60 + KVStd * 60) / 60).ToString("N"),                         // Defect 4300, 4947
                                   az.GTAbsenzID.ToString(), az.GTAbsenz, az.GTAbsenzText, az.StdAbsenzText,
                                   az.AStatus, az.ABemerk, (az.ASoll / 60).ToString("N"), (az.AIst / 60).ToString("N"),
                                  (az.ANorm / 60).ToString("N"), (az.AUe50 / 60).ToString("N"), (az.AUe100 / 60).ToString("N"),
                                  (az.ATSaldo / 60).ToString("N"), (az.AGSaldo / 60).ToString("N"), (az.AGuthaben / 60).ToString("N"),
                                  az.Morgens, az.Abends, az.MAMorgens, az.MAAbends, KVStd.ToString("N"))
                                  );
            // Ende Defect #5705 5. Teil
            if (tZeilen.Count == 0)
            {//add 1 tZeile mit TagesDatum
                tZeilen.Add(new tZeile(az.TagesDatum, ParamVal.Date0, ParamVal.Date0, "", "", "", "", "", "", "", "", "", false, "", "", "", "", "", "", "", "", "", "", "", "", false, false, false, false, ""));
            }

            for (int i = 0; i < tZeilen.Count; i++)
            {
                tabAZListe.Rows.Add(AddOneNewRow((tZeile)tZeilen[i], i, az.TagesDatum, nAzeit));
            }
            nAzeit++;
        }

        //Total Summe Zeile        
        TableRow tr = new TableRow();
        // tZeile tz = new tZeile(ParamVal.Date0, ParamVal.Date0, ParamVal.Date0, KGMonat.NormStunden.ToString("N"), KGMonat.UE50.ToString("N"), KGMonat.UE100.ToString("N"), "Summe", "GK", KGMonat.GK.ToString("N"), "", Convert.ToDouble(KGMonat.SummeProduktiveStunden + KGMonat.GK).ToString("N"), "", false, "","", "", "", KGAzm.ASoll.ToString("N"), KGAzm.AIst.ToString("N"), KGAzm.ANorm.ToString("N"), KGAzm.AUe50.ToString("N"), KGAzm.AUe100.ToString("N"), "", "", "", false, false, false, false);
        // Begin Defect #5705 6. Teil
        tZeile tz = new tZeile(ParamVal.Date0, ParamVal.Date0, ParamVal.Date0,
            (KGMonat.NormStunden + alleAbsenzNorStd + alleReiseNormStd).ToString("N"),
            KGMonat.UE50.ToString("N"),
            KGMonat.UE100.ToString("N"),
            (alleAbsenzGKStd + alleGKNormStd).ToString("N"),
            alleGK50Std.ToString("N"),
            alleGK100Std.ToString("N"),
            "",
            Convert.ToDouble(KGMonat.SummeProduktiveStunden + KGMonat.GK + alleAbsenzNorStd + alleAbsenzGKStd + alleReiseNormStd + alleKVStd).ToString("N"),
            "", false, "", "", "", "", KGAzm.ASoll.ToString("N"), KGAzm.AIst.ToString("N"), KGAzm.ANorm.ToString("N"), KGAzm.AUe50.ToString("N"), KGAzm.AUe100.ToString("N"), "", "", "", false, false, false, false, alleKVStd.ToString("N"));
        // Ende Defect #5705 6. Teil
        tz.Datum = "Summe";
        //tabAZListe.Rows.Add(AddOneNewRow(tz, 0, DateTime.Now, 0));
        tabAZListe.Rows.Add(AddOneNewRow(tz, 0, KGMonat.MaxDatum.Date, 0));
        return tabAZListe;
    }

    TableRow AddOneNewRow(tZeile tz, int ind, DateTime Tag, int iCountZeile)
    {
        TableRow tr = new TableRow();
        if ((tz.Datum.ToUpper().IndexOf("SUM") >= 0)) ind = 0;
        string strCssClassRow = (ind > 0 ? "TabZeile" + CssWE(Tag) : "TabNewDay" + CssWE(Tag));
        TableCell d1 = new TableCell();
        if (ind == 0) d1.Text = tz.Datum;
        if ((tz.Datum.ToUpper().IndexOf("SUM") >= 0))
        {
            d1.ID = "";
        }
        else
        {
            d1.ID = Tag.ToString() + "-" + iCountZeile.ToString();
        }
        d1.HorizontalAlign = HorizontalAlign.Center;
        //d1.ID = ind.ToString();
        d1.CssClass = strCssClassRow;
        tr.Cells.Add(d1);

        TableCell d2 = new TableCell();
        d2.Text = tz.Von;
        d2.HorizontalAlign = HorizontalAlign.Center;
        d2.CssClass = strCssClassRow;
        tr.Cells.Add(d2);

        TableCell d3 = new TableCell();
        d3.Text = tz.Bis;
        d3.HorizontalAlign = HorizontalAlign.Center;
        d3.CssClass = strCssClassRow;
        tr.Cells.Add(d3);

        TableCell d4 = new TableCell();
        d4.Text = (tz.TNormStd == "0,00" ? "" : tz.TNormStd);
        d4.HorizontalAlign = HorizontalAlign.Center;
        d4.CssClass = strCssClassRow;
        tr.Cells.Add(d4);

        TableCell d5 = new TableCell();
        d5.Text = (tz.TUe50 == "0,00" ? "" : tz.TUe50);
        d5.HorizontalAlign = HorizontalAlign.Center;
        d5.CssClass = strCssClassRow;
        tr.Cells.Add(d5);

        TableCell d6 = new TableCell();
        d6.Text = (tz.TUe100 == "0,00" ? "" : tz.TUe100);
        d6.HorizontalAlign = HorizontalAlign.Center;
        d6.CssClass = strCssClassRow;
        tr.Cells.Add(d6);

        TableCell d7 = new TableCell();
        d7.Text = (tz.TGNormStd == "0,00" ? "" : tz.TGNormStd);
        d7.HorizontalAlign = HorizontalAlign.Center;
        d7.CssClass = strCssClassRow;
        tr.Cells.Add(d7);

        TableCell d8 = new TableCell();
        d8.Text = (tz.TGUe50 == "0,00" ? "" : tz.TGUe50);
        d8.HorizontalAlign = HorizontalAlign.Center;
        d8.CssClass = strCssClassRow;
        tr.Cells.Add(d8);

        TableCell d9 = new TableCell();
        d9.Text = (tz.TGUe100 == "0,00" ? "" : tz.TGUe100);
        d9.HorizontalAlign = HorizontalAlign.Center;
        d9.CssClass = strCssClassRow;
        tr.Cells.Add(d9);

        TableCell d91 = new TableCell();
        d91.Text = (tz.TKVStd == "0,00" ? "" : tz.TKVStd);
        d91.HorizontalAlign = HorizontalAlign.Center;
        d91.CssClass = strCssClassRow;
        tr.Cells.Add(d91);

        TableCell d10 = new TableCell();
        if (tz.GTAbsenz)
            d10.Text = tz.GTAbsenzText;
        else
            if (tz.StdAbsenzText != "")
                d10.Text = tz.StdAbsenzText;
        d10.HorizontalAlign = HorizontalAlign.Center;
        d10.CssClass = strCssClassRow;
        tr.Cells.Add(d10);

        TableCell d11 = new TableCell();
        d11.Text = (tz.TSumme == "0,00" ? "" : tz.TSumme);
        d11.HorizontalAlign = HorizontalAlign.Center;
        d11.CssClass = strCssClassRow;
        tr.Cells.Add(d11);

        TableCell d12 = new TableCell();
        if ((tz.Datum.ToUpper().IndexOf("SUM") >= 0) | tz.GTAbsenz)
        {
            //do nothing
        }
        else
        {
            if (tz.MAMorgens)
            {
                CheckBox cboxMo = new CheckBox();
                // Beginn CR 4690: Checkboxen f�r EEI disablen,
                // keine individuelle �berstundengenehmigung zul�ssig
                // Beginn Defect 5456
                // Mehrarbeitsh�ckchen f�r Mandant ME wieder erm�glichen
                //if (KGMonat.Monteur.Mandant.MANDANT == "ME")
                //{
                //  cboxMo.Enabled = false;
                //}
                //else
                //{ Ende Defect 5456
                // Ende CR 4690
                cboxMo.AutoPostBack = true;
                cboxMo.ID = NextIDMo();
                cboxMo.Checked = tz.Morgens;
                cboxMo.CheckedChanged += new EventHandler(cboxMo_CheckedChanged);
                // } Defect 5456
                d12.Controls.Add(cboxMo);
            }
        }
        d12.HorizontalAlign = HorizontalAlign.Center;
        d12.CssClass = strCssClassRow;
        tr.Cells.Add(d12);

        TableCell d13 = new TableCell();
        if ((tz.Datum.ToUpper().IndexOf("SUM") >= 0) | tz.GTAbsenz)
        {
            //do nothing
        }
        else
        {
            if (tz.MAAbends)
            {
                CheckBox cboxAb = new CheckBox();
                // Beginn CR 4690: Checkboxen f�r EEI disablen,
                // keine individuelle �berstundengenehmigung zul�ssig
                // Beginn Defect 5456
                // Mehrarbeitsh�ckchen f�r Mandant ME wieder erm�glichen
                //if (KGMonat.Monteur.Mandant.MANDANT == "ME")
                //{
                //  cboxAb.Enabled = false;
                //}
                //else
                //{ Ende Defect 5456
                // Ende CR 4690
                cboxAb.AutoPostBack = true;
                cboxAb.ID = NextIDAb();
                cboxAb.Checked = tz.Abends;
                cboxAb.CheckedChanged += new EventHandler(cboxAb_CheckedChanged);
                d13.Controls.Add(cboxAb);
                // } // Defect 5456
            }
        }
        d13.HorizontalAlign = HorizontalAlign.Center;
        d13.CssClass = strCssClassRow;
        tr.Cells.Add(d13);

        TableCell d14 = new TableCell();
        d14.Text = tz.AStatus;
        d14.HorizontalAlign = HorizontalAlign.Center;
        d14.CssClass = strCssClassRow;
        tr.Cells.Add(d14);

        TableCell d15 = new TableCell();
        d15.Text = tz.ABemerk;
        d15.HorizontalAlign = HorizontalAlign.Center;
        d15.CssClass = strCssClassRow;
        tr.Cells.Add(d15);

        TableCell d16 = new TableCell();
        d16.Text = (tz.ASoll == "0,00" ? "" : tz.ASoll);
        d16.HorizontalAlign = HorizontalAlign.Center;
        d16.CssClass = strCssClassRow;
        tr.Cells.Add(d16);

        TableCell d17 = new TableCell();
        d17.Text = (tz.AIst == "0,00" ? "" : tz.AIst);
        d17.HorizontalAlign = HorizontalAlign.Center;
        d17.CssClass = strCssClassRow;
        tr.Cells.Add(d17);

        //TableCell d14 = new TableCell();
        //d14.Text = (tz.ANorm == "0,00" ? "" : tz.ANorm);
        //d14.HorizontalAlign = HorizontalAlign.Center;
        //d14.CssClass = strCssClassRow;
        //tr.Cells.Add(d14);

        TableCell d18 = new TableCell();
        d18.Text = (tz.AUe50 == "0,00" ? "" : tz.AUe50);
        d18.HorizontalAlign = HorizontalAlign.Center;
        d18.CssClass = strCssClassRow;
        tr.Cells.Add(d18);

        TableCell d19 = new TableCell();
        d19.Text = (tz.AUe100 == "0,00" ? "" : tz.AUe100);
        d19.HorizontalAlign = HorizontalAlign.Center;
        d19.CssClass = strCssClassRow;
        tr.Cells.Add(d19);

        TableCell d20 = new TableCell();
        d20.Text = (tz.ATSaldo == "0,00" ? "" : tz.ATSaldo);
        d20.HorizontalAlign = HorizontalAlign.Center;
        d20.CssClass = strCssClassRow;
        tr.Cells.Add(d20);

        TableCell d21 = new TableCell();
        d21.Text = (tz.AGSaldo == "0,00" ? "" : tz.AGSaldo);
        d21.HorizontalAlign = HorizontalAlign.Center;
        d21.CssClass = strCssClassRow;
        tr.Cells.Add(d21);

        //TableCell d19 = new TableCell();
        //d19.Text = (tz.AGuthaben == "0,00" ? "" : tz.AGuthaben);
        //d19.HorizontalAlign = HorizontalAlign.Center;
        //d19.CssClass = strCssClassRow;
        //tr.Cells.Add(d19);

        return tr;
    }
    void cboxMo_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = (CheckBox)sender;
        dbKG_AZMTag at = GetAzmTagByID((cb.Parent.Parent as TableRow).Cells[0].ID);
        at.Morgens = cb.Checked;
        //        Session["KGAzm"] = KGAzm;
    }
    void cboxAb_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = (CheckBox)sender;
        dbKG_AZMTag at = GetAzmTagByID((cb.Parent.Parent as TableRow).Cells[0].ID);
        at.Abends = cb.Checked;
        //        Session["KGAzm"] = KGAzm;
    }

    private string CssWE(DateTime Tag)
    {
        //BAF 530042 - Beginn
        if (KGMonat.Monteur.AZMKalenderTage.ContainsKey(Tag))
        {
            if (KGMonat.Monteur.AZMKalenderTage[Tag].IstArbeitstag)
                return "";
            else
                return "WE";
        } //BAF 530042 Ende
        else
        {
            if (KGMonat.Monteur.IstArbeitstag(Tag))
                return "";
            else
                return "WE";
        }
    }

    TableRow AddNewCell(TableRow r, string LabelText, string css, HorizontalAlign align, int colspan, int borderwidth, bool noborder)
    {
        TableCell c = new TableCell();
        Label l = new Label();
        l.Text = LabelText;
        //l.Font.Bold = bold;
        c.Controls.Add(l);
        c.CssClass = css;
        c.HorizontalAlign = align;
        if (css == "" && noborder)
            c.BorderWidth = Unit.Pixel(borderwidth);
        c.ColumnSpan = colspan;
        r.Cells.Add(c);
        return r;
    }

    protected void BtnPrev_Click(object sender, EventArgs e)
    {
        if (KGMonat.IstFremdPersonal)
            Response.Redirect("~/Genehmigung/KG_Zeiten.aspx");
        else
        {
            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
            {
                Response.Redirect("~/Genehmigung/KG_SAP_RA.aspx");
            }
            else
            {
                //TAPM-34 Session variable versorgen, damit man neu Reisengenerierung unterdrucken kann
                try
                {
                    Session["fromAZM"] = true;
                }
                catch
                { }
                Response.Redirect("~/Genehmigung/KG_RA.aspx");
            }
        }
    }

    //Defect 4801
    //20.03.2007
    //Deadlocks beim Genehmigen
    //Folgendes Objekt wird f�rs Locken verwendet. Durch die statische Deklarierung dieses Objekts
    //wird ein applikationsweiter Lock erm�glicht.
    private static object myLock = new object();

    //Defect 4777
    //GN 19.3.2007 AZM-Kommunikation vor Datenbankspeicherung
    //Die Reihenfolge der Datenspeicherung wurde umgedreht.
    //Nun wird zuerst in der Datenbank gespeichert und dann nach
    //erfolgreicher AZM-Kommunikation committed
    protected void BtnNext_Click(object sender, EventArgs e)
    {
        string name = KGMonat.Monteur.Params.NACHNAME.Value.ToString();
        //Defects 4695_4763_4779_4792
        //GN 8.1.2007
        //Diese Zeilen verhindern, dass die Zeiten innerhalb der Transaktion geladen werden
        //�nderung Ende
        foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
        {
            foreach (dbArbTag at in mb.ReiseTage)
            {
                object o = at.Zeiten;
            }

        }
        //Defects 4695_4763_4779_4792 �nderung Ende

        //Defect 4801
        //20.03.2007
        //Deadlocks beim Genehmigen
        //Folgender Lock behebt den m�glichen Deadlock beim Setzen der Leistungsarten
        lock (myLock)
        {


            //#4625 - Transaktionsthema
            //GN 24.02.2007
            //Hier wird die Transaktion gestartet
            SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString);
            cnx.Open();
            SqlTransaction tx = cnx.BeginTransaction();
            //#4625 �nderung Ende

            try
            {
                //Defect 3984 GN Funktionalit�t von aktualisieren hier eingef�gt
                if (ConfigurationManager.AppSettings["NoAZMUsage"] == null && KGMonat.UseAzm) //Defect 5107 GN if-Abfrage auf KGMonat.UseAZM ausgeweitet
                {
                    if (KGAzm.ResetMonth() == dbKG_AZM.dbKG_FuncRetTyp.OK)
                    {
                        KGAzm.Send2Azm();
                    }
                }
                Session["KGAzm"] = KGAzm;

                //save data, commit EBs, RA, AZM
                //clear Session[...] in KG_Main
                bool bValid = true;
                foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
                    bValid = (Convert.ToInt32(mb.Params.EBSTAT.Value) == (int)dbMontBer.EBStat.freigegeben) & bValid;
                if (bValid)
                {

                    #region EB, RA in der Datenbank Committen
                    foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
                    {
                        mb.Params.EBSTAT.Value = dbMontBer.EBStat.genehmigt;
                        //#4625 - Transaktionsthema
                        //GN 24.02.2007
                        //Transaktion wird jetzt �bergeben
                        mb.Save(tx);
                    }
                    // Defect #4493: Auch die SEG-Zulagen werden in die Tabelle
                    //               'Zulagen' gespeichert
                    try
                    {
                        dbAusZulage dbSEGZulage = null;
                        dbMontBer dbMb = null;
                        foreach (dbKG_SEGZulage dbSEG in KGMonat.SEGZulagen)
                        {
                            // Zun�chst wird der EB f�r diese Zulage gesucht
                            dbMb = null;
                            foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
                            {
                                if (mb.Projekt.Params.KTOBJ.Value.ToString() == dbSEG.AuftragNr)
                                {
                                    dbMb = mb;
                                    break;
                                }
                            }

                            // Neues Zulagenobjekt erstellen, falls EB gefunden
                            if (dbMb != null)
                            {
                                dbSEGZulage = new dbAusZulage(dbMb);
                                /* Beginn Defect #4684: Speichern der SEG-Zulagen
                                 * muss ebenfalls die DB-Transaktion verwenden:
                                 * Offene Transaction verwenden: Parameter 'tx' */
                                dbSEGZulage.SaveSEG(dbSEG, tx);
                                // Ende Defect #4684
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        // Exception bei Speichern der SEG-Zulagen soll
                        // den �brigen Save-Ablauf nicht behindern
                        String strErrMessage = ex.Message;
                        // 
                    }
                    // Ende Defect #4493
                    //BAN 500059 Beginn
                    //BAF xxxxxx - Abfrage auf KGMonat.RZalsAZ verschoben weil Reisen von IUS oder PTD Mitarbeieter
                    //wenn keine RZalsAZ haben dann landen sie ins Code von B&I und bei abspeichern kommt die Exception
                    //"Unable to cast dbKG_ReiseZeile to dbRaZeile"
                    if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                    {
                        if (KGMonat.RZalsAZ != null && KGMonat.RZalsAZ.Count > 0)
                        {
                            //Als erstens die ZNR holen:
                            Int16 znr = GetNextZNR(tx);
                            //string la = GetMostlyLA(tx, ref znr);
                            //ArrayList mostlyLAproEB = new ArrayList();
                            Dictionary<int, string> mostlyLAproEB = new Dictionary<int, string>();

                            //AZID holen:
                            int azid = Bearbeiter.Commons.GetNextxIDs(14, "Arbzeit", KGMonat.RZalsAZ.Count);

                            if (azid < 0)
                            {
                                //Fehler bei Auslesen neuer IDs
                                Exception ex = new Exception("KG_AZM.aspx.cs::dbIDFetcher::getNextIDs: No columns found for mandant, nrbandart, Bemerk: " + Bearbeiter.Params.MANDANT.Value + ", 14, Arbzeit");
                                throw ex;
                            }

                            foreach (dbAZ_ARBZEITParams az in KGMonat.RZalsAZ)
                            {
                                //az.AZID.Value = Bearbeiter.Commons.GetNextID(14, "Arbzeit");
                                az.AZID.Value = azid++;
                                string la = "";
                                if (!mostlyLAproEB.TryGetValue(Convert.ToInt32(az.EBID.Value), out la))
                                {
                                    la = GetMostlyLA(tx, Convert.ToInt32(az.EBID.Value));
                                    if (la != "")
                                    {
                                        mostlyLAproEB.Add(Convert.ToInt32(az.EBID.Value), la);
                                    }
                                    else
                                    {
                                        //keine Ahnung ... sollte aber nicht passieren
                                    }
                                }
                                az.LEISTART.Value = la;
                                az.ZNR.Value = ++znr;
                                string sql = "Insert into Arbzeit " + Config.Rowlock + " (AZID,MANDANT,EBID,PERSKEY,DATUM,BEGINN,ENDE,AZUMMOKZ,AZUMABKZ,KZAZGUELTIG,PAUSE,NORMSTD,UESTD50,UESTD100,KZAZ,STDABSENZID,BEMERKUNG,KMLOHNART,KM,KMKZSG,AUFTRNR,SUBNR,KZTA,CODE,KZVA,BELEGNR,DATLA,AENPERSKEY,DATNEU,KZVK,ZNR,DATUGORK,DATUGEOS,MA_BEGINN,MA_ENDE,MA_STD,MA_PAUSE,DATUGBEMO,FLDTXT1,FLDTXT2,LEISTART,BEREIT,FLDTXT3,DATUGKORAM,DATUGRUECKM,EQUIPMENTNR,INTF_ID,PORTFOLIO) " +
                                             "VALUES (@AZID,@MANDANT,@EBID,@PERSKEY,@DATUM,@BEGINN,@ENDE,@AZUMMOKZ,@AZUMABKZ,@KZAZGUELTIG,@PAUSE,@NORMSTD,@UESTD50,@UESTD100,@KZAZ,@STDABSENZID,@BEMERKUNG,@KMLOHNART,@KM,@KMKZSG,@AUFTRNR,@SUBNR,@KZTA,@CODE,@KZVA,@BELEGNR,@DATLA,@AENPERSKEY,@DATNEU,@KZVK,@ZNR,@DATUGORK,@DATUGEOS,@MA_BEGINN,@MA_ENDE,@MA_STD,@MA_PAUSE,@DATUGBEMO,@FLDTXT1,@FLDTXT2,@LEISTART,@BEREIT,@FLDTXT3,@DATUGKORAM,@DATUGRUECKM,@EQUIPMENTNR,@INTF_ID,@PORTFOLIO)";
                                SqlCommand cmd = new SqlCommand(sql, cnx, tx);
                                foreach (SqlParameter s in az.List) cmd.Parameters.Add(s);
                                cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                            }
                        }
                        //Die Reise ist schon TAP DB
                        //RFC Aufrufen und Reisen in SAP genehmigen
                        //dbSapReise SapReisen = new dbSapReise((int)(KGMonat.Monteur.Params.PERSKEY.Value), KGMonat.MinDatum, KGMonat.Monteur.Params.MANDANT.Value.ToString());
                        //string Fehler = SapReisen.ApproveAllTrips(tx);
                        //if (Fehler.Length > 0)
                        //{
                        //    Exception ex = new Exception("KG_AZM.aspx.cs::Fehler bei SAP Reisengenehmigung : " + Fehler );
                        //    throw ex;
                        //}

                        //Reisen in TAP auf �bertragen setzen
                    }//BAN 500059 Ende
                    else
                    {
                        foreach (dbKG_Reise r in KGMonat.Rabrech.Reisen)
                        {
                            // defect 5363 beginn: pruefen ob berichtsmonat mit reise passt:
                            int ber_jahr = Convert.ToInt16(KGMonat.Monat.ToString().Substring(0, 4));
                            int ber_monat = Convert.ToInt16(KGMonat.Monat.ToString().Substring(4, 2));
                            DateTime r_von_nextday = r.Von.AddDays(1);
                            DateTime r_von_prevday = r.Von.AddDays(-1);
                            DateTime r_von = r.Von;
                            DateTime r_bis_nextday = r.Bis.AddDays(1);
                            DateTime r_bis_prevday = r.Bis.AddDays(-1);
                            DateTime r_bis = r.Bis;
                            // wir pr�fen, ob dea von oder bis im monat liegt, auch einen tag vor oder nach dem monat
                            // das ist jetzt ein tag aus dem vormonat 
                            if ((r_von_nextday.Month == ber_monat) && (r_von_nextday.Year == ber_jahr) && (r_von_nextday.Day == 1))
                            {
                                r_von = r_von_nextday;
                            }
                            // das ist jetzt ein tag aus dem n�chten monat
                            if ((r_von_prevday.Month == ber_monat) && (r_von_prevday.Year == ber_jahr) && (r.Von.Day == 1))
                            {
                                r_von = r_von_prevday;
                            }
                            // das ist jetzt ein tag aus dem vormonat
                            if ((r_bis_nextday.Month == ber_monat) && (r_bis_nextday.Year == ber_jahr) && (r_bis_nextday.Day == 1))
                            {
                                r_bis = r_bis_nextday;
                            }
                            // das ist jetzt ein tag aus dem n�chten monat
                            if ((r_bis_prevday.Month == ber_monat) && (r_bis_prevday.Year == ber_jahr) && (r.Bis.Day == 1))
                            {
                                r_bis = r_bis_prevday; // r_von_prevday;   defect 5621 cut and paste fehler....
                            }
                            // jetzt sind die tage aus dem vor un folgemonat bereinigt, jetzt pr�fen wir das auf aktuelle monat
                            if ((r_bis.Month != ber_monat) || (r_bis.Year != ber_jahr)
                                 || (r_von.Month != ber_monat) || (r_von.Year != ber_jahr)
                                 || (r.Kopf.Berichtsmonat != KGMonat.Monat)
                            )
                            {
                                // da ist was faul im staate reisen...wir werfen ne exception...
                                Exception ex2 = new Exception("KG_AZM.aspx.cs::BtnNext_Click: Reisemonat falsch: Reise.Berichtsmonat = " + KGMonat.Monat
                                    + ", Typ = " + r.GetType()
                                    + ", Reise.Von = " + r.Von.ToString()
                                    + ", Reise.Bis = " + r.Bis.ToString()
                                    + ", Reise.Kopf.Berichtsmonat " + r.Kopf.Berichtsmonat.ToString()
                                    )
                                    ;
                                throw ex2; // wir schwirren mal ab...defect 5363

                            }
                            //defect 5363 ende

                            if ((dbKG_Rabrech.RaStat)r.Kopf.Params.RASTAT.Value != dbKG_Rabrech.RaStat.Uebertragen)
                            {
                                r.Kopf.Params.RASTAT.Value = dbKG_Rabrech.RaStat.Genehmigt;
                                //#4625 - Transaktionsthema
                                //GN 24.02.2007
                                //Transaktion wird jetzt �bergeben
                                r.Kopf.Save(tx);
                            }
                        }
                    }
                    foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
                    {


                        //#4625 - Transaktionsthema
                        //GN 24.02.2007
                        //Transaktion wird jetzt �bergeben

                        SetLeistart(mb, tx); //HACK: Hier werden per sql skript die Leistungsarten gesetzt
                    }


                    // CG Defect 4993
                    // #region AZM: Tagfreigabe, Zulagen, Genehmigung
                    // Optimierung- Freigabe nicht mehr notwendig
                    #region AZM: Zulagen, Genehmigung

                    if (ConfigurationManager.AppSettings["NoAZMUsage"] == null && KGMonat.UseAzm) //Defect 5107 GN if-Abfrage auf KGMonat.UseAZM ausgeweitet
                    {
                        KGAzm.Zulagen();
                    }

                    dbKG_AZM.dbKG_MonatstatusTyp Monatstatus = dbKG_AZM.dbKG_MonatstatusTyp.statusunknown;
                    if (KGAzm.NextKommunication)
                    {
                        if (ConfigurationManager.AppSettings["NoAZMUsage"] == null && KGMonat.UseAzm) //Defect 5107 GN if-Abfrage auf KGMonat.UseAZM ausgeweitet
                        {
                            // CG: Defect 4993
                            // Optimierung- Freigabe nicht mehr notwendig
                            // KGAzm.Tagfreigabe();
                            //Ende 4993

                            // CG: Defect 4993 - wurde um ein Parameter erweitert Taggenehmigung() --> Taggenehmigung(false)
                            Monatstatus = KGAzm.Taggenehmigung(false);
                            switch ((int)Monatstatus)
                            {
                                case (int)dbKG_AZM.dbKG_MonatstatusTyp.NotReadyforDispo:
                                    // 
                                    Monatstatus = KGAzm.CheckDispo(dbKG_AZM.dbKG_AUTOIVZRequestTyp.Taggenehmigungkz);
                                    break;
                                case (int)dbKG_AZM.dbKG_MonatstatusTyp.DispoReleased:
                                    // 
                                    Monatstatus = KGAzm.Taggenehmigung(true);
                                    break;
                                default: break;
                            }
                            if (Monatstatus == dbKG_AZM.dbKG_MonatstatusTyp.DispoApproved)
                            {
                                // es wurde automatisch disponiert
                                // tue nix mehr!
                            }
                            if (Monatstatus == dbKG_AZM.dbKG_MonatstatusTyp.ReadyforDispo)
                            {
                                // 
                                // Es wurde nicht automatisch disponiert, jetzt Dispo - Maske holen
                                //
                                KGAzm.GetDispo();
                                Monatstatus = (dbKG_AZM.dbKG_MonatstatusTyp)KGAzm.DMStatus;
                            }
                        }
                    #endregion

                        //#4625 - Transaktionsthema
                        //GN 24.02.2007
                        //wenn alles gut geht, wird hier die Transaktion abgeschlossen
                        tx.Commit();

                    #endregion
                        if (ConfigurationManager.AppSettings["NoAZMUsage"] == null && KGMonat.UseAzm) //Defect 5107 GN if-Abfrage auf KGMonat.UseAZM ausgeweitet
                        {
                            /*   
                                if (KGAzm.DMStatus == 1)
                                    Response.Redirect("~/Genehmigung/KG_Dispo.aspx");
                                else
                                    Response.Redirect("~/Genehmigung/KG_Main.aspx");
                            */
                            // CG: Defect 4993 � Monatstatus 0 und 2 bearbeiten
                            switch (Monatstatus)
                            {
                                case dbKG_AZM.dbKG_MonatstatusTyp.NotReadyforDispo:
                                    // kommt hier nicht, wird schon �ber checkDispo abgearbeitet
                                    break;

                                // Beginn #4726 - name mitarbeiter auf �berstundendisposition fehlt
                                case dbKG_AZM.dbKG_MonatstatusTyp.ReadyforDispo:
                                    string userName = KGMonat.Monteur.Params.VORNAME.Value.ToString() + " " + KGMonat.Monteur.Params.NACHNAME.Value.ToString() + " (" + KGMonat.Monteur.Params.PERSNR.Value.ToString() + ")";
                                    Response.Redirect("~/Genehmigung/KG_Dispo.aspx?userName=" + userName);
                                    break;
                                // Ende #4726

                                case dbKG_AZM.dbKG_MonatstatusTyp.DispoReleased:
                                    // kommt hier nicht, wird schon �ber checkDispo abgearbeitet
                                    break;

                                case dbKG_AZM.dbKG_MonatstatusTyp.DispoApproved:
                                    Response.Redirect("~/Genehmigung/KG_Main.aspx");
                                    break;
                                default: break;
                            }
                        }
                        else
                        {
                            // wenn hier angelangt, gehe z�rck zum Main; Dispo nicht notwendig
                            Response.Redirect("~/Genehmigung/KG_Main.aspx");
                        }
                    }
                    else
                    {
                        Label3.Text = KGAzm.ErrorMsg + "Ung�ltige Lohnarten werden nicht�bernommen. Sie haben unzul�ssige Zulagen f�r diesen Mitarbeiter.";
                        tx.Rollback();
                    }
                }
                else
                {
                    //display Error!
                }

            }
            catch (Exception ef)
            {
                try
                {
                    //#4625 - Transaktionsthema
                    //GN 24.02.2007
                    //Hier wird die Tranaktionsverbindung zur�ckgerollt, wenn etwas schiefgeht
                    tx.Rollback();
                }
                catch (Exception) { }
                throw ef;
            }
        }

    }

    private short GetNextZNR(SqlTransaction tx)
    {
        short ret = -1;
        string ebids = "";
        foreach (dbMontBer mb in KGMonat.Monteur.MBerichte)
        {
            if (ebids.Length > 0)
                ebids += ",";
            ebids += mb.Params.EBID.Value.ToString();
        }
        try
        {
            SqlConnection cnx = tx.Connection;
            string sql = "SELECT MAX(ZNR) FROM ARBZEIT " + Config.Nolock + " WHERE EBID IN (" + ebids + ")";
            SqlCommand cmd = new SqlCommand(sql, cnx, tx);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ret = rd.GetInt16(0);
            }
            rd.Close();
        }
        catch
        {
        }
        return ret;
    }

    private void InsertRZinAZ(SqlTransaction tx)
    {


    }

    private string GetMostlyLA(SqlTransaction tx, int ebid)
    {
        string la = "";
        try
        {
            SqlConnection cnx = tx.Connection;
            string sql = "SELECT TOP 1 LEISTART FROM ARBZEIT " + Config.Nolock + " WHERE EBID = " + ebid.ToString();
            SqlCommand cmd = new SqlCommand(sql, cnx, tx);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                la = rd.GetString(0);
            }
            rd.Close();
        }
        catch
        {

        }
        return la;
    }

    private void SetLeistart(dbMontBer mb, SqlTransaction tx)
    {

        //#4625 - Transaktionsthema
        //GN 24.02.2007
        //Hier wird die Tranaktionsverbindung verwendet
        SqlConnection cnx = tx.Connection;

        {
            // Defect 3647
            // Bei Reisezeit au�erhalb NAZ die Leistungsart eintragen
            // Reisezeiten innerhalb der NAZ sind in der AZ-Zeile mit
            // "W" zu hinterlegen
            // Defect 5725, Config.Rowlock eingef�hrt
            String sql1 = "UPDATE ARBZEIT " + Config.Rowlock + " SET LEISTART = (SELECT top 1 LEISTART FROM ARBZEIT " + Config.Rowlock + " WHERE DATUM < a1.beginn and perskey = a1.perskey and kzaz = 'A' ORDER BY BEGINN DESC) FROM ARBZEIT a1 " + Config.Rowlock + " JOIN RAZEILE " + Config.Rowlock + " ON (beginn = ab or ende = an) "
              + "WHERE perskey = @PERSKEY "
              + "AND DATUM >= @MONAT1 "
              + "AND DATUM < @MONAT2 "
              + "AND Zeilenkz in ('S', 'R') AND (a1.LEISTART IS NULL OR a1.LEISTART = '') and a1.EBID IS NOT NULL AND KZAZ IN ('W', 'R') AND RAID IN (SELECT RAID FROM RAKOPF " + Config.Rowlock + " WHERE ABRNR IN (SELECT EBID FROM EINSBER " + Config.Rowlock + " WHERE perskey = a1.perskey))";

            String sql2 = "UPDATE ARBZEIT " + Config.Rowlock + " SET LEISTART = (SELECT top 1 LEISTART FROM ARBZEIT " + Config.Rowlock + " WHERE beginn > a1.beginn and perskey = a1.perskey and kzaz = 'A' ORDER BY BEGINN ASC) FROM ARBZEIT a1 " + Config.Rowlock + " JOIN RAZEILE " + Config.Rowlock + " ON (beginn = ab or ende = an) "
              + "WHERE perskey = @PERSKEY "
              + "AND DATUM >= @MONAT1 "
              + "AND DATUM < @MONAT2 "
              + "AND Zeilenkz in ('H') AND (a1.LEISTART IS NULL OR a1.LEISTART = '') and a1.EBID IS NOT NULL AND KZAZ IN ('W', 'R') AND RAID IN (SELECT RAID FROM RAKOPF " + Config.Rowlock + " WHERE ABRNR IN (SELECT EBID FROM EINSBER " + Config.Rowlock + " WHERE perskey = a1.perskey))";

            SqlCommand cmd1 = new SqlCommand(sql1, cnx, tx);
            SqlCommand cmd2 = new SqlCommand(sql2, cnx, tx);

            DateTime pmonth1 = mb.MinDatum.AddDays(-1); //falls Hinreise in vormonat begonnen ist
            DateTime pmonth2 = mb.MaxDatum;
            int ppersKey = int.Parse(mb.Params.PERSKEY.Value.ToString());

            SqlParameter persKey = new SqlParameter("@PERSKEY", ppersKey);
            SqlParameter month1 = new SqlParameter("@MONAT1", pmonth1);
            SqlParameter month2 = new SqlParameter("@MONAT2", pmonth2);

            cmd1.Parameters.Add(month1);
            cmd1.Parameters.Add(month2);
            cmd1.Parameters.Add(persKey);

            int res1 = cmd1.ExecuteNonQuery();
            cmd1.Parameters.Remove(month1);
            cmd1.Parameters.Remove(month2);
            cmd1.Parameters.Remove(persKey);

            cmd2.Parameters.Add(month1);
            cmd2.Parameters.Add(month2);
            cmd2.Parameters.Add(persKey);
            int res2 = cmd2.ExecuteNonQuery();
        }

    }

    private void ReadLine(TableRow r)
    {
        bool bMorgens = false;
        bool bAbends = false;
        dbKG_AZMTag at = GetAzmTagByID(r.Cells[0].ID);
        if ((r.Cells[11].Controls.Count > 0) && (r.Cells[11].Controls[0] is CheckBox))
        {
            bMorgens = (r.Cells[11].Controls[0] as CheckBox).Checked;
            at.Morgens = bMorgens;
        }
        if ((r.Cells[12].Controls.Count > 0) && (r.Cells[12].Controls[0] is CheckBox))
        {
            bAbends = (r.Cells[12].Controls[0] as CheckBox).Checked;
            at.Abends = bAbends;
        }
    }

    private void ReadTable()
    {
        Table TabListe = (Table)phAZListe.Controls[0];
        foreach (TableRow tr in TabListe.Rows)
            if ((tr.Cells[0].ID != null) && (tr.Cells[0].ID != "")) ReadLine(tr);
    }

    protected void BtnLoad_Click(object sender, EventArgs e)
    {
        ReadTable();
        KGAzm.ErrorMsg = "";
        if (ConfigurationManager.AppSettings["NoAZMUsage"] == null && KGMonat.UseAzm) //Defect 5107 GN if-Abfrage auf KGMonat.UseAZM ausgeweitet
        {
            if (KGAzm.ResetMonth() == dbKG_AZM.dbKG_FuncRetTyp.OK)
            {
                KGAzm.Send2Azm();
            }
        }
        Session["KGAzm"] = KGAzm;
        phAZListe.Controls.Clear();
        phAZListe.Controls.Add(AZListe());
        if (KGAzm.ErrorMsg.Length > 0)
        {
            Label3.Text = KGAzm.ErrorMsg + ". Bitte aktualisieren Sie die Mehrarbeit.";
            BtnNext.Enabled = false;
            BtnLoad.Focus();
        }
        else
        {
            Label3.Text = "";
            BtnNext.Enabled = true;
            BtnNext.Focus();
        }
    }

    int GetTagByID(string ID)
    {
        return Convert.ToInt32(ID.Substring(ID.IndexOf("-") + 1));
    }

    dbKG_AZMTag GetAzmTagByID(string ID)
    {
        return (KGAzm.AnzTage[GetTagByID(ID)] as dbKG_AZMTag);
    }

}
