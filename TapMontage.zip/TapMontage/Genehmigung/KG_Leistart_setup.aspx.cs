//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_Leistart_setup.ascx.cs
//
// Description  : Voreinstellung einer Leistungsart je Mitarbeiter
//
//=============== V1.0.0045 ===============================================
//
// Date         : 16.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-21
//                Voreinstellung einer Leistungsart je Mitarbeiter
//
//=========================================================================
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using TapMontage.dbObjects;

public partial class Genehmigung_Default : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    int SelMAVon = 0; // Startindex in MAListe f�r Selektion der Mitarbeiter
    int SelMABis = 0; // Endeindex in MAListe f�r Selektion der Mitarbeiter

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Kontrolle & Genehmigung - Voreinstellung einer Leistungsart je Mitarbeiter</span>";
        }
        catch
        {/* Nicht behandelt! */}
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        try
        {
            SelMAVon = (int)Session["SelMAVon2"];
            SelMABis = (int)Session["SelMABis2"];
        }
        catch
        {
            SelMAVon = 1;
            SelMABis = 20;
            Session["SelMAVon2"] = SelMAVon;
            Session["SelMABis2"] = SelMABis;
        }
        phMAListe.Controls.Clear();
        phMAListe.Controls.Add(MAUebersicht());
        Panel1.Visible = false;
    }
    /*
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (Session["SelMAVon2"] != null)
        {
            SelMAVon = (int)Session["SelMAVon2"];
        }
        else
        {
            // Es werden die Mitarbeiter 1 - 20 angezeigt
            SelMAVon = 1;
            Session["SelMAVon2"] = SelMAVon;
        }

        if (Session["SelMABis2"] != null)
        {
            SelMABis = (int)Session["SelMABis2"];
        }
        else
        {
            // Es werden die Mitarbeiter 1 - 20 angezeigt
            SelMABis = 20;
            Session["SelMABis2"] = SelMABis;
        }
        phMAListe.Controls.Clear();
        phMAListe.Controls.Add(MAUebersicht());
    }*/
    private Table MAUebersicht()
    {
        Table tabListe = new Table();
        xxID = 0;

        tabListe.Rows.Clear();

        tabListe.Width = Unit.Percentage(100);
        TableRow HeaderRow = new TableRow();
        TableCell c1 = new TableCell();
        c1.CssClass = "TabHeader";
        c1.Text = "Name";
        c1.Font.Bold = true;
        c1.HorizontalAlign = HorizontalAlign.Center;
        TableCell c2 = new TableCell();
        c2.Text = "Vorname";
        c2.Font.Bold = true;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        TableCell c3 = new TableCell();
        c3.Text = "Personalnummer";
        c3.Font.Bold = true;
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        TableCell c4 = new TableCell();
        c4.Text = "Default Leistart";
        c4.Font.Bold = true;
        c4.HorizontalAlign = HorizontalAlign.Center;
        c4.CssClass = "TabHeader";
        TableCell c5 = new TableCell();
        c5.Text = "Aktion";
        c5.Font.Bold = true;
        c5.HorizontalAlign = HorizontalAlign.Center;
        c5.CssClass = "TabHeader";

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c4);
        HeaderRow.Cells.Add(c5);

        tabListe.Rows.Add(HeaderRow);
        ArrayList AllMA = new ArrayList(); // enthaelt alle Mitarbiter, auch die die momentan nicht angezeigt werden

        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT b.perskey, b.persnr, b.mandant, b.vorname, b.nachname, (select Firmapers from x_con_fkz " + Config.Nolock + " where firmenkz = substring(b.persnr,1,2)) as fk, " +
                                                       "dl.leistart FROM bearbeit b " + Config.Nolock + ", bearborg bo " + Config.Nolock + ", default_leistart dl " + Config.Nolock +
                                                       "WHERE b.perskey = bo.perskey " +
                                                       "AND dl.perskey = bo.perskey " +
                                                       "AND b.status = 20 " + //4608 status 20 eingef�gt
                                                       "AND orgkz ='V' " +
                                                       "AND perskey_org = @PERSKEY " +
                                                       "ORDER BY nachname, vorname", cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", Bearbeiter.Params.PERSKEY.Value));
                    //cmd.Parameters.Add(Bearbeiter.Params.PERSKEY);
                    //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005070" + "ComputeStd(): " + cmd.CommandText, null);

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005071" + "ComputeStd(): ", null);

                        //cmd.Parameters.Remove(Bearbeiter.Params.PERSKEY);
                        cmd.Parameters.Clear();

                        int iCnt = 0;

                        while (rd.Read())
                        {
                            iCnt++;
                            string leistart = "nicht definiert";
                            if (!rd.IsDBNull(6))
                            {
                                dbBearbeiter Monteur = new dbBearbeiter(rd.GetInt32(0));
                                ArrayList ListofValuePairs = Monteur.Commons.Leistungsart;
                                foreach (ValuePair vp in ListofValuePairs)
                                {
                                    if (vp.Value == rd.GetString(6))
                                        leistart = vp.Text;
                                }
                            }
                            MAUebersichtZeile MAZeile = new MAUebersichtZeile(rd.GetInt32(0), rd.GetString(4), rd.GetString(3), rd.GetString(1), rd.GetString(5), leistart);
                            AllMA.Add(MAZeile);

                            if ((SelMABis > -1 && SelMAVon > -1) &&
                                (SelMABis >= SelMAVon))
                            {
                                if (iCnt < SelMAVon ||
                                    iCnt > SelMABis)
                                {
                                    // nur Mitarbeiter im selektierten Bereich anzeigen
                                    continue;
                                }
                            }

                            //MAZeile.SelectAllKtobjs(); // kontierbare Objekte (Auftragsnummer) ermitteln
                            //MAZeile.ComputeStd();
                            //Argument = rd.GetInt32(0) + "-" + Convert.ToString(d.Year * 100 + d.Month); // im Format perskey-yyyymm
                            //Argument = rd.GetInt32(0) + "-" + Convert.ToString(d.Year * 100 + d.Month); // im Format perskey-yyyymm
                            // Ende #4079

                            TableRow tr = new TableRow();
                            TableCell d1 = new TableCell();
                            d1.Text = rd.GetString(4); // Nachname Mitarbeiter
                            d1.HorizontalAlign = HorizontalAlign.Center;
                            d1.CssClass = "TabNewDay";
                            tr.Cells.Add(d1);

                            TableCell d2 = new TableCell();
                            d2.Text = rd.GetString(3); // Vorname Mitarbeiter
                            d2.HorizontalAlign = HorizontalAlign.Center;
                            d2.CssClass = "TabNewDay";
                            tr.Cells.Add(d2);

                            TableCell d3 = new TableCell();
                            d3.Text = rd.GetString(1); // Persnr Mitarbeiter;
                            d3.HorizontalAlign = HorizontalAlign.Center;
                            d3.CssClass = "TabNewDay";
                            tr.Cells.Add(d3);

                            TableCell d4 = new TableCell();
                            d4.Text = leistart; //LA
                            d4.HorizontalAlign = HorizontalAlign.Center;
                            d4.CssClass = "TabNewDay";
                            tr.Cells.Add(d4);

                            LinkButton btn = new LinkButton();
                            btn.ID = nid();
                            btn.SkinID = "";
                            btn.Width = Unit.Percentage(100);
                            btn.Text = "Bearbeiten";
                            btn.CommandName = rd.GetInt32(0).ToString(); //Perskey
                            btn.CommandArgument = leistart;
                            btn.ToolTip = "Klicken Sie hier um default LA einzustellen.";
                            btn.CausesValidation = false;
                            btn.Command += new CommandEventHandler(TaskButton_Click);
                            TableCell d5 = new TableCell();
                            d5.Controls.Add(btn);
                            d5.HorizontalAlign = HorizontalAlign.Center;
                            d5.CssClass = "TabNewDay";
                            tr.Cells.Add(d5);

                            tabListe.Rows.Add(tr);
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }

        // Es werden die Buttons zur Selektion der Mitarbeiter (jeweils 20) erzeugt
        Table2.Controls.Clear();
        int SeiteMAVon = 0;
        int SeiteMABis = 0;

        TableRow trSeite = new TableRow();

        for (int Index = 1, IndexS = 1; Index <= AllMA.Count; Index += 20, IndexS++)
        {
            // Button f�r Selektion der Seite erzeugen
            // 1 Button selektiert 20 Mitarbeiter
            LinkButton btn = new LinkButton();
            btn.ID = "Seite" + Index;
            btn.SkinID = "";
            btn.Width = Unit.Percentage(100);
            SeiteMAVon = Index;
            SeiteMABis = Index + 19 > AllMA.Count ? AllMA.Count : Index + 19;

            btn.Text = IndexS + " ";
            btn.Font.Size = 14;
            btn.CommandName = "Select";
            btn.CommandArgument = SeiteMAVon + "-" + SeiteMABis;
            // Im Tooltip den ersten und letzten Nachnamen des Mitarbeiters anzeigen
            btn.ToolTip = ((MAUebersichtZeile)AllMA[SeiteMAVon - 1]).Nachname + " - " + ((MAUebersichtZeile)AllMA[SeiteMABis - 1]).Nachname;
            btn.Command += new CommandEventHandler(TaskSeiteButton_Click);
            TableCell d1Seite = new TableCell();
            d1Seite.Text = btn.Text;
            d1Seite.Controls.Add(btn);
            trSeite.Controls.Add(d1Seite);
        }
        Table2.Rows.Add(trSeite);

        // Button um die Gesamtliste anzuzeigen (f�r Genehmiger mit wenigen Mitarbeitern
        LinkButton btnG = new LinkButton();
        btnG.ID = "Gesamt";
        btnG.SkinID = "";
        btnG.Width = Unit.Percentage(100);
        SeiteMAVon = 1;
        SeiteMABis = AllMA.Count;
        btnG.Text = "Gesamtliste";
        btnG.Font.Size = 14;
        btnG.CommandName = "Select";
        btnG.CommandArgument = SeiteMAVon + "-" + SeiteMABis;
        btnG.ToolTip = "";
        btnG.Command += new CommandEventHandler(TaskSeiteButton_Click);
        TableCell d1Gesamt = new TableCell();
        d1Gesamt.Text = btnG.Text;
        d1Gesamt.Controls.Add(btnG);
        trSeite.Controls.Add(d1Gesamt);
        Table2.Rows.Add(trSeite);

        for (int j = 0; j < ((TableRow)Table2.Controls[0]).Cells.Count; j++)
        {
            LinkButton cell = (LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0];
            if (cell.CommandArgument == SelMAVon.ToString() + "-" + SelMABis.ToString())
            {
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Bold = true;
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Underline = true;
            }
            else
            {
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Bold = false;
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Underline = false;
            }
        }
        return tabListe;
    }

    private class MAUebersichtZeile
    {
        public int Perskey;
        public string Nachname;
        public string Vorname;
        public string Persnr;
        public string Firmenkennung;
        public string Leistart;

        public MAUebersichtZeile(int perskey, string nachname, string vorname, string persnr, string firmenkennung, string la)
        {
            Perskey = perskey;
            Nachname = nachname;
            Vorname = vorname;
            Persnr = persnr;
            Firmenkennung = firmenkennung;
            Leistart = la;
        }

    }
    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        lbPerskey.Text = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        Panel1.Visible = true;
        int iPkey = Convert.ToInt32(lbPerskey.Text);
        dbBearbeiter Monteur = new dbBearbeiter(iPkey);
        string SelectedValue = arg;
        MAName.Text = Monteur.Params.NACHNAME.Value.ToString() + " " + Monteur.Params.VORNAME.Value.ToString();
        ArrayList ListofValuePairs = Monteur.Commons.Leistungsart;
        ddlLeistart.Items.Clear();
        ddlLeistart.Items.Add(new ListItem ("nicht definiert", "zero"));
        foreach (ValuePair vp in ListofValuePairs)
        {
            ddlLeistart.Items.Add(new ListItem(vp.Text, vp.Value));
            if (vp.Text == SelectedValue)
                ddlLeistart.SelectedIndex = ddlLeistart.Items.Count - 1;
        }
    }
    void TaskSeiteButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        switch (cmd)
        {
            case "Select":
                SelMAVon = Convert.ToInt32(arg.Substring(0, arg.IndexOf("-")));
                SelMABis = Convert.ToInt32(arg.Substring(arg.IndexOf("-") + 1, arg.Length - (arg.IndexOf("-") + 1)));
                Session["SelMAVon2"] = SelMAVon;
                Session["SelMABis2"] = SelMABis;
                phMAListe.Controls.Clear();
                phMAListe.Controls.Add(MAUebersicht());
                Session["Bearbeiter"] = Bearbeiter;
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (lbPerskey.Text == "")
            return;
        if (ddlLeistart.SelectedValue == "")
            return;
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("update DEFAULT_LEISTART SET leistart = @LEISTART, datla = @DATLA, aendperskey = @AENDPERSKEY where perskey = @PERSKEY", cnx))
                {
                    if( ddlLeistart.SelectedValue == "zero" )
                        cmd.Parameters.Add(new SqlParameter("@LEISTART", DBNull.Value));
                    else
                        cmd.Parameters.Add(new SqlParameter("@LEISTART", ddlLeistart.SelectedValue));
                    cmd.Parameters.Add(new SqlParameter("@DATLA", DateTime.Now));
                    cmd.Parameters.Add(new SqlParameter("@AENDPERSKEY", Bearbeiter.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", Convert.ToInt32(lbPerskey.Text)));

                    if (cmd.ExecuteNonQuery() == 1)
                    {
                       //Alles OK
                        ddlLeistart.Items.Clear();
                        lbPerskey.Text = "";
                    }
                    cmd.Parameters.Clear();
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        phMAListe.Controls.Clear();
        phMAListe.Controls.Add(MAUebersicht());
        Panel1.Visible = false;
    }
}
