﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KG_ReisenDeckblatt.aspx.cs
//
// Description  : SAP Barcodes
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.Oktober 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=========================================================================
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Tap.Schnittstellen.TAP_RA;

public partial class Genehmigung_KG_ReisenDeckblatt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int perskey = 0;
        string mandant = "";
        string[] raids = null;

        if (Request.Params["perskey"] != null)
        {
            try
            {
                perskey = Convert.ToInt32(Request.Params["perskey"]);
            }
            catch
            {
            }
        }
        if (Request.Params["mandant"] != null)
        {
            mandant = Request.Params["mandant"].ToString();
        }
        if (Request.Params["raids"] != null)
        {
            raids = Request.Params["raids"].ToString().Split(',');
        }

        RFCReise rfc = new RFCReise();
        string filepath = "";
        string tapreturn = "";
        string coGhostScriptExe =  ConfigurationManager.AppSettings["GhostScriptExe"] != null ?
            ConfigurationManager.AppSettings["GhostScriptExe"] : @"d:\tap\_pdf\gs\gs8.60\bin\gswin32.exe";
        string GSMergeDatei = "ges_" + perskey.ToString() + ".pdf"; // die temporäre Datei, die mit GS erstellt wird
        string cmdGS = " -dNOPAUSE -sDEVICE=pdfwrite -sPAPERSIZE=a4 -sOUTPUTFILE=" + @"d:\tap\_pdf\barcode\" + GSMergeDatei + " -dBATCH";
               
        bool DoIt = true;
        foreach (string raid in raids)
        {
            if (raid != "")
                rfc.GetBarCodeVB6(perskey, mandant, raid, out filepath, out tapreturn);
            else
                tapreturn = "Barcode ist nicht notwendig";
            if (tapreturn != "")
            {
                DoIt = false;
                if (raid == "")
                    tapreturn = "Barcode ist nicht notwendig";
                break;
            }
            else
            {
                cmdGS += " " + filepath;
            }
        }

        if (DoIt)
        {
            System.Diagnostics.Process Proc = new System.Diagnostics.Process();
            Proc.EnableRaisingEvents = false;
            Proc.StartInfo.Verb = "runas";                                          // STE002
            Proc.StartInfo.FileName = coGhostScriptExe;
            Proc.StartInfo.Arguments = cmdGS;
            Proc.Start();
            Proc.WaitForExit();
            Proc.Close();
            
            Response.ContentType = "Application/pdf";
            Response.WriteFile(@"d:\tap\_pdf\barcode\" + GSMergeDatei);
            Response.End();
        }
        else
            Response.Write(tapreturn);
    }
}
