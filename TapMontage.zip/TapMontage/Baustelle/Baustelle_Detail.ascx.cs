﻿//-----------------------------------------------------------------------------
//
// Projekt      : TapMontage
//
// File         : Baustelle_Detail.aspx.cs
//
// Description  : Baustellendaten Detailansicht
//
//=============== V1.0.0042 ===============================================
//
// Date         : 24.Juni 2008
// Author       : Joldic Dzevad
// Defect#      : MC49359
//                Ortsangabe bei Inlandsreisen ist Mussfeld
//
//=============== V1.0.0039 ===============================================
//
// Date         : 26.April 2008
// Author       : Joldic Dzevad
// Defect#      : 4363
//                Ändern von Baustellenbezeichnungen
//
//--------------- V1.0.0028 ---------------------------------------------------
//
// Date         : 5.Juni 2007
// Author       : GN
// Defect#      : 5117
//                Das Löschen einer hinterlegten Barauslage war nicht möglich, Grund war ein
//                fehlerhaftes If-then-else Statement
//
//-----------------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using TapMontage.dbObjects;

public partial class Baustelle_Baustelle_Detail : System.Web.UI.UserControl
{

    dbBaustelle dbBaust;
    dbBearbeiter Bearbeiter;

    public delegate void SaveCallbackDelegate();
    public SaveCallbackDelegate SaveClicked;

    public delegate void CancelCallbackDelegate();
    public CancelCallbackDelegate CancelClicked;

    protected void Page_Load(object sender, EventArgs e)
    {
        dbBaust = (dbBaustelle)Session["Baustelle"];
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        wtxtBauNr.TextBoxChangedDelegee = wtxtBauNrChanged; 
        btnCancel.Visible = ((int)dbBaust.Params.BAUID.Value > 0);
        btnSave.Visible = Bearbeiter.BearbInRole.IstKaufmann;
        LabelSuccess.Visible = false;
        if ((Request.QueryString["Message"] != null) & (!Page.IsPostBack)) LabelSuccess.Visible = true;
        // MC49359 beginn - 2 neue Felder in der Maske Auswahlliste für PLZ/Ort und Filter dazu
        FilterOrtPlz.TextBoxChangedDelegee = Filter_Change;
        BaustellenOrt.SelIndexChanged = BaustellenOrt_SelIndexChanged;
        WebDrowDownList2.SelIndexChanged = WebDrowDownList2_SelIndexChanged;
        if (FilterOrtPlz.TB.Text.Length < 3)
            Label5.Visible = true;
        else
            Label5.Visible = false;
        if (WebDrowDownList2.DDL.SelectedIndex <= 0 ) 
        {
            WebTextBox1.Enabled = false;
            WebTextBox2.Enabled = false;
            FilterOrtPlz.Visible = true;
            BaustellenOrt.Visible = true;
        }
        else
        {
            WebTextBox1.Enabled = true;
            WebTextBox2.Enabled = true;
            FilterOrtPlz.Visible = false;
            BaustellenOrt.Visible = false;
            Label5.Visible = Label4.Visible = Label3.Visible = false;
        }
        if (!Page.IsPostBack)
        {
            FilterOrtPlz.TB.Text = "???";
            Session["FilterOrtschaften"] = false;
        }
        // MC49359 Ende
    }

    public bool Enabled
    {
        get { return Panel1.Enabled; }
        set
        {
            Panel1.Enabled = value;
        }
    }


    public string wtxtBauNrChanged(object sender, EventArgs e)
    {   //refresh required
        if (dbBaust.AllowUpdate)
        {
            dbBaustelle b = new dbBaustelle(null);
            b.Params.BAUID.Value = dbBaust.Params.BAUID.Value;
            b = dbBaust.BauDatenPerBauId(b);
            //if (wtxtBauNr.TextBoxText == dbBaust.Params.BAUNR.Value.ToString() && wtxtName.TextBoxText == dbBaust.Params.NAME.Value.ToString())
            if (wtxtBauNr.TextBoxText != b.Params.BAUNR.Value.ToString())
            {
                if (dbBaust.ExistBauNr((sender as TextBox).Text))
                {
                    Label2.Visible = true;
                    Label2.ForeColor = System.Drawing.Color.Red;
                  // Text korrigiert
                    Label2.Text = "* Zu dieser Baustellennummer gibt es bereits eine Baustelle! Bitte verwenden Sie eine andere Baustellenummer.";
                    return (sender as TextBox).Text;
                }
                else
                {
                    Label2.ForeColor = System.Drawing.Color.Black;
                    Label2.Text = "Baustellenummer Ok!";
                    return (sender as TextBox).Text;
                }

            }
            else
            {
                Label2.Visible = false;
                return (sender as TextBox).Text;
            }
        }
        else
        {
            if (dbBaust.ExistBauNr((sender as TextBox).Text))
            {
                Label2.Visible = true;
                Label2.ForeColor = System.Drawing.Color.Red;
              // Text korrigiert
                Label2.Text = "* Zu dieser Baustellennummer gibt es bereits eine Baustelle! Bitte verwenden Sie eine andere Baustellenummer.";
                return (sender as TextBox).Text;
            }
            else
            {
                Label2.Visible = true;
                Label2.ForeColor = System.Drawing.Color.Black;
                Label2.Text = "Baustellenummer Ok!";
                return (sender as TextBox).Text;
            }
        }
    }

    public int BaustelleID
    {
        get
        {
            return (int)dbBaust.Params.BAUID.Value;
        }
        set
        {
            //Please Fill Baustelle outside!
            Page_Load(null, null);
            MapData();
            //Baustelle_Reisedatenzeile1.BaustelleID = (int)dbBaust.Params.BAUID.Value;
        }
    }

    private void ReadData()
    {
        foreach (Control c in Panel1.Controls)
        {
            if ((c as TapWebTextBox) != null)
                foreach (SqlParameter s in dbBaust.Params.List)
                    if (((TapWebTextBox)c).DataField == s.ParameterName)
                        s.Value = ParamVal.SetParameter(s, ((TapWebTextBox)c).TextBoxText);
            if ((c as TapWebDropDownList) != null)
                foreach (SqlParameter s in dbBaust.Params.List)
                    if (((TapWebDropDownList)c).DDLDataField == s.ParameterName)
                        s.Value = ParamVal.SetParameter(s, ((TapWebDropDownList)c).DDLSelectedValue);
        }
        Session["Baustelle"] = dbBaust;
    }
    private void MapData()
    {
        foreach (Control c in Panel1.Controls)
        {
            if ((c as TapWebTextBox) != null)
            {
                TapWebTextBox tb = (TapWebTextBox)c;
                foreach (SqlParameter s in dbBaust.Params.List)
                    if (tb.DataField == s.ParameterName)
                        tb.TextBoxText = ParamVal.GetParameter(s);
            }
            if ((c as TapWebDropDownList) != null)
            {
                TapWebDropDownList dl = (TapWebDropDownList)c;
                foreach (SqlParameter s in dbBaust.Params.List)
                    if (dl.DDLDataField == s.ParameterName)
                        dl.DDLSelectedValue = ParamVal.GetParameter(s);
            }
        }
    }
    protected void BtnReise_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            ReadData();
            Response.Redirect("~/Baustelle/Baustelle_Reisedaten.aspx?RetUrl=" + Request.RawUrl + "&Restore=1");
        }
    }
   
    protected void Barauslagen_Save()
    {
        dbBaust = (dbBaustelle)Session["Baustelle"];
        foreach (dbBarauslagen ba in dbBaust.Barauslagen)
        {

            //Defect 5117
            //If-then-else war falsch gesetzt
            if (ba.Deleted) ba.Delete();
            else
            {
                if (ba.AllowUpdate) ba.Update();
                else ba.Insert();
            }
        }
        Session["Baustelle"] = dbBaust;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        bool NameOrNumberExist = false;
        bool BaustTouched = false;

        // MC49359 - prüfen ob PLZ und Ort eingegeben sind - relevant nur für altdaten
        if (WebDrowDownList2.DDL.SelectedIndex == 0) //Oesterreich
        {
            if (WebTextBox1.TB.Text == "" || WebTextBox2.TB.Text == "")
            {
                Label3.Text = "<- PLZ und Ort hier auswählen";
                Label4.Text = "PLZ und Ort sind Pflichtfelder bei Inlandsreisen !!!";
                Label4.Visible = Label3.Visible = true;
                return;
            }
        }
        // MC49359 - Ende

        if (!dbBaust.AllowUpdate)
            if (isNameOrNumberExist())
                NameOrNumberExist = true;
        if (Page.IsValid)
        {
            foreach (Control c in Panel1.Controls)
            {
                if ((c as TapWebTextBox) != null)
                    foreach (SqlParameter s in dbBaust.Params.List)
                        if (((TapWebTextBox)c).DataField == s.ParameterName)
                            s.Value = ParamVal.SetParameter(s, ((TapWebTextBox)c).TextBoxText);
                if ((c as TapWebDropDownList) != null)
                    foreach (SqlParameter s in dbBaust.Params.List)
                        if (((TapWebDropDownList)c).DDLDataField == s.ParameterName)
                            s.Value = ParamVal.SetParameter(s, ((TapWebDropDownList)c).DDLSelectedValue);
            }
            if (dbBaust.AllowUpdate)
            {
                dbBaustelle b = new dbBaustelle(null);
                b.Params.BAUID.Value = dbBaust.Params.BAUID.Value;
                b = dbBaust.BauDatenPerBauId(b);
                //if (wtxtBauNr.TextBoxText == dbBaust.Params.BAUNR.Value.ToString() && wtxtName.TextBoxText == dbBaust.Params.NAME.Value.ToString())
                if (wtxtBauNr.TextBoxText == b.Params.BAUNR.Value.ToString() && wtxtName.TextBoxText == b.Params.NAME.Value.ToString())
                {
                    Label2.Visible = false;
                    dbBaust.Update();
                    BaustTouched = true;
                }
                else
                {
                    if ((!dbBaust.ExistBauNr(wtxtBauNr.TextBoxText)) && (wtxtName.TextBoxText == b.Params.NAME.Value.ToString()))
                    {
                        Label2.Visible = false;
                        dbBaust.Update();
                        BaustTouched = true;
                    }
                    else
                    {
                        if (isNameOrNumberExist())
                            NameOrNumberExist = true;
                        else
                        {
                            //4363 na ja - update durchführen
                            Label2.Visible = false;
                            dbBaust.Update();
                            BaustTouched = true;
                        }
                    }
                }
            }
            else
            {
                if (!NameOrNumberExist)
                {
                    Label2.Visible = false;
                    dbBaust.Insert();
                    BaustTouched = true;
                }
            }

            if (BaustTouched)
            {
                Barauslagen_Save();
            }

            if (!NameOrNumberExist)
            {
                Bearbeiter.Commons.AlleBaustellen = null;
                Bearbeiter.Commons.BaustellenNr = null;
                Bearbeiter.Commons.Baustellenoffen = null; //force reload
                Session["Bearbeiter"] = Bearbeiter;
                BaustellenOrt.Filter = FilterOrtPlz.TB.Text = "???";
                if (SaveClicked != null) SaveClicked();
            }
        }
    }

    private bool isNameOrNumberExist()
    {
        if (dbBaust.Params.BAUNR.Value.ToString() != wtxtBauNr.TextBoxText //defect 4363
            && dbBaust.ExistBauNr(wtxtBauNr.TextBoxText)) 
        {
            Label1.Visible = false;
            Label2.Visible = true;
          // Text korrigiert
            Label2.Text = "* Zu dieser Baustellennummer gibt es bereits eine Baustelle! Bitte verwenden Sie eine andere Baustellenummer.";
            return true;
        }
        else if (dbBaust.ExistName(wtxtName.TextBoxText))
        {
            Label2.Visible = false;
            Label1.Visible = true;
          // Text korrigiert
            Label1.Text = "* Zu diesem Namen gibt es bereits eine BaustellenNr! Bitte verwenden Sie einen anderen Namen.";
            return true;
        }
        else
        {
            Label1.Visible = false;
            Label2.Visible = false;
            return false;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (CancelClicked != null) CancelClicked();
    }
    /*
    protected void FilterOrt_Load(object sender, EventArgs e)
    {

    }*/
    //MC49359 - wenn das Filter geändert ist
    public string Filter_Change(object sender, EventArgs e)
    {
        (sender as TextBox).Text = (sender as TextBox).Text.Replace("*", ""); // weg mit *
        (sender as TextBox).Text = (sender as TextBox).Text.Trim(); // weg mit leeren Zeichen

        if ((sender as TextBox).Text.Length > 2) //mintestens 3 Zeichen
        {
            Session["FilterOrtschaften"] = true;
            BaustellenOrt.Filter = (sender as TextBox).Text;
            Page.SetFocus(BaustellenOrt.DDL);
        }
        else
            Label5.Visible = true;

        return (sender as TextBox).Text;
    }
    // wenn PLZ/ORT geändert ist
    public void BaustellenOrt_SelIndexChanged(object sender, EventArgs e)
    {
        Label4.Visible = Label3.Visible = false;
        if (BaustellenOrt.DDL.SelectedIndex > 0)
        {
            string[] values = BaustellenOrt.DDL.SelectedValue.Split('|');
            WebTextBox1.TB.Text = values[0];
            WebTextBox2.TB.Text = values[1];
        }
        else
        {
            WebTextBox1.TB.Text = "";
            WebTextBox2.TB.Text = "";
        }

    }
    public void WebDrowDownList2_SelIndexChanged(object sender, EventArgs e)
    {
        if (WebDrowDownList2.DDL.SelectedIndex <= 0)
        {
            WebTextBox1.TB.Text = "";
            WebTextBox2.TB.Text = "";
        }
    }
    //MC49359 -Ende
 }   
