﻿//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : Baustelle.aspx.cs
//
// Description  : Baustelle
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 28.August 2007
// Author       : Adam Kiefer
// Defect#      : 5135
//                GK-Std und Prod-Std in Baustellenübersicht trennen
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;

public partial class Baustelle : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    dbBaustelle dbBaust;
    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Baustellen suchen / bearbeiten</span>";
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        //if (!User.Identity.IsAuthenticated) Response.Redirect("~/Allgemein/Login.aspx?ReturnUrl=" + Request.RawUrl);
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        DDLBaustellen.SelIndexChanged = BaustelleSelectChange;
        DDLBaustelleNr.SelIndexChanged = BaustelleSelectChange; 
        Filter.TextBoxChangedDelegee = FilterChanged;
        FilterNr.TextBoxChangedDelegee = FilterNrChanged; 
        BaustelleDetail.SaveClicked = SaveClicked;
        BaustelleDetail.CancelClicked = CancelClicked;
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["Restore"] != null)
            {
                dbBaust = (dbBaustelle)Session["Baustelle"];
                PanNummer.Enabled = panName.Enabled = false;
                DDLBaustellen.DDLSelectedValue = dbBaust.Params.BAUID.Value.ToString();
                BaustelleDetail.BaustelleID = (int)dbBaust.Params.BAUID.Value;
            }
            else
            {
                dbBaust = new dbBaustelle(Bearbeiter);
                Session["Baustelle"] = dbBaust;
            }
            BaustelleDetail.Enabled = (Request.QueryString["Restore"] != null);
        }
        else
            dbBaust = (dbBaustelle)Session["Baustelle"];
        BtnBearbeiten.Visible = Bearbeiter.BearbInRole.IstKaufmann;
        BtnCopy.Visible = Bearbeiter.BearbInRole.IstKaufmann;
    }
    public void BaustelleSelectChange(object sender, EventArgs e)
    {
        dbBaust = new dbBaustelle(Bearbeiter);
        dbBaust.Params.BAUID.Value = Convert.ToInt32((sender as DropDownList).SelectedValue);
        dbBaust.Select();
        Session["Baustelle"] = dbBaust;
        DDLBaustellen.DDLSelectedValue = dbBaust.Params.BAUID.Value.ToString();
        DDLBaustelleNr.DDLSelectedValue = dbBaust.Params.BAUID.Value.ToString();
        BaustelleDetail.BaustelleID = (int)dbBaust.Params.BAUID.Value;
        BtnBearbeiten.Enabled = ((int)dbBaust.Params.BAUID.Value > 0);
        BtnCopy.Enabled = ((int)dbBaust.Params.BAUID.Value > 0);
    }

    public string FilterChanged(object sender, EventArgs e)
    {
        DDLBaustellen.Filter = (sender as TextBox).Text;
        DDLBaustellen.DDL.Focus();
        return (sender as TextBox).Text;
    }

    public string FilterNrChanged(object sender, EventArgs e)
    {
        DDLBaustelleNr.Filter = (sender as TextBox).Text;
        DDLBaustelleNr.DDL.Focus();
        return (sender as TextBox).Text;
    }
    
    protected void BtnBearbeiten_Click(object sender, EventArgs e)
    {
        BtnBearbeiten.Enabled = false;
        BtnCopy.Enabled = false;
        BaustelleDetail.Enabled = true;
        PanNummer.Enabled = panName.Enabled = false;
    }

    public void CancelClicked()
    {
        BtnBearbeiten.Enabled = true;
        BtnCopy.Enabled = true;
        BaustelleDetail.Enabled = false;
        PanNummer.Enabled = panName.Enabled = true;
    }

    public void SaveClicked()
    {
        BtnBearbeiten.Enabled = true;
        BtnCopy.Enabled = true;
        BaustelleDetail.Enabled = false;
        PanNummer.Enabled = panName.Enabled = true;
        DDLBaustellen.Filter = Filter.TextBoxText;
        DDLBaustelleNr.Filter = FilterNr.TextBoxText;
        /*string tempRawu = Request.RawUrl;
        if (tempRawu.IndexOf("?") > 0)
            tempRawu = tempRawu.Substring(0, tempRawu.IndexOf("?"));
        Response.Redirect(tempRawu + "?Message=Gespeichert!");*/

    }

    protected void BtnCopy_Click(object sender, EventArgs e)
    {
        BtnBearbeiten.Enabled = false;
        BtnCopy.Enabled = false;
        dbBaust.AllowUpdate = false;
        BaustelleDetail.Enabled = true;
        PanNummer.Enabled = panName.Enabled = false;
    }
}
