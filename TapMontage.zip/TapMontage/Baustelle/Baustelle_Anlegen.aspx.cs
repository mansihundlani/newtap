﻿//-----------------------------------------------------------------------------
//
// Projekt      : TAP_Montage
//
// File         : Baustelle_Anlegen.aspx.cs
//
// Description  : Erstellung einer neuen Baustelle
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//--------------- V1.0.0017 ---------------------------------------------------
//
// Date         : 21. Dezember 2006
// Author       : GN
// Defect#      : 3976
//
// Keine defaultmässigen Barauslagen bei einer neuen Baustelle
//
//-----------------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using TapMontage.dbObjects;


public partial class Baustelle_Anlegen : System.Web.UI.Page
{

    dbBaustelle dbBaust;
    dbBearbeiter dbBea;

    protected void Page_Load(object sender, EventArgs e)
    {        
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Baustellen anlegen</span>";            
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        dbBea = (dbBearbeiter)Session["Bearbeiter"];
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["Restore"] != null)
            {
                dbBaust = (dbBaustelle)Session["Baustelle"];
                Baustelle_Detail1.BaustelleID = (int)dbBaust.Params.BAUID.Value;
            }
            else
            {
                // Beginn Defect #3976: 'Leere' neue Baustelle
                dbBaust = new dbBaustelle(dbBea);
                Session["Baustelle"] = dbBaust;
                // Ende Defect #3976
            }
        }
        else dbBaust = (dbBaustelle)Session["Baustelle"];
        Baustelle_Detail1.SaveClicked = SaveClicked;
    }

    public void SaveClicked()
    {
        string tempRawu = Request.RawUrl;
        if (tempRawu.IndexOf("?") > 0)
            tempRawu = tempRawu.Substring(0, tempRawu.IndexOf("?"));
        Response.Redirect(tempRawu + "?Message=Gespeichert!");
    }

    protected void Baustelle_Detail1_Load(object sender, EventArgs e)
    {
        
    }
}
