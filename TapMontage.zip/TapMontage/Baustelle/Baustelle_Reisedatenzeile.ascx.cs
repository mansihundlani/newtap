﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : Baustelle_Reisedatenzeile.ascx.cs
//
// Description  : Erfassung Reisedatenzeilen
//
//=============== V1.2.0017 ===============================================
//
// Date         : 18.November 2013
// Author       : Joldic Dzevad
// Defect#      : TT 6654245
//                Bei @CENT soll decimal anstatt float verwendet werden
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' für lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' für DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0032 ===================================================
//
// Date         : 1.August 2007
// Author       : Nebehay Georg
// Defect#      : 5122
//                Es können ab jetzt nur mehr Barauslagen im Status 20 ausgewählt werden
//
//=============== V1.0.0028 ===================================================
//
// Date         : 12.Juni 2007
// Author       : Nebehay Georg
// Defect#      : 5121
//                Fehler beim Ändern von Barauslagen
//
//=============== V1.0.0020 ===================================================
//
// Date         : 27.Jänner 2007
// Author       : Lahofer Christian
// Defect#      : 4425
//                Fehler bei der Eingabe von Barauslagen an der Baustelle
//
//=============== V1.0.0006 ===================================================
//
// Date         : 08.November 2006
// Author       : Gebhardt caleb
// Defect#      : 3611
//                Fahrzeugart "0" ist falsch. Verkehrsmittel immer 0,
//                wie die Baustellenreisedaten vom Anwender definiert
//                wurden.
//
//=============== V1.0.0004 ===================================================
//
// Date         : 7.November 2006
// Author       : Caleb Gebhardt
// Defect#      : 3537
//                Kommastellen bei Barauslagen ermöglichen
//
// ========================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using TapMontage.dbObjects;
using TapMontage.Misc;


public partial class Baustelle_Baustelle_Reisedatenzeile : System.Web.UI.UserControl
{
    dbBaustelle Baustelle;
    dbBearbeiter Bearbeiter;
    private bool isEdit = false;
    string Argument = "";

    // Das OFFSET-Konstante dient zur Berechung 
    // eines eindeutigen  STDID, "Standort ID" für
    // Ensatztyp "Baustelle zur Quartier" in der
    // Tabelle Baustelle_std. 
    // Daher das Ändern dieses OFFSET setzt eine
    // leere "Baustelle_std"-Tabelle voraus.
    private const int STDID_OFFSET = 30000000;
    private dbBarauslagen selectedBarauslage = null;

    private DropDownList AlteEintraege = new DropDownList();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        selectedBarauslage = (dbBarauslagen)Session["selectedBarauslage"];
        Baustelle = (dbBaustelle)Session["Baustelle"];
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];

        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {

            //Defect 5122 GN 1.8.2007 Einträge mit Status 40 sollen zwar angezeigt, aber nicht mehr auswählbar sein
            //Änderung beginn

            //5122 Diese beiden Listen enthalten nur Barauslagen im Status 20
            ArrayList txts = new ArrayList();
            ArrayList kzs = new ArrayList();

            //5122 Diese beiden Listen enthalten die Daten für alle Barauslagen, auch Status 40
            ArrayList txtsalt = new ArrayList();
            ArrayList kzsalt = new ArrayList();
            cnx.Open();
            // Defect 5725, Config.Rowlock eingeführt
            // Defect 5771, Config.Nolock eingeführt
            using (SqlCommand cmd = new SqlCommand("SELECT RAKZTXT, RAKZ,Status FROM Y_RAKZ " + Config.Nolock + " WHERE RAKZID = 'AAI' ORDER BY RAKZTXT", cnx)) // Defect 5436, using eingeführt
            {
              using (SqlDataReader reader = cmd.ExecuteReader()) // Defect 5436
              {
                while (reader.Read())
                {
                  int status = reader.GetInt16(2);

                  string rakztxt = reader.GetString(0);
                  string rakz = reader.GetString(1);

                  if (status == 20)
                  {
                    txts.Add(rakztxt);
                    kzs.Add(rakz);
                  }
                  txtsalt.Add(rakztxt);
                  kzsalt.Add(rakz);
                }
              }
            }
            int selInd = DDLTyp.SelectedIndex;
            DDLTyp.Items.Clear();
            for (int i = 0; i < txts.Count; i++)
            {
                ListItem item = new ListItem(txts[i].ToString(), kzs[i].ToString());
                DDLTyp.Items.Add(item);
            }
            DDLTyp.SelectedIndex = selInd;

            selInd = AlteEintraege.SelectedIndex;
            AlteEintraege.Items.Clear();
            for (int i = 0; i < txtsalt.Count; i++)
            {
                ListItem item = new ListItem(txtsalt[i].ToString(), kzsalt[i].ToString());
                AlteEintraege.Items.Add(item);
            }
            AlteEintraege.SelectedIndex = selInd;

            //5122 Änderung Ende
        }

        //if (Baustelle.StandorteEdit)
        //    TapWebTextBox3.AutoPostback = false;
        if (Baustelle.Standorte.Count != 0)
            phTable.Controls.Add(ReisedatenTable());

        if (Baustelle.Barauslagen.Count > 0)
            barauslagenTable.Controls.Add(getBarauslagenTable());

        // Vorbelegung wegen Einsatztyp Baustelle zu Quartier 
        TapWebDrowDownList3.Enabled = true;
        TapWebDrowDownList4.Enabled = true;
        DropDownList2.Items.FindByValue("0").Enabled = true; //Ortsmontage
        DropDownList2.Items.FindByValue("5").Enabled = true; //Ortsmontage B&I
        MsgFBaustlbl.Text = "";
        MsgFBaustlbl.Visible = false;
        // Ende Baustelle zu Quartier

    }

    public int BaustelleID
    {
        get { return (int)Baustelle.Params.BAUID.Value; }
        set
        {
            phTable.Controls.Clear();
            Page_Load(null, null);
        }
    }
    protected void TapWebTextBox2_Load(object sender, EventArgs e)
    {

    }
    
    protected void TapWebDrowDownList1_Load(object sender, EventArgs e)
    {

    }
    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TapWebDrowDownList1.Visible = (DropDownList1.SelectedValue == "0");
        TapWebDrowDownList2.Visible = (DropDownList1.SelectedValue == "1");
        ValidCheck(TapWebTextBox2, TapWebTextBox3, false);
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    public bool ValidCheck(TapWebTextBox txtBox)
    {
        if (!RangeCheck.IsInteger(txtBox.TextBoxText))
        {
            string msg = "Geben Sie bitte eine gültige Zahl an.";
            if (txtBox.ID == "TapWebTextBox2")
            {
                label1.ForeColor = System.Drawing.Color.Red;
                label1.Text = msg;
                label1.Visible = true;
            }
            else
            {
                label2.ForeColor = System.Drawing.Color.Red;
                label2.Text = msg;
                label2.Visible = true;
            }
            txtBox.Focus();
            isEdit = true;
            return false;
        }
        else
        {
            label1.Text = "";
            label1.Visible = false;
            label2.Text = "";
            label2.Visible = false;
            isEdit = false;
            return true;
        }
    }

    public bool ValidCheck(TapWebTextBox txtInBox1, TapWebTextBox txtInBox2, bool Chkval)
    {
        bool iretval = true;
        // wenn Baustelle zu Quartier angewählt wurde, dann Nahmontage in der
        // Auswahlliste entfernern und Verkehrsmittel bzw. Bestellung nicht anwählbar, d.h.
        // deaktiviert
        TapWebDrowDownList1.Enabled = (Int32.Parse(DropDownList1.SelectedValue.ToString()) != (int)dbBaustelleStandort.Einsatz.BaustZuQuartier); // Standort
        //TapWebDrowDownList3.Enabled = (Int32.Parse(DropDownList1.SelectedValue.ToString()) != (int)dbBaustelleStandort.Einsatz.BaustZuQuartier); // Verkehrsmittel
        TapWebDrowDownList4.Enabled = (Int32.Parse(DropDownList1.SelectedValue.ToString()) != (int)dbBaustelleStandort.Einsatz.BaustZuQuartier); // Bestellung
        DropDownList2.Items.FindByValue("0").Enabled = (Int32.Parse(DropDownList1.SelectedValue.ToString()) != (int)dbBaustelleStandort.Einsatz.BaustZuQuartier);
        DropDownList2.Items.FindByValue("3").Enabled = (Int32.Parse(DropDownList1.SelectedValue.ToString()) != (int)dbBaustelleStandort.Einsatz.BaustZuQuartier);
        DropDownList2.Items.FindByValue("5").Enabled = (Int32.Parse(DropDownList1.SelectedValue.ToString()) != (int)dbBaustelleStandort.Einsatz.BaustZuQuartier);
        if (Int32.Parse(DropDownList1.SelectedValue.ToString()) != (int)dbBaustelleStandort.Einsatz.BaustZuQuartier)
        {
           MsgFBaustlbl.Text = "";
           MsgFBaustlbl.Visible = false;
        }
        else
        {
          TapWebDrowDownList1.Visible = true;
          if (Chkval)
          {
             string msg = "Bitte geben Sie die Reisezeit und/oder die Entfernung an!";
             iretval = (RangeCheck.IsInteger(txtInBox1.TextBoxText) || RangeCheck.IsInteger(txtInBox2.TextBoxText));
             if (!iretval)
             {
                 MsgFBaustlbl.ForeColor = System.Drawing.Color.Red;
                 MsgFBaustlbl.Text = msg;
                 MsgFBaustlbl.Visible = true;
             }
           }
        }
        return iretval;
    }

    public int CalculateKey (string txt1, string txt2, string txt3, string txt4, string txt5, int Offset)
    {
        string in1 = txt1;
        string in2 = txt2;
        string in3 = txt3;
        string in4 = txt4;
        string in5 = txt5;

        if ((in1 == null) || (in1 == "")) in1 = "0";
        if ((in2 == null) || (in2 == "")) in2 = "0";
        if ((in3 == null) || (in3 == "")) in3 = "0";
        if ((in4 == null) || (in4 == "")) in4 = "0";
        if ((in5 == null) || (in5 == "")) in5 = "0";

        
        int iCalcKey =  Int32.Parse(in1) + Int32.Parse(in2) + Int32.Parse(in3) +
                        Int32.Parse(in4) + Int32.Parse(in5) + Offset;
        return iCalcKey;

    }

    public bool ChecKeyEqual( string key1, string Key2)
    {    
            return key1 == Key2;        
    }   
 
    public bool IsRecordNew(dbBaustelleStandort bs, int checkWhat)
    {

        // check Cases:   checkWhat == 1, only keys
        //                checkWhat == 2, keys equal and at least one pair of fields different
        //                checkWhat == 3, keys not equal or case 2
        bool bRetval= false;
        string iCacheSchluessel = bs.Params.STDID.Value.ToString();
        string iSatzSchluessel = CalculateKey(bs.Params.BAUID.Value.ToString(),
                                  DropDownList1.SelectedValue.ToString(),
                                  TapWebTextBox2.TextBoxText.ToString(),  // Reisezeit
                                  TapWebTextBox3.TextBoxText.ToString(),  // Entfernung in Km
                                  DropDownList2.SelectedValue.ToString(), // Reisetyp
                                  STDID_OFFSET
                                  ).ToString(); ;
        switch (checkWhat)
        { 
            case 1:
                bRetval =  ChecKeyEqual(iSatzSchluessel.ToString(), iCacheSchluessel.ToString());
                break;    
            case 2:
                bRetval = ((ChecKeyEqual(iSatzSchluessel.ToString(), iCacheSchluessel.ToString()) == true) &&
                           ( bs.Params.REISEZEIT.Value.ToString() != TapWebTextBox2.TextBoxText.ToString() ||
                             bs.Params.KM.Value.ToString() != TapWebTextBox3.TextBoxText.ToString() ||
                             bs.Params.RATYP.Value.ToString() != DropDownList2.SelectedValue.ToString())
                            );
                break;
            case 3:
                bRetval = ((ChecKeyEqual(iSatzSchluessel.ToString(), iCacheSchluessel.ToString()) == true) &&
                           ( bs.Params.REISEZEIT.Value.ToString() != TapWebTextBox2.TextBoxText.ToString() ||
                             bs.Params.KM.Value.ToString() != TapWebTextBox3.TextBoxText.ToString() ||
                             bs.Params.RATYP.Value.ToString() != DropDownList2.SelectedValue.ToString())
                            );

                bRetval = (bRetval || ChecKeyEqual(iSatzSchluessel.ToString(), iCacheSchluessel.ToString()) == false);
                break;
            default:
                bRetval = false;
                break;
        }
        return bRetval;
    }

    public void SetzEINSArt(DropDownList c, dbBaustelleStandort BaustelleStandort)
    {
        if ((((DropDownList)c).ID == DropDownList1.ID))
            switch (Int32.Parse(DropDownList1.SelectedValue.ToString()))
            {
                case (int)dbBaustelleStandort.Einsatz.StandOrtZuBaust:
                    BaustelleStandort.EinsatzTyp = (int)dbBaustelleStandort.Einsatz.StandOrtZuBaust;
                    break;
                case (int)dbBaustelleStandort.Einsatz.BaustZuBaust:
                    BaustelleStandort.EinsatzTyp = (int)dbBaustelleStandort.Einsatz.BaustZuBaust;
                    break;
                    
                case (int)dbBaustelleStandort.Einsatz.BaustZuQuartier:
                    BaustelleStandort.Params.BAUID_STDW.Value = Int32.Parse(DropDownList1.SelectedValue.ToString());
                    BaustelleStandort.EinsatzTyp = Int32.Parse(DropDownList1.SelectedValue.ToString());
                    //BaustelleStandort.EinsatzTyp = (int)dbBaustelleStandort.Einsatz.BaustZuQuartier;
                    break;
                default:
                    break;
            }
    }
    protected void btnInsert_Click(object sender, EventArgs e)
    {
        dbBaustelleStandort BaustelleStandort = new dbBaustelleStandort(Baustelle, null);
        bool doInsert = true;
        bool validateOK = true;
        int iSatzSchluessel = 0;
        bool IsNewRec = false;
        // Prüfen d. "baustelle zu Quartier-logik"
        // diese basert auf: DropDownList1.SelectedValue != "2"

        if (ValidCheck(TapWebTextBox2, TapWebTextBox3, true) == false) return;
        
        // Validierung der Engabe-Textfelder
        if (Int32.Parse(DropDownList1.SelectedValue.ToString()) != (int)dbBaustelleStandort.Einsatz.BaustZuQuartier)
            validateOK = ValidCheck(TapWebTextBox2) && ValidCheck(TapWebTextBox3);
          if (validateOK)
          {
            if (Baustelle.Standorte.Count != 0)
            {
                foreach (dbBaustelleStandort bs in Baustelle.Standorte)
                {
                    if (!bs.Deleted)
                    {
                        int iEinsatzTyp = Int32.Parse(DropDownList1.SelectedValue.ToString());
                        
                        if (iEinsatzTyp == (int)dbBaustelleStandort.Einsatz.BaustZuQuartier)
                        {
                                 IsNewRec = IsRecordNew(bs, 3);
                        }
                        if (((iEinsatzTyp == (int)dbBaustelleStandort.Einsatz.StandOrtZuBaust) && (TapWebDrowDownList1.DDLSelectedValue == bs.Params.STDID.Value.ToString())) |
                                ((iEinsatzTyp == (int)dbBaustelleStandort.Einsatz.BaustZuBaust) && (TapWebDrowDownList2.DDLSelectedValue == bs.Params.BAUID_STDW.Value.ToString())) |
                                 ((iEinsatzTyp == (int)dbBaustelleStandort.Einsatz.BaustZuQuartier) && IsNewRec == false))
                       {
                            doInsert = false;
                        }
                    }
                }

            }
            if (doInsert)
            {
                foreach (Control c in Panel1.Controls)
                {
                    if ((c as TapWebTextBox) != null)
                        foreach (SqlParameter bs in BaustelleStandort.Params.List)
                            if (((TapWebTextBox)c).DataField == bs.ParameterName)
                                bs.Value = ParamVal.SetParameter(bs, ((TapWebTextBox)c).TextBoxText);
                    if ((c as TapWebDropDownList) != null)
                        if ((c as TapWebDropDownList).Visible)
                            foreach (SqlParameter bs in BaustelleStandort.Params.List)
                            {
                                if (((TapWebDropDownList)c).DDLDataField == bs.ParameterName)
                                {
                                    string UsrCtlID = ((TapWebDropDownList)c).ID;
                                    if ( (UsrCtlID == "TapWebDrowDownList1") ||  // Standort
                                         (UsrCtlID == "TapWebDrowDownList2") ||  // Baustelle
                                        // Defect 3611
                                         (UsrCtlID == "TapWebDrowDownList3") ||  // Verkehrsmittel
                                        // ende 3611
                                         (UsrCtlID == "TapWebDrowDownList4"))    // Bereistellung
                                    {
                                        if (Int32.Parse(DropDownList1.SelectedValue.ToString()) == (int) dbBaustelleStandort.Einsatz.BaustZuQuartier)
                                        {
                                            switch (((TapWebDropDownList)c).DDLDataField)
                                            {
                                                case "@STDID":
                                                    iSatzSchluessel = CalculateKey( Baustelle.Params.BAUID.Value.ToString(),
                                                                                    DropDownList1.SelectedValue.ToString(),
                                                                                    TapWebTextBox2.TextBoxText.ToString(),  // Reisezeit
                                                                                    TapWebTextBox3.TextBoxText.ToString(),  // Entfernung in Km
                                                                                    DropDownList2.SelectedIndex.ToString(), // Reisetyp
                                                                                    STDID_OFFSET
                                                                                    );
                                                    if (IsRecordNew(BaustelleStandort, 2)) ++iSatzSchluessel;
                                                    bs.Value = iSatzSchluessel;
                                                    break;
                                                case "@BAUID_STDW":
                                                case "@RAKZ_B":
                                                    bs.Value = "";
                                                    break;
                                                case "@RAKZ_VM":
                                                    bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                                                    break;
                                                default:
                                                    bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                                                    break;
                                            }
                                        }
                                        else
                                        {
                                                bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue); 
                                       }
                                    }
                                }
                            }
                    if ((c as DropDownList) != null)
                        foreach (SqlParameter bs in BaustelleStandort.Params.List)
                        {
                            SetzEINSArt((DropDownList)c, BaustelleStandort);
                            if (((DropDownList)c).DataTextFormatString == bs.ParameterName)
                            {
                                bs.Value = ParamVal.SetParameter(bs, ((DropDownList)c).SelectedValue);
                            }
                        }          
                }
                BaustelleStandort.Params.BAUID.Value = Baustelle.Params.BAUID.Value.ToString();
                BaustelleStandort.Deleted = false;
                Baustelle.Standorte.Add(BaustelleStandort);
                phTable.Controls.Clear();
                phTable.Controls.Add(ReisedatenTable());
            }
        }
    }

    private Table ReisedatenTable()
    {
        xxID = 0;
        Table ReiseDaten = new Table();
        
        ReiseDaten.Width = Unit.Percentage(100);
        TableRow HeaderRow = new TableRow();
        TableCell c1 = new TableCell(); 
        c1.Text = "Zuordnung";
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;
        TableCell c2 = new TableCell(); 
        c2.Text = "Standort / Baustelle";
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;
        TableCell c3 = new TableCell(); 
        c3.Text = "Reisezeit";
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;
        TableCell c4 = new TableCell(); 
        c4.Text = "km";
        c4.CssClass = "TabHeader";
        c4.Font.Bold = true;
        TableCell c5 = new TableCell();
        c5.Text = "Reisetyp";
        c5.CssClass = "TabHeader";
        c5.Font.Bold = true;
        TableCell c6 = new TableCell(); 
        c6.Text = "Verkehrsmittel";
        c6.CssClass = "TabHeader";
        c6.Font.Bold = true;
        TableCell c7 = new TableCell(); 
        c7.Text = "Bereitstellung";
        c7.CssClass = "TabHeader";
        c7.Font.Bold = true;
        TableCell c8 = new TableCell();
        c8.CssClass = "TabHeader";
        c8.Text = "";
        c8.Font.Bold = true;
        TableCell c9 = new TableCell();
        c9.CssClass = "TabHeader";
        c9.Text = "";
        c9.Font.Bold = true;

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c4);
        HeaderRow.Cells.Add(c5);
        HeaderRow.Cells.Add(c6);
        HeaderRow.Cells.Add(c7);
        HeaderRow.Cells.Add(c8);
        HeaderRow.Cells.Add(c9);
        ReiseDaten.Rows.Add(HeaderRow);
        //...
        string sarg = "";
        //sarg = Argument;
        sarg = (string)Page.Cache["Edit-ID"];
        LinkButton lnkbtn;
        int iSzeile = 0;
        string strCssClassRow = "TabNewDay";
        foreach (dbBaustelleStandort bs in Baustelle.Standorte)
        {
            if (!bs.Deleted)
            {
                HeaderRow.Visible = true;
                TableRow tr = new TableRow();
                TableCell d1 = new TableCell();
                d1.CssClass = strCssClassRow;
           
                int iselind = 0;
                switch (bs.EinsatzTyp)
                {
                    // bs.EinsatzTyp entspricht dem von Benutzer selektierten Wert, 
                    // DB-Parameter:bs.Params.BAUID_STDW
                    // Ausnahme: "Baustelle zu Baustelle". EinsatzTyp = BausstellenId
                    //
                    case (int) dbBaustelleStandort.Einsatz.StandOrtZuBaust:
                    case (int) dbBaustelleStandort.Einsatz.BaustZuQuartier:
                    case (int) dbBaustelleStandort.Einsatz.BaustZuBaust:
                        iselind = (int) bs.EinsatzTyp;
                        break;
                    default:
                        if ((int) bs.EinsatzTyp > (int) dbBaustelleStandort.Einsatz.BaustZuQuartier)
                        {
                            // Einsatyp ist grösser als die grösste Indize in der Selektion, daher
                            // handelt es um "Bausstelle zu Baustelle" - Einsatztyp
                            // IselInd, selektierter Wert = dbBaustelleStandort.Einsatz.BaustZuBaust
                            iselind = (int)dbBaustelleStandort.Einsatz.BaustZuBaust;
                        }
                        break;

                } 
                d1.Text = DropDownList1.Items[iselind].Text;
                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString()) |
                    (sarg.Substring(2) == bs.Params.BAUID_STDW.Value.ToString())))
                    d1.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                d2.CssClass = strCssClassRow;

                switch (iselind)
                {
                    case 0: 
                        d2.Text = Bearbeiter.Commons.vpGetText(Bearbeiter.Commons.Standorte, bs.Params.STDID.Value.ToString());
                        Argument = "S-" + bs.Params.STDID.Value.ToString();
                        break;
                    case 1:
                        d2.Text = Bearbeiter.Commons.vpGetText(Bearbeiter.Commons.Baustellenoffen, bs.Params.BAUID_STDW.Value.ToString());
                        Argument = "B-" + bs.Params.BAUID_STDW.Value.ToString();
                        break;
                    case 2:
                        // Standort/Baustelle nicht gegeben f. diesen Typ
                        d2.Text = "";

                        Argument = "Q-" + bs.Params.STDID.Value.ToString();
                        break;
                    default:
                        d2.Text = Bearbeiter.Commons.vpGetText(Bearbeiter.Commons.Baustellenoffen, bs.Params.BAUID_STDW.Value.ToString());
                        Argument = "B-" + bs.Params.BAUID_STDW.Value.ToString();
                        break;
                }

                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString()) |
                    (sarg.Substring(2) == bs.Params.BAUID_STDW.Value.ToString())))
                    d2.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d2);

                TableCell d3 = new TableCell();
                d3.CssClass = strCssClassRow;
                d3.Text = ParamVal.GetParameter(bs.Params.REISEZEIT);
                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString()) | 
                    (sarg.Substring(2) == bs.Params.BAUID_STDW.Value.ToString())))
                    d3.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d3);

                TableCell d4 = new TableCell();
                d4.CssClass = strCssClassRow;
                d4.Text = ParamVal.GetParameter(bs.Params.KM);
                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString()) | 
                   (sarg.Substring(2) == bs.Params.BAUID_STDW.Value.ToString())))
                    d4.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d4);

                TableCell d5 = new TableCell();
                d5.CssClass = strCssClassRow;
                int iRKM = Convert.ToInt32(ParamVal.GetParameter(bs.Params.RATYP));
                d5.Text = DropDownList2.Items.FindByValue(iRKM.ToString()).Text;
                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString()) | 
                    (sarg.Substring(2) == bs.Params.BAUID_STDW.Value.ToString())))             
                    d5.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d5);

                TableCell d6 = new TableCell();
                d6.CssClass = strCssClassRow;
                if (iselind == 2)
                {
                    // Verkehrsmitell nicht gegeben f. diesen Typ
                    //d6.Text = "";
                    d6.Text = Bearbeiter.Commons.vpGetText(Bearbeiter.Commons.Verkehrsmittel, bs.Params.RAKZ_VM.Value.ToString());
                }
                else
                {
                    d6.Text = Bearbeiter.Commons.vpGetText(Bearbeiter.Commons.Verkehrsmittel, bs.Params.RAKZ_VM.Value.ToString());
                }
                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString()) |
                    (sarg.Substring(2) == bs.Params.BAUID_STDW.Value.ToString())))

                    d6.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d6);

                TableCell d7 = new TableCell();
                d7.CssClass = strCssClassRow;

                if (iselind == (int)dbBaustelleStandort.Einsatz.BaustZuQuartier)
                {
                    // Bereitstellung nicht gegeben f. diesen Typ
                    d7.Text = "";
                }
                else
                {
                    d7.Text = Bearbeiter.Commons.vpGetText(Bearbeiter.Commons.Bereitstellungsarten, bs.Params.RAKZ_B.Value.ToString());
                }
                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString()) |
                    (sarg.Substring(2) == bs.Params.BAUID_STDW.Value.ToString())))
                    d7.ForeColor = System.Drawing.Color.Blue;
                tr.Cells.Add(d7);

                TableCell d8 = new TableCell();
                d8.CssClass = strCssClassRow;
                lnkbtn = NewTaskButton("Bearbeiten", "Edit", Argument, "Eintrag bearbeiten", TaskButton_Click);
                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString()) |
                    (sarg.Substring(2) == bs.Params.BAUID_STDW.Value.ToString()) ))
                    lnkbtn.Enabled = false;

                Image img = new Image();
                img.ImageUrl = "~/Images/Bearbeiten_16x16.jpg";
                lnkbtn.Controls.Add(img);
                d8.Controls.Add(lnkbtn);
                tr.Cells.Add(d8);

                TableCell d9 = new TableCell();
                d9.CssClass = strCssClassRow;
                lnkbtn = NewTaskButton("Löschen", "Delete", Argument, "Eintrag löschen", TaskButton_Click);
                d9.Controls.Add(lnkbtn);
                if (isEdit && ((sarg.Substring(2) == bs.Params.STDID.Value.ToString())))
                    lnkbtn.Enabled = false;

                img = new Image();
                img.ImageUrl = "~/Images/trash16x16.jpg";
                lnkbtn.Controls.Add(img);
                
                tr.Cells.Add(d9);
                ReiseDaten.Rows.Add(tr);
            }
            else
            {
                if (iSzeile == 0)
                    HeaderRow.Visible = false;
            }
            iSzeile++;
        }
        return ReiseDaten;
    }

    private Table getBarauslagenTable()
    {

        Table t = new Table();

        xxID = 0;
        
        t.Width = Unit.Percentage(100);
        TableRow HeaderRow = new TableRow();
        TableCell c1 = new TableCell();
 
        // Start Defect 4425: Text 'Barauslagen statt Typ'
        c1.Text = "Barauslagen";
        // Ende Defect 4425: Text 'Barauslagen statt Typ'
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;
        TableCell c2 = new TableCell(); 
        c2.Text = "EUR/Gesamt";
        c2.CssClass = "TabHeader";
        c2.Font.Bold = true;
        TableCell c3 = new TableCell(); 
        c3.Text = "Anzahl";
        c3.CssClass = "TabHeader";
        c3.Font.Bold = true;
        TableCell c4 = new TableCell(); 
        c4.Text = "Gesamt";
        c4.CssClass = "TabHeader";
        c4.Font.Bold = true;
        TableCell c5 = new TableCell();
        c5.Text = "";
        c5.CssClass = "TabHeader";
        c5.Font.Bold = true;
        TableCell c6 = new TableCell();
        c6.Text = "";
        c6.CssClass = "TabHeader";
        c6.Font.Bold = true;

        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        //HeaderRow.Cells.Add(c4);
        HeaderRow.Cells.Add(c5);
        HeaderRow.Cells.Add(c6);
        t.Rows.Add(HeaderRow);

        string strCssClassRow = "TabNewDay";


//        Baustelle.barauslagen = null;
        int id = 0;
        foreach (dbBarauslagen ba in Baustelle.Barauslagen)
        {
            if (!ba.Deleted)
            {
                TableCell d1 = new TableCell();
                TableCell d2 = new TableCell();
                TableCell d3 = new TableCell();
                TableCell d4 = new TableCell();
                TableCell d5 = new TableCell();
                TableCell d6 = new TableCell();

                d1.CssClass = strCssClassRow;
                d2.CssClass = strCssClassRow;
                d3.CssClass = strCssClassRow;
                d4.CssClass = strCssClassRow;
                d5.CssClass = strCssClassRow;
                d6.CssClass = strCssClassRow;

                TableRow tr = new TableRow();

                Literal l1 = new Literal();
                Literal l2 = new Literal();
                Literal l3 = new Literal();
                Literal l4 = new Literal();
                LinkButton l5 = new LinkButton();
                LinkButton l6 = new LinkButton();

              // Defect 3537
              // Kommastellen bei Barauslagen ermöglichen
                //float c;
                //l1.Text = AlteEintraege.Items.FindByValue(ba.Params.TYP.Value.ToString()).Text;
                //l2.Text = ba.Params.CENTS.Value.ToString();

                //l3.Text = ba.Params.ANZ.Value.ToString();
                //c = (float)Convert.ToDecimal(ba.Params.CENTS.Value.ToString());
                //c = c * (float)Convert.ToDecimal(ba.Params.ANZ.Value.ToString());
                //l4.Text = c.ToString("N");
                //id++;

                //TT - 6654245 - verwende decimal anstatt float
                Decimal c;
                l1.Text = AlteEintraege.Items.FindByValue(ba.Params.TYP.Value.ToString()).Text;
                l2.Text = ba.Params.CENTS.Value.ToString();

                l3.Text = ba.Params.ANZ.Value.ToString();
                c = Convert.ToDecimal(ba.Params.CENTS.Value) * Convert.ToDecimal(ba.Params.ANZ.Value);
                l4.Text = c.ToString("N");
                id++;




                if (DDLTyp.Items.FindByValue(ba.Params.TYP.Value.ToString()) != null)
                {

                    l5.Text = "Bearbeiten";
                    //5121 ID-Zuweisung war falsch
                    //l5.ID = nid();
                    l5.ID = "EditBar->" + id;

                    Image i = new Image();
                    i.ImageUrl = "~/Images/Bearbeiten_16x16.jpg";
                    l5.Controls.Add(i);

                    l5.CommandArgument = ba.Params.AUSLAGENID.Value.ToString();
                    l5.Command += new CommandEventHandler(Bearbeiten_CLick);
                }
                else
                {
                    l5.Text = "abgelaufen";
                    l5.Enabled = false;
                }

                l6.Text = "Löschen";
                //5121 ID-Zuweisung war falsch
                l6.ID = "DeleteBar->" + id;

                
                Image img = new Image();
                img.ImageUrl = "~/Images/trash16x16.jpg";
                l6.Controls.Add(img);


                l6.CommandArgument = ba.Params.AUSLAGENID.Value.ToString();
                l6.Command += new CommandEventHandler(Loeschen_Click);

                d1.Controls.Add(l1);
                d2.Controls.Add(l2);
                d3.Controls.Add(l3);
                d4.Controls.Add(l4);
                d5.Controls.Add(l5);
                d6.Controls.Add(l6);

                tr.Cells.Add(d1);
                tr.Cells.Add(d2);
                tr.Cells.Add(d3);
                //tr.Cells.Add(d4);
                tr.Cells.Add(d5);
                tr.Cells.Add(d6);

                t.Rows.Add(tr);
            }

        }
        return t;
    }

    void Bearbeiten_CLick(object sender, CommandEventArgs e)
    {
        Barauslagen_Cancel.Visible = true;
        Barauslagen_Save.Visible = true;
        Barauslagen_Add.Visible = false;

        int RowId = int.Parse(e.CommandArgument.ToString());
        
        foreach (dbBarauslagen ba in Baustelle.Barauslagen)
        {
            if (int.Parse(ba.Params.AUSLAGENID.Value.ToString()) == RowId)
            {
                selectedBarauslage = ba;
                break;

            }
        }
        Session["selectedBarauslage"] = selectedBarauslage;


        DDLTyp.SelectedValue = selectedBarauslage.Params.TYP.Value.ToString();

        //TT - 6654245 - verwende decimal anstatt float
        //float c = float.Parse(selectedBarauslage.Params.CENTS.Value.ToString());
        TBCents.Text = Convert.ToDecimal(selectedBarauslage.Params.CENTS.Value).ToString();
        TBAnz.Text = selectedBarauslage.Params.ANZ.Value.ToString();
    }

    void Loeschen_Click(object sender, CommandEventArgs e)
    {
        Barauslagen_Add.Visible = true;
        Barauslagen_Cancel.Visible = false;
        Barauslagen_Save.Visible = false;

        int id = int.Parse(e.CommandArgument.ToString());
        foreach (dbBarauslagen ba in Baustelle.Barauslagen)
        {
            if (int.Parse(ba.Params.AUSLAGENID.Value.ToString()) == id)
            {
                  ba.Deleted = true;
//                ba.Delete();
                break;
            }
        }
        barauslagenTable.Controls.Clear();
        if (Baustelle.Barauslagen.Count > 0)
            barauslagenTable.Controls.Add(getBarauslagenTable());
    }

    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler)
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        //cList.Add(btn);
        return btn;
    }

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString(); 
    }

    protected void Btn_CellSave_Click(object sender, EventArgs e)
    {
        string arg = (string)Page.Cache["Edit-ID"];
//        Page.Cache.Remove("Edit-ID");

        bool validateOK = true;
        // Prüfen d. "baustelle zu Quartier-logik"
        // diese basert auf: DropDownList1.SelectedValue != "2"

        if (ValidCheck(TapWebTextBox2, TapWebTextBox3, true) == false) return;
        // Validierung der Engabe-Textfelder
        if (DropDownList1.SelectedValue != "2")
            validateOK = ValidCheck(TapWebTextBox2) && ValidCheck(TapWebTextBox3);
        if (validateOK)
        {
            isEdit = false;
            btnInsert.Visible = true;
            Btn_CellSave.Visible = false;
            Btn_CellCancel.Visible = false;
            for (int i = Baustelle.Standorte.Count - 1; i >= 0; i--)
            {
                if (((arg.Substring(0, 2) == "S-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value.ToString())) |
                    ((arg.Substring(0, 2) == "B-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.BAUID_STDW.Value.ToString()))|
                   ((arg.Substring(0, 2) == "Q-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value.ToString())))
                {
                    dbBaustelleStandort st = (dbBaustelleStandort)Baustelle.Standorte[i];
                    foreach (Control c in Panel1.Controls)
                    {
                        if ((c as TapWebTextBox) != null)
                            foreach (SqlParameter bs in st.Params.List)
                                if (((TapWebTextBox)c).DataField == bs.ParameterName)
                                    bs.Value = ParamVal.SetParameter(bs, ((TapWebTextBox)c).TextBoxText);
                        if ((c as TapWebDropDownList) != null)
                            if ((c as TapWebDropDownList).Visible)
                                foreach (SqlParameter bs in st.Params.List)
                                    if (((TapWebDropDownList)c).DDLDataField == bs.ParameterName)
                                    {
                                        string UsrCtlID = ((TapWebDropDownList)c).ID;
                                        if ((UsrCtlID == "TapWebDrowDownList1") ||  // Standort
                                             (UsrCtlID == "TapWebDrowDownList2") ||  // Baustelle
                                             // defect 3611
                                             (UsrCtlID == "TapWebDrowDownList3") ||  // Verkehrsmittel
                                             // ende 3611
                                             (UsrCtlID == "TapWebDrowDownList4"))    // Bereistellung
                                        {
                                            if (Int32.Parse(DropDownList1.SelectedValue.ToString()) == (int)dbBaustelleStandort.Einsatz.BaustZuQuartier)
                                            {
                                                switch (((TapWebDropDownList)c).DDLDataField)
                                                {
                                                    case "@STDID":
                                                        break;
                                                    case "@BAUID_STDW":
                                                    case "@RAKZ_B":
                                                        bs.Value = "";
                                                        break;
                                                    case "@RAKZ_VM":
                                                        bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                                                        break;
                                                    default:
                                                        bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                                                        break;
                                                }
                                            }
                                            else
                                            {
                                                    bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                                            }
                                        }
                                    }
                        if ((c as DropDownList) != null)
                            //if ((c as TapWebDropDownList).Visible)
                            foreach (SqlParameter bs in st.Params.List)
                                if (((DropDownList)c).DataTextFormatString == bs.ParameterName)
                                {
                                    bs.Value = ParamVal.SetParameter(bs, ((DropDownList)c).SelectedValue);                               
                                }
                    }
                }
            }
            phTable.Controls.Clear();
            if (Baustelle.Standorte.Count != 0)
                phTable.Controls.Add(ReisedatenTable());
            Panel1.DefaultButton = "btnInsert";
        }
    }
    protected void Btn_CellCancel_Click(object sender, EventArgs e)
    {
        btnInsert.Visible = true;
        Btn_CellSave.Visible = false;
        Btn_CellCancel.Visible = false;
        Panel1.DefaultButton = "btnInsert";
    }
    
    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        switch (cmd)
        {
            case "Edit":
                Panel1.DefaultButton = "Btn_CellSave";
                isEdit = true;
                //Baustelle.StandorteEdit = true;
                btnInsert.Visible = false;
                Btn_CellSave.Visible = true;
                Btn_CellCancel.Visible = true;
                Argument = arg;
                Page.Cache["Edit-ID"] = arg;

                switch (arg.Substring(0, 2))
                {
                    case "S-":
                        DropDownList1.SelectedValue = "0";
                        TapWebDrowDownList2.Visible = false;
                        TapWebDrowDownList1.Visible = true;
                        break;
                    case "B-":
                        DropDownList1.SelectedValue = "1";
                        TapWebDrowDownList2.Visible = true;
                        TapWebDrowDownList1.Visible = false;
                        break;


                    case "Q-":
                        DropDownList1.SelectedValue = "2";
                        TapWebDrowDownList1.Enabled = false;              // Standort
                        TapWebDrowDownList2.Enabled = false;              // Baustelle
                        //TapWebDrowDownList3.Enabled = false;              // Verkehrsmittel
                        TapWebDrowDownList4.Enabled = false;              // Bereitstellung
                        break;
                    default: break;
                }

                for (int i = Baustelle.Standorte.Count - 1; i >= 0; i--)
                {
                    if (((arg.Substring(0, 2) == "S-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value.ToString())) |
                        ((arg.Substring(0, 2) == "B-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.BAUID_STDW.Value.ToString())) |
                        ((arg.Substring(0, 2) == "Q-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value.ToString())))
                       {

                        if (arg.Substring(0, 2) == "S-")
                        {
                              // WEGZEIT wird hier als temp. variablenspeicher für stdid bzw. bauid_stdw verwendet
                              (Baustelle.Standorte[i] as dbBaustelleStandort).Params.WEGZEIT.Value = (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value;
                        }
                        if (arg.Substring(0, 2) == "B-")
                        {
                            (Baustelle.Standorte[i] as dbBaustelleStandort).Params.WEGZEIT.Value = (Baustelle.Standorte[i] as dbBaustelleStandort).Params.BAUID_STDW.Value;
                        }
                        if (arg.Substring(0, 2) == "Q-")
                        {
                            // setze auf default wert 
                            (Baustelle.Standorte[i] as dbBaustelleStandort).Params.WEGZEIT.Value = 0;
                        }

                        //werte
                        foreach (Control c in Panel1.Controls)
                        {
                            if ((c as TapWebTextBox) != null)
                                foreach (SqlParameter s in (Baustelle.Standorte[i] as dbBaustelleStandort).Params.List)
                                    if (((TapWebTextBox)c).DataField == s.ParameterName)
                                        ((TapWebTextBox)c).TextBoxText = ParamVal.GetParameter(s);
                            if ((c as TapWebDropDownList) != null)
                                foreach (SqlParameter s in (Baustelle.Standorte[i] as dbBaustelleStandort).Params.List)
                                    if (((TapWebDropDownList)c).DDLDataField == s.ParameterName)
                                        ((TapWebDropDownList)c).DDLSelectedValue = ParamVal.GetParameter(s);
                            if ((c as DropDownList) != null)
                                foreach (SqlParameter s in (Baustelle.Standorte[i] as dbBaustelleStandort).Params.List)
                                    if (((DropDownList)c).DataTextFormatString == s.ParameterName)
                                        ((DropDownList)c).SelectedValue = ParamVal.GetParameter(s);
                        }
                    }
                }
   
                break;
            case "Delete":
                for (int i = Baustelle.Standorte.Count - 1; i >= 0; i--)
                {

                    if (((arg.Substring(0, 2) == "S-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value.ToString())) |
                        ((arg.Substring(0, 2) == "B-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.BAUID_STDW.Value.ToString())) |
                         ((arg.Substring(0, 2) == "Q-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value.ToString())))
                    {
                        dbBaustelleStandort bst = (dbBaustelleStandort)Baustelle.Standorte[i];
                        bst.Deleted = true;
                        bst.Delete();
                    }
                }                  
                ValidCheck(TapWebTextBox2, TapWebTextBox3, false);
                break;
            case "CellSave":

                bool validateOK = true;
                // Prüfen d. "baustelle zu Quartier-logik"
                // diese basert auf: DropDownList1.SelectedValue != "2"

                if (ValidCheck(TapWebTextBox2, TapWebTextBox3, true) == false) return;

                // Validierung der Engabe-Textfelder
                if (DropDownList1.SelectedValue != "2")
                    validateOK = ValidCheck(TapWebTextBox2) && ValidCheck(TapWebTextBox3);
                if (validateOK)
                {
                    isEdit = false;
                    btnInsert.Visible = true;
                    Btn_CellSave.Visible = false;
                    Btn_CellCancel.Visible = false;
                    for (int i = Baustelle.Standorte.Count - 1; i >= 0; i--)
                    {
                        if (((arg.Substring(0, 2) == "S-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value.ToString())) |
                            ((arg.Substring(0, 2) == "B-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.BAUID_STDW.Value.ToString())) |
                            ((arg.Substring(0, 2) == "Q-") && (arg.Substring(2) == (Baustelle.Standorte[i] as dbBaustelleStandort).Params.STDID.Value.ToString())))

                        {
                            dbBaustelleStandort st = (dbBaustelleStandort)Baustelle.Standorte[i];
                            foreach (Control c in Panel1.Controls)
                            {
                                if ((c as TapWebTextBox) != null)
                                    foreach (SqlParameter bs in st.Params.List)
                                        if (((TapWebTextBox)c).DataField == bs.ParameterName)
                                            bs.Value = ParamVal.SetParameter(bs, ((TapWebTextBox)c).TextBoxText);
                                if ((c as TapWebDropDownList) != null)
                                    if ((c as TapWebDropDownList).Visible)
                                        foreach (SqlParameter bs in st.Params.List)
                                            if (((TapWebDropDownList)c).DDLDataField == bs.ParameterName)
                                            {

                                                string UsrCtlID = ((TapWebDropDownList)c).ID;
                                                if ((UsrCtlID == "TapWebDrowDownList1") ||  // Standort
                                                     (UsrCtlID == "TapWebDrowDownList2") ||  // Baustelle
                                                     // defect 3611
                                                     (UsrCtlID == "TapWebDrowDownList3") ||  // Verkehrsmittel
                                                     // ende
                                                     (UsrCtlID == "TapWebDrowDownList4"))    // Bereistellung
                                                {
                                                    if (Int32.Parse(DropDownList1.SelectedValue.ToString()) == (int)dbBaustelleStandort.Einsatz.BaustZuQuartier)
                                                    {
                                                        switch (((TapWebDropDownList)c).DDLDataField)
                                                        {
                                                            case "@STDID":
                                                                break;
                                                            case "@BAUID_STDW":
                                                            case "@RAKZ_B":
                                                                bs.Value = "";
                                                                break;
                                                            case "@RAKZ_VM":
                                                                bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                                                                break;
                                                            default:
                                                                bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                                                                break;
                                                        }
                                                    }
                                                    else
                                                    {
                                                            bs.Value = ParamVal.SetParameter(bs, ((TapWebDropDownList)c).DDLSelectedValue);
                                                    }
                                                }
                                            }
                                if ((c as DropDownList) != null)
                                    //if ((c as TapWebDropDownList).Visible)
                                    foreach (SqlParameter bs in st.Params.List)
                                        if (((DropDownList)c).DataTextFormatString == bs.ParameterName)
                                        {
                                           bs.Value = ParamVal.SetParameter(bs, ((DropDownList)c).SelectedValue);
                                        }
                            }
                        }
                    }
                }
                ValidCheck(TapWebTextBox2, TapWebTextBox3, false);
                break;
            case "CellCancel":
                //to Do
                btnInsert.Visible = true;
                Btn_CellSave.Visible = false;
                Btn_CellCancel.Visible = false;
                ValidCheck(TapWebTextBox2, TapWebTextBox3, false);
                break;
            case "Save":
                //to Do
                break;  
            case "Cancel":
                //to Do
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;
        }
        phTable.Controls.Clear();
        if (Baustelle.Standorte.Count != 0)
            phTable.Controls.Add(ReisedatenTable());
    }
/* 
    protected void Barauslagen_Add_Click(object sender, EventArgs e)
    {
        //if (ValidCheck(, TapWebTextBox3, true) == false) return;
        
        string typ = DDLTyp.SelectedValue;
        float cents = float.Parse(TBCents.Text);
        int anz = int.Parse(TBAnz.Text);

        dbBarauslagen dba = new dbBarauslagen(Baustelle);
        dba.Params.BAUID.Value = Baustelle.Params.BAUID.Value;
        dba.Params.TYP.Value = typ;
        dba.Params.CENTS.Value = cents;
        dba.Params.ANZ.Value = anz;

        dba.Insert();

        DDLTyp.SelectedIndex = 0;
        TBAnz.Text = "";
        TBCents.Text = "";

        barauslagenTable.Controls.Clear();
        barauslagenTable.Controls.Add(getBarauslagenTable());

    }
*/

    protected void Barauslagen_Add_Click(object sender, EventArgs e)
    {
        string typ = DDLTyp.SelectedValue;

        // Beginn Defect 4425: Check input in Betrag und Anzahl (try/catch)
        bool blnFormatError = false;
        float cents = 0.0F;
        int anz     = 0;
        try
        {
            if (TBCents.Text.Contains(".")
                || TBCents.Text.Contains(" "))
            {
                blnFormatError = true;
            }
            else
            {
                cents = float.Parse(TBCents.Text);
            }
        }
        catch (Exception)
        {
            cents = 0.0F;
            blnFormatError = true;
        }

        try
        {
            if (TBAnz.Text.Contains(".")
                || TBAnz.Text.Contains(" "))
            {
                blnFormatError = true;
            }
            else
            {
                anz = int.Parse(TBAnz.Text);
            }
        }
        catch (Exception)
        {
            anz = 0;
            blnFormatError = true;
        }
        // Ende Defect 4425: Check input in Betrag und Anzahl (try/catch)

        Baustelle = (dbBaustelle)Session["Baustelle"];

        // Beginn Defect 4425: Check input in Betrag und Anzahl (try/catch)
        if (!blnFormatError)
        {
            dbBarauslagen dbausl = new dbBarauslagen(Baustelle);
            dbausl.Params.BAUID.Value = Baustelle.Params.BAUID.Value;
            dbausl.Params.TYP.Value = typ;
            dbausl.Params.CENTS.Value = cents;
            dbausl.Params.ANZ.Value = anz;
            Baustelle.Barauslagen.Add(dbausl);
            DDLTyp.SelectedIndex = 0;
        }

        // Ende Defect 4425: Check input in Betrag und Anzahl (try/catch)
        
        TBAnz.Text = "";
        TBCents.Text = "";
        Session["Baustelle"] = Baustelle;
        barauslagenTable.Controls.Clear();
        barauslagenTable.Controls.Add(getBarauslagenTable());        
    }

    protected void Barauslagen_Save_Click(object sender, EventArgs e)
    {

        //Defect 5121 Verändern einer Barauslage
        //GN 12.6.2007
        bool bInFormatError = false; //5121 wird auf true gesetzt, wenn ein Formatfehler auftritt

        if (selectedBarauslage != null)
        {
            string typ = DDLTyp.SelectedValue;

            try //5121 Formatfehlerexception wird abgefangen und bInFormatError wird entsprechend gesetzt
            {
                float cents = float.Parse(TBCents.Text);
                int anz = int.Parse(TBAnz.Text);

                selectedBarauslage.Params.CENTS.Value = cents;
                selectedBarauslage.Params.TYP.Value = typ;
                selectedBarauslage.Params.ANZ.Value = anz;
            } catch(Exception) {
                bInFormatError = true;
            }
        }

        //5121 Nur bei korrekter Eingabe wird fortgefahren
        if (!bInFormatError)
        {

            Barauslagen_Cancel.Visible = false;
            Barauslagen_Save.Visible = false;
            Barauslagen_Add.Visible = true;
        }
        barauslagenTable.Controls.Clear();
        if (Baustelle.Barauslagen.Count > 0)
            barauslagenTable.Controls.Add(getBarauslagenTable());
        Session["Baustelle"] = Baustelle;
    }
  
    protected void Barauslagen_Cancel_Click(object sender, EventArgs e)
    {
        Barauslagen_Cancel.Visible = false;
        Barauslagen_Save.Visible = false;
        Barauslagen_Add.Visible = true;
    }
}
