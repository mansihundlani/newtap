//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : PrintEB.aspx.cs
//
// Description  : Drucken von Einsatzberichten
//
//=============== V1.2.0013 ===============================================
//
// Date         : 02.November 2012
// Author       : Joldic Dzevad
// Defect#      : OSD 15745166
//                PDF Stream to Web funktioniert nicht mehr bei Siemens. 
//                L�sung: Generierte PDF Report wird zuerst gespeichert
//                dann ins Applikation geladen 
//
//=============== V1.0.0042 ===============================================
//
// Date         : 18.Juni 2008
// Author       : Frantisek Sabol
// Defect#      : 6074
//                Alle MA Belege Ausdrucken durch ein Knopfdruck
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.Pdf;
using TapMontage.dbObjects;

public partial class Einsatzbericht_PrintEB : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //btnBack.Visible = (Request.QueryString["RetUrl"] != null);
        //PlaceHolder1.Controls.Add(pdfReports.ShowMBericht(Page, 800, 600));
        //Root.Reports.RT.ResponsePDF(new pdfMBJournal((dbMontBer) Session["MBericht"]), Response);   // Defect# 6074
        //Defect# 6074 - Anstatt von einem EB, ab jetzt wird eine Liste von EBs nach pdfMBJournal gesendet
        //Root.Reports.RT.ResponsePDF(new pdfMBJournal((ArrayList)Session["mBerichtListe"]), this);//Response); // Defect# 6074
        /*TAP.Allgemein.Drucken.Einsber EB = new TAP.Allgemein.Drucken.Einsber();
        string path = EB.GetPDFPath();
        System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(path);
        if (dir.Exists)
        {
            System.IO.FileInfo[] fi = dir.GetFiles("170007018.pdf");
            if (fi.Length == 1)
            {
                //file exist
                Response.ContentType = "Application/pdf";
                Response.WriteFile(path + "\\170007018.pdf");
                Response.End();
            }
            else
            {
                //create new
                if (EB.PDFDrucken(1, "170007018,170007017", "TAP MONTAGE", "M3", "170007018"))
                {
                    Response.ContentType = "Application/pdf";
                    Response.WriteFile(path + "\\170007018.pdf");
                    Response.End();
                }
            }
        }
        */
        //TT OSD 15745166 Beginn
        pdfMBJournal report = new pdfMBJournal((ArrayList)Session["mBerichtListe"]);
        string Path = this.Page.MapPath("~/Reports/");
        string filename = RandomFname("EB_");
        report.Save(Path + filename);
        this.Response.Redirect("~/Reports/" + filename);
        //TT OSD 15745166 Ende

    }

    private string RandomFname(string p)
    {
        Random rand = new Random(DateTime.Now.Millisecond);
        return p + rand.Next().ToString() + ".pdf";
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.QueryString["RetUrl"].ToString());
    }
}
