//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : KFZ.ascx.cs
//
// Description  : Erfassung KFZ-Daten
//
//--------------- V1.0.0037 ---------------------------------------------------
//
// Date         : 16.J�nner 2008
// Author       : Georg Nebehay
// Defect#      : 5749
//                Korrektur Eingabevalidierung Obifahrt
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 30.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 5190, 5211
//                Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt l�schen
//
//=============== V1.0.0028 ===============================================
//
// Date         : 01.Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4887:
//                �berpr�fung der KFZ-Daten, ob diese innerhalb der
//                der Arbeitszeit
//
//=============== V1.0.0027 ===============================================
//
// Date         : 21.Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4073:
//                Warnung bei Autotype und Kennzeichen
//
//=============== V1.0.0027 ===============================================
//
// Date         : 14.Mai 2007
// Author       : Nebehay Georg
// Defect#      : 4931:
//                Neues Feld Mitfahrt
//
// Date         : 14.Mai 2007
// Author       : Nebehay Georg
// Defect#      : 4932:
//                Neues Feld Schwergep�ck
//
// Date         : 23.April 2007
// Author       : Christian Lahofer
// Defect#      : 4701:
//                Mehrere KFZ-Fahrten zum gleichen Zeitpunkt sind nicht
//                zul�ssig.
//
//=============== V1.0.0022 ===============================================
//
// Date         : 23.Februar 2007
// Author       : Nebehay Georg
// Defect#      : 4417, 4619:
//                Obifahrten nur innerhalb der Arbeitszeit
//
//=============== V1.0.0020 ===============================================
//
// Date         : 29.J�nner 2007
// Author       : Christian Lahofer
// Defect#      : 4403:
//                Verbesserung des Meldungstextes f�r falsche Datumseingabe.
//
//=============== V1.0.0011 ===============================================
//
// Date         : 24.November 2006
// Author       : Gebhardt Caleb
// Defect#      : 3737:
//                Standortwechsel sind nur innerhalb von H und R zul��ig
//
//=============== V1.0.0008 ===============================================
//
// Date         : 15.November 2006
// Author       : Gebhardt Caleb
// Defect#      : 3664:
//                Beim Eintragen eines Standortwechsels wird die Uhrzeit
//                nicht abgespeichert
//
//=============== V1.0.0004 ===============================================
//
// Date         : 07.November 2006
// Author       : Wieland Erwin
// Defect#      : 3551:
//                Uhrzeit muss innerhalb der Arbeitszeit liegen
//
//=========================================================================
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Einsatzbericht_KFZ : System.Web.UI.UserControl
{
  private bool isEdit = false;
  string Argument = "";
  dbMontBer MBericht;

  // Beginn Defect 4887
  public bool bOnlyValidKFZDaten
  {
    get
    {
      return CheckKFZDaten();
    }
  }

  public string strLabel1
  {
    set
    {
      Label1.Text = value;
      if (Label1.Text != "")
      {
        Label1.Visible = true;
      }
    }
    get
    {
      return Label1.Text;
    }
  }
  // Ende Defect 4887

  protected void Page_Load(object sender, EventArgs e)
  {
    MBericht = (dbMontBer)Session["MBericht"];
    if ((int)MBericht.Params.EBID.Value > 0)
    {
      if (MBericht.KfzDatenlist.Count > 0)
        phTable.Controls.Add(KfzDatenTable());
      Session["MBericht"] = MBericht;
      if (!Page.IsPostBack)
        MapData();
    }

    // Beginn #5190, 5211 - Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt l�schen
    TapWebTextBox1.SelectedDate = MBericht.MinDatum.ToString();
    // Ende #5190, 5211
    TapWebTextBox5.TB.ToolTip = "Mehr als 2000km k�nnen nicht an SAP �bertragen werden!";
  }
  public bool Enabled
  {
    get { return panMain.Enabled; }
    set { panMain.Enabled = value; }
  }

  private void MapData()
  {
    MBericht = (dbMontBer)Session["MBericht"];
    if (MBericht.PersKfzDatenList.Count > 0)
    {
      if (TapWebTextBox2.TextBoxText == "")
      {
        TapWebTextBox2.TextBoxText = (MBericht.PersKfzDatenList[0] as dbRAKfzdaten).KfzParams.KFZ.Value.ToString();
        TapWebTextBox3.TextBoxText = (MBericht.PersKfzDatenList[0] as dbRAKfzdaten).KfzParams.KFZKZ.Value.ToString();
      }
    }
  }

  public void Save()
  {
    //if (Page.IsValid)
    //{
    MBericht = (dbMontBer)Session["MBericht"];
    ExecDBCmd();
    Session["MBericht"] = MBericht;
    phTable.Controls.Clear();
    phTable.Controls.Add(KfzDatenTable());
    //}
  }

  // Beginn Defect 4887
  public bool CheckKFZDaten()
  {
    // Alle KFZ-Fahrten werden gepr�ft, ob
    // ob die KFZ-Fahrten innerhalb der Arbeitszeit stattfinden.
    // Fehlerhafte Eintr�ge werden im Fehlerlabel gemeldet, evtl. gemeinsam mit Hinweisen
    // auf falsche Zeitstempel.

    if (MBericht.KfzDatenlist.Count == 0) return true;

    // Beginn #5190, 5211 - Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt l�schen
    bool bOnlyGoodData = true; 
    // Ende #5190, 5211

    MBericht = (dbMontBer)Session["MBericht"];

    // Alle KFZ-Daten durchsuchen
    for (int indKFZ = 0; indKFZ <= MBericht.KfzDatenlist.Count - 1; indKFZ++)
    {
      DateTime dtKFZTag = Convert.ToDateTime(((dbRAKfzdaten)MBericht.KfzDatenlist[indKFZ]).Params.RDATUM.Value);

      if (((dbRAKfzdaten)MBericht.KfzDatenlist[indKFZ]).Deleted)
      {            
          continue;
      }

      // entsprechenden Tag passend zu den KFZ-Daten holen
      dbArbTag tag = (dbArbTag)MBericht.Tage[dtKFZTag.Day - 1];

      // �berpr�fung der Zeiten
      foreach (dbArbZeit z in tag.Zeiten)
      {
        if (!z.Deleted)
        {
          if ((tag.Relevanz && //Zeit ist produktiv/GK
               z.Kommen != ParamVal.Date0 &&
               z.Gehen != ParamVal.Date0 &&
               z.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz &&
               z.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz
               ))
          {
            if (dtKFZTag.Ticks < z.Kommen.Ticks || //Obifahrt liegt au�erhalb einer prod./GK Arbeitszeit -> bOnlyGoodData = false, aber weitere �berpr�fung
                dtKFZTag.Ticks > z.Gehen.Ticks)
            {
              bOnlyGoodData = false;
              strLabel1 = "Die am " + dtKFZTag.ToString("dd.MM. HH:mm") +
                          " erfassten KFZ-Daten liegen au�erhalb der Arbeitszeit!";
            }
            else //Obifahrt liegt innerhalb einer produktiven Arbeitszeit -> korrekt
            {
              bOnlyGoodData = true;
              strLabel1 = "";
              break;
            }
          }
          else
          {
              //Defect 5749
              //GN 16.1.2008
              //�berpr�fung auf stundenweise Absenz korrigiert
              if (z.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz)
              {

                  if (z.Kommen < dtKFZTag && z.Gehen > dtKFZTag) //Obifahrt liegt innerhalb stdw. Absenz
                  {
                      bOnlyGoodData = false; 
                      strLabel1 = "Die am " + dtKFZTag.ToString("dd.MM. HH:mm") +
                                  " erfassten KFZ-Daten befinden sich innerhalb einer stundenweise Absenz.";
                      break;
                  } //Ansonsten weitere �berp�fung

              }
              else //Keine Zeit erfasst oder GT-Absenz 
              {

                  bOnlyGoodData = false;
                  strLabel1 = "Zu den am " + dtKFZTag.ToString("dd.MM.") +
                              " erfassten KFZ-Daten wurde keine Arbeitszeit eingegeben!";
                  break;
              }
          }
        }
      }

      // Ausstieg beim ersten fehlerhaften Satz
      if (bOnlyGoodData == false)
      {
        break;
      }
    }
    return bOnlyGoodData;
  }
  // Ende Defect 4887

  private bool UserInputValid()
  {
    bool bRetval = true;
    // Beginn Defect 4403: �nderung Meldungstext f�r falsches Datum
    // string msgdat = "* Geben Sie bitte ein g�ltiges Datum an, z.B.: " + DateTime.Now.ToShortDateString();
    string msgdat = "* Geben Sie bitte ein g�ltiges Datum im lfd. Kalendermonat ein";
    // Ende Defect 4403: �nderung Meldungstext f�r falsches Datum

    string msgstr = "* Geben Sie bitte einen g�ltigen Wert an, im Feld: '";
    string rdatum = "";
    dbRAKfzdaten RAKfzdaten = new dbRAKfzdaten(MBericht);
    Label1.Visible = false;
    Label1.ForeColor = System.Drawing.Color.Red;
    Label1.Text = "";
    foreach (Control c in panMain.Controls)
    {
      if ((c as TapWebTextBox) != null)
        foreach (SqlParameter kdt in RAKfzdaten.Params.List)
        {
          if (((TapWebTextBox)c).DataField == kdt.ParameterName)
          {
            string dtItem = ((TapWebTextBox)c).TextBoxText;
            switch (kdt.ParameterName)
            {
              case "@RRICHT":
                break;
              case "@RDATUM":
                rdatum = dtItem;
                // Beginn Defect 3551
                // Uhrzeit muss innerhalb der Arbeitszeit liegen
                if (AbfahrtZeit.TextBoxText == "00:00" || AbfahrtZeit.TextBoxText == "")
                {
                  Label1.Visible = true;
                  Label1.Text = msgstr + AbfahrtZeit.LabelText + "'";
                  bRetval = false;
                  break;
                }
                // Ende Defect 3551
                if ((dtItem == "") || ((CheckDate(dtItem) == false)))
                {
                  Label1.Visible = true;
                  // Beginn Defect 4403: �nderung Meldungstext f�r falsches Datum
                  // Label1.Text = msgdat + ((TapWebTextBox)c).LabelText + "'";
                  Label1.Text = msgdat;
                  // Ende Defect 4403: �nderung Meldungstext f�r falsches Datum
                  bRetval = false;
                }
                break;
              case "@ABKM":
              case "@GEFKM":
                /*
                if ((dtItem == "") | !RangeCheck.IsNumeric(dtItem))
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = msgnum + ((TapWebTextBox)c).LabelText + "'";
                    bRetval = false;
                }
                 */
                break;
              case "@KFZ":
              case "@KFZKZ":
                /*
                if ((dtItem == "") | (dtItem == null))
                {
                    Label1.Visible = true;
                    Label1.ForeColor = System.Drawing.Color.Red;
                    Label1.Text = msgstr + ((TapWebTextBox)c).LabelText + "'"; ;
                    bRetval = false;
                }
                 */
                break;
            }
          }
          if (bRetval == false) break;
        }
    }
    return bRetval;
  }

  protected void btnInsertKfz_Click(object sender, EventArgs e)
  {
    // Defect#      : 4073 - Warnung bei Autotype und Kennzeichen
    // ASPX Seite ist zuerst best�tigt - Page.Validate();
    Page.Validate();
    if (Page.IsValid)
    {// Ende Defect # 4073

      dbRAKfzdaten RAKfzdaten = new dbRAKfzdaten(MBericht);
      // Defect# 3737: Standortwechsel sind nur innerhalb von H und R zul��ig
      // Defect #4417
      // Defect #4619
      //GN 23.02.2007 Obifahrten nur innerhalb Arbeitszeit (Einf�gen)
      //Start
      String dateString = TapWebTextBox1.TextBoxText;
      String time = AbfahrtZeit.TextBoxText;
      DateTime date = ParamVal.Date0; // Defect # 4701
      bool blnContinueInsert = true; // Defect # 4701       

      try
      {
        date = Convert.ToDateTime(dateString + " " + time);
      }
      catch (Exception ex)
      {
        String strErrMessage = ex.Message;
        // Fehlermeldung bez�glich falschem Datums-/Zeitformat ausgeben
        Label1.Visible = true;
        Label1.Text = "Bitte Datum im Format tt.mm.jjjj und Zeit im Format hh:mm eingeben !";
        blnContinueInsert = false;
        if (MBericht.KfzDatenlist != null)
        {
          if (MBericht.KfzDatenlist.Count > 0)
          {
            phTable.Controls.Clear();
            phTable.Controls.Add(KfzDatenTable());
          }
        }
      }

      /* Beginn Defect # 4701: Zum gleichen Zeitpunkt d�rfen nicht mehrere
       * KFZ-Fahrten erfasst werden. Falls in der Liste der Fahrten zum
       * angegebenen Zeitpunkt bereits eine Fahrt eingetragen ist, wird die
       * aktuelle Eingabe mit Fehlermeldung abgelehnt.
       * */
      if (blnContinueInsert)
      {
        if (MBericht.KfzDatenlist != null)
        {
          if (MBericht.KfzDatenlist.Count > 0)
          {
            foreach (dbRAKfzdaten dbKFZData in MBericht.KfzDatenlist)
            {
                // Beginn #5190, 5211 - Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt l�schen
                if ((((DateTime)(dbKFZData.Params.RDATUM.Value)).Ticks == date.Ticks) && (!dbKFZData.Deleted)) 
                // Ende #5190, 5211
              {
                /* Fahrt zu diesem Zeitpunkt bereits vorhanden,
                 * Fehlermeldung wird ausgegeben und Insert wird
                 * abgebrochen
                 * */
                Label1.Visible = true;
                Label1.Text = "Zu diesem Zeitpunkt ist eine KFZ-Fahrt bereits vorhanden !";
                blnContinueInsert = false;
                // GUI-Tabelle neu aufbauen und einblenden
                phTable.Controls.Clear();
                phTable.Controls.Add(KfzDatenTable());
                break;
              }
            }
          }
        }
      }

      if (blnContinueInsert)
      {
        /* Fortsetzung nur, falls zu diesem Zeitpunkt noch keine Fahrt
           erfasst wurde */
        // Ende Defect # 4701

        int day = date.Day;
        dbArbTag tag = (dbArbTag)MBericht.Tage[day - 1];

        Boolean found = false;
        foreach (dbArbZeit z in tag.Zeiten)
        {
          if ((tag.Relevanz && z.Kommen != ParamVal.Date0 && z.Gehen != ParamVal.Date0 && z.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz && z.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz && !z.Deleted))
          {
            if (date.Ticks >= z.Kommen.Ticks && date.Ticks <= z.Gehen.Ticks)
            {
              found = true;
              break;
            }
          }
        }

        //Ende


        if (UserInputValid())
        {

          if (found)
          {
            foreach (Control c in panMain.Controls)
            {
              if ((c as TapWebTextBox) != null)
                foreach (SqlParameter bs in RAKfzdaten.Params.List)
                  if (((TapWebTextBox)c).DataField == bs.ParameterName)
                  {
                    string parmval = ((TapWebTextBox)c).TextBoxText;
                    if (bs.ParameterName == "@RDATUM")
                    {
                      parmval += " ";
                      parmval += AbfahrtZeit.TextBoxText;
                    }
                    bs.Value = ParamVal.SetParameter(bs, parmval);
                  }
              if ((c as TapWebDropDownList) != null)
                if ((c as TapWebDropDownList).Visible)
                  foreach (SqlParameter Kfzzl in RAKfzdaten.Params.List)
                    if (((TapWebDropDownList)c).DDLDataField == Kfzzl.ParameterName)
                      Kfzzl.Value = ParamVal.SetParameter(Kfzzl, ((TapWebDropDownList)c).DDLSelectedValue);
              if ((c as DropDownList) != null)
                foreach (SqlParameter Kfzzl in RAKfzdaten.Params.List)
                  if (((DropDownList)c).DataTextFormatString == Kfzzl.ParameterName)
                    if (Kfzzl.ParameterName == "@RRICHT") Kfzzl.Value = dbKG_ReiseZeilenKZ.GetKZ(dbKG_ReiseZeilenTyp.StandortWechsel);
                    else Kfzzl.Value = ParamVal.SetParameter(Kfzzl, ((DropDownList)c).SelectedValue);

            }

            RAKfzdaten.Params.EBID.Value = MBericht.Params.EBID.Value;
            RAKfzdaten.Params.MANDANT.Value = MBericht.Bearbeiter.Params.MANDANT.Value;
            RAKfzdaten.Params.PERSKEY.Value = MBericht.Bearbeiter.Params.PERSKEY.Value;
            //CR 4932 Schwergep�ckspeicherung
            //GN 14.5.2007
            RAKfzdaten.Params.SCHWERGP.Value = (SchwergepCheckbox.Checked) ? "S" : "";

            MBericht.KfzDatenlist.Add(RAKfzdaten);
            phTable.Controls.Clear();
            phTable.Controls.Add(KfzDatenTable());

            Label1.Visible = false;

          }
          else
          {
            Label1.Visible = true;
            Label1.Text = "Sie k�nnen Standortwechsel nur innerhalb einer Arbeitszeit eingeben";
            if (MBericht.KfzDatenlist != null)
            {
              if (MBericht.KfzDatenlist.Count > 0)
              {
                phTable.Controls.Clear();
                phTable.Controls.Add(KfzDatenTable());
              }
            }
          }

          /*
          TapWebTextBox2.TextBoxText = (MBericht.PersKfzDatenList[0] as dbRAKfzdaten).KfzParams.KFZ.Value.ToString();
          TapWebTextBox3.TextBoxText = (MBericht.PersKfzDatenList[0] as dbRAKfzdaten).KfzParams.KFZKZ.Value.ToString();
          */
        }
      } // Defect # 4701
      btnInsertkfz.Focus();
    }

  // Defect#      : 4073 - Warnung bei Autotype und Kennzeichen
    // ASPX Seite ist nich g�ltig -> phTable wird augef�llt.
    else
    {
      if (MBericht.KfzDatenlist != null)
      {
        if (MBericht.KfzDatenlist.Count > 0)
        {
          phTable.Controls.Clear();
          phTable.Controls.Add(KfzDatenTable());
        }
      }
    }
    // Ende Defect # 4073       
  }

  private bool CheckDate(string s)
  {
    if (!RangeCheck.IsDate(RangeCheck.FixDate(s)))
    {
      return false;
    }
    else
    {
      DateTime dt = Convert.ToDateTime(s);
      long dasDat = dt.Year * 1000 + dt.Month * 10;
      dt = MBericht.MinDatum;
      long monberDat = dt.Year * 1000 + dt.Month * 10;
      if (dasDat == monberDat)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }

  private Table KfzDatenTable()
  {
    xxID = 0;
    Table KfzDaten = new Table();

    KfzDaten.Width = Unit.Percentage(100);
    TableRow HeaderRow = new TableRow();

    TableCell c1 = new TableCell();
    c1.Text = "Datum";
    c1.CssClass = "TabHeader";
    c1.Font.Bold = true;
    /*
       TableCell c2 = new TableCell();
       c2.Text = "ZielTyp";
       c2.CssClass = "TabHeader";
       c2.Font.Bold = true;
        */
    TableCell c3 = new TableCell();
    c3.CssClass = "TabHeader";
    c3.Text = "KfzTyp";
    c3.Font.Bold = true;

    TableCell c4 = new TableCell();
    c4.CssClass = "TabHeader";
    c4.Text = "Pol. Kennz.";
    c4.Font.Bold = true;

    TableCell c5 = new TableCell();
    c5.CssClass = "TabHeader";
    c5.Text = "Km-Stand";
    c5.Font.Bold = true;

    TableCell c6 = new TableCell();
    c6.CssClass = "TabHeader";
    c6.Text = "Gef.Km";
    c6.Font.Bold = true;

    //CR 4931 Neue Spalte Mitfahrer eingef�gt
    //GN 14.5.07
    TableCell c7 = new TableCell();
    c7.CssClass = "TabHeader";
    c7.Text = "MF";
    c7.Font.Bold = true;

    //CR 4932 Neue Spalte Schwergep�ck eingef�gt
    //GN 14.5.07
    TableCell c8 = new TableCell();
    c8.CssClass = "TabHeader";
    c8.Text = "SG";
    c8.Font.Bold = true;

    TableCell c9 = new TableCell();
    c9.CssClass = "TabHeader";
    c9.Text = "";
    c9.Font.Bold = true;

    TableCell c10 = new TableCell();
    c10.CssClass = "TabHeader";
    c10.Text = "";
    c10.Font.Bold = true;

    HeaderRow.Cells.Add(c1);
    //HeaderRow.Cells.Add(c2);
    HeaderRow.Cells.Add(c3);
    HeaderRow.Cells.Add(c4);
    HeaderRow.Cells.Add(c5);
    HeaderRow.Cells.Add(c6);

    //CR 4931 Neue Spalte Mitfahrer eingef�gt
    //GN 14.5.07
    HeaderRow.Cells.Add(c7);

    //CR 4932 Neue Spalte Schwergep�ck eingef�gt
    //GN 14.5.07
    HeaderRow.Cells.Add(c8);

    HeaderRow.Cells.Add(c9);
    HeaderRow.Cells.Add(c10);

    KfzDaten.Rows.Add(HeaderRow);
    HeaderRow.Visible = true;

    string strCssClassRow = "TabNewTRIP";
    int iRAKfzzl = 0;
    //...
    string sarg = "";
    sarg = (string)Session["Edit-ID"];

    LinkButton lnkbtn;
    foreach (dbRAKfzdaten Kfzzl in MBericht.KfzDatenlist)
    {
      if (!Kfzzl.Deleted)
      {
        HeaderRow.Visible = true;
        Argument = "K-" + iRAKfzzl.ToString();
        TableRow tr = new TableRow();

        TableCell d1 = new TableCell();
        d1.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + Kfzzl.Params.RDATUM.Value.ToString().Substring(0, 16);
        d1.HorizontalAlign = HorizontalAlign.Center;
        d1.ID = Argument.ToString() + "d1.ID";
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          d1.ForeColor = System.Drawing.Color.Blue;
        tr.Cells.Add(d1);

        /*TableCell d2 = new TableCell();
        d2.CssClass = strCssClassRow;
        d2.Text = ParamVal.GetParameter(Kfzzl.Params.RRICHT);
        d2.ID = Argument.ToString() + "d2.ID";
        tr.Cells.Add(d2);
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
            d2.ForeColor = System.Drawing.Color.Blue;
        */

        TableCell d3 = new TableCell();
        d3.CssClass = strCssClassRow;
        d3.Text = ParamVal.GetParameter(Kfzzl.Params.KFZ);
        d3.ID = Argument.ToString() + "d3.ID";
        tr.Cells.Add(d3);

        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          d3.ForeColor = System.Drawing.Color.Blue;

        TableCell d4 = new TableCell();
        d4.CssClass = strCssClassRow;
        d4.Text = ParamVal.GetParameter(Kfzzl.Params.KFZKZ);
        d4.ID = Argument.ToString() + "d4.ID";
        tr.Cells.Add(d4);
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          d4.ForeColor = System.Drawing.Color.Blue;

        TableCell d5 = new TableCell();
        d5.CssClass = strCssClassRow;
        d5.Text = ParamVal.GetParameter(Kfzzl.Params.ABKM);
        d5.ID = Argument.ToString() + "d5.ID";
        tr.Cells.Add(d5);
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          d5.ForeColor = System.Drawing.Color.Blue;

        TableCell d6 = new TableCell();
        d6.CssClass = strCssClassRow;
        d6.Text = ParamVal.GetParameter(Kfzzl.Params.GEFKM);
        d6.ID = Argument.ToString() + "d6.ID";
        tr.Cells.Add(d6);
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          d6.ForeColor = System.Drawing.Color.Blue;

        //CR 4931 Neue Spalte Mitfahrer eingef�gt
        //GN 14.5.07
        TableCell d7 = new TableCell();
        d7.CssClass = strCssClassRow;
        d7.Text = ParamVal.GetParameter(Kfzzl.Params.MITFAHRER);
        d7.ID = Argument.ToString() + "d7.ID";
        tr.Cells.Add(d7);
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          d6.ForeColor = System.Drawing.Color.Blue;

        //CR 4932 Neue Spalte Schwergep�ck eingef�gt
        //GN 14.5.07
        TableCell d8 = new TableCell();
        d8.CssClass = strCssClassRow;
        d8.Text = (ParamVal.GetParameter(Kfzzl.Params.SCHWERGP) == "S") ? "Ja" : "Nein";
        d8.ID = Argument.ToString() + "d8.ID";
        tr.Cells.Add(d8);
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          d6.ForeColor = System.Drawing.Color.Blue;



        TableCell d9 = new TableCell();
        d9.CssClass = strCssClassRow;
        lnkbtn = NewFuncButton("Bearbeiten", "Edit", Argument, "Klicken Sie hier um den Eintrag zu bearbeiten.", FuncButton_Click);
        d9.Controls.Add(lnkbtn);
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          lnkbtn.Enabled = false;
        tr.Cells.Add(d9);

        TableCell d10 = new TableCell();
        d10.CssClass = strCssClassRow;
        lnkbtn = NewFuncButton("L�schen", "Delete", Argument, "Klicken Sie hier um den Eintrag zu l�schen.", FuncButton_Click);
        d10.Controls.Add(lnkbtn);
        if (isEdit && sarg.Substring(2) == iRAKfzzl.ToString())
          lnkbtn.Enabled = false;
        tr.Cells.Add(d10);

        KfzDaten.Rows.Add(tr);

      }
      else
      {
        if (iRAKfzzl == 0) HeaderRow.Visible = false;

      }
      ++iRAKfzzl;
    }
    MapData();
    return KfzDaten;
  }

  private LinkButton NewFuncButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler FuncButtonClick_EventHandler)
  {

    LinkButton btn = new LinkButton();
    btn.ID = nid();
    btn.SkinID = "";
    btn.Width = Unit.Percentage(100);
    btn.Text = Text;
    btn.CommandName = Command;
    btn.CommandArgument = Argument;
    btn.ToolTip = ToolTip;
    btn.Command += new CommandEventHandler(FuncButtonClick_EventHandler);
    return btn;
  }

  public int xxID = 0;
  public string nid()
  {
    xxID++;
    return "LnkBTN->" + xxID.ToString();
  }

  void FuncButton_Click(object sender, CommandEventArgs e)
  {
    string cmd = (string)e.CommandName;
    string arg = (string)e.CommandArgument;

    // L�schen einer evtl. angezeigten Fehlermeldung
    Label1.Text = "";
    Label1.Visible = false;

    switch (cmd)
    {
      case "Edit":
        isEdit = true;
        btnInsertkfz.Visible = false;
        Btn_CellSavekfz.Visible = true;
        Btn_CellCancelkfz.Visible = true;
        Session["Edit-ID"] = arg;
        int iEditzeile = MBericht.KfzDatenlist.Count - 1;
        for (int i = MBericht.KfzDatenlist.Count - 1; i >= 0; i--)
        {
          if (arg.Substring(2) == iEditzeile.ToString())
          {
            foreach (Control c in panMain.Controls)
            {
              if ((c as TapWebTextBox) != null)
                foreach (SqlParameter rakfz in (MBericht.KfzDatenlist[i] as dbRAKfzdaten).Params.List)
                  if (((TapWebTextBox)c).DataField == rakfz.ParameterName)
                  {
                    string parmval = ParamVal.GetParameter(rakfz);
                    if (rakfz.ParameterName == "@RDATUM")
                    {
                      string temp = rakfz.Value.ToString();
                      AbfahrtZeit.TextBoxText = temp.Substring(11, 5);
                    }
                    ((TapWebTextBox)c).TextBoxText = parmval;
                  }
              if ((c as TapWebDropDownList) != null)
                foreach (SqlParameter rakfz in (MBericht.KfzDatenlist[i] as dbRAKfzdaten).Params.List)
                  if (((TapWebDropDownList)c).DDLDataField == rakfz.ParameterName)
                    ((TapWebDropDownList)c).DDLSelectedValue = ParamVal.GetParameter(rakfz);
              if ((c as DropDownList) != null)
              {
                foreach (SqlParameter rakfz in (MBericht.KfzDatenlist[i] as dbRAKfzdaten).Params.List)
                  if (((DropDownList)c).DataTextFormatString == rakfz.ParameterName)
                    if (rakfz.ParameterName == "@RRICHT")
                    {
                      rakfz.Value = dbKG_ReiseZeilenKZ.GetKZ(dbKG_ReiseZeilenTyp.StandortWechsel);
                    }
                    else
                    {
                      rakfz.Value = ParamVal.SetParameter(rakfz, ((DropDownList)c).SelectedValue);
                    }
              }
              //CR 4932 Schwergep�ck muss gespeichert werden
              //GN 14.5.2007
              if (c is CheckBox)
              {
                CheckBox schwergp = (CheckBox)c;
                bool value = (string)((dbRAKfzdaten)MBericht.KfzDatenlist[i]).Params.SCHWERGP.Value == "S";
                schwergp.Checked = value;

              }
            }
          }
          iEditzeile--;
        }
        Btn_CellSavekfz.Focus();
        break;
      case "Delete":
        int iDelzeile = MBericht.KfzDatenlist.Count - 1;
        for (int i = MBericht.KfzDatenlist.Count - 1; i >= 0; i--)
        {
          if (arg.Substring(2) == iDelzeile.ToString())
          {
            dbRAKfzdaten rakfz = (dbRAKfzdaten)MBericht.KfzDatenlist[i];
            rakfz.Deleted = true;
          }
          iDelzeile--;
        }
        btnInsertkfz.Focus();
        CheckKFZDaten(); // Defect 4887: Nachdem KFZ-Daten gel�scht wurden, neuerliche �berpr�fung
        break;
      default:
        Exception ex = new Exception("Command not recognised: " + cmd);
        throw ex;
    }
    phTable.Controls.Clear();
    Session["Edit-ID"] = arg;
    if (MBericht.KfzDatenlist.Count != 0)
      phTable.Controls.Add(KfzDatenTable());
  }

  private void ExecDBCmd()
  {
    MBericht = (dbMontBer)Session["MBericht"];
    for (int i = 0; i <= MBericht.KfzDatenlist.Count - 1; i++)
    {
      if ((MBericht.KfzDatenlist[i] as dbRAKfzdaten).Deleted)
        (MBericht.KfzDatenlist[i] as dbRAKfzdaten).Delete();
      else
        if ((MBericht.KfzDatenlist[i] as dbRAKfzdaten).AllowUpdate)
          (MBericht.KfzDatenlist[i] as dbRAKfzdaten).Update();
        else
          (MBericht.KfzDatenlist[i] as dbRAKfzdaten).Insert();
    }
  }

  protected void Btn_CellSavekfz_Click(object sender, EventArgs e)
  {
    MBericht = (dbMontBer)Session["MBericht"];
    string arg = (string)Session["Edit-ID"];

    //Defect #4417
    //Defect #4619
    //GN 23.02.2007 Obifahrten nur innerhalb Arbeitszeit (Bearbeiten)
    //Start
    String dateString = TapWebTextBox1.TextBoxText;
    String time = AbfahrtZeit.TextBoxText;

    DateTime date = ParamVal.Date0; // Defect # 4701
    bool blnContinueEdit = true; // Defect # 4701

    try
    {
      date = Convert.ToDateTime(dateString + " " + time);
    }
    catch (Exception ex)
    {
      String strErrMessage = ex.Message;
      // Fehlermeldung bez�glich falschem Datums-/Zeitformat ausgeben
      Label1.Visible = true;
      Label1.Text = "Bitte Datum im Format tt.mm.jjjj und Zeit im Format hh:mm eingeben !";
      blnContinueEdit = false;
      /*
      if (MBericht.KfzDatenlist != null)
      {
          if (MBericht.KfzDatenlist.Count > 0)
          {
              phTable.Controls.Clear();
              phTable.Controls.Add(KfzDatenTable());
          }
      } */
    }

    /* Beginn Defect # 4701: Zum gleichen Zeitpunkt d�rfen nicht mehrere
     * KFZ-Fahrten erfasst werden. Falls in der Liste der Fahrten zum
     * angegebenen Zeitpunkt bereits eine Fahrt eingetragen ist, wird die
     * aktuelle Eingabe mit Fehlermeldung abgelehnt.
     * */
    if (blnContinueEdit)
    {
      if (MBericht.KfzDatenlist != null)
      {
        if (MBericht.KfzDatenlist.Count > 0)
        {
          dbRAKfzdaten dbRaKfz = null;
          for (int iIndex = MBericht.KfzDatenlist.Count - 1; iIndex >= 0; iIndex--)
          {
            // Nicht mit der aktuellen Zeile vergleichen
            if (arg.Substring(2) != iIndex.ToString())
            {
              dbRaKfz = (dbRAKfzdaten)MBericht.KfzDatenlist[iIndex];
              if (((DateTime)(dbRaKfz.Params.RDATUM.Value)).Ticks
              == date.Ticks)
              {
                /* Fahrt zu diesem Zeitpunkt bereits vorhanden,
                 * Fehlermeldung wird ausgegeben und Edit wird
                 * abgebrochen
                 * */
                Label1.Visible = true;
                Label1.Text = "Zu diesem Zeitpunkt ist eine KFZ-Fahrt bereits vorhanden !";
                blnContinueEdit = false;
                /* GUI-Tabelle neu aufbauen und einblenden
                phTable.Controls.Clear();
                phTable.Controls.Add(KfzDatenTable());
                 * */
                break;
              }
            }
          }
        }
      }
    }

    Boolean found = false; // Defect 4887

    if (blnContinueEdit)
    {
      /* Fortsetzung nur, falls zu diesem Zeitpunkt keine weitere Fahrt
         erfasst wurde */
      // Ende Defect # 4701
      int day = date.Day;
      dbArbTag tag = (dbArbTag)MBericht.Tage[day - 1];

      //Boolean found = false; Defect 4887
      foreach (dbArbZeit z in tag.Zeiten)
      {
        if ((tag.Relevanz && z.Kommen != ParamVal.Date0 && z.Gehen != ParamVal.Date0 && z.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz && z.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz && !z.Deleted))
        {
          if (date.Ticks >= z.Kommen.Ticks && date.Ticks <= z.Gehen.Ticks)
          {
            found = true;
            break;
          }
        }
      }
      //Ende


      if (UserInputValid())
      {

        if (found)
        {
          isEdit = false;

          btnInsertkfz.Visible = true;
          Btn_CellSavekfz.Visible = false;
          Btn_CellCancelkfz.Visible = false;
          int iZeile = MBericht.KfzDatenlist.Count - 1;
          for (int i = MBericht.KfzDatenlist.Count - 1; i >= 0; i--)
          {
            if (arg.Substring(2) == iZeile.ToString() || arg.Substring(2) == null)
            {
              dbRAKfzdaten Kfzzl = (dbRAKfzdaten)MBericht.KfzDatenlist[i];
              foreach (Control c in panMain.Controls)
              {
                if ((c as TapWebTextBox) != null)
                  foreach (SqlParameter mr in Kfzzl.Params.List)
                    if (((TapWebTextBox)c).DataField == mr.ParameterName)
                    {

                      //Defect 3664
                      //CG 15.11.2006 Beim Eintragen eines Standortwechsels wird die Uhrzeit nicht abgespeichert
                      string parmval = ((TapWebTextBox)c).TextBoxText;
                      if (mr.ParameterName == "@RDATUM")
                      {
                        parmval += " ";
                        parmval += AbfahrtZeit.TextBoxText;
                        ;
                      }
                      //                                    ((TapWebTextBox)c).TextBoxText = parmval;

                      mr.Value = ParamVal.SetParameter(mr, parmval);
                    }

                //                                   mr.Value = ParamVal.SetParameter(mr, ((TapWebTextBox)c).TextBoxText);

                if ((c as TapWebDropDownList) != null)
                  if ((c as TapWebDropDownList).Visible)
                    foreach (SqlParameter mr in Kfzzl.Params.List)
                      if (((TapWebDropDownList)c).DDLDataField == mr.ParameterName)
                        mr.Value = ParamVal.SetParameter(mr, ((TapWebDropDownList)c).DDLSelectedValue);

                if ((c as DropDownList) != null)
                  foreach (SqlParameter mr in Kfzzl.Params.List)
                    if (((DropDownList)c).DataTextFormatString == mr.ParameterName)
                      mr.Value = ParamVal.SetParameter(mr, ((DropDownList)c).SelectedValue);
              }

              //CR 4932 Schwergep�ck muss gespeichert werden
              //GN 14.5.2007
              Kfzzl.Params.SCHWERGP.Value = (SchwergepCheckbox.Checked) ? "S" : "";

            }
            iZeile--;
          }
          btnInsertkfz.Focus();
        }
        else
        {
          blnContinueEdit = false;
          Label1.Visible = true;
          Label1.Text = "Sie k�nnen Standortwechsel nur innerhalb einer Arbeitszeit eingeben";
          Btn_CellSavekfz.Focus();
        }
      }
      else
      {
        isEdit = true;
        Btn_CellSavekfz.Focus();
      }
    } // Defect # 4701

    Session["MBericht"] = MBericht;

    /* Beginn Defect # 4701: Neuanzeige der KFZ-Fahrtentabelle nur, wenn kein Fehler
     * Andernfalls: Focus auf Save-Button
     * */
    if (blnContinueEdit)
    { // Ende Defect # 4701
      phTable.Controls.Clear();
      if (MBericht.KfzDatenlist.Count != 0)
        phTable.Controls.Add(KfzDatenTable());
      // Beginn Defect # 4701: Fehlerfall - Focus auf Save-Button

      // Beginn Defect 4887
      if (found)
      {
        // �berpr�fung ob weiter Datums-Fehler vorhanden sind
        CheckKFZDaten();
      }
      // Ende Defect 4887
    }
    else
    {
      Btn_CellSavekfz.Focus();
    }
    // Ende Defect # 4701
  }

  protected void Btn_CellCancelkfz_Click(object sender, EventArgs e)
  {
    // Beginn Defect # 4701: L�schen einer evtl. Fehlermeldung
    Label1.Visible = false;
    Label1.Text = "";
    // Ende Defect # 4701

    btnInsertkfz.Visible = true;
    Btn_CellSavekfz.Visible = false;
    Btn_CellCancelkfz.Visible = false;
    btnInsertkfz.Focus();
  }
}