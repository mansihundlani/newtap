//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : Bemerkung.ascx.cs
//
// Description  : Bemerkung
//
//--------------- V1.0.0041 ---------------------------------------------------
//
// Date         : 14.May 2008
// Author       : Joldic Dzevad
// Defect#      : 6060
//                Bemerkung f�r Kunden
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;

public partial class Einsatzbericht_Bemerkung : System.Web.UI.UserControl
{
    dbMontBer MBericht;

    protected void Page_Load(object sender, EventArgs e)
    {
        MBericht = (dbMontBer)Session["MBericht"];
        if (!Page.IsPostBack)
        {
            tbEBHIST.Text = MBericht.Params.EBHIST.Value.ToString();
            tbKfmBemerkung.Text = MBericht.Params.KFMBEMERKUNG.Value.ToString();
        }
    }
    public bool Enabled
    {
        get { return panMain.Enabled; }
        set { panMain.Enabled = value; }
    }

    public void Save()
    {
        //Defect #6060 - Text verk�rzen auf 255 Zeichen falls es gr�sser ist
        if (tbEBHIST.Text.Length > 255)
            tbEBHIST.Text = tbEBHIST.Text.Remove(255);
        if (tbKfmBemerkung.Text.Length > 255)
            tbKfmBemerkung.Text = tbKfmBemerkung.Text.Remove(255);
        MBericht = (dbMontBer)Session["MBericht"];
        MBericht.Params.EBHIST.Value = tbEBHIST.Text;
        MBericht.Params.KFMBEMERKUNG.Value = tbKfmBemerkung.Text;
        Session["MBericht"] = MBericht;
    }
}
