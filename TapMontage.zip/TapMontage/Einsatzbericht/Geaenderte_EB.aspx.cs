using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Einsatzbericht_Geaenderte_EB : System.Web.UI.Page
{
    //protected void Page_Load(object sender, EventArgs e)
    //{
    //    string erfasser = "";
    //    try
    //    {
    //        erfasser = Session["loginAccount"];

    //        // nacitame EB z tabulky KEYUSER_MELDUNGEN
    //        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
    //        {
    //            try
    //            {
    //                cnx.Open();
    //                using (SqlCommand cmd = new SqlCommand(" SELECT b2.persnr, b2.vorname, b2.nachname, bp.name " +
    //                                                       " FROM   KEYUSER_MELDUNGEN m " + Config.Nolock + ", BEARBEIT b " + Config.Nolock + ", EINSBER e " + Config.Nolock + ", BEARBEIT b2 " + Config.Nolock + ", BAUPROJEKT bp " + Config.Nolock +
    //                                                       " WHERE  m.PERSKEY_ERF=b.PERSKEY " +
    //                                                       "        AND e.EBID = m.EBID " +
    //                                                       "        AND e.PERSKEY = b2.PERSKEY " +
    //                                                       "    	AND e.PROJID = bp.PROJID " +
    //                                                       "        AND b.BELOGIN = @LOGIN ", cnx))
    //                {
    //                    cmd.Parameters.Add(new SqlParameter("@LOGIN", erfasser));

    //                    using (SqlDataReader rd = cmd.ExecuteReader())
    //                    {
    //                        cmd.Parameters.Clear();

    //                        while (rd.Read())
    //                        {
    //                            // nacitat vysledok selectu
    //                            /** TODO */
    //                        }
    //                    }
    //                }
    //            }
    //            catch (Exception ex) { throw ex; }
    //            finally { cnx.Close(); }
    //        }



    //    }
    //    catch { }


        
    //}

    //private class EBeintrag
    //{
    //    string personalNummer = "";
    //    string vorname = "";
    //    string nachname = "";
    //    string projektnummer = "";
    //    string ebid = "";
    //}
}
