//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : EB_Select.ascx.cs
//
// Description  : Projektauswahl f�r den EB
//
//=============== V1.2.0007 ===============================================
//
// Date         : 10.September 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530045
//                Dynamische Aufbau der Buttons Freigeben/R�cksetzen/Drucken
//=============== V1.0.0048 ===============================================
//
// Date         : 11.Mai 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-49
//                Behandlung f�r nicht kontierbare SAP objekte
//
//=============== V1.0.0046 ===============================================
//
// Date         : 11.Dezember 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-37
//                Ausdruck von EB welche 3 Monaten alt sind fehlerhaft
//
//=============== V1.0.0044 ===============================================
//
// Date         : 30.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : 6178/TAPM-19
//                R�cksetzen EB durch Erfasser
//
//=============== V1.0.0043 ===============================================
//
// Date         : 11.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : 6075
//                Alle offene EB mit einem Knopfdruck freigeben
//
//=============== V1.0.0042 ===============================================
//
// Date         : 18.Juni 2008
// Author       : Frantisek Sabol
// Defect#      : 6074
//                Alle MA Belege Ausdrucken durch ein Knopfdruck
//
//=============== V1.0.0039 ===============================================
//
// Date         : 26.April 2008
// Author       : Joldic Dzevad
// Defect#      : 5901
//                Performance Verbesserung durch verwenden von dbReadOnly 
//
//=============== V1.0.0037 ===============================================
//
// Date         : 18.J�nner 2008
// Author       : Joldic Dzevad
// Defect#      : 5750
//                Kombinationsfeld "AnzBerichtsmonat" korrigiert 
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//
//=============== V1.0.0036 ===============================================
//
// Date         : 14.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//--------------- V1.0.0034 ---------------------------------------------------
//
// Date         : 28.August 2007
// Author       : Adam Kiefer
// Defect#      : 5135
//                GK-Std und Prod-Std in Baustellen�bersicht trennen
//
//--------------- V1.0.0028 ---------------------------------------------------
//
// Date         : 13.Juni 2007
// Author       : Adam Kiefer
// Defect#      : 4069
//                Anzeige zuletzt erfasstes Projekt
//
//--------------- V1.0.0027 ---------------------------------------------------
//
// Date         : 24. April 2007
// Author       : CL
// Defect#      : 4987
//
// Die Abfrage auf Projekt-Objekt in 'FillTabListe' wird erweitert, um eine
// falsche Anzeige von Mitarbeitern in der �bersichtsliste zu vermeiden
// (Bereits zum Projekt erfasste Einsatzberichte).
//
//--------------- V1.0.0024 ---------------------------------------------------
//
// Date         : 12. April 2007
// Author       : CL
// Defect#      : 4919
//
// Die Session-Variable 'FromGenehmigung' wird in 'PageLoad' wieder auf null
// gesetzt, damit auch im Fall einer vorhergehenden Einzelansicht eines EB in
// der Genehmigung die Freigabe-Checkbox angezeigt wird.
//
//--------------- V1.0.0024 ---------------------------------------------------
//
// Date         : 12. April 2007
// Author       : CL
// Defect#      : 4751
//
// Einschr�nkung der Auswahl der Mitarbeiter auf diejenigen, welche noch keine
// genehmigten EB (= Status 40) besitzen. Damit wird verhindert, dass zu bereits
// abgeschlossenen Mitarbeitern nachtr�glich noch EB's erfasst werden.
//
//--------------- V1.0.0024 ---------------------------------------------------
//
// Date         : 02. April 2007
// Author       : CL
// Defect#      : 4756
//
// Initialisierung des 'BackFromEB'-Flags (Zur�ck-Button in EB-Anzeige).
//
//--------------- V1.0.0022 ---------------------------------------------------
//
// Date         : 13.Februar 2007
// Author       : Caleb GEBHARDT
// Defect#      : 4516
//                select statement f�r Projektauswahl  (Einsatzbericht) korr.
//
//--------------- V1.0.0022 ---------------------------------------------------
//
// Date         : 27.Februar 2007
// Author       : Caleb GEBHARDT
// Defect#      : 4594 - 'Kein Arbeitszeitmodell f�r Mitarbeiter gefunden'
//                Merkvariable f. d. selektierten EB - Monat
// 
//--------------- V1.0.0017 ---------------------------------------------------
//
// Date         : 04.J�nner 2007
// Author       : GN
// Defect#      : 4027, 4044, 4175, 4176
//                Korrekte Anzeige der Projekte in der Auswahlliste.
//
//-----------------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using System.Data.SqlClient;

public partial class Einsatzbericht_EB_Select : System.Web.UI.UserControl
{
    dbProjekt Projekt;
    dbBearbeiter Bearbeiter;
    dbBearbeiter Monteur;
    dbMontBer MBericht;
    dbBaustelle Baustelle;

    public delegate void EditButton_ClickedDelegate(object sender, CommandEventArgs args);
    public delegate void ViewButton_ClickedDelegate(object sender, CommandEventArgs args);
    public delegate void PrintButton_ClickedDelegate(object sender, CommandEventArgs args);
    public EditButton_ClickedDelegate EditButton_Clicked;
    public ViewButton_ClickedDelegate ViewButton_Clicked;
    public PrintButton_ClickedDelegate PrintButton_Clicked;
    public delegate void NewButton_ClickedDelegate();
    public NewButton_ClickedDelegate NewButton_Clicked;

    // Defect #5750 Begin 1. Teil
    // DDLMonat_SelectedIndexChanged aufrufen, wenn noch kein Berichtsmonat in der
    // Sessionvariablen gespeichert wurde
    protected void Page_PreRender(object sender, EventArgs e)
    {
        try
        {
            if (Session["EB_Select_SelectedMonat"] == null)
                DDLMonat_SelectedIndexChanged(null, null);
        }
        catch
        {
        }
    }
    // Defect #5750 Ende 1. Teil
    protected void Page_Load(object sender, EventArgs e)
    {
        /* Beginn Defect # 4756: Initialisierung des 'BackFromEB'-Flags f�r
         * Zur�ck-Funktionalit�t in EB-Anzeige.
         * */
        try
        {
            Session["BackFromEB"] = false;
        }
        catch (Exception ex)
        {
            string strErrorMessage = ex.Message;
        }
        // Ende Defect # 4756

        /* Beginn Defect # 4919: Initialisierung des 'FromGenehmigung'-Flags f�r
         * Anzeige der Freigabe-Checkbox.
         * */
        try
        {
            Session["FromGenehmigung"] = null;
        }
        catch (Exception ex)
        {
            string strErrorMessage = ex.Message;
        }
        // Ende Defect # 4919

        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        FilterProjekt.TextBoxChangedDelegee = FilterProjekt_Change;
        FilterBearbeiter.TextBoxChangedDelegee = FilterBearbeiter_Change;
        DDLProjekt.SelIndexChanged = DDLProjekt_SelectedIndexChanged;
        DDLMonat.SelIndexChanged = DDLMonat_SelectedIndexChanged;
        DDLBearbeiter.SelIndexChanged = DDLBearbeiter_SelectedIndexChanged;
        if ((!Page.IsPostBack) & (Session["EB_Select_SelectedMonat"] != null))
        {
            DDLMonat.DDLSelectedValue = Session["EB_Select_SelectedMonat"].ToString();
            DDLMonat_SelectedIndexChanged(null, null);
        }
        if ((!Page.IsPostBack) & (Session["EB_Select_SelectedProjekt"] != null))
        {
            DDLProjekt.DDLSelectedValue = Session["EB_Select_SelectedProjekt"].ToString();
            DDLProjekt_SelectedIndexChanged(null, null);
        }
        if ((!Page.IsPostBack) & (Session["EB_Select_SelectedMonteur"] != null))
        {
            DDLBearbeiter.DDLSelectedValue = Session["EB_Select_SelectedMonteur"].ToString();
            DDLBearbeiter_SelectedIndexChanged(null, null);
        }
        Projekt = null;
        //TAPM-37 DDLMonat.DDL.SelectedIndex >= 0 anstatt DDLMonat.DDL.SelectedIndex > 0, index 0 ist ebenfalls valid
        if ((DDLMonat.DDL.SelectedIndex >= 0) && (DDLProjekt.DDL.SelectedIndex > 0))
        {
            Projekt = (dbProjekt)Session["Projekt"];
            Baustelle = (dbBaustelle)Session["Baustelle"];
        }
        Monteur = null;
        if (DDLBearbeiter.DDL.SelectedIndex > 0)
        {
            Monteur = (dbBearbeiter)Session["Monteur"];
            MBericht = (dbMontBer)Session["MBericht"];
        }
        //SetObjects();
        FillTabListe();

        // Beginn #4069 - Anzeige zuletzt erfasstes Projekt
        if (Session["ErfEBAus_State"] != null)
        {
            try
            {
                string[] stateParams = Session["ErfEBAus_State"].ToString().Split('|');
                /* Berichtsmonat einstellen  */
                DDLMonat.DDL.SelectedIndex = Convert.ToInt32(stateParams[0]);
                DDLMonat_SelectedIndexChanged(null, null);

                /* Projekt einstellen */
                DDLProjekt.DDL.SelectedValue = stateParams[1];
                DDLProjekt_SelectedIndexChanged(null, null);

                try
                {
                    string meldungEBGespeichert = String.Format("Der Einsatzbericht f�r {0} wurde gespeichert!", stateParams[2]);
                    if (stateParams[2] != "null")
                    {
                        lbEBGespeichert.Text = meldungEBGespeichert;
                        lbEBGespeichert.Visible = true;
                    }
                }
                catch
                {
                    lbEBGespeichert.Visible = false;
                }
            }
            catch
            {
                /* Berichtsmonat einstellen  */
                DDLMonat.DDL.SelectedIndex = 0;
                DDLMonat_SelectedIndexChanged(null, null);

                /* Projekt einstellen */
                DDLProjekt.DDL.SelectedIndex = 0;
                DDLProjekt_SelectedIndexChanged(null, null);
            }

            /* Session Variable l�schen */
            Session.Remove("ErfEBAus_State");
        }
        else
        {
            lbEBGespeichert.Text = "";
            lbEBGespeichert.Visible = false;
        }
        // Ende #4069
    }

    public string FilterProjekt_Change(object sender, EventArgs e)
    {
        DDLProjekt.Filter = (sender as TextBox).Text;
        DDLMonat_SelectedIndexChanged(null, null);
        Page.SetFocus(DDLProjekt.DDL);
        return (sender as TextBox).Text;
    }
    public string FilterBearbeiter_Change(object sender, EventArgs e)
    {
        DDLBearbeiter.Filter = (sender as TextBox).Text;
        DDLProjekt_SelectedIndexChanged(null, null);
        Page.SetFocus(DDLBearbeiter.DDL);
        return (sender as TextBox).Text;
    }
    public void DDLProjekt_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["EB_Select_SelectedProjekt"] = DDLProjekt.DDL.SelectedValue;
        Projekt = null;
        if (DDLProjekt.DDL.SelectedIndex > 0)
        {
            DateTime dtBermon = Convert.ToDateTime(DDLMonat.DDL.SelectedValue); // Defect # 4751
            DDLBearbeiter.Enabled = true;
            /* Beginn Defect # 4751: Nur Mitarbeiter, welche noch nicht genehmigt wurden
             * (kein EB mit Status 40), k�nnen gew�hlt werden.
             * */
            // Defect 5725, Config.Rowlock eingef�hrt
            // Defect 5771, Config.Nolock eingef�hrt
            string strBearbeiterSelect =
                   "select Nachname+', '+Vorname+' (P:'+PERSNR+' K:'+" +
                   " bearbtech.kst +')' as CTEXT, " +
                   "CAST(BEARBEIT.PERSKEY as VARCHAR(10))as CVALUE " +
                   "from BEARBEIT " + Config.Nolock + ", bearbtech " + Config.Nolock + " where BEARBEIT.Status = 20 and " +
                   "BEARBEIT.Mandant = '" + Bearbeiter.Mandant.MANDANT + "' " +
                   "and BEARBEIT.stdstdid in " +
                   "(select stdid from baustelle_std " + Config.Nolock + " where bauid in " +
                   "(select bauid from bauprojekt " + Config.Nolock + " where projid = " +
                   DDLProjekt.DDL.SelectedValue + ")) " +
                   "and bearbtech.perskey = bearbeit.perskey " +
                   "and (select ISNULL(max(ebstat),0) from einsber " + Config.Nolock +
                   " where einsber.perskey = bearbeit.perskey " +
                   "and datepart(year,einsber.bermon) = " + dtBermon.Year + " " +
                   "and datepart(month, einsber.bermon) = " + dtBermon.Month + ") < " +
                   (Int16)dbMontBer.EBStat.genehmigt +
                   "order by bearbeit.Nachname, bearbeit.Vorname, bearbeit.Persnr";
            DDLBearbeiter.DDL = Bearbeiter.Commons.DDL(DDLBearbeiter.DDL,
                                                       "",
                                                       Bearbeiter.Commons.vpSelect(strBearbeiterSelect));
            /* Old select statement
            DDLBearbeiter.DDL = Bearbeiter.Commons.DDL(DDLBearbeiter.DDL, "", Bearbeiter.Commons.vpSelect(
                "select Nachname+', '+Vorname+' (P:'+PERSNR+' K:'+ bearbtech.kst +')' "
                + "as CTEXT, CAST(BEARBEIT.PERSKEY as VARCHAR(10))as CVALUE " + 
                "from BEARBEIT, bearbtech where BEARBEIT.Status = 20 " +
                "and BEARBEIT.Mandant = '" + Bearbeiter.Mandant.MANDANT + 
                "' and BEARBEIT.stdstdid in " +
                "(select stdid from baustelle_std where bauid in " +
                "(select bauid from bauprojekt where projid = " 
                + DDLProjekt.DDL.SelectedValue + ")) " +
                "and bearbtech.perskey = bearbeit.perskey " +
                "order by bearbeit.Nachname, bearbeit.Vorname, bearbeit.Persnr"));
             * */
            // Ende Defect # 4751
            DDLBearbeiter.DDL.Items.Insert(0, new ListItem());
            DDLBearbeiter.Filter = FilterBearbeiter.TB.Text;
            //Page.SetFocus(FilterBearbeiter.TB);
        }
        else
        {
            DDLBearbeiter.Enabled = false;
            DDLBearbeiter.DDL.Items.Clear();
        }
        Monteur = null;
        Session["Monteur"] = Monteur;
        SetObjects();
        FillTabListe();
    }
    public void DDLBearbeiter_SelectedIndexChanged(object sender, EventArgs e)
    {
        Monteur = null;
        MBericht = null;
        Session["EB_Select_SelectedMonteur"] = DDLBearbeiter.DDL.SelectedValue;
        SetObjects();
        FillTabListe();
    }

    public void DDLMonat_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["EB_Select_SelectedMonat"] = DDLMonat.DDL.SelectedValue;
        if (DDLMonat.DDL.SelectedIndex >= 0) // Defect #5750 2. Teil
        {
            DDLProjekt.Enabled = true;
            DDLProjekt.DDL.Items.Clear();
            //DDLProjekt.DDL = Bearbeiter.Commons.DDL(DDLProjekt.DDL, "", Bearbeiter.Commons.vpSelect("Select NAME+' ('+KTOBJ+')', CAST(PROJID as VARCHAR(10)) from BAUPROJEKT where MLPerskey = " + Bearbeiter.Params.PERSKEY.Value.ToString() + " and mandant = '" + Bearbeiter.Mandant.MANDANT + "' and BAUID in (Select bauid from BAUSTELLE where DATVON <= '"+datvon+"' and DATBIS >= '"+datvon+"') and VALID >= '"+datvon+"' order by name, ktobj"));

            // Defect # 4516
            // string datvon = DateTime.Now.AddMonths(-3 + DDLMonat.DDL.SelectedIndex).ToString("yyyy-MM") + "-01"; //Einschr�nkung der Erfassung erst im EB!!
            //string datvon = DateTime.Now.AddMonths(-4 + DDLMonat.DDL.SelectedIndex).ToString("yyyy-MM") + "-01";
            // Defect #5750 3. Teil
            string datvon = DateTime.Now.AddMonths(-3 + DDLMonat.DDL.SelectedIndex).ToString("yyyy-MM") + "-01";
            //DDLProjekt.DDL = Bearbeiter.Commons.DDL(DDLProjekt.DDL, "", Bearbeiter.Commons.vpSelect("Select NAME+' ('+KTOBJ+')', CAST(PROJID as VARCHAR(10)) from BAUPROJEKT p where MLPerskey = " + Bearbeiter.Params.PERSKEY.Value.ToString() + " and mandant = '" + Bearbeiter.Mandant.MANDANT + "' and p.BAUID in (Select bauid from BAUSTELLE where DATVON <= p.VALID and DATBIS >= p.VALID) order by name, p.ktobj"));
            // Defect # 4027, 4044, 4175, 4176: Auswahl der Projekte entsprechend Bearbeiter, Mandant und Datum
            // Defect 5725, Config.Rowlock eingef�hrt
            // Defect 5771, Config.Nolock eingef�hrt
            string sqltxt = "Select NAME+' ('+KTOBJ+')', CAST(PROJID as VARCHAR(10)) from BAUPROJEKT p " + Config.Nolock + " where MLPerskey = " + Bearbeiter.Params.PERSKEY.Value.ToString() +
                            " and mandant = '" + Bearbeiter.Mandant.MANDANT + "'" +
                            " and p.BAUID in (Select bauid from BAUSTELLE " + Config.Nolock + " where DATVON <= p.VALID and p.VALID <= DATBIS and DATVON <= '" + datvon + "' and  '" + datvon + "' <= DATBIS) and " +
                            " p.VALID >= '" + datvon + "'" +
                            " order by name, p.ktobj";
            // Ende Defect # 4027, 4044, 4175, 4176

            DDLProjekt.DDL = Bearbeiter.Commons.DDL(DDLProjekt.DDL, "", Bearbeiter.Commons.vpSelect(sqltxt));
            // Ende Defect # 4516
            // Defect# 4594
            DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
            Bearbeiter.EBSelectedMonat = d.Year * 100 + d.Month;
            // Ende Defect# 4594
            DDLProjekt.DDL.Items.Insert(0, new ListItem());
            DDLProjekt.Filter = FilterProjekt.TB.Text;
            Page.SetFocus(FilterProjekt.TB);
        }
        else
        {
            DDLProjekt.Enabled = false;
            DDLProjekt.DDL.Items.Clear();
            // Defect #5750 Begin 4. Teil
            DDLBearbeiter.Enabled = false;
            DDLBearbeiter.DDL.Items.Clear();
            // Defect #5750 Ende 4. Teil
        }
        Baustelle = null;
        Session["Baustelle"] = Baustelle;
        Projekt = null;
        Session["Projekt"] = Projekt;
        Monteur = null;
        Session["Monteur"] = Monteur;
        Session["Bearbeiter"] = Bearbeiter;
        SetObjects();
        FillTabListe();
    }

    public void SetObjects()
    {
        // Defect# 4594
        if (DDLMonat.DDL.SelectedIndex >= 0) //TAPM-37 DDLMonat.DDL.SelectedIndex >= 0 anstatt DDLMonat.DDL.SelectedIndex > 0, index 0 ist ebenfalls valid
        {
            DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
            Bearbeiter.EBSelectedMonat = d.Year * 100 + d.Month;
        }
        // Ende Defect# 4594
        BtnEdit.Enabled = false;
        if ((Monteur == null) || ((int)Monteur.Params.PERSKEY.Value == -12638))
        {
            Monteur = new dbBearbeiter(-12638);
            if (DDLBearbeiter.DDL.SelectedIndex > 0)
            {
                Monteur = new dbBearbeiter(DDLBearbeiter.DDL.SelectedValue);
                Monteur.Params.PERSKEY.Value = Convert.ToInt32(DDLBearbeiter.DDL.SelectedValue);
                Monteur.Select(false);
                //Defect# 4594
                Monteur.EBSelectedMonat = Bearbeiter.EBSelectedMonat;
                // Ende Defect# 4594                 

                Session["Monteur"] = Monteur;
                Session["EB_Select_SelectedMonteur"] = DDLBearbeiter.DDL.SelectedValue;
            }
        }
        if ((Projekt == null) || ((int)Projekt.Params.PROJID.Value == 0))
        {
            Baustelle = new dbBaustelle(Monteur);
            Projekt = new dbProjekt(Baustelle);
            if (DDLProjekt.DDL.SelectedIndex > 0)
            {
                Projekt.Params.PROJID.Value = Convert.ToInt32(DDLProjekt.DDL.SelectedValue);
                Projekt.Select();
                if (Projekt.KontierbarInSAP())
                {
                    DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
                    Projekt.BerichtsMonat = d.Year * 100 + d.Month;
                    Baustelle.Params.BAUID.Value = Projekt.Params.BAUID.Value;
                    Baustelle.Select();
                    Session["Baustelle"] = Baustelle;
                    Projekt.Baustelle = Baustelle;
                    Session["Projekt"] = Projekt;
                    Projekt_Detail1.ProjektID = (int)Projekt.Params.PROJID.Value;
                    LabelErrorKont.Visible = false;
                }
                else
                {
                    //TAPM-49 auch wenn nicht kontierbar ... liste der EB soll ausgelesen werden
                    DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
                    Projekt.BerichtsMonat = d.Year * 100 + d.Month;
                    LabelErrorKont.Visible = true;
                    BtnEdit.Enabled = false;
                }
            }
        }
        if (MBericht == null)
        {
            //TAPM-37 DDLMonat.DDL.SelectedIndex >= 0 anstatt DDLMonat.DDL.SelectedIndex > 0, index 0 ist ebenfalls valid
            if (((int)Projekt.Params.PROJID.Value > 0) & ((int)Monteur.Params.PERSKEY.Value > 0) & (DDLMonat.DDL.SelectedIndex >= 0))
            {
                DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
                Projekt.BerichtsMonat = d.Year * 100 + d.Month;
                //Defect# 4594
                Bearbeiter.EBSelectedMonat = Projekt.BerichtsMonat;
                // Ende Defect# 4594
                MBericht = new dbMontBer(Projekt, Monteur);
                MBericht.BerichtsMonat = d.Year * 100 + d.Month;
                MBericht.Projekt.Baustelle.Bearbeiter = Monteur;
                MBericht.Select();
                BtnEdit.Enabled = (((Int16)MBericht.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.erfasst) | ((Int16)MBericht.Params.EBSTAT.Value == 0));
                if (!Projekt.KontierbarInSAP())
                {
                    LabelErrorKont.Visible = true;
                    BtnEdit.Enabled = false;
                }
            }
            else
                if (DDLBearbeiter.DDL.SelectedValue.Length > 0)
                {
                    Monteur.Params.PERSKEY.Value = Convert.ToInt32(DDLBearbeiter.DDL.SelectedValue);
                    Monteur.Select(false);
                    Session["Monteur"] = Monteur;
                    Session["EB_Select_SelectedMonteur"] = DDLBearbeiter.DDL.SelectedValue;
                    DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
                    Projekt.BerichtsMonat = d.Year * 100 + d.Month;

                    MBericht = new dbMontBer(Projekt, Monteur);
                    MBericht.BerichtsMonat = d.Year * 100 + d.Month;
                    MBericht.Projekt.Baustelle.Bearbeiter = Monteur;
                    MBericht.Select();
                    //Defect# 4594
                    Bearbeiter.EBSelectedMonat = MBericht.BerichtsMonat;
                    // Ende Defect# 4594
                    BtnEdit.Enabled = (((Int16)MBericht.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.erfasst) | ((Int16)MBericht.Params.EBSTAT.Value == 0));
                    if (!Projekt.KontierbarInSAP())
                    {
                        LabelErrorKont.Visible = true;
                        BtnEdit.Enabled = false;
                    }
                }
        }
        else
            //TAPM-37 DDLMonat.DDL.SelectedIndex >= 0 anstatt DDLMonat.DDL.SelectedIndex > 0, index 0 ist ebenfalls valid
            if (((int)Projekt.Params.PROJID.Value > 0) & ((int)Monteur.Params.PERSKEY.Value > 0) & (DDLMonat.DDL.SelectedIndex >= 0))
            {
                BtnEdit.Enabled = (((Int16)MBericht.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.erfasst) | ((Int16)MBericht.Params.EBSTAT.Value == 0));
            }
        Session["Monteur"] = Monteur;
        Session["Projekt"] = Projekt;
        Session["Baustelle"] = Baustelle;
        Session["MBericht"] = MBericht;
    }

    private void FillTabListe()
    {
        xxID = 0;
        tabListe.Rows.Clear();
        {
            string css = "TabHeader";
            TableHeaderRow r = new TableHeaderRow();
            TableHeaderCell c = new TableHeaderCell();
            c.CssClass = css;
            Label l = new Label();
            l.Text = "Nachname";
            c.Controls.Add(l);
            TableHeaderCell c2 = new TableHeaderCell();
            c2.CssClass = css;
            Label l2 = new Label();
            l2.Text = "Vorname";
            TableHeaderCell c3 = new TableHeaderCell();
            c3.CssClass = css;
            Label l3 = new Label();
            l3.Text = "Pers-Nr.";

            // Beginn #5135 - GK-Std und Prod-Std in Baustellen�bersicht trennen
            TableHeaderCell c3_1 = new TableHeaderCell();
            c3_1.CssClass = css;
            Label l3_1 = new Label();
            l3_1.Text = "Sum.<br />Prod. Std.";

            TableHeaderCell c3_2 = new TableHeaderCell();
            c3_2.CssClass = css;
            Label l3_2 = new Label();
            l3_2.Text = "Sum. GK<br />& Abs. Std.";
            // Ende #5135

            TableHeaderCell c4 = new TableHeaderCell();
            c4.CssClass = css;
            Label l4 = new Label();
            l4.Text = "Summe<br />Stunden";
            c2.Controls.Add(l2);
            c3.Controls.Add(l3);
            // Beginn #5135 - GK-Std und Prod-Std in Baustellen�bersicht trennen
            c3_1.Controls.Add(l3_1);
            c3_2.Controls.Add(l3_2);
            // Ende #5135
            c4.Controls.Add(l4);
            r.Cells.Add(c);
            r.Cells.Add(c2);
            r.Cells.Add(c3);
            // Beginn #5135 - GK-Std und Prod-Std in Baustellen�bersicht trennen
            r.Cells.Add(c3_1);
            r.Cells.Add(c3_2);
            // Ende #5135
            r.Cells.Add(c4);
            TableHeaderCell cb = new TableHeaderCell();
            cb.CssClass = css;
            Label l5 = new Label();  // Defect# 6074
            l5.Text = "Bearbeiten / <br />Ansehen / <br />L�schen";
            cb.Controls.Add(l5);
            r.Cells.Add(cb);

            //Defect #6075 - Tabellenheader �Freigeben�
            TableHeaderCell cb2 = new TableHeaderCell();
            cb2.CssClass = css;
            Label l7 = new Label();
            l7.Text = "Freigeben";
            cb2.Controls.Add(l7);
            r.Cells.Add(cb2);

            //Defect #6178 - Tabellenheader �R�cksetzen�
            TableHeaderCell cb3 = new TableHeaderCell();
            cb3.CssClass = css;
            //Label l8 = new Label();
            //l7.Text = "Freigeben";
            cb3.Text = "R�cksetzen";
            //cb2.Controls.Add(l7);
            r.Cells.Add(cb3);

            // Defect# 6074 - Tabellenheader �Drucken�
            TableHeaderCell cb1 = new TableHeaderCell();
            cb1.CssClass = css;
            Label l6 = new Label();
            l6.Text = "Drucken";
            cb1.Controls.Add(l6);
            r.Cells.Add(cb1);

            tabListe.Rows.Add(r);
        }

        /* Beginn Defect # 4987: Liste bereits erfasster Einsatzberichte darf
         * nur dann bef�llt werden, wenn Projekt vorhanden ist UND ProjektId > 0
         * */
        if (Projekt != null && (int)(Projekt.Params.PROJID.Value) > 0) // Ende Defect # 4987
            foreach (dbMontBer m in Projekt.MBerichte)
            {
                string css = "TabNewDay";
                TableRow r = new TableRow();
                TableCell c = new TableCell();
                c.CssClass = css;
                Label l = new Label();
                l.Text = m.Bearbeiter.Params.NACHNAME.Value.ToString();
                c.Controls.Add(l);
                TableCell c2 = new TableCell();
                c2.CssClass = css;
                Label l2 = new Label();
                l2.Text = m.Bearbeiter.Params.VORNAME.Value.ToString();
                TableCell c3 = new TableCell();
                c3.CssClass = css;
                c3.HorizontalAlign = HorizontalAlign.Center;
                //Label l3 = new Label();
                c3.Text = m.Bearbeiter.Params.PERSNR.Value.ToString();

                //Defect #5901 - dbReadOnlywird verwendet anstatt von neu Stundenberechnung
                dbReadOnly dbEntry = new dbReadOnly(m.MinDatum, (int)m.Params.PERSKEY.Value, (int)m.Params.EBID.Value);
                ArrayList al = dbEntry.SelectArbzeiten();

                // Beginn #5135 - GK-Std und Prod-Std in Baustellen�bersicht trennen
                TableCell c3_1 = new TableCell();
                c3_1.CssClass = css;
                c3_1.HorizontalAlign = HorizontalAlign.Right;
                c3_1.Text = dbEntry.summeProdStd.ToString("N");
                //Label l3_1 = new Label();
                //l3_1.Text = dbEntry.summeProdStd.ToString("N");
                //l3_1.Text = m.SummeProduktiveStunden.ToString("N");

                TableCell c3_2 = new TableCell();
                c3_2.CssClass = css;
                c3_2.HorizontalAlign = HorizontalAlign.Right;
                // Label l3_2 = new Label();
                // double SummeGKStunden = m.SummeStunden - m.SummeProduktiveStunden;
                // if (SummeGKStunden > 0.0)
                if (dbEntry.summeGK > 0.0)
                    c3_2.Text = dbEntry.summeGK.ToString("N");
                else
                    c3_2.Text = "&nbsp;";
                // Ende #5135
                TableCell c4 = new TableCell();
                c4.CssClass = css;
                c4.HorizontalAlign = HorizontalAlign.Right;
                //Label l4 = new Label();
                // l4.Text = m.SummeStunden.ToString("N");
                c4.Text = (dbEntry.summeProdStd + dbEntry.summeGK).ToString("N");
                c2.Controls.Add(l2);
                //c3.Controls.Add(l3);
                // Beginn #5135 - GK-Std und Prod-Std in Baustellen�bersicht trennen
                //c3_1.Controls.Add(l3_1);
                //c3_2.Controls.Add(l3_2);
                // Ende #5135
                //c4.Controls.Add(l4);

                r.Cells.Add(c);
                r.Cells.Add(c2);
                r.Cells.Add(c3);
                // Beginn #5135 - GK-Std und Prod-Std in Baustellen�bersicht trennen
                r.Cells.Add(c3_1);
                r.Cells.Add(c3_2);
                // Ende #5135
                r.Cells.Add(c4);

                TableCell cb = new TableCell();
                cb.CssClass = css;
                cb.HorizontalAlign = HorizontalAlign.Center;
                //TAPM-49 Beginn - wenn ein EB erfasst oder freigegeben ist und SAP Konto nicht bebuchbar, dann deletebutton erzeugen
                if ((Int16)m.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.erfasst)
                    if (Projekt.KontierbarInSAP())
                        cb.Controls.Add(NewTaskButton("Bearbeiten", "Edit", m.Params.EBID.Value.ToString() + "-" + m.Bearbeiter.Params.PERSKEY.Value.ToString(), "Klicken Sie hier um diesen Bericht zu bearbeiten.", TaskButton_Click));
                    else
                        cb.Controls.Add(NewTaskButton("L�schen", "Delete", m.Params.EBID.Value.ToString() + "-" + m.Bearbeiter.Params.PERSKEY.Value.ToString(), "Klicken Sie hier um diesen Bericht zu l�schen.", TaskButton_Click));
                else
                    if ((Int16)m.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.freigegeben)
                        if (Projekt.KontierbarInSAP())
                            cb.Controls.Add(NewTaskButton("Ansehen", "View", m.Params.EBID.Value.ToString() + "-" + m.Bearbeiter.Params.PERSKEY.Value.ToString(), "Klicken Sie hier um diesen Bericht anzuzeigen.", TaskButton_Click));
                        else
                            cb.Controls.Add(NewTaskButton("L�schen", "Delete", m.Params.EBID.Value.ToString() + "-" + m.Bearbeiter.Params.PERSKEY.Value.ToString(), "Klicken Sie hier um diesen Bericht zu l�schen.", TaskButton_Click));
                    else
                        //genehmigt
                        if (Projekt.KontierbarInSAP())
                            cb.Controls.Add(NewTaskButton("Ansehen", "View", m.Params.EBID.Value.ToString() + "-" + m.Bearbeiter.Params.PERSKEY.Value.ToString(), "Klicken Sie hier um diesen Bericht anzuzeigen.", TaskButton_Click));
                        else
                            cb.Text = "&nbsp;";//nichts anzeigen
                //TAPM-49 Ende
                /*
                if ((Int16)m.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.freigegeben)
                    cb.Controls.Add(NewTaskButton("Ansehen (freigegeben)", "View", m.Params.EBID.Value.ToString() + "-" + m.Bearbeiter.Params.PERSKEY.Value.ToString(), "Klicken Sie hier um diesen Bericht anzuzeigen.", TaskButton_Click));
                if ((Int16)m.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.genehmigt)
                    cb.Controls.Add(NewTaskButton("Ansehen (genehmigt)", "View", m.Params.EBID.Value.ToString() + "-" + m.Bearbeiter.Params.PERSKEY.Value.ToString(), "Klicken Sie hier um diesen Bericht anzuzeigen.", TaskButton_Click));
                 */
                //if ((Int16)m.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.kontrolliert)
                //    cb.Text = "kontrolliert";
                r.Cells.Add(cb);

                // Defect# 6075 - Checkbox "Freigeben" erzeugen ja/nein ?
                TableCell chb2 = new TableCell();
                chb2.CssClass = css;
                chb2.HorizontalAlign = HorizontalAlign.Center;
                switch ((Int16)m.Params.EBSTAT.Value)
                {
                    case (Int16)dbMontBer.EBStat.erfasst:
                        if (Projekt.KontierbarInSAP())
                            chb2.Controls.Add(FreigabeCheckBox("freigabecheckbox-" + m.Bearbeiter.Params.PERSKEY.Value.ToString()));
                        else
                            chb2.Text = "nicht kontierbar";
                        break;
                    case (Int16)dbMontBer.EBStat.freigegeben:
                        chb2.Text = "freigegeben";
                        break;
                    case (Int16)dbMontBer.EBStat.genehmigt:
                        chb2.Text = "genehmigt";
                        break;
                }
                r.Cells.Add(chb2);

                //Defect #6178 - Checkbox f�rs r�cksetzen
                TableCell cbr = new TableCell();
                cbr.CssClass = css;
                cbr.HorizontalAlign = HorizontalAlign.Center;
                //TAPM-49 checkbox f�rs R�cksetzen erzeigen nur wenn konto bebuchbar ist
                if ((Int16)m.Params.EBSTAT.Value == (Int16)dbMontBer.EBStat.freigegeben && Projekt.KontierbarInSAP())
                    cbr.Controls.Add(RuecksetzenCheckBox("ruecksetzen-" + m.Params.EBID.Value.ToString()));
                else
                    cbr.Text = "&nbsp;";
                r.Cells.Add(cbr);

                // Defect# 6074
                TableCell chb1 = new TableCell();
                chb1.CssClass = css;
                chb1.HorizontalAlign = HorizontalAlign.Center;
                chb1.Controls.Add(NewCheckBox(m.Params.EBID.Value.ToString() + "-" + m.Bearbeiter.Params.PERSKEY.Value.ToString()));
                r.Cells.Add(chb1);

                tabListe.Rows.Add(r);
            }
        // BAF 530045 - Beginn
        if (tabListe.Rows.Count > 1)
        {
            string css = "TabNewDay";
            TableRow r = new TableRow();
            //Ersten 7 bleiben Leer
            for (int i = 0; i < 7; i++)
            {
                TableCell c = new TableCell();
                c.CssClass = css;
                c.Text = "&nbsp;";
                r.Cells.Add(c);
            }
            //Freigabe Button
            TableCell cFreigabe = new TableCell();
            cFreigabe.CssClass = css;
            btnMassenFreigabe.Width = new Unit("100%");
            cFreigabe.Controls.Add(btnMassenFreigabe);
            r.Cells.Add(cFreigabe);
            //R�cksetzen
            TableCell cRuecksetzen = new TableCell();
            cRuecksetzen.CssClass = css;
            btnRuecksetzen.Width = new Unit("100%");
            cRuecksetzen.Controls.Add(btnRuecksetzen);
            r.Cells.Add(cRuecksetzen); //r�cksetzen
            //Drucken
            TableCell cDrucken = new TableCell();
            cDrucken.CssClass = css;
            btnPrintSelected.Width = new Unit("100%");
            cDrucken.Controls.Add(btnPrintSelected);
            r.Cells.Add(cDrucken); //persrn
            tabListe.Rows.Add(r);
        }//BAF 530045 Ende
    }

    // begin Defect# 6074
    private CheckBox NewCheckBox(String Argument)
    {
        CheckBox chb = new CheckBox();
        chb.ID = Argument;
        chb.Checked = false;
        chb.CheckedChanged += new EventHandler(chb_CheckedChanged);
        return chb;
    }

    void chb_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chb = (CheckBox)sender;

        foreach (dbMontBer m in Projekt.MBerichte)
        {
            if (m.Params.PERSKEY.Value.ToString() == chb.ID.Substring(chb.ID.IndexOf("-") + 1))
                m.drucken = chb.Checked;
        }
    }
    // ende Defect# 6074
    //Defect# 6075 create new checkbox
    private CheckBox FreigabeCheckBox(String Argument)
    {
        CheckBox chb = new CheckBox();
        chb.ID = Argument;
        chb.Checked = false;
        chb.CheckedChanged += new EventHandler(freigabe_CheckedChanged);
        return chb;
    }
    //Defect# 6075 event ausl�sen wenn checkbox angesprochen wird
    void freigabe_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chb = (CheckBox)sender;

        foreach (dbMontBer m in Projekt.MBerichte)
        {
            if (m.Params.PERSKEY.Value.ToString() == chb.ID.Substring(chb.ID.IndexOf("-") + 1))
                m.freigeben = chb.Checked;
        }
    }
    //Ende #6075

    //Defect# 6178 create new checkbox
    private CheckBox RuecksetzenCheckBox(String Argument)
    {
        CheckBox chb = new CheckBox();
        chb.ID = Argument;
        chb.Checked = false;
        chb.CheckedChanged += new EventHandler(ruecksetzen_CheckedChanged);
        return chb;
    }
    //Defect# 6178 event ausl�sen wenn checkbox angesprochen wird
    void ruecksetzen_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox chb = (CheckBox)sender;

        foreach (dbMontBer m in Projekt.MBerichte)
        {
            if (m.Params.EBID.Value.ToString() == chb.ID.Substring(chb.ID.IndexOf("-") + 1))
                m.ruecksetzen = chb.Checked;
        }
    }
    //Ende #6178

    private LinkButton NewTaskButton(string Text, string Command, string Argument, string ToolTip, CommandEventHandler TaskButtonClick_EventHandler)
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;
        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        //cList.Add(btn);
        return btn;
    }

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }

    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        Monteur = new dbBearbeiter(Convert.ToInt32(arg.Substring(arg.IndexOf("-") + 1)));
        Session["Monteur"] = Monteur;
        MBericht = new dbMontBer(Projekt, Monteur);
        DateTime d = Convert.ToDateTime(DDLMonat.DDL.SelectedValue);
        MBericht.BerichtsMonat = d.Year * 100 + d.Month;
        MBericht.Params.EBID.Value = Convert.ToInt32(arg.Substring(0, arg.IndexOf("-")));
        MBericht.Select();
        Session["MBericht"] = MBericht;
        switch (cmd)
        {
            case "Edit":
                // Beginn #4069 - Anzeige zuletzt erfasstes Projekt
                try
                {
                    Session.Add("ErfEBAus_State", String.Format("{0}|{1}", DDLMonat.DDL.SelectedIndex.ToString(), DDLProjekt.DDL.SelectedValue.ToString()));
                }
                catch
                {
                    Session.Add("ErfEBAus_State", "0|0");
                }
                // Ende #4069
                if (EditButton_Clicked != null) EditButton_Clicked(sender, e);
                break;
            case "View":
                // Beginn #4069 - Anzeige zuletzt erfasstes Projekt
                try
                {
                    Session.Add("ErfEBAus_State", String.Format("{0}|{1}", DDLMonat.DDL.SelectedIndex.ToString(), DDLProjekt.DDL.SelectedValue.ToString()));
                }
                catch
                {
                    Session.Add("ErfEBAus_State", "0|0");
                }
                // Ende #4069
                if (ViewButton_Clicked != null) ViewButton_Clicked(sender, e);
                break;
            case "Print":
                if (PrintButton_Clicked != null) PrintButton_Clicked(sender, e);
                break;
            //TAPM-49 - Einsatzberichte l�schen
            case "Delete":
                //TAPM-49 Setzen QueriesTableAdatpter
                SISSITableAdapters.SISSI_Queries taQueries = new SISSITableAdapters.SISSI_Queries();

                //Setzen lokal Variable
                int ebid = -1;

                //EBID wird gesetzt
                try { ebid = Convert.ToInt32(MBericht.Params.EBID.Value); }
                catch { ebid = -1; }

                /* EBID nicht null, EBID g�ltig */
                if (ebid != -1 && ebid != 0)
                {
                    //TAPM-49 - L�schen von Auslagen
                    taQueries.Delete_AUSLAGE(ebid);
                    //TAPM-49 - L�schen von Zulagen
                    taQueries.Delete_ZULAGE(ebid);
                    //TAPM-49 - L�schen von Arbeitszeiten
                    taQueries.Delete_ARBZEIT(ebid);
                    //TAPM-49 - L�schen von Reiseauslagen
                    taQueries.Delete_RAAUSLAGE(ebid);
                    //TAPM-49 - L�schen von KFZ Daten
                    taQueries.Delete_TPM_RAKfzdaten(ebid);
                    //TAPM-49 - EB L�schen
                    taQueries.Delete_EINSBER(ebid);
                    //TAPM-49 -- habe ich was vergessen ????
                }
                //TAPM-49 - Projekt aktualisieren, damit der gel�schte EB aus der tabelle verschwinden
                Projekt.BerichtsMonat = d.Year * 100 + d.Month;
                //TAP-49 jetzt die Tabelle erneut bef�hlen
                FillTabListe();
                break;
        }
    }

    protected void BtnEdit_Click(object sender, EventArgs e)
    {
        // Beginn #4069 - Anzeige zuletzt erfasstes Projekt
        try
        {
            Session.Add("ErfEBAus_State", String.Format("{0}|{1}", DDLMonat.DDL.SelectedIndex.ToString(), DDLProjekt.DDL.SelectedValue.ToString()));
        }
        catch
        {
            Session.Add("ErfEBAus_State", "0|0");
        }
        // Ende #4069
        if (NewButton_Clicked != null) NewButton_Clicked();
    }

    // Defect# 6074
    protected void btnPrintSelected_Click(object sender, EventArgs e)
    {
        if (Projekt == null) return;
        ArrayList mBerichtListe = new ArrayList();
        foreach (dbMontBer m in Projekt.MBerichte)
        {
            if (m.drucken)
            {
                mBerichtListe.Add(m);
            }
        }

        if (Session["mBerichtListe"] != null)
        {
            Session.Remove("mBerichtListe");
        }

        if (mBerichtListe.Count > 0)
        {
            Session["mBerichtListe"] = mBerichtListe;
            if (PrintButton_Clicked != null) PrintButton_Clicked(null, null);
        }
    }
    // ende Defect# 6074
    //Defect #6075 - "Freigabe" button bet�tigt
    protected void btnMassenFreigabe_Click(object sender, EventArgs e)
    {
        if (Projekt == null) return;
        foreach (dbMontBer mber in Projekt.MBerichte)
        {
            if (mber.freigeben)
            {
                //int iRes = 0;
                System.Collections.Generic.List<string> allRaAuslagen = new System.Collections.Generic.List<string>();
                System.Collections.Generic.List<DateTime> allSTROAuslagen = new System.Collections.Generic.List<DateTime>();
                SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                cnx.Open();
                SqlTransaction tx = cnx.BeginTransaction();
                try
                {
                    // ermitteln alle bisher gespeicherten RA Auslagen von MA
                    using (SqlCommand cmd = new SqlCommand(
                        "select bau.bauid, ra.datum, ra.RAKZ, ra.ANZAHL, ra.BETRAG from bauprojekt bau " + Config.Nolock + ", raauslage ra " + Config.Nolock +
                        "where  bau.projid = (select projid from einsber where ebid = ra.ebid ) " +
                        "and ra.perskey = @PERSKEY " +
                        "and DatePart(\"yyyy\", ra.datum ) = DatePart(\"yyyy\", @BERMON) " +
                        "and DatePart(\"mm\", ra.datum) = DatePart(\"mm\", @BERMON) ", cnx, tx))
                    {
                        cmd.Parameters.Add(mber.Bearbeiter.Params.PERSKEY);
                        cmd.Parameters.Add(mber.Params.BERMON);
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Remove(mber.Bearbeiter.Params.PERSKEY);
                            cmd.Parameters.Remove(mber.Params.BERMON);
                            while (rd.Read())
                            {
                                // die ergebniss in allRaAuslagen Liste speichern
                                allRaAuslagen.Add(rd.GetValue(0).ToString() + "-" + rd.GetValue(1).ToString() +
                                    "-" + rd.GetValue(2).ToString() + "-" + rd.GetValue(3).ToString() + "-" + Convert.ToInt32(rd.GetValue(4)).ToString());
                                //zus�tzlich eine Liste von STRO Auslagen - die werden pro Tag nur einmal geschrieben
                                if (rd.GetValue(2).ToString() == "STRO")
                                    allSTROAuslagen.Add(Convert.ToDateTime(rd.GetValue(1)));
                            }
                            // Liste Sortieren wegen Binarysearch
                            allRaAuslagen.Sort();
                            allSTROAuslagen.Sort();
                        }
                    }
                    dbBarauslagen bau = new dbBarauslagen(mber.Projekt.Baustelle);
                    ArrayList list = bau.SelectAllforBaustelle();

                    //Defect 4435 Keine RAuslagen f�r Fremdpersonal
                    //GN 15.5.2007
                    string strSozStell = mber.Bearbeiter.TechParams.SOZSTELL.Value.ToString();
                    if (!(strSozStell == "6" || strSozStell == "7"))
                    {
                        foreach (dbArbTag tag in mber.Tage)
                        {
                            //if (!tag.Relevanz) continue;
                            tag.pauseBerechnen = false;
                            bool valid = false;
                            foreach (dbArbZeit z in tag.Zeiten)
                            {
                                /* Beginn Defect #4708, 4740, 4746: Nur wenn die eingetragene
                                 * Zeit dem Projekt des aktuellen Einsatzberichts zugeordnet
                                 * ist, wird das 'valid'-Flag auf true gesetzt. */
                                if ((z.Kommen != ParamVal.Date0 && // Kommen-Zeit vorhanden
                                     z.Gehen != ParamVal.Date0 && // Gehen-Zeit vorhanden
                                     z.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz && // Keine GT-Absenz
                                     !z.Deleted && // Nicht als gel�scht markiert
                                     z.AuftragNr ==
                                     mber.Projekt.Params.KTOBJ.Value.ToString())) // Zeiteintrag f�r aktuellen EB
                                {
                                    valid = true;
                                    break;
                                }
                                // Ende Defect #4708, 4740, 4746
                            }
                            if (valid)
                            {
                                foreach (dbBarauslagen ba in list)
                                {
                                    int auslageBetrag = 0;

                                    try
                                    {
                                        auslageBetrag = Convert.ToInt32(ba.Params.CENTS.Value);
                                    }
                                    catch
                                    {
                                        auslageBetrag = 0;
                                    }

                                    // no defect
                                    if (ba.Params.TYP.Value.ToString() == "STRO"
                                        && allSTROAuslagen.BinarySearch(tag.TagesDatum) >= 0) //STRO wird nur einmal pro tag generiert.
                                        continue;

                                    //Defect #5341 Beginn Teil 2
                                    //Eintrag formatieren wie im allRaAuslagen
                                    string entry = mber.Projekt.Baustelle.Params.BAUID.Value.ToString() +
                                               "-" + tag.TagesDatum.ToString() +
                                               "-" + ba.Params.TYP.Value.ToString() +
                                               "-" + ba.Params.ANZ.Value.ToString() +
                                               "-" + Convert.ToInt32(ba.Params.CENTS.Value).ToString();
                                    //falls "entry" Eintrag schon allRaAuslagen existiert, dann wir es ein zweites nicht in DB geschrieben
                                    if (allRaAuslagen.BinarySearch(entry) < 0)   // Defect #5341 Ende Teil 2
                                    {
                                        //iRes++;
                                        dbRAAuslage RAAuslage = new dbRAAuslage(mber);
                                        RAAuslage.Params.ANZAHL.Value = ba.Params.ANZ.Value;
                                        RAAuslage.Params.BETRAG.Value = ba.Params.CENTS.Value;
                                        RAAuslage.Params.DATUM.Value = tag.TagesDatum;
                                        RAAuslage.Params.EBID.Value = mber.Params.EBID.Value;
                                        RAAuslage.Params.MANDANT.Value = mber.Params.MANDANT.Value;
                                        RAAuslage.Params.PERSKEY.Value = mber.Params.PERSKEY.Value;
                                        //RAAuslage.Params.RAAUSLAGEID.Value = iRes;
                                        RAAuslage.Params.RAKZ.Value = ba.Params.TYP.Value;
                                        mber.Reiseauslagen.Add(RAAuslage);
                                        //RAAuslage.Insert(tx);
                                    }
                                }
                            }
                        }
                    }
                    mber.Params.EBSTAT.Value = (Int16)dbMontBer.EBStat.freigegeben;
                    mber.Params.AENPERSKEY.Value = mber.Projekt.Baustelle.Bearbeiter.Params.PERSKEY.Value;
                    mber.Params.DATLA.Value = DateTime.Now;
                    mber.Save();
                    mber.freigeben = false;
                    Session["Projekt"] = Projekt;
                    //using (SqlCommand cmd = new SqlCommand("UPDATE EINSBER SET EBSTAT = @EBSTAT, AENPERSKEY = @AENPERSKEY, " +
                    //    "DATLA = @DATLA WHERE EBID = @EBID" + Config.Rowlock, cnx, tx)) // Defect 5436, using eingef�hrt
                    /*using (SqlCommand cmd = new SqlCommand("sp_TM_EinsberUpdate", cnx, tx)) // Defect 5436, using eingef�hrt
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        foreach (SqlParameter s in mber.Params.List)
                            cmd.Parameters.Add(s);
                        if (cmd.ExecuteNonQuery() == 1)
                            mber.freigeben = false;
                        foreach (SqlParameter s in mber.Params.List)
                            cmd.Parameters.Remove(s);
                        tx.Commit();
                    }*/
                }
                catch (Exception ex)
                {
                    try
                    {
                        tx.Rollback();
                    }
                    catch
                    {

                    }
                    throw ex;
                }
                finally { cnx.Close(); }
            }
        }
        FillTabListe();
    }
    //Defect #6178 Button "R�cksetzen"
    protected void btnRuecksetzen_Click(object sender, EventArgs e)
    {
        if (Projekt == null) return;
        foreach (dbMontBer mber in Projekt.MBerichte)
        {
            if (mber.ruecksetzen)
            {
                dbRuecksetzen rueck = new dbRuecksetzen(Convert.ToInt32(mber.Params.EBID.Value), mber.Projekt.Baustelle.Barauslagen);
                if (rueck.ruecksetzen())
                {
                    mber.Params.EBSTAT.Value = (Int16)dbMontBer.EBStat.erfasst;
                    mber.Reiseauslagen.Clear();
                    mber.ruecksetzen = false;
                    Session["Projekt"] = Projekt;
                }
            }
        }
        FillTabListe();
    }
}
