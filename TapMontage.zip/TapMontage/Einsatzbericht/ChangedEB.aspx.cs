﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : ChangedEB.ascx.cs
//
// Description  : Liste der geänderte Einsatzberichte
//
//=============== V1.0.0046 ===============================================
//
// Date         : 11.December 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-36
//                Anzeige der geänderten EB falsch
//
//=============== V1.0.0045 ===============================================
//
// Date         : 17.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-22
//                Init Module
//
// ========================================================================
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using TapMontage.dbObjects;


public partial class Einsatzbericht_ChangedEB : System.Web.UI.Page
{
    dbBearbeiter Bearbeiter;
    int SelMAVon = 0; // Startindex in MAListe für Selektion der Mitarbeiter
    int SelMABis = 0; // Endeindex in MAListe für Selektion der Mitarbeiter

    public int xxID = 0;
    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Einsatzbericht - geänderte Einsatzberichte</span>";
        }
        catch
        {/* Nicht behandelt! */}
        try
        {
            SelMAVon = (int)Session["SelMAVon3"];
            SelMABis = (int)Session["SelMABis3"];
        }
        catch
        {
            SelMAVon = 1;
            SelMABis = 20;
            Session["SelMAVon3"] = SelMAVon;
            Session["SelMABis3"] = SelMABis;
        }
        phMAListe.Controls.Clear();
        phMAListe.Controls.Add(GetListOfChengedEB());
        Panel1.Visible = false;
    }

    private Table GetListOfChengedEB()
    {
        Table tabListe = new Table();
        xxID = 0;
        tabListe.Rows.Clear();

        //Header
        tabListe.Width = Unit.Percentage(100);
        TableRow HeaderRow = new TableRow();
        TableCell c0 = new TableCell();
        c0.CssClass = "TabHeader";
        c0.Text = "Datum";
        c0.Font.Bold = true;
        c0.HorizontalAlign = HorizontalAlign.Center;
        TableCell c1 = new TableCell();
        c1.CssClass = "TabHeader";
        c1.Text = "Name";
        c1.Font.Bold = true;
        c1.HorizontalAlign = HorizontalAlign.Center;
        TableCell c2 = new TableCell();
        c2.Text = "Vorname";
        c2.Font.Bold = true;
        c2.HorizontalAlign = HorizontalAlign.Center;
        c2.CssClass = "TabHeader";
        TableCell c3 = new TableCell();
        c3.Text = "Personalnummer";
        c3.Font.Bold = true;
        c3.HorizontalAlign = HorizontalAlign.Center;
        c3.CssClass = "TabHeader";
        TableCell c4 = new TableCell();
        c4.Text = "Projekt";
        c4.Font.Bold = true;
        c4.HorizontalAlign = HorizontalAlign.Center;
        c4.CssClass = "TabHeader";
        TableCell c5 = new TableCell();
        c5.Text = "Status";
        c5.Font.Bold = true;
        c5.HorizontalAlign = HorizontalAlign.Center;
        c5.CssClass = "TabHeader";
        TableCell c6 = new TableCell();
        c6.Text = "Meldung";
        c6.Font.Bold = true;
        c6.HorizontalAlign = HorizontalAlign.Center;
        c6.CssClass = "TabHeader";

        HeaderRow.Cells.Add(c0);
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        HeaderRow.Cells.Add(c3);
        HeaderRow.Cells.Add(c4);
        HeaderRow.Cells.Add(c5);
        HeaderRow.Cells.Add(c6);

        tabListe.Rows.Add(HeaderRow);
        ArrayList AllMA = new ArrayList(); // enthaelt alle Mitarbiter, auch die die momentan nicht angezeigt werden
        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT KEYUSER_MELDUNGEN.DATUM, EINSBER.NACHNAME, EINSBER.VORNAME, BEARBEIT_1.PERSNR, BAUPROJEKT.NAME, KEYUSER_MELDUNGEN.STATUS, KEYUSER_MELDUNGEN.EBID " + 
                                                       "FROM KEYUSER_MELDUNGEN INNER JOIN EINSBER ON KEYUSER_MELDUNGEN.EBID = EINSBER.EBID " + 
                                                       "INNER JOIN BAUPROJEKT ON EINSBER.PROJID = BAUPROJEKT.PROJID " + 
                                                       "INNER JOIN BEARBEIT ON KEYUSER_MELDUNGEN.PERSKEY_ERF = BEARBEIT.PERSKEY " + 
                                                       "INNER JOIN BEARBEIT BEARBEIT_1 ON EINSBER.PERSKEY = BEARBEIT_1.PERSKEY " + 
                                                       "WHERE (BEARBEIT.PERSKEY = @PERSKEY) " +
                                                       "ORDER BY KEYUSER_MELDUNGEN.DATUM DESC", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", Bearbeiter.Params.PERSKEY.Value));
                    //cmd.Parameters.Add(Bearbeiter.Params.PERSKEY);
                    //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005070" + "ComputeStd(): " + cmd.CommandText, null);

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        //LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Information, "005071" + "ComputeStd(): ", null);

                        //cmd.Remove(Bearbeiter.Params.PERSKEY);
                        cmd.Parameters.Clear();

                        int iCnt = 0;

                        while (rd.Read())
                        {
                            iCnt++;
                            /*string leistart = "nicht definiert";
                            if (!rd.IsDBNull(6))
                            {
                                dbBearbeiter Monteur = new dbBearbeiter(rd.GetInt32(0));
                                ArrayList ListofValuePairs = Monteur.Commons.Leistungsart;
                                foreach (ValuePair vp in ListofValuePairs)
                                {
                                    if (vp.Value == rd.GetString(6))
                                        leistart = vp.Text;
                                }
                            }*/
                            MAUebersichtZeile MAZeile = new MAUebersichtZeile(rd.GetDateTime(0), rd.GetString(1), rd.GetString(2), rd.GetString(3));
                            AllMA.Add(MAZeile);

                            if ((SelMABis > -1 && SelMAVon > -1) &&
                                (SelMABis >= SelMAVon))
                            {
                                if (iCnt < SelMAVon ||
                                    iCnt > SelMABis)
                                {
                                    // nur Mitarbeiter im selektierten Bereich anzeigen
                                    continue;
                                }
                            }

                            TableRow tr = new TableRow();
                            TableCell d0 = new TableCell();
                            d0.Text = rd.GetDateTime(0).ToString(); // Datum
                            d0.HorizontalAlign = HorizontalAlign.Center;
                            d0.CssClass = "TabNewDay";
                            tr.Cells.Add(d0);

                            TableCell d1 = new TableCell();
                            d1.Text = rd.GetString(1); // Nachname Mitarbeiter
                            d1.HorizontalAlign = HorizontalAlign.Center;
                            d1.CssClass = "TabNewDay";
                            tr.Cells.Add(d1);

                            TableCell d2 = new TableCell();
                            d2.Text = rd.GetString(2); // Vorname Mitarbeiter
                            d2.HorizontalAlign = HorizontalAlign.Center;
                            d2.CssClass = "TabNewDay";
                            tr.Cells.Add(d2);

                            TableCell d3 = new TableCell();
                            d3.Text = rd.GetString(3); // Persnr Mitarbeiter;
                            d3.HorizontalAlign = HorizontalAlign.Center;
                            d3.CssClass = "TabNewDay";
                            tr.Cells.Add(d3);

                            TableCell d4 = new TableCell();
                            d4.Text = rd.GetString(4);//Projektname
                            d4.HorizontalAlign = HorizontalAlign.Center;
                            d4.CssClass = "TabNewDay";
                            tr.Cells.Add(d4);

                            TableCell d5 = new TableCell();

                            switch (rd.GetInt32(5))
                            {
                                case 10:
                                    d5.Text = "neu";
                                    break;
                                case 20:
                                    d5.Text = "ungelesen";
                                    break;
                                case 30:
                                    d5.Text = "gelesen";
                                    break;
                                default :
                                    d5.Text = "";
                                    break;
                            }
                            d5.HorizontalAlign = HorizontalAlign.Center;
                            d5.CssClass = "TabNewDay";
                            tr.Cells.Add(d5);

                            
                            LinkButton btn = new LinkButton();
                            btn.ID = nid();
                            btn.SkinID = "";
                            btn.Width = Unit.Percentage(100);
                            btn.Text = "Lesen";
                            btn.CommandName = "read";
                            btn.CommandArgument = rd.GetInt32(6).ToString();
                            btn.ToolTip = "Klicken Sie hier um Nachricht zu lesen.";
                            //btn.CausesValidation = false;
                            btn.Command += new CommandEventHandler(TaskButton_Click);
                            TableCell d6 = new TableCell();
                            d6.Controls.Add(btn);
                            d6.HorizontalAlign = HorizontalAlign.Center;
                            d6.CssClass = "TabNewDay";
                            tr.Cells.Add(d6);

                            tabListe.Rows.Add(tr);
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        // Es werden die Buttons zur Selektion der Mitarbeiter (jeweils 20) erzeugt
        Table2.Controls.Clear();
        int SeiteMAVon = 0;
        int SeiteMABis = 0;

        TableRow trSeite = new TableRow();

        for (int Index = 1, IndexS = 1; Index <= AllMA.Count; Index += 20, IndexS++)
        {
            // Button für Selektion der Seite erzeugen
            // 1 Button selektiert 20 Mitarbeiter
            LinkButton btn = new LinkButton();
            btn.ID = "Seite" + Index;
            btn.SkinID = "";
            btn.Width = Unit.Percentage(100);
            SeiteMAVon = Index;
            SeiteMABis = Index + 19 > AllMA.Count ? AllMA.Count : Index + 19;

            btn.Text = IndexS + " ";
            btn.Font.Size = 14;
            btn.CommandName = "Select";
            btn.CommandArgument = SeiteMAVon + "-" + SeiteMABis;
            // Im Tooltip den ersten und letzten Nachnamen des Mitarbeiters anzeigen
            btn.ToolTip = ((MAUebersichtZeile)AllMA[SeiteMAVon - 1]).Nachname + " - " + ((MAUebersichtZeile)AllMA[SeiteMABis - 1]).Nachname;
            btn.Command += new CommandEventHandler(TaskSeiteButton_Click);
            TableCell d1Seite = new TableCell();
            d1Seite.Text = btn.Text;
            d1Seite.Controls.Add(btn);
            trSeite.Controls.Add(d1Seite);
        }
        Table2.Rows.Add(trSeite);

        // Button um die Gesamtliste anzuzeigen (für Genehmiger mit wenigen Mitarbeitern
        LinkButton btnG = new LinkButton();
        btnG.ID = "Gesamt";
        btnG.SkinID = "";
        btnG.Width = Unit.Percentage(100);
        SeiteMAVon = 1;
        SeiteMABis = AllMA.Count;
        btnG.Text = "Gesamtliste";
        btnG.Font.Size = 14;
        btnG.CommandName = "Select";
        btnG.CommandArgument = SeiteMAVon + "-" + SeiteMABis;
        btnG.ToolTip = "";
        btnG.Command += new CommandEventHandler(TaskSeiteButton_Click);
        TableCell d1Gesamt = new TableCell();
        d1Gesamt.Text = btnG.Text;
        d1Gesamt.Controls.Add(btnG);
        trSeite.Controls.Add(d1Gesamt);
        Table2.Rows.Add(trSeite);

        for (int j = 0; j < ((TableRow)Table2.Controls[0]).Cells.Count; j++)
        {
            LinkButton cell = (LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0];
            if (cell.CommandArgument == SelMAVon.ToString() + "-" + SelMABis.ToString())
            {
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Bold = true;
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Underline = true;
            }
            else
            {
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Bold = false;
                ((LinkButton)((TableRow)Table2.Controls[0]).Cells[j].Controls[0]).Font.Underline = false;
            }
        }
        return tabListe;
    }
    private class MAUebersichtZeile
    {
        public DateTime Datum;
        public string Nachname;
        public string Vorname;
        public string Persnr;

        public MAUebersichtZeile(DateTime dt, string nachname, string vorname, string persnr)
        {
            Datum = dt;
            Nachname = nachname;
            Vorname = vorname;
            Persnr = persnr;
        }
    }
    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        int ebid = 0;

        try
        {
            ebid = Convert.ToInt32(e.CommandArgument);
        }
        catch
        {
            return;
        }
        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT BEARBEIT.NACHNAME AS Expr1, BEARBEIT.VORNAME AS Expr2, KEYUSER_MELDUNGEN.DATUM, BEARBEIT_1.NACHNAME, BEARBEIT_1.VORNAME, BAUPROJEKT.NAME " +
                                                       "FROM KEYUSER_MELDUNGEN INNER JOIN EINSBER ON KEYUSER_MELDUNGEN.EBID = EINSBER.EBID " +
                                                       "INNER JOIN BAUPROJEKT ON EINSBER.PROJID = BAUPROJEKT.PROJID " +
                                                       "INNER JOIN BEARBEIT ON EINSBER.PERSKEY = BEARBEIT.PERSKEY " +
                                                       "INNER JOIN BEARBEIT BEARBEIT_1 ON KEYUSER_MELDUNGEN.PERSKEY_GEN = BEARBEIT_1.PERSKEY " +
                                                       "WHERE KEYUSER_MELDUNGEN.EBID= @EBID", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@EBID", ebid));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            lbMA_PR.Text = rd.GetString(0) + " " + rd.GetString(1) + " aufm Projekt \"" + rd.GetString(5) + "\"";
                            lbDatum.Text = rd.GetDateTime(2).ToString();
                            lbGen.Text = rd.GetString(3) + " " + rd.GetString(4);
                            Panel1.Visible = true;
                            btnEB.CommandArgument = ebid.ToString();
                            btnDelete.CommandArgument = ebid.ToString();
                        }
                    }
                }
                using(SqlCommand cmd = new SqlCommand("update KEYUSER_MELDUNGEN set status = 30 where EBID = @EBID", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@EBID", ebid));
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
            catch
            {
            }
            finally { cnx.Close(); }
        }
    }
    void TaskSeiteButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;
        switch (cmd)
        {
            case "Select":
                SelMAVon = Convert.ToInt32(arg.Substring(0, arg.IndexOf("-")));
                SelMABis = Convert.ToInt32(arg.Substring(arg.IndexOf("-") + 1, arg.Length - (arg.IndexOf("-") + 1)));
                Session["SelMAVon3"] = SelMAVon;
                Session["SelMABis3"] = SelMABis;
                phMAListe.Controls.Clear();
                phMAListe.Controls.Add(GetListOfChengedEB());
                Session["Bearbeiter"] = Bearbeiter;
                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        //do nothing
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        Button button = (Button)sender;

        int ebid = Convert.ToInt32(button.CommandArgument);
        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("DELETE FROM KEYUSER_MELDUNGEN WHERE EBID = @EBID", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@EBID", ebid));
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
            catch
            {
            }
            finally { cnx.Close(); }
        }
        phMAListe.Controls.Clear();
        phMAListe.Controls.Add(GetListOfChengedEB());
        Panel1.Visible = false;
    }
    protected void btnEB_Click(object sender, EventArgs e)
    {
        Button button = (Button) sender;
        int projid = 0;
        int perskey = 0;
        int ebid = 0;
        int bermon = 0;
        try
        {
            ebid = Convert.ToInt32(button.CommandArgument);
        }
        catch
        {
            return;
        }

        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("Select projid, perskey, bermon FROM einsber " + Config.Nolock + "WHERE EBID = @EBID", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@EBID", ebid));
                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            projid = rd.GetInt32(0);
                            perskey = rd.GetInt32(1);
                            DateTime bm = rd.GetDateTime(2);
                            bermon = bm.Year * 100 + bm.Month;
                        }
                    }
                }
            }
            catch
            {
                return;
            }
            finally { cnx.Close(); }
        }
        if (ebid != 0 && projid != 0 && perskey != 0 && bermon != 0)
        {
            dbBearbeiter Monteur = new dbBearbeiter(perskey);
            dbProjekt Projekt = new dbProjekt(projid);
            Projekt.Select();
            dbBaustelle Baustelle = new dbBaustelle(Monteur);
            Baustelle.Params.BAUID.Value = Projekt.Params.BAUID.Value;
            //TAPM-36 Beginn- Lese gültigkeit der Baustelle 
            Baustelle.Select();
            //TAPM-36 Ende
            Projekt.Baustelle = Baustelle;
            dbMontBer MBericht = new dbMontBer(Projekt, Monteur);
            MBericht.BerichtsMonat = bermon;
            MBericht.Params.EBID.Value = ebid;
            MBericht.Select();
            Session["Projekt"] = Projekt;
            Session["MBericht"] = MBericht;
            Response.Redirect("~/Einsatzbericht/EditEB.aspx?Readonly=1&RetUrl=" + Request.RawUrl);
        }
    }
}
