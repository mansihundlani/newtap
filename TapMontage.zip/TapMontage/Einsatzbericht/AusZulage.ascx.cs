//-----------------------------------------------------------------------------
//
// Projekt      : TAP_Montage
//
// File         : AusZulage.ascx.cs
//
// Description  : Erfassung Aus/Zulagen im Einsatzbericht
//
//=============== V1.2.0011 ===================================================
//
// Date         : 27.September 2011
// Author       : Joldic Dzevad
// Defect#      : KMS BAN 500256 TAP-Montage: Erweiterte Zulagenpr�fung
//                Hinwei� ausgeben falls Zulagenanzahl gr�sser als es erlaubt  
//
//--------------- V1.0.0016 ---------------------------------------------------
//
// Date         : 07.Dezember 2006
// Author       : GN
// Defect#      : 3910
//                tb.Width von 30 auf 60 gesetzt
//
//-----------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;
using System.Collections.Generic;

public partial class Einsatzbericht_AusZulage : System.Web.UI.UserControl
{
    dbMontBer Monber;

    protected void Page_Load(object sender, EventArgs e)
    {
        Monber = (dbMontBer)Session["MBericht"];
        if (Monber.Auszulagen.Count != 0)
            phTable.Controls.Add(AusZulageTable());
    }
    public bool Enabled
    {
        get { return panMain.Enabled; }
        set { panMain.Enabled = value; }
    }

    private Table AusZulageTable()
    {
        Table AusZulage = new Table();

        AusZulage.Width = Unit.Percentage(100);
        TableRow HeaderRow = new TableRow();
        TableCell c1 = new TableCell();
        c1.Text = "Aus/Zulage";
        c1.CssClass = "TabHeader";
        c1.Font.Bold = true;
        TableCell c2 = new TableCell();
        c2.CssClass = "TabHeader";
        c2.Text = "Anzahl";
        c2.Font.Bold = true;
        HeaderRow.Cells.Add(c1);
        HeaderRow.Cells.Add(c2);
        AusZulage.Rows.Add(HeaderRow);
        string strCssClassRow = "TabNewDay";
        foreach (dbAusZulage azl in Monber.Auszulagen)
        {
            if (!azl.Deleted)
            {
                TableRow tr = new TableRow();
                TableCell d1 = new TableCell();
                d1.CssClass = strCssClassRow;
                d1.Text = ParamVal.GetParameter(azl.Params.LOHNART) + " " + ParamVal.GetParameter(azl.Params.LOHNARTTXT);
                tr.Cells.Add(d1);

                TableCell d2 = new TableCell();
                d2.CssClass = strCssClassRow;
                TextBox tb = new TextBox();
                // Defect 3910
                // GN tb.Width von 30 auf 60 gesetzt
                tb.Width = 60;
                tb.Text = ParamVal.GetParameter(azl.Params.ANZAHL);
                d2.Controls.Add(tb);
                tr.Cells.Add(d2);
                AusZulage.Rows.Add(tr);
            }
        }
        return AusZulage;
    }
    private void ReadTable()
    {
        List<string> warnings = new List<string>();
        Session.Remove("Alert");
        if (phTable.Controls.Count > 0)
        {
            Table TabAusZu = (Table)phTable.Controls[0];
            for (int i = 1; i < TabAusZu.Rows.Count; i++)
            {
                (TabAusZu.Rows[i].Cells[1].Controls[0] as TextBox).Text = (TabAusZu.Rows[i].Cells[1].Controls[0] as TextBox).Text.Replace(".", "");
                (Monber.Auszulagen[i - 1] as dbAusZulage).Params.ANZAHL.Value = Convert.ToSingle((TabAusZu.Rows[i].Cells[1].Controls[0] as TextBox).Text);
                if ((Monber.Auszulagen[i - 1] as dbAusZulage).MaxAnzahl != 0f &&
                    Convert.ToSingle((Monber.Auszulagen[i - 1] as dbAusZulage).Params.ANZAHL.Value) > (Monber.Auszulagen[i - 1] as dbAusZulage).MaxAnzahl)
                    warnings.Add(string.Format("Achtung! Grenzwert von {0} bei Zulage {1} ist �berschritten!", (Monber.Auszulagen[i - 1] as dbAusZulage).MaxAnzahl.ToString(), (Monber.Auszulagen[i - 1] as dbAusZulage).Params.LOHNART.Value.ToString()));
            }
        }
        if (warnings.Count > 0)
            Session.Add("Alert", warnings.ToArray());
    }

    public void OnSave_Click()
    {
        Monber = (dbMontBer)Session["MBericht"];
        ReadTable();
        Session["MBericht"] = Monber;
    }

}
