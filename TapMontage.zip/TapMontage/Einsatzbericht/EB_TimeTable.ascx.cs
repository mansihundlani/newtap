//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : EB_TimeTable.ascx.cs
//
// Description  : Einsatzberichte Timetable
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2013
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//                
//=============== V1.2.0012 ===============================================
//
// Date         : 20.J�nner 2012
// Author       : Joldic Dzevad
// Defect#      : BAF 530053
//                Bei Projektwechsel, auch INTF_ID in EINSBER ARBZEIT  
//                aktualisieren
//                
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//                
//=============== 1.0.0047 ================================================
//
// Date         : 10.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-45
//                B&I CarveOut - Mandantspezifische SAP Anfrage
//
//=============== 1.0.0047 ================================================
//
// Date         : 10.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-27
//                AZ am letzten Tag des Monats darf nur bis 23:59 geschrieben werden
//
//=============== 1.0.0046 ================================================
//
// Date         : 12.Dezember 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-38
//                �berstunden bei STD Absenzen
//
//=============== 1.0.0045 ================================================
//
// Date         : 22.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-22
//                Erfasse benachrichtigen wenn EB durch Genehmiger ge�ndert ist
//
// Date         : 16.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-21
//                Voreinstellung einer Leistungsart je Mitarbeiter
//
//=============== V1.0.0044 ===============================================
//
// Date         : 26.August 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-20
//                Rufbereitschaft
//
// Date         : 30.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : 6178/TAPM-19
//                R�cksetzen EB durch Genehmiger
//
// Date         : 12.August 2008
// Author       : Frantisek Sabol
// Defect#      : 6076/TAPM-22
//                Erfasser benachrichtigen wenn EB durch Genehmiger ge�ndert ist
//
//=============== V1.0.0043 ===============================================
//
// Date         : 11.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : xxxx
//                bei Stundenweiseabsenzen, das gehen um Mitternacht (00:00) verhindern
//
//--------------- V1.0.0041 ---------------------------------------------------
//
// Date         : 13.May 2008
// Author       : Joldic Dzevad
// Defect#      : 5999
//                Projekt �ndern als Genehmiger
//
//--------------- V1.0.0038 ---------------------------------------------------
//
// Date         : 13.M�rz 2008
// Author       : Joldic Dzevad
// Defect#      : 5879
//                Projekt �ndern -> Auftragsnummern in arbzeit wird nun auch ge�ndert
//
// Date         : 25.Februar 2008
// Author       : Wolfgang Patrman
// Defect#      : 4252
//                Session Variable 'realAccount' eingef�hrt, damit bei
//                Vertretert�tigkeit die richtigen Projekte im
//                DropDown Control 'ddlProjekt' angezeigt werden
//
// Date         : 20.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : 5828
//                Fehlermeldung wenn an einem Arbeitstag nur ZA als Stundeweise
//                Absenz erfasst ist
//
//--------------- V1.0.0037 ---------------------------------------------------
//
// Date         : 18.J�nner 2007
// Author       : Joldic Dzevad
// Defect#      : 5759
//                Fehlermeldung wenn an einem Arbeitstag nur Stundeweise Absenzen
//                erfasst sind
//
// Date         : 16.J�nner 2007
// Author       : Georg Nebehay
// Defect#      : 5746
//                Abfrage AZ-Modell auf Firmenkennung erg�nzt
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 18.Dezember 2007
// Author       : Joldic Dzevad
// Defect#      : 5690
//                Pausenberechnung bei Mitternachts�berschreitung falsch
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0034 -----------------------------------------------
//
//
// Date         : 23.November 2007
// Author       : Nebehay Georg
// Defect#      : 5661
//                Absenzen an Fenstertagen erm�glichen
//
// Date         : 23.Oktober 2007
// Author       : Wolfgang Patrman
// Defect#      : 5569
//                Anzeige Benutzerdaten im Kopf, wird im IE mit angedruckt
//
//--------------- V1.0.0033 -----------------------------------------------
//
// Date         : 12.September 2007
// Author       : Georg Nebehay
// Defect#      : 5435
//                Falsche Auftragsnummern - Auftrnrn. wurden beim ausf�hren
//                von btnrollup eb�bergreifend �bernommen
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//--------------- V1.0.0032 -----------------------------------------------
//
// Date         : 9.August 2007
// Author       : Georg Nebehay
// Defect#      : 4945, 5254, 5313
//                GK-Auftr�ge waren unter gewissen Umst�nden nicht
//                produktivierbar
//
//--------------- V1.0.0031 ---------------------------------------------------
//
// Date         : 31.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 5322
//                Projekt-AZM wird durch Mitarbeiter AZM �berschrieben
//
//--------------- V1.0.0029 ---------------------------------------------------
//
// Date         : 16.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 5080
//                �ndern der Projektnummer f�r Einsatzbericht
//
//--------------- V1.0.0029 ---------------------------------------------------
//
// Date         : 27.Juni 2007
// Author       : Adam Kiefer
// Defect#      : 4616, 4617, 4940
//                AZ-Modell
//
//=============== V1.0.0028 ===============================================
//
// Date         : 21.Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4099
//                ganzt�gige Absenzen Krankheit und Unfall werden nur
//                angezeigt und sind nicht �nderbar
//
//--------------- V1.0.0028 ---------------------------------------------------
//
// Date         : 15.Juni 2007
// Author       : Caleb Gebhardt
// Defect#      : 5024, 5082
//                Summenberechnung f. Wochenende falsch
//                Stundenweise Abzensen in der DB nicht gespeichert
//                Berechnung und Anzeige der STD - Abszendauer bei 
//                allen STD Absenzarten
//
//--------------- V1.0.0028 ---------------------------------------------------
//
// Date         : 12.Juni 2007
// Author       : Adam Kiefer
// Defect#      : 5042, 5064
//                L�schen von Einsatzbericht nicht m�glich
//
//--------------- V1.0.0028 ---------------------------------------------------
//
// Date         : 01. Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4887
//                Wenn Button 'Aktualisieren' gedr�ckt wurde, dann �berpr�fen
//                ob bereits vorhandenen RAAuslagen/KFZ-Daten innerhalb der
//                eingegebenen Arbeitszeiten liegen
//
//--------------- V1.0.0027 ---------------------------------------------------
//
// Date         : 21. May 2007
// Author       : Wolfgang Patrman
// Defect#      : 4662
//                Ausgabe einer Meldung (LabelAktWarn), wenn Kommen/Gehen Zeitstempel geaendert
//                wurden.   
//
//--------------- V1.0.0027 ---------------------------------------------------
//
// Date         : 11. May 2007
// Author       : Adam Kiefer
// Defect#      : 3372
//
// Relevanzkennzeichen nur an Arbeitstagen setzen.
// �nderungen:  protected void btnSelect_Click()
//
// ============== V1.0.0024 ===================================================
//
// Date         : 05. April 2007
// Author       : CL
// Defect#      : 4941
//                Alle eingegebenen Zeitstempel werden noch VOR dem Parsen auf
//                int-Wert auf korrektes Format gepr�ft. Gegebenenfalls wird
//                Fehlemeldung eingeblendet (statt Exception).
//
//--------------- V1.0.0023 --------------------------------------------------- *
// Date         : 13. M�rz 2007
// Author       : CL
// Defect#      : 4795
//
// Stundenweise Absenzen d�rfen nicht ausserhalb der Normalarbeitszeit
// eingegeben werden.
//
//--------------- V1.0.0023 ------------------------------------------------------
//
// Date         : 07. M�rz 2007
// Author       : CL
// Defect#      : 4754
//                Stundensumme im Einsatzbericht summiert nur das aktuelle Projekt
//                und nicht alle Stunden aller EB.
// 
//--------------- V1.0.0022 ------------------------------------------------------
//
// Date         : 23. Februar 2007
// Author       : CG
// Defect#      : 4594
//                Statusanzeige beim abgelaufenen Arbeitszeitmodell
//
//--------------- V1.0.0022 ------------------------------------------------------
//
// Date         : 15. Februar 2007
// Author       : CG
// Defect#      : 4501
//
//   Es soll verhindert werden, da� 
//      - der MA auf ein schon innerhalb dieses EB-Monats abgelaufenes 
//        Projekt kontiert, d.h. 
//        Bauprojekt.valid >= Einsatzbericht.Arbeitstag.TagesDatum          
//      - der MA auf ein schon innerhalb dieses EB-Monats abgelaufenes
//        AZmodell verwendet, 
//        d.h. MA_gueltig_von <= Einsatzbericht.Arbeitstag.TagesDatum 
//                             <= MA_gueltig_bis
//      - Vor und nach dem Firmenaustritt, kein EB-generierung m�glich
//        ma_stamm.eintritt <= Einsatzbericht.Arbeitstag.TagesDatum
//                            <= ma_stamm.austritt
//
//--------------- V1.0.0017 ------------------------------------------------------
//
// Date         : 4.J�nner 2007
// Author       : Nebehay Georg
// Defect#      : 3766
//                Innenauftr�geauswahl: nur diejenige, die aktiv sind (status = 20)
//
//--------------- V1.0.0016 ------------------------------------------------------
//
// Date         : 13.Dezember 2006
// Author       : Nebehay Georg
// Change       : 3229, 3923
//                24:00 is set to 00:00 to prevent a conversion error
//                in Function Convert.ToDateTime
//
//--------------- V1.0.0009 ------------------------------------------------------
//
// Date         : 14.November 2006
// Author       : Nebehay Georg
// Defect#      : 3677
//                Mitarbeiter der EEI erhielten keine Auswahlm�glichkeit f�r GK-Auftr�ge
//                durch eine fehlerhaftes SQL-Skript. 
//
//--------------- V1.0.0007 ------------------------------------------------------
//
// Date         : 10.November 2006
// Author       : Gebhardt caleb
// Defect#      : 3246
//                Fehler bei der Erfassung eines Montageberichts
//
//--------------- V1.0.0005 ------------------------------------------------------
//
// Date         : 07.November 2006
// Author       : Gebhardt caleb
// Defect#      : 3352, 3360, 3375
//                Summe der Stunden falsch. Sowohl die Gesamtsumme bei der
//                Normalstunden als auch in der Einteilung der �berstunden in
//                50% und 100%   
//
//--------------- V1.0.0001 --------------------------------------------------- *
// Date         : 20. Oktober 2006
// Author       : EW
// Defect#      : 3336
//
// Korrekte �berpr�fung der eingegebenen Arbeitszeiten
//
// ===============================================================================
using System;
using System.Data;

using System.Data.SqlClient;
using System.IO;

using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Einsatzbericht_EB_TimeTable : System.Web.UI.UserControl
{
    dbBearbeiter Bearbeiter;
    dbProjekt Projekt;
    dbMontBer MBericht;

    // Defect 3352, 3360, 3375
    private float dNormStd = 0.00f;
    private float dUEStd50 = 0.00f;
    private float dUEStd100 = 0.00f;
    // ende defect 3352, 3360, 3375
    private bool blnLastChecked = false; // Defect #4524
    private int CtrlID = 0;
    private bool pauseBerechnen = false; // Defect #5690
    private string defLA = "";
    private string NextID()
    {
        CtrlID++;
        return "ctrl-" + CtrlID.ToString();
    }

    // Beginn Defect 4887
    public Einsatzbericht_KFZ KFZ; // Verweis auf KFZ1 speichern
    public Einsatzbericht_RAAuslage RAAuslage; // Verweis auf RAAuslage1 speichern
    // Ende Defect 4887

    protected void Page_Load(object sender, EventArgs e)
    {
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        Projekt = (dbProjekt)Session["Projekt"];
        MBericht = (dbMontBer)Session["MBericht"];

        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
            {
                Session.Add("headData", "");
            }

            Session["headData"] = "<span style=\"font-size: 20px;\">Einsatzbericht Bearbeiten</span><br /><span style=\"font-size: 12px;\">";
            // Beginn Defect 5569, Mitarbeiterinformationen anzeigen
            string[] mn = new string[] { "J�nner", "Februar", "M�rz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember" };
            string lbTmp = MBericht.Bearbeiter.Params.VORNAME.Value.ToString() + " " +
                           MBericht.Bearbeiter.Params.NACHNAME.Value.ToString() + " (" +
                           MBericht.Bearbeiter.Params.PERSNR.Value.ToString() + ") " +
                           mn[Convert.ToInt32(MBericht.BerichtsMonat.ToString().Substring(4, 2)) - 1] + " " +
                           MBericht.BerichtsMonat.ToString().Substring(0, 4) + " - " +
                           Projekt.Params.NAME.Value.ToString() + " (" +
                           Projekt.Params.KTOBJ.Value.ToString() + ")";
            lbHeadInfo.Text = lbTmp;

            Session["headData"] += lbTmp + "</span>";
            /*
            Session["headData"] += Projekt.Params.NAME.Value.ToString() + " (" + Projekt.Params.KTOBJ.Value.ToString() + ") - ";
            Session["headData"] += MBericht.BerichtsMonat.ToString() + " - ";
            Session["headData"] += MBericht.Bearbeiter.Params.VORNAME.Value.ToString() + " " + MBericht.Bearbeiter.Params.NACHNAME.Value.ToString() + " (" + MBericht.Bearbeiter.Params.PERSNR.Value.ToString() + ")</span>";
            */
            // Ende Defect 5569

        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416

        // Beginn #4616, 4617, 4940 - AZ-Modell
        // Nur neue MBericht
        if (Convert.ToInt32(MBericht.Params.EBSTAT.Value) == 0)
        {
            MBericht_Aktualizieren();
        }
        // Ende #4616, 4617, 4940
        //TAPM-21
        if (Page.IsPostBack)
        {
            try
            {
                //TAPM-21 - is ist ein Postback, default LA wird von der Session Variable versorgt
                defLA = (string)Session["DefaultLeistungsArt"];
            }
            catch
            {
            }

        }
        else
        {
            //TAPM-21 - die Seite wird zum ersten mal aufgerufen, das Default LA wird von DB ausgelesen
            Session["DefaultLeistungsArt"] = "";
            using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("select leistart from DEFAULT_LEISTART " + Config.Nolock + "where perskey = @PERSKEY", cnx))
                    {
                        cmd.Parameters.Add(MBericht.Bearbeiter.Params.PERSKEY);
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();
                            while (rd.Read())
                            {
                                if (!rd.IsDBNull(0))
                                {
                                    defLA = rd.GetString(0);
                                    Session["DefaultLeistungsArt"] = defLA;
                                }
                            }
                            rd.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    defLA = "";
                    throw ex;
                }
                finally { cnx.Close(); }
            }
        }
        BuildTable();
        pauseBerechnen = true; // Defekt #5690
        ReadTable();
        LabelAktWarn.Attributes["style"] = "display:none;";
        // Beginn #5042, 5064 - L�schen von Einsatzbericht nicht m�glich
        string warning = "Achtung! Wollen Sie diesen Einsatzbericht l�schen?";
        btnEBL�schen.Attributes.Add("onclick", "javascript:return " + string.Format("confirm('{0}')", warning));
        lbEBL�schenFehler.ForeColor = System.Drawing.Color.Red;
        lbEBL�schenFehler.Visible = false;
        // Ende #5042, 5064

        // Bedginn #5080 - �ndern der Projektnummer f�r Einsatzbericht
        string warning2 = "Achtung! Wollen Sie diesen Einsatzbericht �ndern?";
        btnChange.Attributes.Add("onclick", "javascript:return " + string.Format("confirm('{0}')", warning2));
        lbEBL�schenFehler.ForeColor = System.Drawing.Color.Red;
        lbEBL�schenFehler.Visible = false;
        lbChanged.Visible = false;

        // Defect #6178 - Einsatzbericht Zur�cksetzen
        string warning3 = "Achtung! Wollen Sie diesen Einsatzbericht zur�cksetzen?";
        btnRuecksetzen.Attributes.Add("onclick", "javascript:return " + string.Format("confirm('{0}')", warning3));


        try
        {
            if (Session["loginRole"].ToString().Contains("Erfasser"))
            {
                btnShowpnlChange.Visible = true;
            }
            if (!Page.IsPostBack)
            {
                int projId = (int)MBericht.Params.PROJID.Value;

                SISSITableAdapters.BAUPROJEKTTableAdapter taBAUPROJEKT = new SISSITableAdapters.BAUPROJEKTTableAdapter();
                SISSI.BAUPROJEKTDataTable dtBAUPROJEKT = taBAUPROJEKT.GetBauIdByProjekt(projId);
                SISSI.BAUPROJEKTRow rowBAUPROJEKT = (SISSI.BAUPROJEKTRow)dtBAUPROJEKT.Rows[0];
                int bauId = (int)rowBAUPROJEKT.BAUID;

                ddlBaustelle.SelectedValue = bauId.ToString();
                ddlBaustelle.DataBind();

                //Defect #5999 Als Genehmiger kann man nur das Projekt innerhalb der selbe Baustelle �ndern
                bool FromGenehmigung = false;
                try
                {
                    FromGenehmigung = (bool)Session["FromGenehmigung"];
                }
                catch
                { }
                if (FromGenehmigung)
                {
                    ddlBaustelle.Enabled = false;
                    btnRuecksetzen.Visible = true; //Defect #6178 - Genehmiger - R�cksetzbutton wird gezeichnet
                }
                else
                    btnRuecksetzen.Visible = false; //Defect #6178 - Erfasser - R�cksetzbutton wird nicht gezeichnet

                // Beginn Defect 4252
                // basierend auf der Session Variable 'realAccount' wird das DropDown Control Projektnummer
                // versorgt
                if (Session["realAccount"] == null)
                {
                    Session.Add("realAccount", ((dbBearbeiter)Session["Bearbeiter"]).Params.BELOGIN.Value.ToString());
                }
                else
                {
                    Session["realAccount"] = ((dbBearbeiter)Session["Bearbeiter"]).Params.BELOGIN.Value.ToString();
                }
                // Ende Defect 4252

                ddlProjekt.SelectedValue = projId.ToString();
                ddlProjekt.DataBind();
            }
        }
        catch
        {
            pnlChange.Visible = false;
        }
        // Ende #5080
    }

    // Beginn #5322 - Projekt-AZM wird durch Mitarbeiter AZM �berschrieben
    // Beginn #4616, 4617, 4940 - AZ-Modell
    private void MBericht_Aktualizieren()
    {
        try
        {
            if (MBericht != null)
            {
                bool AZMFound;
                foreach (dbArbTag Tag in MBericht.Tage)     //Alle Tage im Einsatzbericht
                {
                    /* Pr�fen fr�her gespeichert Tage (17.07.2007 - Adam Kiefer) */
                    SISSITableAdapters.ARBZEITTableAdapter taAZ = new SISSITableAdapters.ARBZEITTableAdapter();
                    SISSI.ARBZEITDataTable dtAZ = taAZ.CheckArbtag(Convert.ToInt32(MBericht.Params.PERSKEY.Value), Tag.TagesDatum);
                    SISSI.ARBZEITRow rowAZ = (SISSI.ARBZEITRow)dtAZ.Rows[0];
                    if (rowAZ.ARBZEITCOUNT == 0) /* -> Noch keine AZ gespeichert f�r diese Tag -> AZ wird aktualiziert */
                    {
                        foreach (dbArbZeit Zeit in Tag.Zeiten)  //Alle Zeiten im Tag
                        {
                            string vPersNum = MBericht.Bearbeiter.Params.PERSNR.Value.ToString().Substring(2, 5);
                            string vMAName = MBericht.Bearbeiter.Params.NACHNAME.Value.ToString();
                            string vMAVorame = MBericht.Bearbeiter.Params.VORNAME.Value.ToString();
                            string vTag = Zeit.Kommen.ToString("yyyy-MM-dd");
                            string vProjId = MBericht.Projekt.Params.PROJID.Value.ToString();
                            bool AZM_Found_For_Project = false;

                            if (vTag != "1900-01-01")
                            {

                                using (SqlConnection SissiConnection = new SqlConnection(CurrentEnvironment.DbConnectionString))
                                {
                                    SissiConnection.Open();
                                    // Defect 5725, Config.Rowlock eingef�hrt
                                    // Defect 5771, Config.Nolock eingef�hrt
                                    string SissiSqlCommandText = "SELECT VON AS AZ_Begin, BIS AS AZ_Ende, (DATEDIFF(mi , VON , BIS) / 60.0) AS AZ_SollarbeitStd" +
                                        " FROM BAUPROJEKT_AZMODELL " + Config.Nolock + " WHERE PROJAZMID = '" + vProjId + "' AND TAG = (DATEPART(w , '" + vTag + "') -1)";

                                    using (SqlCommand SissiSqlCommand = new SqlCommand(SissiSqlCommandText, SissiConnection)) // Defect 5436, using eingef�hrt
                                    {
                                        using (SqlDataReader SissiReader = SissiSqlCommand.ExecuteReader()) // Defect 5436
                                        {
                                            AZMFound = false;
                                            while (SissiReader.Read())
                                            {
                                                try
                                                {
                                                    AZMFound = true;
                                                    if (
                                                               (Convert.ToDateTime(SissiReader.GetValue(0).ToString()).Hour == 0)
                                                            && (Convert.ToDateTime(SissiReader.GetValue(0).ToString()).Minute == 0)
                                                            && (Convert.ToDateTime(SissiReader.GetValue(1).ToString()).Hour == 0)
                                                            && (Convert.ToDateTime(SissiReader.GetValue(1).ToString()).Minute == 0)
                                                        )
                                                    {
                                                        AZM_Found_For_Project = false;
                                                    }
                                                    else
                                                    {
                                                        DateTime fromTime = Convert.ToDateTime(SissiReader.GetValue(0).ToString());
                                                        DateTime toTime = Convert.ToDateTime(SissiReader.GetValue(1).ToString());

                                                        /* Zeiten aktualisieren */

                                                        Zeit.Kommen = Zeit.Kommen.AddHours(fromTime.Hour - Zeit.Kommen.Hour);
                                                        Zeit.Kommen = Zeit.Kommen.AddMinutes(fromTime.Minute - Zeit.Kommen.Minute);

                                                        Zeit.Gehen = Zeit.Gehen.AddHours(toTime.Hour - Zeit.Gehen.Hour);
                                                        Zeit.Gehen = Zeit.Gehen.AddMinutes(toTime.Minute - Zeit.Gehen.Minute);

                                                        Zeit.NormStunden = Convert.ToDouble(SissiReader.GetValue(2).ToString());

                                                        AZM_Found_For_Project = true;
                                                    }
                                                }
                                                catch
                                                {
                                                    AZM_Found_For_Project = false;
                                                }
                                            }
                                            if (!AZMFound)
                                            {
                                                DateTime fromTime = Convert.ToDateTime("1900-01-01 00:00");
                                                DateTime toTime = Convert.ToDateTime("1900-01-01 00:00");

                                                /* Zeiten aktualisieren */

                                                Zeit.Kommen = Zeit.Kommen.AddHours(fromTime.Hour - Zeit.Kommen.Hour);
                                                Zeit.Kommen = Zeit.Kommen.AddMinutes(fromTime.Minute - Zeit.Kommen.Minute);

                                                Zeit.Gehen = Zeit.Gehen.AddHours(toTime.Hour - Zeit.Gehen.Hour);
                                                Zeit.Gehen = Zeit.Gehen.AddMinutes(toTime.Minute - Zeit.Gehen.Minute);

                                                Zeit.NormStunden = 0;
                                            }
                                            SissiReader.Close();
                                            SissiConnection.Close();
                                        }
                                    }
                                }

                                if (!AZM_Found_For_Project)
                                {

                                    using (SqlConnection AZMConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                                    {
                                        /* Aktuelle AZModell - Werte lesen */
                                        AZMConnection.Open();
                                        // Defect 5725, Config.Rowlock eingef�hrt
                                        // Defect 5771, Config.Nolock eingef�hrt
                                        //Defect 5746
                                        //Abfrage auf Firmenkennung erg�nzt
                                        //GN 16.1.2007
                                        string AZMSqlCommandText = "SELECT AZ_Begin, AZ_Ende, AZ_SollarbeitStd FROM AZ_Tag " + Config.Nolock +
                                            " WHERE AZ_Modell_Nummer = (" +
                                            " SELECT AZ_Modell_Nummer FROM MA_AZ_Modell " + Config.Nolock +
                                            " WHERE (MA_AZ_g�ltig_von <= '" + vTag + "') AND (MA_AZ_g�ltig_bis >= '" + vTag + "') AND (MA_PersNummer = '" + vPersNum + "')" +
                                            "')  AND (MA_FKN = (SELECT MA_FKN FROM MA_Stamm " + Config.Nolock + " WHERE MA_PersNummer = '" + vPersNum + "' AND MA_Name = '" + vMAName + "' AND MA_Vorname = '" + vMAVorame + "'))" +
                                            " ) AND AZ_Wochentag = DATEPART(w , '" + vTag + "')  ";

                                        SqlCommand AZMSqlCommand = new SqlCommand(AZMSqlCommandText, AZMConnection);
                                        SqlDataReader AZMReader = AZMSqlCommand.ExecuteReader();
                                        AZMFound = false;
                                        while (AZMReader.Read())
                                        {
                                            try
                                            {
                                                AZMFound = true;
                                                DateTime fromTime = Convert.ToDateTime(AZMReader.GetValue(0).ToString());
                                                DateTime toTime = Convert.ToDateTime(AZMReader.GetValue(1).ToString());

                                                /* Zeiten aktualisieren */

                                                Zeit.Kommen = Zeit.Kommen.AddHours(fromTime.Hour - Zeit.Kommen.Hour);
                                                Zeit.Kommen = Zeit.Kommen.AddMinutes(fromTime.Minute - Zeit.Kommen.Minute);

                                                Zeit.Gehen = Zeit.Gehen.AddHours(toTime.Hour - Zeit.Gehen.Hour);
                                                Zeit.Gehen = Zeit.Gehen.AddMinutes(toTime.Minute - Zeit.Gehen.Minute);

                                                Zeit.NormStunden = Convert.ToDouble(AZMReader.GetValue(2).ToString());
                                            }
                                            catch { }
                                        }
                                        if (!AZMFound)
                                        {
                                            DateTime fromTime = Convert.ToDateTime("1900-01-01 00:00");
                                            DateTime toTime = Convert.ToDateTime("1900-01-01 00:00");

                                            /* Zeiten aktualisieren */

                                            Zeit.Kommen = Zeit.Kommen.AddHours(fromTime.Hour - Zeit.Kommen.Hour);
                                            Zeit.Kommen = Zeit.Kommen.AddMinutes(fromTime.Minute - Zeit.Kommen.Minute);

                                            Zeit.Gehen = Zeit.Gehen.AddHours(toTime.Hour - Zeit.Gehen.Hour);
                                            Zeit.Gehen = Zeit.Gehen.AddMinutes(toTime.Minute - Zeit.Gehen.Minute);

                                            Zeit.NormStunden = 0;
                                        }
                                        AZMReader.Close();
                                        AZMConnection.Close();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Session["MBericht"] = MBericht;
        }
        catch
        {
            MBericht = (dbMontBer)Session["MBericht"];
        }
    }
    // Ende #4616, 4617, 4940 
    // Ende #5322

    public bool Enabled
    {
        get { return panMain.Enabled; }
        set { panMain.Enabled = value; }
    }

    // Defect # 4941: Function 'ReadLine' returns bool
    private bool ReadLine(TableRow r)
    {
        bool blnValidTimeFormat = true; // Defect # 4941: Flag f�r Zeitstempelformat
        dbArbZeit az = GetArbzeitByID(r.Cells[0].ID);
        string kommen = "";

        //Falls kommen/gehen keine Uhrzeit, sollten folgende Aufrufe zu einer Exception f�hren -> leerer String
        // Beginn Defect # 3336: Pr�fung der eingegebenen Zeitstempel
        try { kommen = RangeCheck.FixTime((r.Cells[2].Controls[0] as TextBox).Text); }
        catch { }
        string gehen = "";
        try { gehen = RangeCheck.FixTime((r.Cells[3].Controls[0] as TextBox).Text); }
        catch { }
        //avoid 
        if ((r.Cells[1].Controls.Count > 0) && (r.Cells[1].Controls[0] is CheckBox))
        {
            az.Arbeitstag.Relevanz = false;
            if (Checkgueltigkeit(az))
            {
                az.Arbeitstag.Relevanz = (r.Cells[1].Controls[0] as CheckBox).Checked;
            }
        }
        // Ende Defect # 3336
        // Defect 3229, 3923
        // GN 24:00 is set to 00:00 to prevent a conversion error in Function Convert.ToDateTime
        if (kommen.Equals("24:00")) kommen = "00:00";
        if (gehen.Equals("24:00")) gehen = "00:00";

        if (gehen == "" || kommen == "") //Both values have to be correct
        {
            kommen = "";
            gehen = "";
        }
        else
        {
            /* Beginn Defect # 4941: Pr�fen der Zeitstempel VOR dem int-Parse.
             * Exception wird abgefangen und als Fehlermeldung ausgegeben.
             * Dadurch ist f�r den Benutzer Korrektur und Weiterarbeit m�glich
             * */
            int kom = 0;
            int geh = 0;
            if (kommen.Length < 5)
            {
                // Kommen-Stempel zu klein
                kommen += "???";
            }
            if (gehen.Length < 5)
            {
                // Gehen-Stempel zu klein
                gehen += "???";
            }
            try
            {
                kom = Int16.Parse(kommen.Remove(2, 1));
            }
            // Defect 5771
            // Exception Objekt ex entfernt, da es nicht verwendet wird
            catch
            {
                // Falsches Format des Kommen-Zeitstempels
                blnValidTimeFormat = false;
                if (LWrongTimeFormat.Text.Length > 0)
                {
                    LWrongTimeFormat.Text += "   ---   ";
                }
                LWrongTimeFormat.Text += "Falsches Zeitstempelformat bei Tag: " +
                                         az.Arbeitstag.TagesDatum.Date.ToString().Substring(0, 10) +
                                         " Kommenzeit = " +
                                         kommen;
                LWrongTimeFormat.Visible = true;
            }
            try
            {
                geh = Int16.Parse(gehen.Remove(2, 1));
            }
            // Defect 5771
            // Exception Objekt ex entfernt, da es nicht verwendet wird
            catch
            {
                // Falsches Format des Gehen-Zeitstempels
                blnValidTimeFormat = false;
                if (LWrongTimeFormat.Text.Length > 0)
                {
                    LWrongTimeFormat.Text += "   ---   ";
                }
                LWrongTimeFormat.Text += "Falsches Zeitstempelformat bei Tag: " +
                                         az.Arbeitstag.TagesDatum.Date.ToString().Substring(0, 10) +
                                         " Gehenzeit = " +
                                         gehen;
                LWrongTimeFormat.Visible = true;
            }
            // Ende Defect # 4941
            if (geh != 0 && kom >= geh) //00:00 (24:00) is the only allowed leaving entry smaller than coming entry
            {
                kommen = "";
                gehen = "";
            }
        }

        /* Beginn Defect # 4941: Weitere Verarbeitung nur bei korrekten Zeitstempeln */
        if (blnValidTimeFormat)
        {
            // Ende Defect # 4941
            switch (az.ZeitTyp)
            {
                case dbArbZeit.ArbZeitType.produktiv:
                    if (kommen != "") az.Kommen = Convert.ToDateTime(az.Arbeitstag.TagesDatum.ToShortDateString() + " " + kommen);
                    else az.Kommen = ParamVal.Date0;
                    if (gehen != "") az.Gehen = Convert.ToDateTime(az.Arbeitstag.TagesDatum.ToShortDateString() + " " + gehen);
                    else az.Gehen = ParamVal.Date0;
                    az.Leistart = (r.Cells[12].Controls[0] as DropDownList).SelectedValue;//TAPM-20 Cells[11]->[12] RB ist dazwieschen gekommen
                    break;
                case dbArbZeit.ArbZeitType.gk:
                    if (kommen != "") az.Kommen = Convert.ToDateTime(az.Arbeitstag.TagesDatum.ToShortDateString() + " " + kommen);
                    else az.Kommen = ParamVal.Date0;
                    if (gehen != "") az.Gehen = Convert.ToDateTime(az.Arbeitstag.TagesDatum.ToShortDateString() + " " + gehen);
                    else az.Gehen = ParamVal.Date0;

                    az.Leistart = (r.Cells[12].Controls[0] as DropDownList).SelectedValue;//TAPM-20 Cells[11]->[12] RB ist dazwieschen gekommen
                    az.GKAuftragNR = (r.Cells[12].Controls[1] as DropDownList).SelectedValue;//TAPM-20 Cells[11]->[12] RB ist dazwieschen gekommen
                    break;

                case dbArbZeit.ArbZeitType.stdAbsenz:
                    if (kommen != "") az.Kommen = Convert.ToDateTime(az.Arbeitstag.TagesDatum.ToShortDateString() + " " + kommen);
                    else az.Kommen = ParamVal.Date0;
                    if (gehen != "") az.Gehen = Convert.ToDateTime(az.Arbeitstag.TagesDatum.ToShortDateString() + " " + gehen);
                    else az.Gehen = ParamVal.Date0;
                    az.STDAbsenzID = (r.Cells[12].Controls[0] as DropDownList).SelectedValue;//TAPM-20 Cells[11]->[12] RB ist dazwieschen gekommen
                    break;
                case dbArbZeit.ArbZeitType.gtAbsenz:
                    az.GTAbsenzID = Convert.ToInt16((r.Cells[12].Controls[0] as DropDownList).SelectedValue);//TAPM-20 Cells[11]->[12] RB ist dazwieschen gekommen
                    break;
            }
            //Sonderfall Eingabe Kommen > Gehen = Arbeiot �ber Mitternacht
            if ((az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz) && ((kommen != "") & (gehen != "")) && (az.Gehen.Ticks <= az.Kommen.Ticks))
            {
                az.Gehen = az.Gehen.AddDays(1); //n�chster Tag 00:00
            }
        } // Defect # 4941
        // Defect # 4941: Function returns bool value
        return blnValidTimeFormat;
    }

    /* Beginn Defect # 4941: Methode 'ReadTable' liefert bool-Wert,
     * um Speichern von falschen Zeitstempeln zu vermeiden
     * */
    private bool ReadTable()
    {
        // Beginn Defect # 4941: Initialisierung des Zeitstempel-Fehlerlabels
        bool blnValidTimestamps = true;
        LWrongTimeFormat.Visible = false;
        LWrongTimeFormat.Text = "";
        // Ende Defect # 4941

        Table TabListe = (Table)phListe.Controls[0];
        foreach (TableRow tr in TabListe.Rows)
            if ((tr.Cells[0].ID != null) && (tr.Cells[0].ID != ""))
            // Beginn Defect # 4941: Check return value
            {
                if (!ReadLine(tr))
                {
                    blnValidTimestamps = false;
                }
            }
        return blnValidTimestamps; // Defect # 4941
    }

    /* Beginn Defect #4524: Pr�fen in der Liste, ob ein leerer Einsatzbericht
     * vorliegt, d.h. keine Zeile ist als relevant markiert, bzw. in keiner relevanten
     * Zeile sind Kommen-Gehen-Zeiten eingetragen
     * */
    public bool IsEmptyTable()
    {
        bool blnEmpty = true;
        Table TabListe = (Table)phListe.Controls[0];
        blnLastChecked = false;
        foreach (TableRow tr in TabListe.Rows)
        {
            if ((tr.Cells[0].ID != null) && (tr.Cells[0].ID != ""))
            {
                blnEmpty = IsEmptyLine(tr);
                if (!blnEmpty)
                {
                    break;
                }
            }
        }

        return blnEmpty;
    }

    private bool IsEmptyLine(TableRow r)
    {
        bool blnEmpty = true;

        // Ist Zeile �berhaupt relevant (Checkbox selektiert) ?
        if ((r.Cells[1].Controls.Count > 0) && (r.Cells[1].Controls[0] is CheckBox))
        {
            // In 'blnLastChecked' bleibt der Check-Status der Checkbox gespeichert,
            // da weitere Zeilen desselben Tages keine eigene Checkbox besitzen.
            blnLastChecked = (r.Cells[1].Controls[0] as CheckBox).Checked;
        }

        if (blnLastChecked)
        {
            if ((r.Cells[2].Controls[0] as TextBox).Enabled &&
                (r.Cells[3].Controls[0] as TextBox).Enabled)
            {
                dbArbZeit az = GetArbzeitByID(r.Cells[0].ID);
                string kommen = "";
                try { kommen = RangeCheck.FixTime((r.Cells[2].Controls[0] as TextBox).Text); }
                catch { }
                string gehen = "";
                try { gehen = RangeCheck.FixTime((r.Cells[3].Controls[0] as TextBox).Text); }
                catch { }

                if (kommen.Equals("24:00")) kommen = "00:00";
                if (gehen.Equals("24:00")) gehen = "00:00";

                if (gehen == "" || kommen == "")
                {
                    kommen = "";
                    gehen = "";
                }
                else
                {
                    int kom = Int16.Parse(kommen.Remove(2, 1));
                    int geh = Int16.Parse(gehen.Remove(2, 1));
                    if (geh != 0 && kom >= geh)
                    {
                        kommen = "";
                        gehen = "";
                    }
                    else
                    {
                        blnEmpty = false;
                    }
                }
            }
        }

        return blnEmpty;
    }
    // Ende Defect #4524

    private bool CheckConsistency()
    {
        LConsistError.Text = "";
        DateTime d1 = ParamVal.Date0; ;
        foreach (dbArbTag at in MBericht.Tage)
        {
            dbArbZeitSort azsort = new dbArbZeitSort(dbArbZeitSort.SortByEnum.Kommen);
            at.Zeiten.Sort(azsort);
            if (d1.Ticks == ParamVal.Date0.Ticks) d1 = at.TagesDatum;
            foreach (dbArbZeit az in at.Zeiten)
                if (!az.Deleted)
                    if (az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz)
                    {
                        if (az.Kommen != ParamVal.Date0)
                        {
                            if ((d1.Ticks > az.Kommen.Ticks) & (d1.Ticks != ParamVal.Date0.Ticks) & (az.Kommen.Ticks != ParamVal.Date0.Ticks))
                            {
                                LConsistError.Text = "Fehler Zeit�berschneidung: " + az.Kommen.ToShortDateString() + " " + az.Kommen.ToShortTimeString();
                                return false;
                            }
                            d1 = az.Kommen;
                            if ((d1.Ticks > az.Gehen.Ticks) & (d1.Ticks != ParamVal.Date0.Ticks) & (az.Gehen.Ticks != ParamVal.Date0.Ticks))
                            {
                                LConsistError.Text = "Fehler Zeit�berschneidung: " + az.Gehen.ToShortDateString() + " " + az.Gehen.ToShortTimeString();
                                return false;
                            }
                            d1 = az.Gehen;
                        }
                    }
        }
        foreach (dbArbTag at in MBericht.Tage)
        {
            dbArbZeitSort azsort = new dbArbZeitSort(dbArbZeitSort.SortByEnum.Kommen);
            at.Zeiten.Sort(azsort);
            // Defect #5759. Die hilfsvariable sindNurSTdAbsenzen wird feden Tag als true
            // initialisiert und auf false wird gesetzt erst dann wenn am Tag ein ZeitTyp
            // ungleich stdAbsenz erfasst ist.
            // Erg�nzung durch Defect #5828
            // FM wird ausgegeben nur wenn ZA als StdAbsenz an einem Tag erfasst ist
            bool sindNurSTdAbsenzen = true;
            foreach (dbArbZeit az in at.Zeiten)
            {
                if (!az.Deleted)
                {
                    if (az.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz)
                    {
                        if (az.STDAbsenzID != "110") // Pr�fen ob StdAbsenz nicht ZA ist
                            sindNurSTdAbsenzen = false; // falls ja FM nicht ausgeben
                        //BAF 530042 Beginn
                        if (MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(az.Kommen.Date))
                        {
                            if (MBericht.Bearbeiter.MAMorgens(az.Kommen))
                                LConsistError.Text = "Fehler am " + at.TagesDatum.ToString("dd.MM.") + " Stundenweise Absenz au�erhalb Normal-Arbeitszeit (" + az.Kommen.ToString("HH:mm") + ")"; // Defect 5759, Fehlertext korr.
                        }
                        else //BAF 530042 Ende
                            if (MBericht.Bearbeiter.AZModell.MAMorgens(az.Kommen))
                                LConsistError.Text = "Fehler am " + at.TagesDatum.ToString("dd.MM.") + " Stundenweise Absenz au�erhalb Normal-Arbeitszeit (" + az.Kommen.ToString("HH:mm") + ")"; // Defect 5759, Fehlertext korr.
                        //Defect xxxx - wir definieren ein neues DateTime = gehen
                        DateTime dt = new DateTime(az.Gehen.Ticks);
                        if (az.Kommen.Day != az.Gehen.Day)// wenn das gehen um mitternacht angesetzt ist, dann ist gehen praktisch am n�chste Tag um 00:00
                            dt = dt.AddMinutes(-1); //wenn gehen um Mitternacht, dann ziehen wir eine minute von 00:00 weg, somit bekommen wir 23:59
                        //BAF 530042 Beginn
                        if (MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(dt.Date))
                        {
                            if (MBericht.Bearbeiter.MAAbends(dt))
                                LConsistError.Text = "Fehler am " + at.TagesDatum.ToString("dd.MM.") + " Stundenweise Absenz au�erhalb Normal-Arbeitszeit (" + az.Gehen.ToString("HH:mm") + ")"; // Defect 5759, Fehlertext korr.
                        }
                        else //BAF 530042 Ende
                            if (MBericht.Bearbeiter.AZModell.MAAbends(dt))//az.Gehen))//nun pr�ffen wir nach dt und nicht mehr nach gehen
                                LConsistError.Text = "Fehler am " + at.TagesDatum.ToString("dd.MM.") + " Stundenweise Absenz au�erhalb Normal-Arbeitszeit (" + az.Gehen.ToString("HH:mm") + ")"; // Defect 5759, Fehlertext korr.
                    }
                    else
                        sindNurSTdAbsenzen = false;
                }
            }
            // Defect #5759 - Fehlertext ausgeben falls sindNurSTdAbsenzen bleibt auf true
            if (sindNurSTdAbsenzen)
                LConsistError.Text = "Fehler am " + at.TagesDatum.ToString("dd.MM.") + " Verwenden Sie die ganzt�gige ZA Absenz anstatt der stundenweise ZA!!!";
        }

        return (LConsistError.Text == "");
    }

    private void ClearTable()
    {
        phListe.Controls.Clear();
        CheckConsistency();
    }

    private void BuildTable()
    {
        bool bRelKennzChecked = false;
        dNormStd = 0.00f;       // Defect 3352, 3360, 3375
        dUEStd50 = 0.00f;       // Defect 3352, 3360, 3375
        dUEStd100 = 0.00f;      // Defect 3352, 3360, 3375
        float summe = 0.00f;
        Table TabListe = new Table();
        TabListe.Width = Unit.Percentage(95);
        CtrlID = 0;
        string[] wTag = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa." };
        string[] ht = new string[] { "Datum", "Relevanz", "Kommen", "Gehen", "RB", "NormStd", "50%", "100%", "Prod.", "GK", "Absenz", "GT-Absenz", "Schl�ssel", "Zeile" }; //TAPM-20 - Rufbereitschaft RB
        ///Create Header
        TableRow hr = new TableRow();
        hr.CssClass = "TabHeader";
        for (int i = 0; i < ht.Length; i++)
        {
            TableCell hc = new TableCell();
            Label hl = new Label();
            hl.Text = ht[i];
            if (hl.Text == "RB")//TAPM-20 Tooltip um RB zu erl�uten
                hl.ToolTip = "Einsatz w�hrend der Rufbereitschaft";
            hl.Font.Bold = true;
            hc.Controls.Add(hl);
            hc.CssClass = "TabHeader";
            hr.Cells.Add(hc);
        }
        TabListe.Rows.Add(hr);

        foreach (dbArbTag tag in MBericht.Tage)
        {
            tag.pauseBerechnen = pauseBerechnen; // Defect #5690
            //Build 1st Line for each day
            tag.PauseBerechnen();
            Label ltag = new Label();
            ltag.Text = wTag[(int)tag.TagesDatum.DayOfWeek] + tag.TagesDatum.Day.ToString() + "." + tag.TagesDatum.Month.ToString() + ".";
            bool showDatum = true;
            int iZeit = -1;
            int iZeilen = 0;
            bool bCreateDelButton = true; // Defect 4099, kein Delete Button bei Krankheit/Unfall erzeugen
            foreach (dbArbZeit az in tag.Zeiten)
            {
                iZeit++;
                if (!az.Deleted)
                {
                    iZeilen++;
                    TableRow r = new TableRow();
                    TableCell c1 = new TableCell();
                    c1.ID = tag.Tag.ToString() + "-" + iZeit.ToString();
                    Label ldebug = new Label();
                    ldebug.Text = c1.ID;
                    //c1.Controls.Add(ldebug);
                    TableCell cPause = new TableCell();
                    CheckBox chkPause = new CheckBox();
                    if (showDatum)
                    {
                        chkPause.ID = c1.ID + "chkp";
                        chkPause.Checked = tag.Relevanz; //wird zuk�nfitg f�r Relevanz verwendet
                        chkPause.CheckedChanged += new EventHandler(chkPause_CheckedChanged);
                        c1.Controls.Add(ltag);
                        cPause.Controls.Add(chkPause);
                    }
                    TableCell c2 = new TableCell();
                    TextBox kommen = new TextBox();

                    kommen.ID = c1.ID + "kommen";
                    if (az.Kommen != ParamVal.Date0) kommen.Text = az.Kommen.ToShortTimeString();
                    kommen.Width = Unit.Pixel(50);
                    //kommen.Enabled = DarfIchDas(az);
                    kommen.Enabled = DarfIchDas(az);
                    kommen.ToolTip = az.GKAuftragNR;
                    CustomValidator vk = new CustomValidator();
                    vk.ID = c1.ID + "kommenv";
                    vk.Text = "Geben Sie bitte eine g�ltige Uhrzeit an oder lassen Sie das Feld leer.";
                    vk.ErrorMessage = "*";
                    vk.ControlToValidate = kommen.ID;
                    vk.ValidateEmptyText = true;
                    vk.EnableClientScript = false;
                    vk.ServerValidate += new ServerValidateEventHandler(KommenValidator_Validate);

                    if (az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz)
                    {
                        c2.Controls.Add(kommen); c2.Controls.Add(vk);
                    }

                    // Defect 4622:
                    // Bei Aenderungen im Zeitstempel kommen, wird MyTextboxChanged() aufgerufen,
                    // der Label LabelAktWarn wird angezeigt
                    kommen.Attributes["onchange"] = "javascript:MyTextboxChanged();";

                    TableCell c3 = new TableCell();
                    TextBox gehen = new TextBox();
                    gehen.ID = c1.ID + "gehen";
                    if (az.Gehen != ParamVal.Date0)
                    {
                        //TAPM-27 ist letztes Tag des Monats
                        if (tag.Tag == MBericht.Tage.Count)
                        {
                            if (az.Gehen.ToShortTimeString() == "00:00")
                            {
                                //falls 00:00 eingetragen ist, dann reduzieren wir es um eine minute
                                //00:00 ist in dem Fall f�r AZM schon das n�chste Monat
                                az.Gehen = az.Gehen.AddMinutes(-1);
                            }

                        }
                        gehen.Text = az.Gehen.ToShortTimeString();
                    }
                    gehen.Width = Unit.Pixel(50);
                    gehen.Enabled = DarfIchDas(az);
                    gehen.ToolTip = az.GKAuftragNR;
                    CustomValidator vg = new CustomValidator();
                    vg.ID = c1.ID + "gehenv";
                    vg.Text = "Geben Sie bitte eine g�ltige Uhrzeit an oder lassen Sie das Feld leer.";
                    vg.ErrorMessage = "*";
                    vg.ControlToValidate = gehen.ID;
                    vg.ValidateEmptyText = true;
                    vg.EnableClientScript = false;
                    vg.ServerValidate += new ServerValidateEventHandler(GehenValidator_Validate);
                    if (az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz)
                    {
                        c3.Controls.Add(gehen); c3.Controls.Add(vg);
                    }

                    // Defect 4622:
                    // Bei Aenderungen im Zeitstempel gehen, wird MyTextboxChanged() aufgerufen,
                    // der Label LabelAktWarn wird angezeigt
                    gehen.Attributes["onchange"] = "javascript:MyTextboxChanged();";

                    // TAPM 20 - Rufbereitschaft Checkbox vorbereiten
                    TableCell c13 = new TableCell();
                    CheckBox checkBereitschaft = new CheckBox();
                    checkBereitschaft.ID = c1.ID + "chkb";
                    //checkBereitschaft.AutoPostBack = true;
                    checkBereitschaft.Attributes["onclick"] = "javascript:MyTextboxChanged();";
                    if ((az.ZeitTyp == dbArbZeit.ArbZeitType.produktiv || az.ZeitTyp == dbArbZeit.ArbZeitType.gk) && kommen.Enabled)
                    {
                        checkBereitschaft.Checked = ((az.Params as dbAZ_ARBZEITParams).BEREIT.Value.ToString() == "1");
                        checkBereitschaft.Enabled = true;
                        checkBereitschaft.CheckedChanged += new EventHandler(CheckBereitschaftChanged);
                    }
                    else
                    {
                        checkBereitschaft.Checked = false;
                        checkBereitschaft.Enabled = false;
                        //az.Bereitschaft = false;
                    }
                    c13.HorizontalAlign = HorizontalAlign.Center;
                    c13.Controls.Add(checkBereitschaft);

                    TableCell c4 = new TableCell();
                    Label normStd = new Label();
                    // Beginn #4616, 4617, 4940 - AZ-Modell
                    if (az.NormStunden > 0) normStd.Text = Convert.ToDouble(az.NormStunden).ToString("N");
                    if (!kommen.Enabled)
                        normStd.Text = "";
                    c4.Controls.Add(normStd);
                    TableCell c5 = new TableCell();
                    Label ue50 = new Label();
                    if (az.UEStunden50 > 0) ue50.Text = Convert.ToDouble(az.UEStunden50).ToString("N");
                    if (!kommen.Enabled)
                        ue50.Text = "";
                    c5.Controls.Add(ue50);
                    TableCell c6 = new TableCell();
                    Label ue100 = new Label();
                    if (az.UEStunden100 > 0) ue100.Text = Convert.ToDouble(az.UEStunden100).ToString("N");
                    if (!kommen.Enabled)
                        ue100.Text = "";
                    // Ende #4616, 4617, 4940
                    c6.Controls.Add(ue100);
                    TableCell c7 = new TableCell();
                    RadioButton prod = new RadioButton();
                    prod.ID = c1.ID + "rbprod";
                    prod.Enabled = DarfIchDas(az);
                    prod.AutoPostBack = true;
                    prod.Checked = (az.ZeitTyp == dbArbZeit.ArbZeitType.produktiv);
                    prod.CheckedChanged += new EventHandler(prod_CheckedChanged);
                    if (az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz) c7.Controls.Add(prod);
                    TableCell c8 = new TableCell();
                    RadioButton gk = new RadioButton();
                    gk.ID = c1.ID + "rbgk";
                    gk.Enabled = DarfIchDas(az);
                    gk.AutoPostBack = true;
                    gk.Checked = (az.ZeitTyp == dbArbZeit.ArbZeitType.gk);
                    gk.CheckedChanged += new EventHandler(gk_CheckedChanged);
                    if (az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz) c8.Controls.Add(gk);
                    TableCell c9 = new TableCell();
                    RadioButton abs = new RadioButton();
                    abs.ID = c1.ID + "rbabs";
                    abs.Enabled = DarfIchDas(az);
                    abs.AutoPostBack = true;
                    abs.Checked = (az.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz);
                    abs.CheckedChanged += new EventHandler(abs_CheckedChanged);
                    if (az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz) c9.Controls.Add(abs);
                    TableCell c10 = new TableCell();
                    RadioButton gtabs = new RadioButton();
                    gtabs.ID = c1.ID + "rbgt";
                    gtabs.Enabled = DarfIchDas(az);

                    // Beginn Defect 4099
                    // Defect  5661 GN 25.11.2007
                    // �berpr�fung auf Fenstertage eingebaut
                    //BAF 530042 Beginn
                    if (MBericht.Bearbeiter.BerichtsMonat == 0)
                        MBericht.Bearbeiter.BerichtsMonat = MBericht.BerichtsMonat;
                    if(MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(tag.TagesDatum))
                    {
                        if (!MBericht.Bearbeiter.AZMKalenderTage[tag.TagesDatum].IstArbeitstag &&
                            !MBericht.Bearbeiter.AZMKalenderTage[tag.TagesDatum].IstFenstertag )
                        {
                            gtabs.Enabled = false;
                        }
                    }//BAF 530042 Ende
                    else
                    {
                        if (!Bearbeiter.IstArbeitstag(tag.TagesDatum) && !Bearbeiter.IstFenstertag(tag.TagesDatum))
                        {
                            gtabs.Enabled = false;
                        }
                        // Ende Defect 4099
                    }
                    gtabs.AutoPostBack = true;
                    gtabs.Checked = (az.ZeitTyp == dbArbZeit.ArbZeitType.gtAbsenz);
                    gtabs.CheckedChanged += new EventHandler(gtabs_CheckedChanged);
                    if (GetTagZeitenCount(tag) == 1) c10.Controls.Add(gtabs);
                    TableCell c11 = new TableCell();

                    if (az.ZeitTyp == dbArbZeit.ArbZeitType.produktiv)
                    {
                        DropDownList ddl = new DropDownList();
                        ddl.ID = c1.ID + "ddl1";
                        ddl.Enabled = DarfIchDas(az);
                        //TAPM-21 - falls LEistart noch nicht definiert/erfasst ist, dann wird sie mir defaultwert initialisiert
                        if ((az.Params as dbAZ_ARBZEITParams).LEISTART.Value.ToString() == "")
                            (az.Params as dbAZ_ARBZEITParams).LEISTART.Value = defLA;
                        ddl = MBericht.Bearbeiter.Commons.DDL(ddl,
                            (az.Params as dbAZ_ARBZEITParams).LEISTART.Value.ToString(),
                            MBericht.Bearbeiter.Commons.Leistungsart);

                        c11.Controls.Add(ddl);
                        if (ddl.Enabled)
                        {
                            LinkButton btnRollUp = new LinkButton();
                            btnRollUp.ID = c1.ID + "ddl2";
                            btnRollUp.CommandName = "RollUPL";
                            btnRollUp.CommandArgument = c1.ID;
                            btnRollUp.Text = "...";
                            btnRollUp.ToolTip = "Klicken Sie hier um diese Einstellung f�r nachfolgende Zeilen zu �bernehmen!";
                            btnRollUp.Command += new CommandEventHandler(btnRollup_Command);
                            c11.Controls.Add(btnRollUp);
                        }
                    }
                    if (az.ZeitTyp == dbArbZeit.ArbZeitType.gk)
                    {
                        DropDownList ddl = new DropDownList();
                        ddl.Enabled = DarfIchDas(az);
                        ddl.ID = c1.ID + "ddl3";
                        //TAPM-21 - falls LEistart noch nicht definiert/erfasst ist, dann wird sie mir defaultwert initialisiert
                        if ((az.Params as dbAZ_ARBZEITParams).LEISTART.Value.ToString() == "")
                            (az.Params as dbAZ_ARBZEITParams).LEISTART.Value = defLA;
                        ddl = MBericht.Bearbeiter.Commons.DDL(ddl, (az.Params as dbAZ_ARBZEITParams).LEISTART.Value.ToString(), MBericht.Bearbeiter.Commons.Leistungsart);
                        DropDownList ddl2 = new DropDownList();
                        ddl2.ID = c1.ID + "ddl4";
                        ddl2.Enabled = DarfIchDas(az);

                        //Defect 3766 obsolet durch Behebung von 4945, 5254, 5313
                        //Defect 4945, 5254, 5313 SQL-Skript veschoben noch dbCommons
                        ddl2 = MBericht.Bearbeiter.Commons.DDL(ddl2, (az.Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString(), MBericht.Bearbeiter.Commons.GK_Auftrag);
                        c11.Controls.Add(ddl);
                        c11.Controls.Add(ddl2);
                        if (ddl.Enabled)
                        {
                            LinkButton btnRollUp = new LinkButton();
                            btnRollUp.ID = c1.ID + "btnroll";
                            btnRollUp.CommandName = "RollUPL";
                            btnRollUp.CommandArgument = c1.ID;
                            btnRollUp.Text = "...";
                            btnRollUp.ToolTip = "Klicken Sie hier um diese Einstellung f�r die nachfolgende Zeilen zu �bernehmen!";
                            btnRollUp.Command += new CommandEventHandler(btnRollup_Command);
                            c11.Controls.Add(btnRollUp);
                        }
                    }
                    if (az.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz)
                    {
                        DropDownList ddl = new DropDownList();
                        ddl.ID = c1.ID + "ddl6";
                        ddl.Enabled = DarfIchDas(az);
                        ddl = MBericht.Bearbeiter.Commons.DDL2(ddl, (az.Params as dbAZ_ARBZEITParams).STDABSENZID.Value.ToString(), MBericht.Bearbeiter.Commons.STDAbsenzID, MBericht.Bearbeiter.KVOption);
                        c11.Controls.Add(ddl);
                        if (ddl.Enabled)
                        {
                            LinkButton btnRollUp = new LinkButton();
                            btnRollUp.ID = c1.ID + "btnRoll";
                            btnRollUp.CommandName = "RollUPL";
                            btnRollUp.CommandArgument = c1.ID;
                            btnRollUp.Text = "...";
                            btnRollUp.ToolTip = "Klicken Sie hier um diese Einstellung f�r nachfolgende Zeilen zu �bernhemen!";
                            btnRollUp.Command += new CommandEventHandler(btnRollup_Command);
                            c11.Controls.Add(btnRollUp);
                        }
                    }
                    if (az.ZeitTyp == dbArbZeit.ArbZeitType.gtAbsenz)
                    {
                        DropDownList ddl = new DropDownList();
                        ddl.ID = c1.ID + "ddl8";
                        ddl.Enabled = DarfIchDas(az);
                        ddl = MBericht.Bearbeiter.Commons.DDL2(ddl, (az.Params as dbAZ_KALTAGParams).GTABSENZID.Value.ToString(), MBericht.Bearbeiter.Commons.GTAbsenze, MBericht.Bearbeiter.KVOption);
                        c11.Controls.Add(ddl);

                        // Beginn Defect 4099
                        // Anzeige von Unfall/Krankheit in DropDownList, nicht �nderbar
                        int iGTAbsenzID = Convert.ToInt32((az.Params as dbAZ_KALTAGParams).GTABSENZID.Value);
                        switch (iGTAbsenzID)
                        {
                            case dbGTAbsenz.gtKrankheit:
                            case dbGTAbsenz.gtKrankheit_begin:
                            case dbGTAbsenz.gtKrankheit_ende:
                            case dbGTAbsenz.gtUnfall:
                            case dbGTAbsenz.gtUnfall_begin:
                            case dbGTAbsenz.gtUnfall_ende:
                                ddl.Enabled = false;
                                bCreateDelButton = false;
                                break;
                            default:
                                //BAF 530042 Beginn
                                if (MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(tag.TagesDatum))
                                {
                                    if (!MBericht.Bearbeiter.AZMKalenderTage[tag.TagesDatum].IstArbeitstag)
                                        ddl.Enabled = false;
                                }//BAF 530042 Ende
                                else
                                {
                                    if (!Bearbeiter.IstArbeitstag(tag.TagesDatum))
                                    {
                                        ddl.Enabled = false;
                                    }
                                }
                                // Auswahl von Unfall/Krankheit in DropDownList nicht erm�glichen

                                foreach (ListItem li in ddl.Items)
                                {
                                    switch (Convert.ToInt32(li.Value))
                                    {
                                        case dbGTAbsenz.gtKrankheit:
                                        case dbGTAbsenz.gtKrankheit_begin:
                                        case dbGTAbsenz.gtKrankheit_ende:
                                        case dbGTAbsenz.gtUnfall:
                                        case dbGTAbsenz.gtUnfall_begin:
                                        case dbGTAbsenz.gtUnfall_ende:
                                            li.Enabled = false;
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                bCreateDelButton = true;
                                break;
                        }
                        // Ende Defect 4099
                    }
                    TableCell c12 = new TableCell();
                    if ((az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz) & (showDatum)) //dann zeige auch den Button!
                    {
                        LinkButton btnAdd = new LinkButton();
                        btnAdd.ID = c1.ID + "btnadd";
                        btnAdd.CommandName = "Add1Line";
                        btnAdd.CommandArgument = c1.ID;
                        btnAdd.Text = "Zeile hinzuf�gen";
                        btnAdd.ToolTip = "Eine Zeile zu diesem Tag hinzuzuf�gen.";
                        btnAdd.Command += new CommandEventHandler(btnAdd_Command);
                        c12.Controls.Add(btnAdd);
                        Label lll = new Label();
                        lll.Text = " - ";
                        c12.Controls.Add(lll);
                    }
                    LinkButton btnDel = new LinkButton();
                    btnDel.ID = c1.ID + "btndel";
                    btnDel.Enabled = DarfIchDas(az);
                    btnDel.CommandName = "Del1Line";
                    btnDel.CommandArgument = c1.ID;
                    btnDel.Text = "l�schen";
                    btnDel.ToolTip = "Diese Zeile zu l�schen.";
                    btnDel.Command += new CommandEventHandler(btnDel_Command);
                    c12.Controls.Add(btnDel);

                    // Beginn Defect 4099
                    // bei Krankheit/Unfall den Delete Button nicht anzeigen
                    // Delete nicht erlaubt
                    if (!bCreateDelButton)
                    {
                        btnDel.Visible = false;
                    }
                    // Ende Defect 4099

                    ArrayList cs = new ArrayList();
                    cs.Add(c1);
                    cs.Add(cPause);
                    cs.Add(c2);
                    cs.Add(c3);
                    cs.Add(c13); //TAPM-20 - RB Checkbox zeichnen
                    cs.Add(c4);
                    cs.Add(c5);
                    cs.Add(c6);
                    cs.Add(c7);
                    cs.Add(c8);
                    cs.Add(c9);
                    cs.Add(c10);
                    cs.Add(c11);
                    cs.Add(c12);
                    foreach (TableCell cc in cs)
                    {
                        if (showDatum) cc.CssClass = "TabNewDay" + CssWE(tag);
                        else cc.CssClass = "TabZeile" + CssWE(tag);
                        cc.VerticalAlign = VerticalAlign.Middle;
                        r.Cells.Add(cc);
                    }
                    showDatum = false;
                    TabListe.Rows.Add(r);
                }
                if (az.Arbeitstag.Relevanz)
                {

                    bRelKennzChecked = true;
                    // akualisieren d. Stundensummen in Abhangigkeit des Relevanzknz
                    /* Beginn Defect #4754: Auch wenn Tag relevant ist, d�rfen f�r
                     * die EB-Summen nur die Stunden des aktuellen Projektes
                     * ber�cksichtigt werden
                     * */

                    // Defect #4754
                    //if (Projekt.Params.KTOBJ.Value.ToString() == az.AuftragNr)
                    if ((az.Params is dbAZ_ARBZEITParams) &&
                        az.STDAbsenzID != "110" &&
                        (az.Params as dbAZ_ARBZEITParams).EBID.Value.ToString() == MBericht.Params.EBID.Value.ToString())
                    { // Ende Defect #4754
                        // Defect 3352, 3360, 3375
                        if (tag.NormStd > 0) dNormStd += (float)az.NormStunden;
                        if (tag.UEStunden50 > 0) dUEStd50 += (float)az.UEStunden50;
                        if (tag.UEStunden100 > 0) dUEStd100 += (float)az.UEStunden100;
                        // Ende 3352, 3360, 3375
                    }
                }
            }
            if (iZeilen > 1)
            {
                Label l1 = new Label();
                Label l2 = new Label();
                Label l3 = new Label();
                Label l4 = new Label();

                l1.Text = "Summe " + tag.TagesDatum.Day.ToString() + "." + tag.TagesDatum.Month.ToString() + ".";
                // Defect 3352, 3360, 3375
                if (tag.NormStd > 0) l2.Text = tag.NormStd.ToString("N");
                if (tag.UEStunden50 > 0) l3.Text = tag.UEStunden50.ToString("N");
                if (tag.UEStunden100 > 0) l4.Text = tag.UEStunden100.ToString("N");

                // Ende Defect 3352, 3360, 3375
                TableRow r = new TableRow();
                TableCell c1 = new TableCell(); c1.Controls.Add(l1); c1.CssClass = "TabNewDay" + CssWE(tag); c1.ColumnSpan = 4; c1.HorizontalAlign = HorizontalAlign.Right;//TAPM-20 jetzt sind es 4 ColumnSpan;
                TableCell cPause = new TableCell(); cPause.CssClass = "TabNewDay" + CssWE(tag);
                TableCell c2 = new TableCell(); c2.Controls.Add(l2); c2.CssClass = "TabNewDay" + CssWE(tag);
                TableCell c3 = new TableCell(); c3.Controls.Add(l3); c3.CssClass = "TabNewDay" + CssWE(tag);
                TableCell c4 = new TableCell(); c4.Controls.Add(l4); c4.CssClass = "TabNewDay" + CssWE(tag); c4.ColumnSpan = 7;
                r.Cells.Add(c1); r.Cells.Add(cPause); r.Cells.Add(c2); r.Cells.Add(c3); r.Cells.Add(c4);
                TabListe.Rows.Add(r);
            }
        }
        //Summenzeile:
        if (true)
        {
            Label l1 = new Label();
            Label l2 = new Label();
            Label l3 = new Label();
            Label l4 = new Label();
            Label l5 = new Label();
            l1.Text = "Summe EB";
            /*
                  // Defect 5024, 5082
             *    // Wenn nur am Wochende gearbeitet wurde, ist "dMormStd" gleich null,
             *    // was zu falschen Summen - EB (NormStd, %50, 100%) im Einsatzbericht f�hrt. 
             *    // Daher folgende Code deaktiviert 

                      if (dNormStd == 0) // sollte immer nur beim "first load"
                      {
                              // das Relevant  ist beim Erstanlauf nicht gesetzt (default),
                              // daher die aus der DB gelesenen Summe sind anzeigen
                              // damit ersparrt man sich das Manuelle "Aktualisieren" durch den Anweder
                              if (MBericht.NormStunden > 0) dNormStd = (float)MBericht.NormStunden;
                              if (MBericht.UE50 > 0) dUEStd50 = (float)MBericht.UE50;
                              if (MBericht.UE100 > 0) dUEStd100 = (float)MBericht.UE100;
                      }
                  // Ende Defect 5024, 5082
             */
            if (bRelKennzChecked)
            {
                // Defect 3352, 3360, 3375
                double fsum; int isum;
                if (dNormStd > 0)
                {
                    fsum = dNormStd * 100;
                    isum = (int)fsum;
                    fsum = (float)isum / 100;
                    l2.Text = fsum.ToString();
                }

                if (dUEStd50 > 0)
                {
                    fsum = dUEStd50 * 100;
                    isum = (int)fsum;
                    fsum = (float)isum / 100;
                    l3.Text = fsum.ToString();
                }
                if (dUEStd100 > 0)
                {
                    fsum = dUEStd100 * 100;
                    isum = (int)fsum;
                    fsum = (float)isum / 100;
                    l4.Text = fsum.ToString();
                }

                // Ende Defect 3352, 3360, 3375
                summe = dNormStd + dUEStd50 + dUEStd100;
                fsum = summe * 100;
                isum = (int)fsum;
                fsum = (float)isum / 100;
                l5.Text = fsum.ToString("N");
            }
            TableRow r = new TableRow();
            TableCell c1 = new TableCell(); c1.Controls.Add(l1); c1.CssClass = "TabSumme"; c1.ColumnSpan = 5; c1.HorizontalAlign = HorizontalAlign.Left;//TAPM-20 jetzt sind es 5 ColumnSpan;
            TableCell c2 = new TableCell(); c2.Controls.Add(l2); c2.CssClass = "TabSumme";
            TableCell c3 = new TableCell(); c3.Controls.Add(l3); c3.CssClass = "TabSumme";
            TableCell c4 = new TableCell(); c4.Controls.Add(l4); c4.CssClass = "TabSumme";
            TableCell c5 = new TableCell(); c5.Controls.Add(l5); c5.CssClass = "TabSumme";
            TableCell c6 = new TableCell(); c6.CssClass = "TabSumme"; c6.ColumnSpan = 6;
            r.Cells.Add(c1); r.Cells.Add(c2); r.Cells.Add(c3); r.Cells.Add(c4); r.Cells.Add(c5); r.Cells.Add(c6);
            TabListe.Rows.Add(r);
        }
        // Defect 4501 - Meldung Anzeigen, wenn entweder Projekt od. Monteur nicht mehr g�ltig
        if (Convert.ToDateTime(MBericht.MaxDatum.ToShortDateString()).Ticks > Convert.ToDateTime(Projekt.Params.VALID.Value).Ticks)
        {

            lProjGueltigInfo.Visible = true;
            lProjGueltigInfo.Text = " Achtung - Dieses Projekt ist g�ltig bis    " + Convert.ToDateTime(Projekt.Params.VALID.Value).ToShortDateString().TrimEnd();
        }
        string Trennzch = " ";
        bool MAEinBed = Convert.ToDateTime(MBericht.MinDatum.ToShortDateString()).Ticks < MBericht.MA_firma_ein.Ticks;
        bool MAAusBed = Convert.ToDateTime(MBericht.MaxDatum.ToShortDateString()).Ticks > MBericht.MA_firma_aus.Ticks;
        bool MAAzmEinBed = Convert.ToDateTime(MBericht.MinDatum.ToShortDateString()).Ticks < MBericht.MA_gueltig_von.Ticks;
        bool MAAzmAusBed = Convert.ToDateTime(MBericht.MaxDatum.ToShortDateString()).Ticks > MBericht.MA_gueltig_bis.Ticks;
        lMAgueltigInfo.Visible = MAEinBed || MAAusBed;
        if (lMAgueltigInfo.Visible)
        {
            if (lProjGueltigInfo.Visible) Trennzch = ", ";
            if (MAEinBed)
            {
                lMAgueltigInfo.Text = Trennzch + " Achtung - Eintrittsdatum " + MBericht.MA_firma_ein.ToShortDateString();

            }
            else
            {
                lMAgueltigInfo.Text = Trennzch + " Achtung - Austrittsdatum " + MBericht.MA_firma_aus.ToShortDateString();

            }
        }
        Trennzch = " ";
        lMAZModell.Visible = MAAzmEinBed || MAAzmAusBed;
        if (lMAZModell.Visible)
        {
            if (MAAzmEinBed)
            {
                lMAZModell.Text = Trennzch + " Achtung - Mitarbeiterarbeitszeitmodell g�ltig ab " + MBericht.MA_gueltig_von.ToShortDateString();
            }
            else
            {
                lMAZModell.Text = Trennzch + " Achtung - Mitarbeiterarbeitszeitmodell g�ltig bis  " + MBericht.MA_gueltig_bis.ToShortDateString();
            }
        }

        // Ende Defect 4501

        phListe.Controls.Add(TabListe);
    }
    //TAPM-20 RB ist eingechecked oder ausgecheckt 
    void CheckBereitschaftChanged(object sender, EventArgs e)
    {
        //ReadTable();
        CheckBox cb = (CheckBox)sender;
        dbArbZeit z = GetArbzeitByID((cb.Parent.Parent as TableRow).Cells[0].ID);
        //z.Bereitschaft = cb.Checked;
        if (cb.Checked == true)
            (z.Params as dbAZ_ARBZEITParams).BEREIT.Value = "1";
        else
            (z.Params as dbAZ_ARBZEITParams).BEREIT.Value = "";
        //ClearTable();
        //BuildTable();
        Page.SetFocus((sender as Control));
    }

    void chkPause_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = (CheckBox)sender;
        dbArbZeit z = GetArbzeitByID((cb.Parent.Parent as TableRow).Cells[0].ID);
        z.Arbeitstag.Relevanz = cb.Checked;
    }

    private string CssWE(dbArbTag tag)
    {// hier sollte man auch noch die Feiertagsabfrage auf Tag implementieren
        string[] we = new string[] { "WE", "", "", "", "", "", "WE" };
        //BAF 530042 Beginn
        if (MBericht.Bearbeiter.BerichtsMonat == 0)
            MBericht.Bearbeiter.BerichtsMonat = MBericht.BerichtsMonat;
        if(MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(tag.TagesDatum))
        {
            if (!MBericht.Bearbeiter.AZMKalenderTage[tag.TagesDatum].IstArbeitstag)
                return we[0];
        }
        else //BAF 530042 Ende
        {
            if (!tag.MBericht.Bearbeiter.IstArbeitstag(tag.TagesDatum))
                return we[0];
        }
        return we[(int)tag.TagesDatum.DayOfWeek];
    }

    /// <summary>
    /// Ist das Control enabled?
    /// nur wenn die Arbeitszeit aus dem gleichen Einsatzbericht stammt und wenn das Tagesdatum zwischen Biginn und Ende der Baustelle liegt
    /// </summary>
    /// <param name="az"></param>
    /// <returns></returns>
    private bool DarfIchDas(dbArbZeit az)
    {
        // defect 4501: check MA - und Projektdaten
        bool MAProjDATOK = Checkgueltigkeit(az);     // 
        if (!MAProjDATOK) return false;              // entweder Projekt abgelaufen od. MA aus der FA ausgetretten 
        // ende defect 4501

        if (az.ZeitTyp == dbArbZeit.ArbZeitType.gtAbsenz) return true;
        bool DateOK = ((az.Arbeitstag.TagesDatum.Ticks >= Convert.ToDateTime(Projekt.Baustelle.Params.DATVON.Value).Ticks) &
                       (az.Arbeitstag.TagesDatum.Ticks <= Convert.ToDateTime(Projekt.Baustelle.Params.DATBIS.Value).Ticks));
        bool EBOK = (((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)az.Arbeitstag.MBericht.Params.EBID.Value) |
                     ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == 0));
        //TAPM-27 Beginn
        try
        {
            if (DateOK && EBOK && (int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == 0)
                (az.Params as dbAZ_ARBZEITParams).EBID.Value = MBericht.Params.EBID.Value;
        }
        catch
        {
            //do nothing
        }
        //TAPM-27 Ende
        return DateOK & EBOK;
    }
    // defect 4501
    /// <summary>
    /// Check die G�ltigkeit d. MA- und Projektdaten f. einen gegebenen EB-Tag
    /// 
    /// </summary>
    /// <param name="az"></param>
    /// <returns></returns>
    private bool Checkgueltigkeit(dbArbZeit az)
    {
        bool ProjektOK;
        bool MAAZModOK;
        bool MAOK;

        // Defect 4501: 
        //
        //   Es soll verhindert werden, da� 
        //      - der MA auf ein schon innerhalb dieses EB-Monats abgelaufenes Projekt kontiert, 	
        //        d.h. Bauprojekt.valid >= Einsatzbericht.Arbeitstag.TagesDatum                         (ProjektOK)
        //      - der MA auf ein schon innerhalb dieses EB-Monats abgelaufenes AZmodell verwendet,
        //        d.h. MA_gueltig_von <= Einsatzbericht.Arbeitstag.TagesDatum <= MA_gueltig_bis         (MAAZModOK)
        //      - Vor und nach dem Firmenaustritt, kein EB-generierung m�glich
        //        ma_stamm.eintritt <= Einsatzbericht.Arbeitstag.TagesDatum <= ma_stamm.austritt        (MAOK)
        //
        ProjektOK = az.Arbeitstag.TagesDatum.Ticks <= Convert.ToDateTime(Projekt.Params.VALID.Value).Ticks;

        // Beginn #4616, 4617, 4940 - AZ-Modell
        //MAAZModOK = MBericht.MA_gueltig_von.Ticks <= az.Arbeitstag.TagesDatum.Ticks && az.Arbeitstag.TagesDatum.Ticks <= MBericht.MA_gueltig_bis.Ticks;
        MAAZModOK = true;
        MAOK = MBericht.MA_firma_ein.Ticks <= az.Arbeitstag.TagesDatum.Ticks && az.Arbeitstag.TagesDatum.Ticks <= MBericht.MA_firma_aus.Ticks;
        // G�ltig AZM?
        //*if ((az.Kommen.Hour + az.Kommen.Minute) == 0)
        //*    MAOK = false;
        // Ende #4616, 4617, 4940
        return ProjektOK & MAAZModOK & MAOK;
    }
    // Ende defect 4501
    int GetTagZeitenCount(dbArbTag tag)
    {
        int iCount = 0;
        foreach (dbArbZeit az in tag.Zeiten) if (!az.Deleted) iCount++;
        return iCount;
    }

    int GetTagByID(string ID)
    {
        return Convert.ToInt32(ID.Substring(0, ID.IndexOf("-"))) - 1;
    }
    int GetZeitByID(string ID)
    {
        return Convert.ToInt32(ID.Substring(ID.IndexOf("-") + 1));
    }
    dbArbZeit GetArbzeitByID(string ID)
    {
        return ((MBericht.Tage[GetTagByID(ID)] as dbArbTag).Zeiten[GetZeitByID(ID)] as dbArbZeit);
    }

    void btnDel_Command(object sender, CommandEventArgs e)
    {
        ReadTable();
        LinkButton b = (LinkButton)sender;
        dbArbZeit z = GetArbzeitByID((b.Parent.Parent as TableRow).Cells[0].ID);
        if (GetTagZeitenCount(z.Arbeitstag) == 1)
        {
            dbArbZeit z2 = new dbArbZeit(z.Arbeitstag, dbArbZeit.ArbZeitType.produktiv, false);
            z.Arbeitstag.Zeiten.Add(z2);
            //z.Arbeitstag.Zeiten.Remove(z);
            if (z.AllowUpdate)
                z.Deleted = true;
            else
                z.Arbeitstag.Zeiten.Remove(z);
        }
        else
        {
            if (z.AllowUpdate)
                z.Deleted = true;
            else
                z.Arbeitstag.Zeiten.Remove(z);
        }
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }

    void btnRollup_Command(object sender, CommandEventArgs e)
    {
        ReadTable();
        LinkButton b = (LinkButton)sender;
        dbArbZeit z = GetArbzeitByID((b.Parent.Parent as TableRow).Cells[0].ID);
        bool rollup = false;
        foreach (dbArbTag at in z.Arbeitstag.MBericht.Tage)
            foreach (dbArbZeit az in at.Zeiten)
            {
                if (at.Tag >= z.Arbeitstag.Tag)
                    if (!rollup)
                        rollup = (z == az);
                    else
                    {
                        // Defect# 4236 - Fehler bei der Erfassung eines Montageberichts
                        // Relevanz hinzugef�gt
                        // Defect# 5435 GN 12.9.07 Auftragsnummern wurden EB�bergreifend �bernommen
                        // Ebid hinzugef�gt
                        if (at.Relevanz == true && az.ZeitTyp == z.ZeitTyp && (az.Params as dbAZ_ARBZEITParams).EBID.Value.ToString() == (z.Params as dbAZ_ARBZEITParams).EBID.Value.ToString())
                        {
                            // ende 4236
                            az.Leistart = z.Leistart;
                            az.STDAbsenzID = z.STDAbsenzID;
                            az.GKAuftragNR = z.GKAuftragNR;
                        }
                    }
            }
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }

    void btnAdd_Command(object sender, CommandEventArgs e)
    {
        ReadTable();
        LinkButton b = (LinkButton)sender;
        dbArbZeit z = GetArbzeitByID((b.Parent.Parent as TableRow).Cells[0].ID);
        // defect 4501 - nur wenn Projekt und MA g�ltig darf ein neuer Stempel erfasst werden
        if (Checkgueltigkeit(z))
        {
            // ende defect 4501
            //z.Arbeitstag.Zeiten.Add(new dbArbZeit(z.Arbeitstag, dbArbZeit.ArbZeitType.produktiv, true));
            //TAPM-27
            //bei neu AZ fehlt EBID ... wirkt sich in der Summe EB
            dbArbZeit newAZ = new dbArbZeit(z.Arbeitstag, dbArbZeit.ArbZeitType.produktiv, true);
            try
            {
                (newAZ.Params as dbAZ_ARBZEITParams).EBID.Value = MBericht.Params.EBID.Value;
            }
            catch
            {
                //do nothing
            }
            z.Arbeitstag.Zeiten.Add(newAZ);
            z.Arbeitstag.Relevanz = true;
            ClearTable();
            BuildTable();
            Page.SetFocus((sender as Control));
        }
    }
    private string SozStelleproMandant()
    {
        if (MBericht.Bearbeiter.Mandant.MANDANT.ToUpper() == "MR" || MBericht.Bearbeiter.Mandant.MANDANT.ToUpper() == "RU")
            return "49";
        else
            return "10";
    }
    void gtabs_CheckedChanged(object sender, EventArgs e)
    {
        ReadTable();
        RadioButton rb = (RadioButton)sender;
        dbArbZeit z = GetArbzeitByID((rb.Parent.Parent as TableRow).Cells[0].ID);
        //TAPM-20 - beim wechseln von prod oder gk zur absenz, RB auschalten
        try
        {
            (z.Params as dbAZ_ARBZEITParams).BEREIT.Value = "";
        }
        catch
        { }
        if ((sender as RadioButton).Checked)
        {
            foreach (dbArbZeit az in (MBericht.Tage[z.Arbeitstag.Tag - 1] as dbArbTag).Zeiten)
            {
                if (az.AllowUpdate)
                    az.Deleted = true;
                else
                {
                    az.Arbeitstag.Zeiten.Remove(az);
                    break;
                }
            }
            z.Arbeitstag.Zeiten.Add(new dbArbZeit(z.Arbeitstag, dbArbZeit.ArbZeitType.gtAbsenz));
            z.Arbeitstag.Relevanz = true;
        }
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }

    void abs_CheckedChanged(object sender, EventArgs e)
    {
        ReadTable();
        RadioButton rb = (RadioButton)sender;
        dbArbZeit z = GetArbzeitByID((rb.Parent.Parent as TableRow).Cells[0].ID);
        //TAPM-20 - beim wechseln von prod oder gk zur absenz, RB auschalten
        try
        {
            (z.Params as dbAZ_ARBZEITParams).BEREIT.Value = "";
            //TAPM-38 - �berstunden bei STD Absenzen auf 0 setzen
            (z.Params as dbAZ_ARBZEITParams).UESTD100.Value = 0;
            (z.Params as dbAZ_ARBZEITParams).UESTD50.Value = 0;
        }
        catch
        { }
        z.ZeitTyp = dbArbZeit.ArbZeitType.stdAbsenz;
        z.GKAuftragNR = "";
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }

    void gk_CheckedChanged(object sender, EventArgs e)
    {
        ReadTable();
        RadioButton rb = (RadioButton)sender;
        dbArbZeit z = GetArbzeitByID((rb.Parent.Parent as TableRow).Cells[0].ID);
        z.ZeitTyp = dbArbZeit.ArbZeitType.gk;
        z.STDAbsenzID = "";
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }

    void prod_CheckedChanged(object sender, EventArgs e)
    {
        ReadTable();
        RadioButton rb = (RadioButton)sender;
        dbArbZeit z = GetArbzeitByID((rb.Parent.Parent as TableRow).Cells[0].ID);
        z.ZeitTyp = dbArbZeit.ArbZeitType.produktiv;
        z.GKAuftragNR = "";
        z.STDAbsenzID = "";
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }

    protected void KommenValidator_Validate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = false;
        TextBox k = (TextBox)(source as CustomValidator).Parent.FindControl((source as CustomValidator).ControlToValidate);
        args.IsValid = ((k.Text == "") || (RangeCheck.IsTime(k.Text)));
        TextBox g = (TextBox)(k.Parent.Parent as TableRow).Cells[3].Controls[0];
        dbArbZeit az = GetArbzeitByID((k.Parent.Parent as TableRow).Cells[0].ID);
    }
    protected void GehenValidator_Validate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = false;
        TextBox g = (TextBox)(source as CustomValidator).Parent.FindControl((source as CustomValidator).ControlToValidate);
        TextBox k = (TextBox)(g.Parent.Parent as TableRow).Cells[2].Controls[0];
        dbArbZeit az = GetArbzeitByID((k.Parent.Parent as TableRow).Cells[0].ID);
        args.IsValid = ((g.Text == "") || (RangeCheck.IsTime(g.Text)));
    }
    public void OnSave_Click()
    {
        MBericht = (dbMontBer)Session["MBericht"];
        ReadTable();
        Session["MBericht"] = MBericht;
        ClearTable();
        BuildTable();
    }

    /* Beginn Defect #4795: Keine std.weise Absenzen ausserhalb Normalarbeitszeit.
     * Checkfunktion wird von EditEB.aspx.cs aufgerufen, um gegebenenfalls das
     * Speichern falscher Zeitstempel zu verhindern. Dies w�rde in Folge zu 
     * Problem mit AZM-Kommunikation f�hren
     * */
    public bool TimestampsAreCorrect()
    {
        bool blnCorrectTimestamps = true;
        bool blnValidFormatTimestamps = true; // Defect # 4941

        MBericht = (dbMontBer)Session["MBericht"];
        blnValidFormatTimestamps = ReadTable(); // Defect # 4941
        Session["MBericht"] = MBericht;
        phListe.Controls.Clear();
        blnCorrectTimestamps = CheckConsistency();
        BuildTable();

        return blnCorrectTimestamps & blnValidFormatTimestamps; // Defect # 4941
    }

    // Set focus to Btn - Aktualisieren im Fehlerfall
    public void SetFocusToBtnRefresh()
    {
        Page.SetFocus(btnRefresh);
    }
    // Ende Defect #4795

    protected void btnSelect_Click(object sender, EventArgs e)
    {
        ReadTable();
        /* Beginn Defect #3372
         * Relevanzkennzeichen nur an Arbeitstagen setzen. */
        foreach (dbArbTag at in MBericht.Tage)
        {
            //BAF 530042 Beginn
            if (at.MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(at.TagesDatum) )
            {
                if( at.MBericht.Bearbeiter.AZMKalenderTage[at.TagesDatum].IstArbeitstag )
                    at.Relevanz = true;
            }//BAF 530042 Ende
            else
                if (at.MBericht.Bearbeiter.IstArbeitstag(at.TagesDatum))
                    at.Relevanz = true;
        }
        /* Ende Defect #3372
         */
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }
    protected void btnDeselect_Click(object sender, EventArgs e)
    {
        ReadTable();
        foreach (dbArbTag at in MBericht.Tage)
            at.Relevanz = false;
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }
    protected void btnVorbelegung_Click(object sender, EventArgs e)
    {
        ReadTable();
        foreach (dbArbTag at in MBericht.Tage)
        {
            if ((at.Relevanz) && (!at.GTAbsenz))
            {
                foreach (dbArbZeit az in at.Zeiten)
                    if ((((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MBericht.Params.EBID.Value)
                        | ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == 0))
                        && ((az.Kommen.Ticks == ParamVal.Date0.Ticks) & (az.Gehen.Ticks == ParamVal.Date0.Ticks) & (at.AnzahlZeiten == 1)))
                    {
                        dbArbTag at2 = new dbArbTag(MBericht, at.Tag);
                        dbArbZeit z2 = new dbArbZeit(at2, dbArbZeit.ArbZeitType.produktiv, true);
                        az.Kommen = z2.Kommen;
                        az.Gehen = z2.Gehen;
                    }
            }
        }
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        ReadTable();
        foreach (dbArbTag at in MBericht.Tage)
        {
            if ((at.Relevanz) && (!at.GTAbsenz))
            {
                for (int i = at.Zeiten.Count - 1; i >= 0; i--)
                {
                    dbArbZeit az = (dbArbZeit)at.Zeiten[i];
                    if (((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MBericht.Params.EBID.Value)
                        | ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == 0))
                    {
                        if (az.AllowUpdate)
                            az.Deleted = true;
                        else
                            at.Zeiten.RemoveAt(i);
                    }
                }
                if (at.AnzahlZeiten == 0)
                {
                    dbArbZeit z2 = new dbArbZeit(at, dbArbZeit.ArbZeitType.produktiv, false);
                    at.Zeiten.Add(z2);
                }
            }
        }
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        ReadTable();
        ClearTable();
        BuildTable();
        Page.SetFocus((sender as Control));

        // Beginn Defect #4524: Durch 'Aktualisieren' wird eventuell
        // angezeigte Speicher/Freigabemeldung wieder gel�scht
        try
        {
            Control ctrlLabel = Page.FindControl("LabelErrorFreigabe");
            if (ctrlLabel is Label)
            {
                (ctrlLabel as Label).Text = "";
                ctrlLabel.Visible = false;
            }
        }
        catch (Exception ex)
        {
            string strErrMessage = ex.Message;
        }
        // Ende Defect #4524

        // Defect 4887:
        // �berpr�fung ob KFZ-Daten (Datumseingaben) korrekt,
        // und Fehlermeldung ausgeben
        bool IsKFZValid = KFZ.bOnlyValidKFZDaten;

        // �berpr�fung ob RAAuslagen (Datumseingaben) korrekt
        // und Fehlermeldung ausgeben
        bool IsRAAuslagenValid = RAAuslage.bOnlyValidRA;
        // Ende Defect 4887
    }

    // Beginn #5042, 5064 - L�schen von Einsatzbericht nicht m�glich
    protected void btnEBL�schen_Click(object sender, EventArgs e)
    {
        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
        {
            //dbSapReise sapReisen = new dbSapReise((int)MBericht.Params.PERSKEY.Value, MBericht.MinDatum, MBericht.Params.MANDANT.Value.ToString());
            dbSapReise sapReisen = new dbSapReise((int)MBericht.Bearbeiter.Params.PERSKEY.Value, MBericht.MinDatum, MBericht.Bearbeiter.Params.MANDANT.Value.ToString());
            if (!sapReisen.DeleteAllTrips())
            {
                lbEBL�schenFehler.Text = "Fehler beim l�schen bereits vorhandener Reisen. Einsatzbericht kann zurzeit nicht gel�scht werden!!!";
                lbEBL�schenFehler.Visible = true;
                return;
            }
        }


        /* Setzen QueriesTableAdatpter */
        SISSITableAdapters.SISSI_Queries taQueries = new SISSITableAdapters.SISSI_Queries();

        /* Setzen lokal Variablen */
        int deletedItems = 0;
        int ebid;

        /* Setzen EBID und EINSID */
        try { ebid = Convert.ToInt32(MBericht.Params.EBID.Value); }
        catch { ebid = -1; }

        /* EBID nicht null, EBID g�ltig */
        if (ebid != -1)
        {
            /* L�schen Einsatzbericht und Arbeitszeit Daten */
            try
            {
                deletedItems += taQueries.Delete_AUSLAGE(ebid);
                deletedItems += taQueries.Delete_ZULAGE(ebid);
                deletedItems += taQueries.Delete_ARBZEIT(ebid);
                deletedItems += taQueries.Delete_RAAUSLAGE(ebid);
                deletedItems += taQueries.Delete_TPM_RAKfzdaten(ebid);
                deletedItems += taQueries.Delete_EINSBER(ebid);

                if (deletedItems != 0)
                {
                    lbEBL�schenFehler.ForeColor = System.Drawing.Color.Blue;
                    lbEBL�schenFehler.Text = "Der Einsatzbericht wurde gel�scht!";
                }
                else
                    lbEBL�schenFehler.Text = "Dieser Einsatzbericht ist noch nicht gespeichert!";

                lbEBL�schenFehler.Visible = true;
                Parent.FindControl("btnSave").Visible = false;
                Parent.FindControl("cbFreigabe").Visible = false;

                /* Bei L�schen keine "Gespeichert" Meldung */
                if (Session["ErfEBAus_State"] != null)
                {
                    string[] stateParams = Session["ErfEBAus_State"].ToString().Split('|');
                    Session["ErfEBAus_State"] = String.Format("{0}|{1}|null", stateParams[0], stateParams[1]);
                }
            }
            catch
            {
                lbEBL�schenFehler.Text = "* Dieser Einsatzbericht kann nicht gel�scht werden! Datenbank Fehler.";
                lbEBL�schenFehler.Visible = true;
            }
        }
        else
        {
            lbEBL�schenFehler.Text = "* Dieser Einsatzbericht kann nicht gel�scht werden! EBID nicht g�ltig.";
            lbEBL�schenFehler.Visible = true;
        }
    }
    // Ende #5042, 5064

    // Bedginn #5080 - �ndern der Projektnummer f�r Einsatzbericht
    protected void ddlBaustelle_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlProjekt.DataBind();
    }
    protected void btnShowpnlChange_Click(object sender, EventArgs e)
    {
        pnlChange.Visible = true;
    }
    protected void btnHidePnlChange_Click(object sender, EventArgs e)
    {
        pnlChange.Visible = false;
    }
    protected void btnChange_Click(object sender, EventArgs e)
    {
        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
        {
            //dbSapReise sapReisen = new dbSapReise((int)MBericht.Params.PERSKEY.Value, MBericht.MinDatum, MBericht.Params.MANDANT.Value.ToString());
            dbSapReise sapReisen = new dbSapReise((int)MBericht.Bearbeiter.Params.PERSKEY.Value, MBericht.MinDatum, MBericht.Bearbeiter.Params.MANDANT.Value.ToString());
            if (!sapReisen.DeleteAllTrips())
            {
                lbEBL�schenFehler.Text = "Fehler beim l�schen bereits vorhandener Reisen. Einsatzbericht kann zurzeit nicht umgebucht werden!!!";
                lbEBL�schenFehler.Visible = true;
                return;
            }
        }
     
        // Defect #5879 Begin
        // Pr�fen ob der ProjektID g�ltig ist
        if (Convert.ToInt32(ddlProjekt.SelectedValue) <= 0)
        {
            lbChanged.Text = "Ung�ltiges Projekt ID erkannt! Die Bearbeitung ist abgebrochen";
            lbChanged.ForeColor = System.Drawing.Color.Red;
            lbChanged.Visible = true;
            pnlChange.Visible = false;
            return;
        }

        try
        {
            ArrayList alleBerichte = MBericht.SelectAllByPerskey(MBericht.BerichtsMonat, Convert.ToInt32(MBericht.Params.PERSKEY.Value));
            foreach (dbMontBer ber in alleBerichte)
            {
                if (Convert.ToInt32(ber.Projekt.Params.PROJID.Value) == Convert.ToInt32(ddlProjekt.SelectedValue))
                {
                    //es gibt schon eine EB auf dem selben Projekt. Umbuchen ung�ltig
                    lbChanged.Text = "Ein Einsatzbericht auf dem Projekt '" + ber.Projekt.Params.NAME.Value.ToString() + "' ist bereits vorhanden! Die Bearbeitung/Umbuchung ist abgebrochen";
                    lbChanged.ForeColor = System.Drawing.Color.Red;
                    lbChanged.Visible = true;
                    pnlChange.Visible = false;
                    return;
                }
            }
        }
        catch
        {
            //sollte nicht schief gehen.
        }

        //TAPM-22 Meldung schreiben falls genehmiger das "Speichern" bet�tigt hat
        //der Log sollte erst nach erfolgreichen umbuchung geschrieben werden 
        //if (Session["FromGenehmigung"] != null)
        //{
        //    dbMeldungen meldung = new dbMeldungen();
        //    meldung.doLog((int)MBericht.Params.EBID.Value, (int)((dbBearbeiter)Session["Bearbeiter"]).Params.PERSKEY.Value);
        //}

        // ein neues tempor�res projekt mit ausgew�hlten ID erzeugen
        // damit man Konto Objekt rausholen kann
        dbProjekt projekt = new dbProjekt(Convert.ToInt32(ddlProjekt.SelectedValue));
        // sapCache holen
        SAPCache sapCache = SAPCache.GetInstance();
        //InfoObject io = sapCache.Query(projekt.Params.KTOBJ.Value.ToString());
        InfoObject io = sapCache.Query(projekt.Params.MANDANT.Value.ToString() + '$' + projekt.Params.KTOBJ.Value.ToString());

        // jetzt �berpr�fen ob Projekt kontierbar ist oder nicht
        if (io.Bebuchbar)
        {
            try
            {
                // den alten auftragnummer ermitteln
                string oldKtobj = MBericht.Projekt.Params.KTOBJ.Value.ToString();
                SISSITableAdapters.SISSI_Queries taQueries = new SISSITableAdapters.SISSI_Queries();
                //BAF 530053 Beginn
                projekt.auftragtyp = new AuftragTyp(io.Autyp, io.Objid);
                Int16 intfid = 0;
                // try/catch verwenden weil projekt.INTF_ID kann auch leer sein.
                try
                {
                    intfid = Convert.ToInt16(projekt.INTF_ID);
                }
                catch
                {
                }
                // update dbo.EINSBER
                taQueries.AendernBaustelleUndProjekt(Convert.ToInt32(ddlProjekt.SelectedValue), intfid, (int)MBericht.Params.EBID.Value);
                // update dbo.ARBZEIT
                taQueries.UpdateArbzeit(intfid, (int)MBericht.Params.EBID.Value, oldKtobj, Convert.ToInt32(ddlProjekt.SelectedValue));

                //TAPM-22 Meldung schreiben falls genehmiger das "Speichern" bet�tigt hat
                //Log schreiben erst wenn update erfoglreich ist
                if (Session["FromGenehmigung"] != null)
                {
                    dbMeldungen meldung = new dbMeldungen();
                    meldung.doLog((int)MBericht.Params.EBID.Value, (int)((dbBearbeiter)Session["Bearbeiter"]).Params.PERSKEY.Value);
                }

                //Defect #5999 Zulagen/Auslagen korrigieren - projekt zulage updaten
                foreach (dbAusZulage zulage in MBericht.Auszulagen)
                {
                    try
                    {
                        bool fromGenehmigung = (bool)Session["FromGenehmigung"];
                        if (System.Convert.ToDouble(zulage.Params.ANZAHL.Value) > 0.0 && fromGenehmigung)
                        {
                            bool zulageVorhanden = false;
                            foreach (dbProjektAusZul zulage2 in projekt.ProjektAusZulagen)
                            {
                                if (zulage.Params.LOHNART.Value == zulage2.Params.LOHNART.Value)
                                {
                                    zulageVorhanden = true;
                                    break;
                                }
                            }

                            if (!zulageVorhanden)
                            {
                                dbProjektAusZul neueZulage = new dbProjektAusZul(projekt, zulage.Params.LOHNART.Value.ToString());
                                neueZulage.Insert();
                            }
                        }
                    }
                    catch
                    {
                        /* do nothing */
                    }
                }
                if (Session["ErfEBAus_State"] != null)
                {
                    string userName = String.Format("|{0} {1}", MBericht.Params.VORNAME.Value.ToString(), MBericht.Params.NACHNAME.Value.ToString());
                    Session["ErfEBAus_State"] += userName;
                    Response.Redirect("EB_Zeiten.aspx");
                }
                else
                {
                    //Defect #5999 response zur KG_Zeiten
                    if (Request.QueryString["RetUrl"] != null)
                    {
                        try
                        {
                            Session["BackFromEB"] = true;
                        }
                        catch
                        {
                        }
                        Response.Redirect(Request.QueryString["RetUrl"].ToString());
                    }

                }
            }
            catch
            {
                lbChanged.Text = "Projekt nicht ge�ndert!";
                lbChanged.ForeColor = System.Drawing.Color.Red;
                lbChanged.Visible = true;
                pnlChange.Visible = false;
            }
        }
        else
        {
            // FM ausgeben falls der neue Konto nicht bebuchbar ist
            lbChanged.Text = "Das Projektkonto ist nicht bebuchbar!";
            lbChanged.ForeColor = System.Drawing.Color.Red;
            lbChanged.Visible = true;
            pnlChange.Visible = false;
        }
        // Defect #5879 Ende
    }
    // Ende #5080

    //Defect #6178 R�cksetzen von EB ausf�hren
    protected void btnRuecksetzen_Click(object sender, EventArgs e)
    {
        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
        {
            //dbSapReise sapReisen = new dbSapReise((int)MBericht.Params.PERSKEY.Value, MBericht.MinDatum, MBericht.Params.MANDANT.Value.ToString());
            dbSapReise sapReisen = new dbSapReise((int)MBericht.Bearbeiter.Params.PERSKEY.Value, MBericht.MinDatum, MBericht.Bearbeiter.Params.MANDANT.Value.ToString());
            if (!sapReisen.DeleteAllTrips())
            {
                lbEBL�schenFehler.Text = "Fehler beim l�schen bereits vorhandener Reisen. Einsatzbericht kann zurzeit nicht r�ckgesetzt werden!!!";
                lbEBL�schenFehler.Visible = true;
                return;
            }
        }

        try
        {
            int ebid = Convert.ToInt32(MBericht.Params.EBID.Value);
            ArrayList list = MBericht.Projekt.Baustelle.Barauslagen;
            dbRuecksetzen rueck = new dbRuecksetzen(ebid, list);
            if (rueck.ruecksetzen())
            {
                //zur�ck nach K&G Auswahl
                Response.Redirect("~/Genehmigung/KG_Main.aspx");
            }
            else
            {
                // FM ausgeben falls R�cksetzung nicht erfolgreich war
                lbChanged.Text = "R�cksetzung war nicht erfolgreich!";
                lbChanged.ForeColor = System.Drawing.Color.Red;
                lbChanged.Visible = true;
                pnlChange.Visible = false;
            }
        }
        catch
        {
        }
    }
}
