//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : EditEB.aspx.cs
//
// Description  : Editieren von Einsatzberichten
//
//=============== V1.2.0017 ===============================================
//
// Date         : 18.November 2013
// Author       : Joldic Dzevad
// Defect#      : TT 6654245
//                Bei @CENT soll decimal anstatt float verwendet werden
//
//--------------- V1.2.0011 ---------------------------------------------------
//
// Date         : 30.September 2011
// Author       : Joldic Dzevad
// Defect#      : BAN 500256
//                Alert ausgeben falls vorhanden
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== 1.0.0048 ================================================
//
// Date         : 17.August 2009
// Author       : Joldic Dzevad
// Defect#      : BAF 530021
//                Mehrfachbg. v Fahrscheinen/Tag b Ersatzruhe
//
//=============== 1.0.0047 ================================================
//
// Date         : 11.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-43
//                offener Krankenstandsstempel in Zukuft soll nicht �berpr�ft werden
//
//=============== 1.0.0045 ================================================
//
// Date         : 22.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-22
//                Erfasse benachrichtigen wenn EB durch Genehmiger ge�ndert ist
//
//=============== V1.0.0044 ===============================================
//
// Date         : 12.August 2008
// Author       : Frantisek Sabol
// Defect#      : 6076/TAPM-22
//                Erfasser benachrichtigen wenn EB durch Genehmiger ge�ndert ist
//
//=============== V1.0.0041 ===============================================
//
// Date         : 21.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : no defect
//                STRO nur ein mal pro tag generieren
//
//=============== V1.0.0038 ===============================================
//
// Date         : 14.M�rz 2008
// Author       : Joldic Dzevad
// Defect#      : 5341
//                Beim Einsatz auf 2 oder mehr Projekten auf gleicher Baustelle
//                am gleichen Tag, mehrfaches generieren von RA Auslagen wird 
//                verhindert
//
// Date         : 28.Februar 2008
// Author       : Wolfgang Patrman
// Defect#      : 5844
//                �berpr�fen ob es Unfall/Krankheit Beginn ohne Ende gibt
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 09.August 2007
// Author       : Adam Kiefer
// Defect#      : 5355,5373
//                Exception bei Erfassen von Barauslage zu bereits geschl. Projekt
//                Projekt nicht mehr sichtbar
//
//--------------- V1.0.0029 ---------------------------------------------------
//
// Date         : 25.Juni 2007
// Author       : Adam Kiefer
// Defect#      : 4041
//                R�ckmeldung "gespeichert"
//
//--------------- V1.0.0028 ---------------------------------------------------
//
// Date         : 13.Juni 2007
// Author       : Adam Kiefer
// Defect#      : 4069
//                Anzeige zuletzt erfasstes Projekt
//
//--------------- V1.0.0028 ---------------------------------------------------
//
// Date         : 01. Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4887
//                Wenn Button 'Speichern' gedr�ckt wurde, dann �berpr�fen
//                ob bereits vorhandenen RAAuslagen/KFZ-Daten innerhalb der
//                eingegebenen Arbeitszeiten liegen
//
//--------------- V1.0.0027 --------------------------------------------------- 
//
// Date         : 15. Mai 2007
// Author       : GN
// Defect#      : 4435
//                F�r MA mit sozialer Stellung 6 und 7 werden keine Reiseauslagen aus der Baustelle generiert.
//
//--------------- V1.0.0024 --------------------------------------------------- 
// Date         : 16. April 2007
// Author       : CG
// Defect#      : 4900
//
// Fehler, der ein Fehlschlagen der �berleitung nach AZM verursachte, behoben.
//
// Date         : 02. April 2007
// Author       : CL
// Defect#      : 4756
//
// Applikationseigener 'Zur�ck'-Button f�r R�ckkehr in Zeiten�bersicht f�r
// Genehmiger.
//
//--------------- V1.0.0023 --------------------------------------------------- 
// Date         : 14. M�rz 2007
// Author       : CL
// Defect#      : 4708, 4740, 4746
//
// Reiseauslagen d�rfen nur dann generiert werden, wenn am entsprechenden Tag
// f�r das aktuelle Projekt des Einsatzberichts gearbeitet wurde (auch
// wenn Relevanz-Checkbox gesetzt ist).
//
//--------------- V1.0.0023 --------------------------------------------------- 
// Date         : 13. M�rz 2007
// Author       : CL
// Defect#      : 4795
//
// Stundenweise Absenzen d�rfen nicht ausserhalb der Normalarbeitszeit
// eingegeben werden.
//
//--------------- V1.0.0022 --------------------------------------------------- 
// Date         : 14. Februar 2007
// Author       : CL
// Defect#      : 4524
//
// Leere Einsatzberichte d�rfen nicht gespeichert und freigegeben werden.
/* 
 * 19.01.2007: CG Defect 4311, 4296: Auftrag nicht bebuchbar ... Fehler anzeigen, nur wenn  auch andere Werte vorbelegt sind
 *                               V.1.0.0020
 *
 */
//--------------- V1.0.0013 --------------------------------------------------- 
// Date         : 4. Dez 2006
// Author       : GN
// Defect#      : 3834
//                Pr�fung auf kontierbarkeit in SAP
//
//--------------- V1.0.0010 ---------------------------------------------------
//
// Date         : 12. November 2006
// Author       : Georg Nebehay
// Defect#      : 3644
//                Hinweismeldung pr�zisiert
//
//--------------- V1.0.0004 --------------------------------------------------- 
//
// Date         : 11. November 2006
// Author       : CG
// Defect#      : 3507
//                Save Funktionalit�t erst nach Speicherung des Einsatzberichts ausf�hren
//
// ============================================================================ 

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Einsatzbericht_EditEB : System.Web.UI.Page
{
    dbMontBer MBericht;

    protected void Page_Load(object sender, EventArgs e)
    {
        bool stdok = false;
        bool bSAPObjValid = true;
        string statusErrTxt = "";

        // Beginn Defect 4887
        EB_TimeTable1.KFZ = KFZ1; // Verweis auf KFZ1 speichern
        EB_TimeTable1.RAAuslage = RAAuslage1; // Verweis auf RAAuslage1 speichern
        // Ende Defect 4887

        MBericht = (dbMontBer)Session["MBericht"];
        if ((!Page.IsPostBack) & ((int)MBericht.Params.EBID.Value != 0)) MBericht.Select();
        /* GN: beginn defect 3834: pr�fung der kontierbarkeit in SAP
         */
        if (!MBericht.Projekt.KontierbarInSAP())
        {
            statusErrTxt = MBericht.Projekt.Params.KTOBJ.Value.ToString() + " " +
                           MBericht.Projekt.Params.MANDANT.Value.ToString() + " " +
                           MBericht.Params.EBID.Value.ToString() + " " +
                           MBericht.Bearbeiter.Params.PERSNR.Value.ToString();

            bSAPObjValid = false;
        }
        /* ende defect 3834 */

        if (bSAPObjValid)
        {
            // PSP element kontierbar, checken von std id
            foreach (dbBaustelleStandort bs in MBericht.Projekt.Baustelle.Standorte)
                if ((int)bs.Params.STDID.Value == Convert.ToInt32((Int16)MBericht.Bearbeiter.Params.STDSTDID.Value)) stdok = true;
        }

        bool leistArtok = (MBericht.Bearbeiter.Commons.Leistungsart.Count > 0);
        if (!stdok || !leistArtok || !bSAPObjValid)
        {
            if (!leistArtok)
            {
                LabelErrorLEISTART.Text = "ZWISCHEN LEISTART und Mitarbeiterkostenstelle besteht keine Zuordnung: PERSNR " + MBericht.Bearbeiter.Params.PERSNR.Value.ToString() + "-" +
                                          MBericht.Bearbeiter.Params.NACHNAME.Value.ToString() + " " + MBericht.Bearbeiter.Params.VORNAME.Value.ToString() +
                                          " MANDANT:" + MBericht.Bearbeiter.Params.MANDANT.Value.ToString();
                LabelErrorLEISTART.Visible = true;
            }
            if (!bSAPObjValid)
            {
                // CG:
                // Defect# 4311, 4296: AllInvalid - check eingef�hrt. Error anzeigen, wenn auch andere Werte vorbelegt sind
                //
                bool AllInvalid = MBericht.Projekt.Params.KTOBJ.Value.ToString() == "" &&
                                   MBericht.Projekt.Params.MANDANT.Value.ToString() == "" &&
                                   MBericht.Params.EBID.Value.ToString() == "" &&
                                   MBericht.Bearbeiter.Params.PERSNR.Value.ToString() == "";
                if (!AllInvalid)
                {
                    // Defect 3644
                    // Hinweismeldung pr�zisiert
                    LabelErrorKTOBJ.Text = "Folgendes nicht bebuchbares Objekt (KTBOBJ, Mandant, EBID, PERSNR) ist diesem Einsatzbericht zugeordnet, " +
                                      "daher Abbruch der Bearbeitung : " + statusErrTxt;
                    LabelErrorKTOBJ.Visible = true;
                }
            }
            if (!stdok)
            {
                LabelErrorSTD.Text = "Zwischen dem Standort dieses Mitarbeiters und der Baustelle besteht keine Zuordnung: " + MBericht.Bearbeiter.Params.NACHNAME.Value.ToString() +
                         " " + MBericht.Bearbeiter.Params.VORNAME.Value.ToString() + " Standort:" + MBericht.Bearbeiter.Standort.Params.NAME1.Value.ToString();
                LabelErrorSTD.Visible = true;
            }

            BtnSave.Visible = false;
            EB_TimeTable1.Visible = false;
            AusZulage1.Visible = false;
            KFZ1.Visible = false;
            RAAuslage1.Visible = false;
            cbFreigabe.Visible = false;
            Bemerkung1.Visible = false;
        }

        // Beginn Defect 5844
        // �berpr�fen ob es Unfall/Krankheit Beginn ohne Ende gibt
        if (CheckGTAbsenz(MBericht.Bearbeiter.Params.PERSNR.Value.ToString()))
        {
            LabelErrorKTOBJ.Text =
              "Es existiert ein Zeitstempel Beginn Krankheit/Unfall aus dem Vormonat," + "<br />" +
              " bitte entsprechenden Ende-Stempel erfassen.";
            LabelErrorKTOBJ.Visible = true;
        }
        // Ende Defect 5844

        BtnSave.Enabled = ((Request.QueryString["RetUrl"] != null) || (Convert.ToInt32(MBericht.Params.EBSTAT.Value) == 30));
        if (Request.QueryString["Readonly"] != null)
        {
            BtnSave.Enabled = false;
            EB_TimeTable1.Enabled = false;
            AusZulage1.Enabled = false;
            KFZ1.Enabled = false;
            RAAuslage1.Enabled = false;
            cbFreigabe.Enabled = false;
            Bemerkung1.Enabled = false;
        }
        // 23.02.07, 14:00
        // CG- Ausgeschaltet. Beim Zur�ck zur vorherigen Seite "Kontrolle & Genehmigung - Einsatzberichte"
        // sind die Zeitstempeln (Norm Std., 50%, 100%) sind ohne Pausenabzug und falsch SEG-Punkte angezeigt worden.
        // Beginn Defect # 4756: Korrigierte Bearbeitung in KG_Zeiten.aspx.cs
        BtnBack.Visible = Request.QueryString["RetUrl"] != null;
        // Ende Defect # 4756
        //
        cbFreigabe.Visible = (Request.QueryString["RetUrl"] != null) && Session["FromGenehmigung"] == null; //Nur dann, wenn Returl gesetzt und nicht von genehmigung
        // Beginn #4041 - R�ckmeldung "gespeichert"
        lbEBSaved.Visible = false;
        // Ende #4041    

        lbKTOBJFehler.Visible = false;

        lblErrorTrips.Text = "";
        lblErrorTrips.Visible = false;
    }

    // Beginn Defect 5844
    protected bool CheckGTAbsenz(string persnr)
    {
        dbBearbeiter Monteur = this.MBericht.Bearbeiter;
        bool bErg = false;

        // Sortierung der ganzt�gigen Absenzen nach Datum absteigend
        GTAbsenzComparer comp = new GTAbsenzComparer();
        Monteur.GTAbsenz.Sort(comp);

        foreach (dbGTAbsenz LastGTAbsenz in Monteur.GTAbsenz)
        {
            //TAPM-43 GT Absenz in Zukuft soll ignoriert werden
            if (Convert.ToDateTime(LastGTAbsenz.Params.DATUM.Value) >= Convert.ToDateTime(MBericht.Params.BERMON.Value).AddMonths(1))
                continue;
            //TAPM-43 Ende
            if ((Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                 Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin) &&
                 (Convert.ToDateTime(LastGTAbsenz.Params.DATUM.Value).Month != Convert.ToDateTime(MBericht.Params.BERMON.Value).Month ||
                  Convert.ToDateTime(LastGTAbsenz.Params.DATUM.Value).Year != Convert.ToDateTime(MBericht.Params.BERMON.Value).Year))
            {
                // Krankheit/Unfall Beginn im Vormonat gefunden
                bErg = true;
                break;
            }
            else
            {
                if (Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende ||
                    Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende)
                {
                    break;
                }
                else
                {
                    continue;
                }
            }
        }
        return bErg;
    }

    public class GTAbsenzComparer : System.Collections.IComparer
    {
        public int Compare(object obj1, object obj2)
        {
            int retVal = 0;

            dbGTAbsenz GTAbsenz1 = (dbGTAbsenz)obj1;
            dbGTAbsenz GTAbsenz2 = (dbGTAbsenz)obj2;

            DateTime i11 = Convert.ToDateTime(GTAbsenz1.Params.DATUM.Value);
            DateTime i21 = Convert.ToDateTime(GTAbsenz2.Params.DATUM.Value);
            if (i11 > i21)
            {
                retVal = -1;
            }
            else
            {
                retVal = 1;
            }
            return retVal;
        }
    }
    // Ende Defect 5844

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        MBericht = (dbMontBer)Session["MBericht"];
        // dbBearbeiter Monteur = (dbBearbeiter)Session["Monteur"];
        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
        {
            //dbSapReise sapReisen = new dbSapReise((int)MBericht.Params.PERSKEY.Value, MBericht.MinDatum, MBericht.Params.MANDANT.Value.ToString());
            dbSapReise sapReisen = new dbSapReise((int)MBericht.Bearbeiter.Params.PERSKEY.Value, MBericht.MinDatum, MBericht.Bearbeiter.Params.MANDANT.Value.ToString());
            if (!sapReisen.DeleteAllTrips())
            {
                lblErrorTrips.Text = "Fehler beim l�schen bereits vorhandener Reisen. EB wird nicht gespeichert!!!";
                lblErrorTrips.Visible = true;
                return;
            }
        }
        //Defect 4900
        //CG 16.04.2007
        //Fehler bei �berleitung nach AZM
        //Wenn der Benutzer sich schon bis zur letzten Seite der Genehmigung durchgeklickt hat und
        //dann wieder zum Einsatzbericht zur�ckkehrt, dannn stehen in MBericht.Reisetage die Reisezeilen
        //drinen. Beim Speichern des Einsatberichts werden dann f�lschlicherweise auch die Reisezeilen
        //in die ARbzeittabelle gespeichert, was diverse Fehler nach sich ziehen kann. (�berleitung nach AZM
        //schl�gt fehl, doppelte R und W Zeilen) Folgender Befehl l�scht diese Zeilen und behebt die Probleme.
        MBericht.ReiseTage = null;

        /* Beginn Defect #4524: Leere Einsatzberichte d�rfen nicht
         * gespeichert und freigegeben werden.
         * Gep�ft wird die Liste der Eintr�ge auf Relevanz und korrekte Zeiten. */

        // Initialisierung der Fehlermeldung
        LabelErrorFreigabe.Text = "";
        LabelErrorFreigabe.Visible = false;

        bool blnEmptyEB = true;

        try
        {
            // Auslesen der Benutzereingaben
            blnEmptyEB = EB_TimeTable1.IsEmptyTable();
        }
        catch (Exception ex)
        {
            string strErrMessage = ex.Message;
            blnEmptyEB = false;
        }

        // Fortsetzen nur, wenn Einsatzbericht nicht leer ist
        if (blnEmptyEB)
        {
            if (cbFreigabe.Checked)
            {
                // Meldung, falls selektierte Freigabe-Checkbox
                LabelErrorFreigabe.Text = "Leerer Einsatzbericht kann nicht gespeichert "
                                          + "und freigegeben werden !";
            }
            else
            {
                // Meldung, falls Freigabe-Checkbox nicht selektiert ist
                LabelErrorFreigabe.Text = "Leerer Einsatzbericht kann nicht gespeichert "
                                          + "werden !";
            }
            LabelErrorFreigabe.Visible = true;
        }
        else
        {
            /* Ende Defect #4524*/

            /* Beginn Defect #4795: Nur wenn die Zeitstempel korrekt sind,
             * darf gespeichert werden
             * */
            if (EB_TimeTable1.TimestampsAreCorrect())
            { // Ende Defect #4795

                // Beginn Defect 4887
                // �berpr�fung der RAAuslagen/KFZ-Daten f�r alle Arbeitszeiten
                bool bOnlyValidData = true;

                if (RAAuslage1.bOnlyValidRA == false |
                    KFZ1.bOnlyValidKFZDaten == false)
                {
                    bOnlyValidData = false;
                }

                if (bOnlyValidData)
                {
                    // Ende Defect 4887
                    if (cbFreigabe.Checked)
                    {
                        int iRes = 0;
                        System.Collections.Generic.List<string> allRaAuslagen = new System.Collections.Generic.List<string>();
                        System.Collections.Generic.List<DateTime> allSTROAuslagen = new System.Collections.Generic.List<DateTime>();
                        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
                        {
                            try
                            {
                                cnx.Open();
                                // Defect 5725, Config.Rowlock eingef�hrt
                                using (SqlCommand cmd = new SqlCommand("select MAX(RAAUSLAGEID) as MaxId from RAAUSLAGE " + Config.Rowlock, cnx)) // Defect 5436, using eingef�hrt
                                {
                                    cmd.Parameters.Add(MBericht.Params.EBID);
                                    using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
                                    {
                                        cmd.Parameters.Remove(MBericht.Params.EBID);
                                        while (rd.Read())
                                        {
                                            if (!rd.IsDBNull(0))
                                                iRes = (int)rd.GetValue(0);
                                            else
                                                iRes = 0;
                                        }
                                    }
                                }
                                // defect #5341 beginn Teil 1
                                // ermitteln alle bisher gespeicherten RA Auslagen von MA
                                using (SqlCommand cmd = new SqlCommand(
                                    "select bau.bauid, ra.datum, ra.RAKZ, ra.ANZAHL, ra.BETRAG from bauprojekt bau " + Config.Nolock + ", raauslage ra " + Config.Nolock +
                                    "where  bau.projid = (select projid from einsber where ebid = ra.ebid ) " +
                                    "and ra.perskey = @PERSKEY " +
                                    "and DatePart(\"yyyy\", ra.datum ) = DatePart(\"yyyy\", @BERMON) " +
                                    "and DatePart(\"mm\", ra.datum) = DatePart(\"mm\", @BERMON) ", cnx))
                                {
                                    // cmd.Parameters.Add(Monteur.Params.PERSKEY);
                                    cmd.Parameters.Add(MBericht.Bearbeiter.Params.PERSKEY);
                                    cmd.Parameters.Add(MBericht.Params.BERMON);
                                    using (SqlDataReader rd = cmd.ExecuteReader())
                                    {
                                        cmd.Parameters.Remove(MBericht.Bearbeiter.Params.PERSKEY);
                                        cmd.Parameters.Remove(MBericht.Params.BERMON);
                                        while (rd.Read())
                                        {
                                            // die ergebniss in allRaAuslagen Liste speichern
                                            allRaAuslagen.Add(rd.GetValue(0).ToString() + "-" + rd.GetValue(1).ToString() +
                                                //TT-6654245 - Bei @CENT soll decimal(original wert) anstatt int verwendet werden
                                                //"-" + rd.GetValue(2).ToString() + "-" + rd.GetValue(3).ToString() + "-" + Convert.ToInt32(rd.GetValue(4)).ToString());
                                                "-" + rd.GetValue(2).ToString() + "-" + rd.GetValue(3).ToString() + "-" + rd.GetValue(4).ToString());
                                            //zus�tzlich eine Liste von STRO Auslagen - die werden pro Tag nur einmal geschrieben
                                            if (rd.GetValue(2).ToString() == "STRO")
                                                allSTROAuslagen.Add(Convert.ToDateTime(rd.GetValue(1)));
                                        }
                                        // Liste Sortieren wegen Binarysearch
                                        allRaAuslagen.Sort();
                                        allSTROAuslagen.Sort();
                                    }
                                }
                                // Defect #5341 Ende Teil 1
                            }
                            catch (Exception ex) { throw ex; }
                            finally { cnx.Close(); }
                        }

                        dbBarauslagen bau = new dbBarauslagen(MBericht.Projekt.Baustelle);
                        ArrayList list = bau.SelectAllforBaustelle();

                        //Defect 4435 Keine RAuslagen f�r Fremdpersonal
                        //GN 15.5.2007
                        string strSozStell = MBericht.Bearbeiter.TechParams.SOZSTELL.Value.ToString();
                        if (!(strSozStell == "6" || strSozStell == "7"))
                        {
                            foreach (dbArbTag tag in MBericht.Tage)
                            {
                                if (!tag.Relevanz) continue;

                                bool valid = false;
                                foreach (dbArbZeit z in tag.Zeiten)
                                {
                                    /* Beginn Defect #4708, 4740, 4746: Nur wenn die eingetragene
                                     * Zeit dem Projekt des aktuellen Einsatzberichts zugeordnet
                                     * ist, wird das 'valid'-Flag auf true gesetzt. */
                                    if ((z.Kommen != ParamVal.Date0 && // Kommen-Zeit vorhanden
                                         z.Gehen != ParamVal.Date0 && // Gehen-Zeit vorhanden
                                         z.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz && // Keine GT-Absenz
                                         z.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz && // BAF 530021 - keine STD-Absenz
                                         !z.Deleted && // Nicht als gel�scht markiert
                                         z.AuftragNr == MBericht.Projekt.Params.KTOBJ.Value.ToString())) // Zeiteintrag f�r aktuellen EB
                                        valid = true;
                                    // Ende Defect #4708, 4740, 4746
                                }
                                if (valid)
                                {
                                    foreach (dbBarauslagen ba in list)
                                    {
                                        //Single auslageBetrag = 0;

                                        //try
                                        //{
                                        //    auslageBetrag = Convert.ToSingle(ba.Params.CENTS.Value);
                                        //}
                                        //catch
                                        //{
                                        //    auslageBetrag = 0;
                                        //}

                                        // no defect
                                        if (ba.Params.TYP.Value.ToString() == "STRO"
                                            && allSTROAuslagen.BinarySearch(tag.TagesDatum) >= 0) //STRO wird nur einmal pro tag generiert.
                                            continue;

                                        //Defect #5341 Beginn Teil 2
                                        //Eintrag formatieren wie im allRaAuslagen
                                        //TT - 6654245 Bei @CENT soll original wert anstatt Convert.ToInt verwendet werden
                                        string entry = MBericht.Projekt.Baustelle.Params.BAUID.Value.ToString() +
                                                       "-" + tag.TagesDatum.ToString() +
                                                       "-" + ba.Params.TYP.Value.ToString() +
                                                       "-" + ba.Params.ANZ.Value.ToString() +
                                                       "-" + ba.Params.CENTS.Value.ToString();
                                        //falls "entry" Eintrag schon allRaAuslagen existiert, dann wir es ein zweites nicht in DB geschrieben
                                        if (allRaAuslagen.BinarySearch(entry) < 0)   // Defect #5341 Ende Teil 2
                                        {
                                            iRes++;
                                            dbRAAuslage RAAuslage = new dbRAAuslage(MBericht);
                                            RAAuslage.Params.ANZAHL.Value = ba.Params.ANZ.Value;
                                            RAAuslage.Params.BETRAG.Value = ba.Params.CENTS.Value;
                                            RAAuslage.Params.DATUM.Value = tag.TagesDatum;
                                            RAAuslage.Params.EBID.Value = MBericht.Params.EBID.Value;
                                            RAAuslage.Params.MANDANT.Value = MBericht.Params.MANDANT.Value;
                                            RAAuslage.Params.PERSKEY.Value = MBericht.Params.PERSKEY.Value;
                                            RAAuslage.Params.RAAUSLAGEID.Value = iRes;
                                            RAAuslage.Params.RAKZ.Value = ba.Params.TYP.Value;
                                            MBericht.Reiseauslagen.Add(RAAuslage);
                                        }
                                    }
                                }
                            }
                        }

                        Bemerkung1.Save();
                        EB_TimeTable1.OnSave_Click();
                        AusZulage1.OnSave_Click();
                        MBericht = (dbMontBer)Session["MBericht"];
                        // Beginn #5355,5373 - Exception bei Erfassen von Barauslage zu bereits geschl. Projekt
                        bool MBerichtSaved = false;
                        try
                        {
                            MBericht.Save();
                            MBerichtSaved = true;
                        }
                        catch
                        {
                            lbKTOBJFehler.Visible = true;
                            MBerichtSaved = false;
                        }
                        if (MBerichtSaved)
                        {
                            MBericht.Select();
                            KFZ1.Save();
                            Session["MBericht"] = MBericht;

                            // Beginn #4069 - Anzeige zuletzt erfasstes Projekt    

                            /* Benutzer ist als Erfasser angemeldet */
                            if (Session["ErfEBAus_State"] != null)
                            {
                                string userName = String.Format("|{0} {1}", MBericht.Params.VORNAME.Value.ToString(), MBericht.Params.NACHNAME.Value.ToString());
                                Session["ErfEBAus_State"] += userName;
                                Response.Redirect("EB_Zeiten.aspx");
                            }

                            // Ende #4069
                        }
                        // Ende #5355,5373
                        if (Session["Alert"] != null)
                        {
                            Alert.Show((string[])Session["Alert"]);
                            Session.Remove("Alert");
                        }
                    }
                    else
                    {
                        Bemerkung1.Save();
                        EB_TimeTable1.OnSave_Click();
                        AusZulage1.OnSave_Click();
                        if (Session["Alert"] != null)
                        {
                            Alert.Show((string[])Session["Alert"]);
                            Session.Remove("Alert");
                        }
                        // Beginn #5355,5373 - Exception bei Erfassen von Barauslage zu bereits geschl. Projekt
                        bool MBerichtSaved = false;
                        try
                        {
                            MBericht.Save();
                            MBerichtSaved = true;
                        }
                        catch
                        {
                            lbKTOBJFehler.Visible = true;
                            MBerichtSaved = false;
                        }
                        if (MBerichtSaved)
                        {
                            MBericht.Select();
                            // Defect 3507
                            // Save Funktionalit�t erst nach Speicherung des Einsatzberichts ausf�hren
                            KFZ1.Save();
                            Session["MBericht"] = MBericht;
                            SetFocus(BtnSave);

                            // Beginn #4069 - Anzeige zuletzt erfasstes Projekt    

                            /* Benutzer ist als Erfasser angemeldet */
                            if (Session["ErfEBAus_State"] != null)
                            {
                                string userName = String.Format("|{0} {1}", MBericht.Params.VORNAME.Value.ToString(), MBericht.Params.NACHNAME.Value.ToString());
                                Session["ErfEBAus_State"] += userName;
                                // Beginn #4041 - R�ckmeldung "gespeichert"
                                lbEBSaved.Visible = true;
                                // Ende #4041
                                //Response.Redirect("EB_Zeiten.aspx");                
                            }

                            // Ende #4069
                        }
                        // Ende #5355,5373
                    }
                }
            } /* Beginn Defect #4795: Focus auf Refresh-Button, um Fehlermeldung
         * zu zeigen */
            else
            {
                EB_TimeTable1.SetFocusToBtnRefresh();
            } // Ende Defect #4795
        } // Defect #4524

        //TAPM-22 Meldung schreiben falls genehmiger das "Speichern" bet�tigt hat
        if (Session["FromGenehmigung"] != null)
        {
            dbMeldungen meldung = new dbMeldungen();
            meldung.doLog((int)MBericht.Params.EBID.Value, (int)((dbBearbeiter)Session["Bearbeiter"]).Params.PERSKEY.Value);
        }
    }

    protected void cbFreigabe_CheckedChanged(object sender, EventArgs e)
    {
        if (cbFreigabe.Checked)
            MBericht.Params.EBSTAT.Value = (Int16)dbMontBer.EBStat.freigegeben;
        else
            MBericht.Params.EBSTAT.Value = (Int16)dbMontBer.EBStat.erfasst;
    }

    protected void BtnBack_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["RetUrl"] != null)
        {
            /* Beginn Defect # 4756: Setzen des 'BackFromEB'-Flags, damit in
             * KG_Zeiten.aspx.cs neuerliches Einlesen des Einsatzberichts
             * durchgef�hrt wird (Anzeige aktueller Daten).
             * */
            try
            {
                Session["BackFromEB"] = true;
            }
            catch (Exception ex)
            {
                string strErrorMessage = ex.Message;
            }
            // Ende Defect # 4756

            // Beginn #4069 - Anzeige zuletzt erfasstes Projekt    

            /* Benutzer ist als Erfasser angemeldet */
            if (Session["ErfEBAus_State"] != null)
            {
                string userName = "|null";
                Session["ErfEBAus_State"] += userName;
                Response.Redirect("EB_Zeiten.aspx");
            }
            else
            {
                Response.Redirect(Request.QueryString["RetUrl"].ToString());
            }

            // Ende #4069
        }
    }
}