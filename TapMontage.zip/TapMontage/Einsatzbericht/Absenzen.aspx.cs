﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : Absenzen.aspx.cs
//
// Description  : Benutzerschnittstelle zur Erfassung d. Absenzen
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2013
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//                
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt ständige AZM abfragen
//                
//=============== V1.0.0048 ===============================================
//
// Date         : 17.August 2009
// Author       : Joldic Dzevad
// Defect#      : BAF 530016
//                Absenzeintrag findet keine Zuordnung in Absenzliste
//
//=============== V1.0.0039 ===============================================
//
// Date         : 10.April 2008
// Author       : Frantisek Sabol
// Defect#      : 5973
//                Exception bei Verwalten von Absenzen
//
//=============== V1.0.0038 ===============================================
//
// Date         : 26.Februar 2008
// Author       : Wolfgang Patrman
// Defect#      : 5844
//                Krankheit Beginn auf Beginn verhindern
//
// Date         : 11.Maerz 2008
// Author       : Frantisek Sabol
// Defect#      : 5921
//                Exception während Verwaltung von GT Absenzen
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' für lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 18.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5734
//                Andere Absenzen als Krankheit/Unfall von der Logik
//                ausschließen
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' für DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Nebehay Georg
// Defect#      : 5661
//                Absenzen an Fenstertagen ermöglichen
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
// Date         : 12.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5618
//                Erstmaliges Erfassen von Krankheit, Urlaub korr.
//
//--------------- V1.0.0034 -----------------------------------------------
//
// Date         : 08.Oktober 2007
// Author       : Wolfgang Patrman
// Defect#      : 5506
//                Fehlerhafte Einträge (Krankheit) korr.
//
//--------------- V1.0.0033 -----------------------------------------------
//
// Date         : 30.August 2007
// Author       : Adam Kiefer
// Defect#      : 5416
//                Anzeige Kopfdaten
//
//=============== V1.0.0032 ===============================================
//
// Date         : 13.August 2007
// Author       : Wolfgang Patrman
// Defect#      : 5364
//                korrekte Berücksichtigung von bereits genehmigten
//                Krankheiten/Unfall aus Vormonaten
//                5361
//                Überprüfung ob für neu eingegebenes Datum bei Modifikation
//                ein Eintrag existiert
//
//=============== V1.0.0029 ===============================================
//
// Date         : 10.Juli 2007
// Author       : Wolfgang Patrman
// Defect#      : 5220
//                Ausgabe der Meldung nur, wenn genau ein Tag erfasst wurde
//                5234
//                Korrektur Überprüfung auf vorhandene Absenzen
//
//=============== V1.0.0028 ===============================================
//
// Date         : 13.Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4099
//                Anzeige ab Monat der ganztägigen Absenzen
//                Eingabe Unfall/Krankheit mit Beginn/Ende Stempel
//
//=============== V1.0.0020 ===============================================
//
// Date         : 27.Jänner 2007
// Author       : Gebhardt Caleb
// Defect       : 4312
//                Logik, die es ermöglicht Begin- und Ende-Absenzen
//                bei Krankheiten und Unfall zu erfassen.
//                Programmcode ist auskommentiert f.V1.0.0020 (funktioniert
//                aber und kann wieder bei Bedarf aktiviert werden) 
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using TapMontage.Misc;

public partial class Arbeitszeit_Absenzen : System.Web.UI.Page
{
    // Beginn Defect 4099
    //  CG - Defect 4312 - CODE AUSKOMMENTIERT f. V1.0.0020
    // CG - Defect 4312 Logik f. Ganztägige Absenzen:
    // Schuessel ID aus der Y_GTABSENZ
    //const int gtKrankheit = 210;
    //const int gtKrankheit_begin = 212;
    //const int gtKrankheit_ende = 214;

    //const int gtUnfall = 220;
    //const int gtUnfall_begin = 222;
    //const int gtUnfall_ende = 224;
    // Ende Defect 4099

    public int xxID = 0;
    dbBearbeiter Monteur;
    dbBearbeiter Bearbeiter;
    string Argument = "";
    // Defect 4099: 
    // Liste aller Monate, für welche die Einträge nicht mehr geändert werden dürfen
    ArrayList dtMonthNotChangeable = new ArrayList();

    protected void Page_Load(object sender, EventArgs e)
    {
        // Beginn #5416 - Anzeige Kopfdaten
        /* Kopfdaten einstellen */
        try
        {
            if (Session["headData"] == null)
                Session.Add("headData", "");

            Session["headData"] = "<span style=\"font-size: 20px;\">Absenzen eingeben / verwalten</span>";
        }
        catch
        {/* Nicht behandelt! */}
        // Ende #5416
        Bearbeiter = (dbBearbeiter)Session["Bearbeiter"];
        Monteur = (dbBearbeiter)Session["Monteur"];
        lblError.Visible = false;

        FilterBearbeiter.TextBoxChangedDelegee = FilterBearbeiter_Change;
        DDLBearbeiter.SelIndexChanged = DDLBearbeiter_SelectedIndexChanged;
        DDLAbsenzMonat.SelIndexChanged = DDLAbsenzMonat_SelectedIndexChanged; // Defect 4099
        DDL_Absenzart.SelIndexChanged = DDL_Absenzart_SelectedIndexChanged; // Defect 4099

        if (IsPostBack)
        {
            DDL_Absenzart.DisableItem(dbGTAbsenz.gtUnfall.ToString());
            DDL_Absenzart.DisableItem(dbGTAbsenz.gtKrankheit.ToString());

            if (DDLBearbeiter.DDL.SelectedIndex > 0)
            {
                lblErrorMA.Visible = false;
                if (Monteur != null)
                {
                    phTable.Controls.Clear();
                    phTable.Controls.Add(GTAbsenzTable());
                }
            }
        }
        else
        {
            btnSave.Enabled = false;
            Btn_CellSave.Enabled = false;
            Btn_CellCancel.Enabled = false;
        }




        // Beginn Defect 4099
        //if (DDLBearbeiter.DDL.SelectedIndex > 0)
        //{
        //  lblErrorMA.Visible = false;
        //  Monteur = new dbBearbeiter(Int32.Parse(DDLBearbeiter.DDL.SelectedValue));
        //  phTable.Controls.Clear();
        //  phTable.Controls.Add(GTAbsenzTable());
        //}
        //else
        //{
        //  Monteur = (dbBearbeiter)Session["Monteur"];
        //  if (Monteur != null)
        //  {
        //    DDLBearbeiter.DDLSelectedValue = Monteur.Params.PERSKEY.Value.ToString();
        //    phTable.Controls.Clear();
        //    phTable.Controls.Add(GTAbsenzTable());
        //  }
        //}
        // Ende Defect 4099
    }


    // Defect 5973 beginn
    protected void Page_PreRender(object sender, EventArgs e)
    {
        try
        {
            if ((bool)Session["showMessage"])
                lbInfo.Visible = true;
            else
                lbInfo.Visible = false;
            Session["showMessage"] = false;
        }
        catch
        {
            Session["showMessage"] = false;
        }

    }
    // Defect 5973 ende


    public void DDLBearbeiter_SelectedIndexChanged(object sender, EventArgs e)
    {
        Monteur = new dbBearbeiter(Int32.Parse(DDLBearbeiter.DDL.SelectedValue));
        dtMonthNotChangeable.Clear();
        phTable.Controls.Clear();
        phTable.Controls.Add(GTAbsenzTable());
        Btn_CellCancel.Enabled = false;
        Btn_CellSave.Enabled = false;
        btnInsert.Enabled = true;
        Session["Monteur"] = Monteur;
    }

    // Beginn Defect 4099:
    public void DDLAbsenzMonat_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DDLBearbeiter.DDL.SelectedIndex > 0)
        {
            Monteur = new dbBearbeiter(Int32.Parse(DDLBearbeiter.DDL.SelectedValue));
            phTable.Controls.Clear();
            phTable.Controls.Add(GTAbsenzTable());
            Btn_CellCancel.Enabled = false;
            Btn_CellSave.Enabled = false;
            btnInsert.Enabled = true;
            Session["Monteur"] = Monteur;
        }
    }

    public void DDL_Absenzart_SelectedIndexChanged(object sender, EventArgs e)
    {
        switch (Convert.ToInt32(DDL_Absenzart.DDL.SelectedValue))
        {
            case dbGTAbsenz.gtKrankheit_begin:
            case dbGTAbsenz.gtKrankheit_ende:
            case dbGTAbsenz.gtUnfall_begin:
            case dbGTAbsenz.gtUnfall_ende:
                TapWebTextBox2.Visible = false;
                TapWebTextBox1.LabelText = "Datum";
                break;
            default:
                TapWebTextBox2.Visible = true;
                TapWebTextBox1.LabelText = "Von";
                break;
        }
    }
    // Ende Defect 4099:

    public string FilterBearbeiter_Change(object sender, EventArgs e)
    {
        DDLBearbeiter.Filter = (sender as TextBox).Text;
        Page.SetFocus(DDLBearbeiter.DDL);
        return (sender as TextBox).Text;
    }

    #region Anhand der EB's feststellen ob die Bearbeitung der ganztägigen Absenzen erlaubt ist
    private void MonthNotChangeableList()
    {
        if (dtMonthNotChangeable.Count == 0)
        {
            DateTime dtCheckDate;

            for (int iIndex = 0; iIndex < DDLAbsenzMonat.DDL.Items.Count; iIndex++)
            {
                dtCheckDate = Convert.ToDateTime(DDLAbsenzMonat.DDL.Items[iIndex].Value);
                bool bBearbeitungErlaubt = GTAbsenzBearbeitungErlaubt(dtCheckDate);

                if (!bBearbeitungErlaubt)
                {
                    //if (dtMonthNotChangeable == null)
                    //{
                    //  dtMonthNotChangeable = new ArrayList();
                    //}
                    DateTime dtTemp = dtCheckDate;
                    dtTemp = dtTemp.AddDays((dtTemp.Day - 1) * -1);
                    if (!dtMonthNotChangeable.Contains(dtTemp))
                    {
                        dtMonthNotChangeable.Add(dtTemp);
                    }
                }
            }
        }
    }
    #endregion

    public class GTAbsenzComparer : System.Collections.IComparer
    {
        public int Compare(object obj1, object obj2)
        {
            int retVal = 0;

            dbGTAbsenz GTAbsenz1 = (dbGTAbsenz)obj1;
            dbGTAbsenz GTAbsenz2 = (dbGTAbsenz)obj2;

            DateTime i11 = Convert.ToDateTime(GTAbsenz1.Params.DATUM.Value);
            DateTime i21 = Convert.ToDateTime(GTAbsenz2.Params.DATUM.Value);
            if (i11 > i21)
            {
                retVal = -1;
            }
            else
            {
                retVal = 1;
            }
            return retVal;
        }
    }

    private bool GTAbsenzBearbeitungErlaubt(DateTime dtSelectedMonth)
    {
        bool bBearbeitung = true;

        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingeführt
                // Defect 5771, Config.Nolock eingeführt
                using (SqlCommand cmd = new SqlCommand("SELECT eb.ebid, ebstat, bo.perskey_org " +
                    //"FROM einsber eb " + Config.Rowlock + ", bearborg bo " + Config.Rowlock + ", bearbeit ba " + Config.Rowlock + // 5771
                                                       "FROM einsber eb " + Config.Rowlock + ", bearborg bo " + Config.Nolock + ", bearbeit ba " + Config.Nolock +
                                                       "WHERE eb.perskey = @perskey " +
                                                       "AND DATEPART(year, eb.bermon) = @year " +
                                                       "AND DATEPART(month, eb.bermon) = @month " +
                                                       "AND bo.perskey = eb.perskey " +
                                                       "AND bo.orgkz = 'V' " +
                                                       "AND bo.perskey_org = ba.perskey " +
                                                       "AND ebstat >= 40", cnx)) // Defect 5436, using eingeführt
                // Defect 5234
                // Status 30 (freigegeben) nicht berücksichtigen
                //"AND ((ebstat >= 30 " + 
                //"AND bo.perskey_org <> @perskey_org) " +
                //"OR (ebstat >= 40))", cnx);
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", Monteur.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY_ORG", Bearbeiter.Params.PERSKEY.Value));
                    cmd.Parameters.Add(new SqlParameter("@YEAR", dtSelectedMonth.Year));
                    cmd.Parameters.Add(new SqlParameter("@MONTH", dtSelectedMonth.Month));

                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        cmd.Parameters.Clear();

                        if (rd.HasRows)
                        {
                            bBearbeitung = false;
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }

        return bBearbeitung;
    }

    private Table GTAbsenzTable()
    {
        Table GTAbsenz = new Table();

        if (DDLBearbeiter.DDL.SelectedIndex >= 0 &&
            DDLAbsenzMonat.DDL.SelectedIndex >= 0)
        {
            xxID = 0;
            string[] wTag = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa." };
            GTAbsenz.Rows.Clear();
            GTAbsenz.Width = Unit.Percentage(40);
            TableRow HeaderRow = new TableRow();
            TableCell c1 = new TableCell();
            c1.Text = "Datum";
            //c1.HorizontalAlign = HorizontalAlign.Center; 
            c1.HorizontalAlign = HorizontalAlign.Left; // Defect 4099, linksbündig
            c1.Font.Bold = true;
            c1.CssClass = "TabHeader";

            TableCell c2 = new TableCell();
            c2.Text = "Absenzart";
            c2.Font.Bold = true;
            c2.HorizontalAlign = HorizontalAlign.Center;
            c2.CssClass = "TabHeader";

            TableCell c3 = new TableCell();
            c3.CssClass = "TabHeader";
            c3.Width = 20;

            // Beginn Defect 4099
            // neu Spalte Bearbeiten
            TableCell c4 = new TableCell();
            c4.CssClass = "TabHeader";
            c4.Width = 20;
            // Ende Defect 4099

            HeaderRow.Cells.Add(c1);
            HeaderRow.Cells.Add(c2);
            HeaderRow.Cells.Add(c3);
            HeaderRow.Cells.Add(c4); // Defect 4099, Bearbeiten
            GTAbsenz.Rows.Add(HeaderRow);
            LinkButton lnkbtn;
            int iGTAzeile = 0;
            DateTime dtSelected = Convert.ToDateTime(DDLAbsenzMonat.DDL.SelectedValue);

            // Defect 4099
            // Monate die nicht mehr änderbar sind in Liste abspeichern
            MonthNotChangeableList();

            // Defect 4099:
            // Sortierung der ganztägigen Absenzen nach Datum absteigend
            GTAbsenzComparer comp = new GTAbsenzComparer();
            Monteur.GTAbsenz.Sort(comp);
            foreach (dbGTAbsenz gt in Monteur.GTAbsenz)
            {
                if (!gt.Deleted)
                {
                    if (Convert.ToDateTime(gt.Params.DATUM.Value) >= dtSelected)
                    {
                        bool bBearbeitungErlaubt = IsAllowedToDel(Convert.ToDateTime(gt.Params.DATUM.Value));

                        if ((Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit ||
                             Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall) &&
                             !IsAlone(gt, null, null))
                        {
                            continue;
                        }

                        lblListe.Visible = true;
                        lblListe.Text = "Liste der eingetragenen Absenzen";
                        HeaderRow.Visible = true;
                        Argument = gt.Params.PERSKEY.Value.ToString() + "-" + gt.Params.DATUM.Value.ToString();
                        TableRow tr = new TableRow();
                        TableCell d1 = new TableCell();
                        string DText = wTag[(int)Convert.ToDateTime(gt.Params.DATUM.Value.ToString()).DayOfWeek] +
                                       Convert.ToDateTime(gt.Params.DATUM.Value.ToString()).Day.ToString() +
                                       "." +
                                       Convert.ToDateTime(gt.Params.DATUM.Value.ToString()).Month.ToString() +
                                       "." +
                                       Convert.ToDateTime(gt.Params.DATUM.Value.ToString()).Year.ToString();
                        d1.Text = DText;
                        d1.HorizontalAlign = HorizontalAlign.Left;
                        d1.CssClass = "TabNewDay";
                        tr.Cells.Add(d1);

                        TableCell d2 = new TableCell();
                        //d2.Text = "(" + gt.Params.GTABSENZID.Value.ToString() + ") " + gt.Params.GTABSENZTXT.Value.ToString(); // Defect 4099
                        string strOld = "(" + gt.Params.GTABSENZID.Value.ToString() + ")"; // Defect 4099 
                        bool bGtAbsenzId = gt.Params.GTABSENZTXT.Value.ToString().Contains(strOld); // Defect 4099
                        if (bGtAbsenzId)
                        {
                            // ID befindet sich bereits im text
                            d2.Text = gt.Params.GTABSENZTXT.Value.ToString(); // Defect 4099
                        }
                        else
                        {
                            d2.Text = gt.Params.GTABSENZTXT.Value.ToString() + " (" + gt.Params.GTABSENZID.Value.ToString() + ")"; // Defect 4099
                        }
                        d2.HorizontalAlign = HorizontalAlign.Center;
                        d2.CssClass = "TabNewDay";
                        tr.Cells.Add(d2);

                        TableCell d3 = new TableCell();
                        //BAF 530016 Beginn
                        //Editlink wird bei alleinsteheneden Krankheit/Unfall nicht aktiviert
                        if( gt.Params.DATABGLKZ.Value != DBNull.Value && gt.Params.DATABGLKZ.Value.ToString() == "X")
                            lnkbtn = new LinkButton();
                        else
                            lnkbtn = NewTaskButton("Bearbeiten", "Edit", Argument, "Klicken Sie hier um den Eintrag zu bearbeiten.", TaskButton_Click, "~/Images/Bearbeiten_16x16.jpg");
                        //BAF 530016 Ende

                        // Beginn Defect 4099
                        if (!bBearbeitungErlaubt)
                        {
                            d3.Visible = false;
                        }
                        // Ende Defect 4099

                        d3.Controls.Add(lnkbtn);
                        d3.HorizontalAlign = HorizontalAlign.Center;
                        d3.CssClass = "TabNewDay";
                        tr.Cells.Add(d3);

                        TableCell d4 = new TableCell();
                        lnkbtn = NewTaskButton("Löschen", "Delete", Argument, "Klicken Sie hier um den Eintrag zu löschen.", TaskButton_Click, "~/Images/Trash16x16.jpg");

                        // Beginn Defect 4099
                        // Warnung ausgeben
                        switch (Convert.ToInt32(gt.Params.GTABSENZID.Value))
                        {
                            case dbGTAbsenz.gtKrankheit_begin:
                            case dbGTAbsenz.gtKrankheit_ende:
                            case dbGTAbsenz.gtUnfall_begin:
                            case dbGTAbsenz.gtUnfall_ende:
                                string warning = "Achtung! Der zugehörige Beginn oder Ende Stempel wird ebenfalls gelöscht!";
                                lnkbtn.Attributes.Add("onclick", "javascript:return " + string.Format("confirm('{0}')", warning));
                                break;
                            default:
                                break;
                        }

                        if (!bBearbeitungErlaubt)
                        {
                            d4.Visible = false;
                        }
                        // Ende Defect 4099

                        d4.Controls.Add(lnkbtn);
                        d4.HorizontalAlign = HorizontalAlign.Center;
                        d4.CssClass = "TabNewDay";
                        tr.Cells.Add(d4);

                        GTAbsenz.Rows.Add(tr);
                    }
                }
                iGTAzeile++;
            }

            if (iGTAzeile == 0)
            {
                HeaderRow.Visible = false;
                lblListe.Visible = true;
                lblListe.Text = "Bitte Absenzen hinzufügen!";
            }

            # region Auswahlliste der Absenzen vorbelegen

            foreach (dbGTAbsenz LastGTAbsenz in Monteur.GTAbsenz)
            {
                if (!LastGTAbsenz.Deleted)
                {
                    if (Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin)
                    {
                        DDL_Absenzart.DisableItem(dbGTAbsenz.gtKrankheit_begin.ToString()); // Defect 5234
                        DDL_Absenzart.DisableItem(dbGTAbsenz.gtUnfall_begin.ToString()); // Defect 5234
                        DDL_Absenzart.DisableItem(dbGTAbsenz.gtUnfall_ende.ToString()); // Defect 5234
                        //DDL_Absenzart.DDL.SelectedValue = dbGTAbsenz.gtKrankheit_ende.ToString();
                        //DDL_Absenzart.DDL.Enabled = false; 5234
                        //DDL_Absenzart_SelectedIndexChanged(null, null);
                        break;
                    }
                    else
                    {
                        if (Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin)
                        {
                            DDL_Absenzart.DisableItem(dbGTAbsenz.gtUnfall_begin.ToString()); // Defect 5234
                            DDL_Absenzart.DisableItem(dbGTAbsenz.gtKrankheit_begin.ToString()); // Defect 5234
                            DDL_Absenzart.DisableItem(dbGTAbsenz.gtKrankheit_ende.ToString()); // Defect 5234
                            //DDL_Absenzart.DDL.SelectedValue = dbGTAbsenz.gtUnfall_ende.ToString();
                            //DDL_Absenzart.DDL.Enabled = false; 5234
                            //DDL_Absenzart_SelectedIndexChanged(null, null);
                            break;
                        }
                        else
                        {
                            // Defect 5844 Beginn
                            // Einträge Krankheit und Unfall (210, 220) weiterlesen bis ev. Beginn oder Ende auftritt

                            if (Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) != dbGTAbsenz.gtKrankheit_ende &&
                                Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) != dbGTAbsenz.gtUnfall_ende)
                            {
                                continue;
                            } // Defect 5844 Ende
                            else
                            {
                                //if (Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende || Defect 5361
                                //    Convert.ToInt32(LastGTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende) 
                                //{
                                DDL_Absenzart.DDL.Enabled = true;
                                DDL_Absenzart.EnableItem(dbGTAbsenz.gtKrankheit_begin.ToString()); // Defect 5234
                                DDL_Absenzart.EnableItem(dbGTAbsenz.gtUnfall_begin.ToString()); // Defect 5234
                                DDL_Absenzart.EnableItem(dbGTAbsenz.gtKrankheit_ende.ToString()); // Defect 5234
                                DDL_Absenzart.EnableItem(dbGTAbsenz.gtUnfall_ende.ToString()); // Defect 5234
                                break;
                                //}
                            }
                        }
                    }
                    //break;
                }
            }
            #endregion
        }
        return GTAbsenz;
    }

    private LinkButton NewTaskButton(string Text,
                                     string Command,
                                     string Argument,
                                     string ToolTip,
                                     CommandEventHandler TaskButtonClick_EventHandler,
                                     string url // Defect 4099, url ergänzt
                                    )
    {
        LinkButton btn = new LinkButton();
        btn.ID = nid();
        btn.SkinID = "";
        btn.Width = Unit.Percentage(100);
        btn.Text = Text;

        // Beginn Defect 4099
        // Image anzeigen, wenn url versorgt
        if (url != "")
        {
            Image i = new Image();
            //zb: "~/Images/user_icon.gif"
            i.ImageUrl = url;
            btn.Controls.Add(i);
        }
        // Ende Defect 4099

        btn.CommandName = Command;
        btn.CommandArgument = Argument;
        btn.ToolTip = ToolTip;
        btn.Command += new CommandEventHandler(TaskButtonClick_EventHandler);
        return btn;
    }

    public string nid()
    {
        xxID++;
        return "LnkBTN->" + xxID.ToString();
    }

    void TaskButton_Click(object sender, CommandEventArgs e)
    {
        string cmd = (string)e.CommandName;
        string arg = (string)e.CommandArgument;

        switch (cmd)
        {
            case "Edit":
                // Beginn Defect 4099
                DateTime dtVon = Convert.ToDateTime(arg.Substring(arg.IndexOf("-") + 1,
                                                    arg.Length - (arg.IndexOf("-") + 1)));

                TapWebTextBox1.TextBoxText = dtVon.ToShortDateString();

                foreach (dbGTAbsenz gt in Monteur.GTAbsenz)
                {
                    if (!gt.Deleted)
                    {
                        if (Convert.ToDateTime(gt.Params.DATUM.Value) == dtVon)
                        {
                            DDL_Absenzart.DDL.SelectedValue = gt.Params.GTABSENZID.Value.ToString();
                        }
                    }
                }

                TapWebTextBox2.Visible = false;
                // Save old value
                TapWebTextBox2.TextBoxText = dtVon.ToShortDateString();
                Btn_CellSave.Enabled = true;
                Btn_CellCancel.Enabled = true;
                btnInsert.Enabled = false;

                // Ende Defect 4099
                break;
            case "Delete":
                string sPkey = arg.Substring(0, arg.IndexOf("-"));
                DateTime dtToDel = Convert.ToDateTime(arg.Substring(arg.IndexOf("-") + 1,
                                                      arg.Length - (arg.IndexOf("-") + 1)));

                // Beginn Defect 4099
                // Daten auf gelöscht setzen, und erst beim Speichern aus DB entfernen
                foreach (dbGTAbsenz GTAbsenzTodel in Monteur.GTAbsenz)
                {
                    // die zu löschende Absenz anhand des Datums gefunden
                    if (Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value) == dtToDel)
                    {
                        GTAbsenzTodel.Deleted = true;
                        // zugehörigen Beginn oder Ende bei Unfall/Krankheit löschen
                        dbGTAbsenzPaar(GTAbsenzTodel);
                        break;
                    }
                }

                // dbGTAbsenz g = new dbGTAbsenz(Monteur);
                // ParamVal.SetParameter(g.Params.PERSKEY, sPkey);
                // ParamVal.SetParameter(g.Params.DATUM, d.ToString());
                // g.Deleted = true;
                // g.Save();

                phTable.Controls.Clear();
                phTable.Controls.Add(GTAbsenzTable());
                TapWebTextBox2.Visible = true;
                Btn_CellCancel.Enabled = false;
                Btn_CellSave.Enabled = false;
                btnInsert.Enabled = true;
                btnSave.Enabled = true;
                Page.SetFocus(btnSave);
                // Page_Load(null, null);
                // Ende Defect 4099

                break;
            default:
                Exception ex = new Exception("Command not recognised: " + cmd);
                throw ex;
        }
    }

    private dbGTAbsenz dbGTAbsenzPaar(dbGTAbsenz GTAbsenzTodel)
    {
        dbGTAbsenz GTAbsenzPaar = null;

        int iGTIndex = 0;
        int iGTStartIndex = 0;
        int iGTEndeIndex = 0;

        while (iGTIndex < Monteur.GTAbsenz.Count)
        {
            dbGTAbsenz GTAbsenz = (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndex]);

            if (Convert.ToInt32(GTAbsenzTodel.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin &&
                Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende &&
                Convert.ToDateTime(GTAbsenz.Params.DATUM.Value) >= Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value))
            {
                iGTStartIndex = iGTIndex;
                // Defect 5364: nur löschen, wenn nicht bereits genehmigt
                if (IsAllowedToDel(Convert.ToDateTime(GTAbsenz.Params.DATUM.Value)))
                {
                    GTAbsenzPaar = GTAbsenz;
                    GTAbsenz.Deleted = true;
                }
                break;
            }

            if (Convert.ToInt32(GTAbsenzTodel.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende &&
                Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin &&
                Convert.ToDateTime(GTAbsenz.Params.DATUM.Value) <= Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value))
            {
                iGTEndeIndex = iGTIndex;
                // Defect 5364: nur löschen, wenn nicht bereits genehmigt
                if (IsAllowedToDel(Convert.ToDateTime(GTAbsenz.Params.DATUM.Value)))
                {
                    GTAbsenzPaar = GTAbsenz;
                    GTAbsenz.Deleted = true;
                }
                break;
            }

            if (Convert.ToInt32(GTAbsenzTodel.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin &&
                Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende &&
                Convert.ToDateTime(GTAbsenz.Params.DATUM.Value) >= Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value))
            {
                iGTStartIndex = iGTIndex;
                // Defect 5364: nur löschen, wenn nicht bereits genehmigt
                if (IsAllowedToDel(Convert.ToDateTime(GTAbsenz.Params.DATUM.Value)))
                {
                    GTAbsenzPaar = GTAbsenz;
                    GTAbsenz.Deleted = true;
                }
                break;
            }

            if (Convert.ToInt32(GTAbsenzTodel.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende &&
                Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin &&
                Convert.ToDateTime(GTAbsenz.Params.DATUM.Value) <= Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value))
            {
                iGTEndeIndex = iGTIndex;
                // Defect 5364: nur löschen, wenn nicht bereits genehmigt
                if (IsAllowedToDel(Convert.ToDateTime(GTAbsenz.Params.DATUM.Value)))
                {
                    GTAbsenzPaar = GTAbsenz;
                    GTAbsenz.Deleted = true;
                }
                break;
            }
            iGTIndex++;
        }

        // Beginn Defect 5361
        // Alle zwischen Beginn und Ende liegenden Einträge
        // als gelöscht markieren, damit bei neuerlichen Eingaben im selben Zeitraum
        // kein Fehler ausgegeben wird
        iGTIndex = 0;

        while (iGTIndex < Monteur.GTAbsenz.Count)
        {
            dbGTAbsenz GTAbsenz = (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndex]);

            if (Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende &&
                Convert.ToInt32(GTAbsenzTodel.Params.GTABSENZID.Value) == Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) &&
                Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value) == Convert.ToDateTime(GTAbsenz.Params.DATUM.Value))
            {
                iGTStartIndex = iGTIndex;
            }

            if (Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende &&
                Convert.ToInt32(GTAbsenzTodel.Params.GTABSENZID.Value) == Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) &&
                Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value) == Convert.ToDateTime(GTAbsenz.Params.DATUM.Value))
            {
                iGTStartIndex = iGTIndex;
            }

            if (Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin &&
                Convert.ToInt32(GTAbsenzTodel.Params.GTABSENZID.Value) == Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) &&
                Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value) == Convert.ToDateTime(GTAbsenz.Params.DATUM.Value))
            {
                iGTEndeIndex = iGTIndex;
            }

            if (Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin &&
                Convert.ToInt32(GTAbsenzTodel.Params.GTABSENZID.Value) == Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) &&
                Convert.ToDateTime(GTAbsenzTodel.Params.DATUM.Value) == Convert.ToDateTime(GTAbsenz.Params.DATUM.Value))
            {
                iGTEndeIndex = iGTIndex;
            }

            iGTIndex++;
        }

        iGTIndex = iGTStartIndex;

        while (iGTIndex < iGTEndeIndex)
        {
            dbGTAbsenz GTAbsenz = (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndex]);

            if (Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall ||
                Convert.ToInt32(GTAbsenz.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit)
            {
                GTAbsenz.Deleted = true;
            }

            iGTIndex++;
        }
        // Ende Defect 5361

        return GTAbsenzPaar;
    }

    private ArrayList SelectAZTag(int Perskey)
    {
        ArrayList al = new ArrayList();
        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingeführt
                using (SqlCommand cmd = new SqlCommand("select distinct(datum) from arbzeit " + Config.Rowlock + " where perskey=" + Perskey, cnx)) // Defect 5436
                {
                    using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                    {
                        while (rd.Read())
                        {
                            al.Add((DateTime)rd.GetValue(0));
                        }
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
        }
        return al;
    }

    /*
     *   / CG - Defect 4312 - CODE AUSKOMMENTIERT f. V1.0.0020
        //  (siehe header)
  
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (DDLBearbeiter.DDL.SelectedIndex > 0)
            {

                if (Page.IsValid)
                {

                    bool doInsert = true;
                    ArrayList AzTage = SelectAZTag((int)Monteur.Params.PERSKEY.Value);

                    DateTime dv = Convert.ToDateTime(TapWebTextBox1.TextBoxText);
                    DateTime db = Convert.ToDateTime(TapWebTextBox2.TextBoxText);
                    if (db.Ticks < dv.Ticks)
                    {
                        Label1.Visible = true;
                        Label1.ForeColor = System.Drawing.Color.Red;
                        Label1.Text = "DatumBis muss größe sein als DatumVon.";
                        doInsert = false;
                    }
                    else
                    {
                        while (dv.Ticks <= db.Ticks)
                        {
                            foreach (dbGTAbsenz g in Monteur.GTAbsenz)
                            {
                                if (g.Params.DATUM.Value.ToString() == dv.ToString())
                                {
                                    Label1.Visible = true;
                                    Label1.ForeColor = System.Drawing.Color.Red;
                                    Label1.Text = "Zu diesem Datum <" + dv.ToShortDateString() + "> gibt es Bereit ein Eintrag.";
                                    doInsert = false;
                                }
                                else
                                {
                                    if (dv.Ticks < g.TagMin.Ticks)
                                    {
                                        Label1.Visible = true;
                                        Label1.ForeColor = System.Drawing.Color.Red;
                                        Label1.Text = "DatumVon darf nicht kleiner als Anfang vorhieriges Monat sein.";
                                        doInsert = false;
                                    }
                                }

                            }
                            foreach (DateTime d in AzTage)
                            {
                                if (d.Ticks == dv.Ticks)
                                {
                                    Label1.Visible = true;
                                    Label1.ForeColor = System.Drawing.Color.Red;
                                    Label1.Text = "Am " + d.ToShortDateString() + " sind bereits Arbeitszeiten eingetragen.";
                                    doInsert = false;
                                }
                            }
                            dv = dv.AddDays(1);
                        }
                    }

                    if (doInsert)
                    {
                        dv = Convert.ToDateTime(TapWebTextBox1.TextBoxText);
                        Label1.Visible = false;
                        // CG - Defect 4312 Logik f. Ganztägige Absenzen:
                        // Begin und Ende Absenz einfügen
                        bool beginSet = false;
                        bool endeSet = false;
                        bool IstZeitspanne = (dv.Ticks < db.Ticks);
                        int SelectedValue = Convert.ToInt32(wDDL_Absenzart.DDL.SelectedValue);
                        int GTAbsenzId = SelectedValue;
                        //Ende
                        while (dv.Ticks <= db.Ticks)
                        {
                       
                    // insert kaltag mit Datum dv
                    //       if ((Convert.ToInt32(wDDL_Absenzart.DDL.SelectedValue) == 210) |
                    //                (Convert.ToInt32(wDDL_Absenzart.DDL.SelectedValue) == 220)) 
                    //       {
                    //             //GT-Absenz eintragen bei Krankheit und Unfall
                    //             dbGTAbsenz g = new dbGTAbsenz(Monteur);
                    //             ParamVal.SetParameter(g.Params.GTABSENZID, wDDL_Absenzart.DDL.SelectedValue);
                    //             ParamVal.SetParameter(g.Params.DATUM, dv.ToString());
                    //             g.Save();
                    //       }
                    //       else
                    //        {
                    //            if (Monteur.IstArbeitstag(dv)) //sollte heute was hackeln
                    //            {
                    //                 //GT-Absenz eintragen
                    //                 dbGTAbsenz g = new dbGTAbsenz(Monteur);
                    //                 ParamVal.SetParameter(g.Params.GTABSENZID, wDDL_Absenzart.DDL.SelectedValue);
                    //                 ParamVal.SetParameter(g.Params.DATUM, dv.ToString());
                    //                 g.Save();
                    //             }
                    //         }
                            if (SelectedValue == gtKrankheit | SelectedValue == gtUnfall)
                            {
                                    switch (SelectedValue)
                                    {
                                        case gtKrankheit:
                                            if (IstZeitspanne)
                                            {
                                                if (!beginSet)
                                                {
                                                    GTAbsenzId = gtKrankheit_begin;
                                                    beginSet = true;
                                                }
                                                else
                                                {
                                                    if (dv.Ticks < db.Ticks)
                                                    {
                                                        GTAbsenzId = gtKrankheit;
                                                    }
                                                    else
                                                    {
                                                        GTAbsenzId = gtKrankheit_ende;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                GTAbsenzId = gtKrankheit;                                
                                            }
                                            break;
                                        case gtUnfall:
                                            if (IstZeitspanne)
                                            {
                                                if (!beginSet)
                                                {
                                                    GTAbsenzId = gtUnfall_begin;
                                                    beginSet = true;
                                                }
                                                else
                                                {
                                                    if (dv.Ticks < db.Ticks)
                                                    {
                                                        GTAbsenzId = gtUnfall;
                                                    }
                                                    else
                                                    {
                                                        GTAbsenzId = gtUnfall_ende;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                GTAbsenzId = gtKrankheit;                                
                                            }
                                            break;
                                    }
                            
                                    //GT-Absenz eintragen bei Krankheit und Unfall
                                    dbGTAbsenz g = new dbGTAbsenz(Monteur);
                                    ParamVal.SetParameter(g.Params.GTABSENZID, GTAbsenzId.ToString());
                                    ParamVal.SetParameter(g.Params.DATUM, dv.ToString());
                                    g.Save();
                            }
                            else
                            {
                                if (Monteur.IstArbeitstag(dv)) //sollte heute was hackeln
                                {
                                    //GT-Absenz eintragen
                                    dbGTAbsenz g = new dbGTAbsenz(Monteur);
                                    ParamVal.SetParameter(g.Params.GTABSENZID, GTAbsenzId.ToString());
                                    ParamVal.SetParameter(g.Params.DATUM, dv.ToString());
                                    g.Save();
                                }
                            }
                            dv = dv.AddDays(1);
                        }
                        TapWebTextBox1.TextBoxText = "";
                        TapWebTextBox2.TextBoxText = "";
                    }
                }
                phTable.Controls.Clear();
                Page_Load(null, null);
            }
            else
            {
                Label3.Visible = true;
                Label3.ForeColor = System.Drawing.Color.Red;
                Label3.Text = "* Bitte zuerst ein Mitarbeiter auswählen";
            }
        }
     */

    // Beginn Defect 4099
    protected void btnInsert_Click(object sender, EventArgs e)
    {
        DateTime dAutoKrankEnde = DateTime.MinValue; // Defect 5921

        if (DDLBearbeiter.DDL.SelectedIndex > 0)
        {
            if (Page.IsValid)
            {
                if (!CheckKVOption())
                    return;

                bool doInsert = true;
                ArrayList AzTage = SelectAZTag((int)Monteur.Params.PERSKEY.Value);

                DateTime dv = Convert.ToDateTime(TapWebTextBox1.TextBoxText);
                DateTime db;

                if (TapWebTextBox2.TextBoxText != "")
                {
                    db = Convert.ToDateTime(TapWebTextBox2.TextBoxText);
                }
                else
                {
                    db = dv;
                }

                bool bInsert = true;

                if (!IsAllowedToDel(dv))
                {
                    bInsert = false;
                }

                if (!bInsert)
                {
                    lblError.Visible = true;
                    lblError.ForeColor = System.Drawing.Color.Red;
                    lblError.Text = "Für das eingegebene Monat <" +
                                    dv.Month + "/" + dv.Year +
                                    "> können keine Absenzen mehr erfasst werden";
                    doInsert = false;
                }
                else
                {
                    if (db.Ticks < dv.Ticks)
                    {
                        lblError.Visible = true;
                        lblError.ForeColor = System.Drawing.Color.Red;
                        //Label1.Text = "DatumBis muss größer sein als DatumVon."; // Defect 4099, Text korr.
                        lblError.Text = "Das eingegebene Von-Datum muss kleiner oder gleich dem Bis-Datum sein."; // Defect 4099, Text korr.
                        doInsert = false;
                    }
                    else
                    {
                        while (dv.Ticks <= db.Ticks)
                        {
                            foreach (dbGTAbsenz g in Monteur.GTAbsenz)
                            {
                                if (!g.Deleted)
                                {
                                    // Beginn Defect 5234
                                    // Überprüfung ob es bereits Absenzen zu diesem Tag gibt,
                                    // in Abhängigkeit von Absenzart
                                    int SelectedValue = Convert.ToInt32(DDL_Absenzart.DDL.SelectedValue);

                                    // Beginn Defect 5921
                                    // if the new GTAbsenz is "Krankheit begin" or "Unfall begin" then the variable dAutoKrankEnde
                                    // is the date of the following GTAbsenz day in the same month - 1 day
                                    // only if exists any GTAbsenz day in the same month
                                    if (Convert.ToDateTime(g.Params.DATUM.Value) > dv && Convert.ToDateTime(g.Params.DATUM.Value).Month == dv.Month &&
                                        (SelectedValue == dbGTAbsenz.gtKrankheit_begin || SelectedValue == dbGTAbsenz.gtUnfall_begin))
                                    {
                                        dAutoKrankEnde = Convert.ToDateTime(g.Params.DATUM.Value).AddDays(-1);
                                    }
                                    // Ende Defect 5921

                                    if (g.Params.DATUM.Value.ToString() == dv.ToString())
                                    {
                                        // Es existiert bereits ein Eintrag für diesen Tag
                                        if (SelectedValue == dbGTAbsenz.gtKrankheit_begin ||
                                            SelectedValue == dbGTAbsenz.gtKrankheit_ende ||
                                            SelectedValue == dbGTAbsenz.gtUnfall_begin ||
                                            SelectedValue == dbGTAbsenz.gtUnfall_ende)
                                        {
                                            if (SelectedValue == dbGTAbsenz.gtKrankheit_begin &&
                                                (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende ||
                                                 Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit))
                                            {
                                            }
                                            else
                                            {
                                                if (SelectedValue == dbGTAbsenz.gtKrankheit_ende &&
                                                    (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                                                     Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit))
                                                {
                                                }
                                                else
                                                {
                                                    if (SelectedValue == dbGTAbsenz.gtUnfall_ende &&
                                                       (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                                                        Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall))
                                                    {
                                                    }
                                                    else
                                                    {
                                                        if (SelectedValue == dbGTAbsenz.gtUnfall_begin &&
                                                            (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende ||
                                                             Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall))
                                                        {
                                                        }
                                                        else
                                                        {
                                                            doInsert = false;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            doInsert = false;
                                        }

                                        if (!doInsert)
                                        {
                                            lblError.Visible = true;
                                            lblError.ForeColor = System.Drawing.Color.Red;
                                            lblError.Text = "Zum <" + dv.ToShortDateString() + "> gibt es bereits einen Eintrag.";
                                        }
                                    } // Ende Defect 5234
                                    else
                                    {
                                        if (dv.Ticks < g.TagMin.Ticks)
                                        {
                                            lblError.Visible = true;
                                            lblError.ForeColor = System.Drawing.Color.Red;
                                            lblError.Text = "Das eingegebene Von-Datum darf nicht kleiner als der Anfang des vorherigen Monats sein.";
                                            doInsert = false;
                                        }
                                    }
                                }
                            }

                            foreach (DateTime d in AzTage)
                            {
                                if (d.Ticks == dv.Ticks)
                                {
                                    lblError.Visible = true;
                                    lblError.ForeColor = System.Drawing.Color.Red;
                                    lblError.Text = "Am " + d.ToShortDateString() + " sind bereits Arbeitszeiten eingetragen.";
                                    doInsert = false;
                                }
                            }
                            dv = dv.AddDays(1);
                        }
                    }
                }

                if (doInsert)
                {
                    dbGTAbsenz gtnew;
                    dbGTAbsenz gtauto; // Defect 5921
                    dv = Convert.ToDateTime(TapWebTextBox1.TextBoxText);
                    lblError.Visible = false;
                    int SelectedValue = Convert.ToInt32(DDL_Absenzart.DDL.SelectedValue); // Defect 4099

                    while (dv.Ticks <= db.Ticks)
                    {
                        // insert kaltag mit Datum dv
                        if (SelectedValue == dbGTAbsenz.gtKrankheit_begin ||
                            SelectedValue == dbGTAbsenz.gtKrankheit_ende ||
                            SelectedValue == dbGTAbsenz.gtUnfall_begin ||
                            SelectedValue == dbGTAbsenz.gtUnfall_ende)
                        {
                            // Damit richtig sortiert wird 1 Sek. addieren,
                            // wird vor der Speicherung wieder subtrahiert
                            if (SelectedValue == dbGTAbsenz.gtKrankheit_ende ||
                                SelectedValue == dbGTAbsenz.gtUnfall_ende)
                            {
                                dv = dv.AddSeconds(1);
                            }
                            // GT-Absenz eintragen bei Krankheit und Unfall
                            gtnew = new dbGTAbsenz(Monteur);
                            gtnew.AllowUpdate = false;
                            gtnew.AllowInsert = true; // Defect 4099
                            ParamVal.SetParameter(gtnew.Params.GTABSENZID, DDL_Absenzart.DDL.SelectedValue);
                            ParamVal.SetParameter(gtnew.Params.GTABSENZTXT, DDL_Absenzart.DDL.SelectedItem.ToString());
                            ParamVal.SetParameter(gtnew.Params.DATUM, dv.ToString());

                            // Überprüfung ob eingegeben eintägige Absenz alleinstehend,
                            // da diese sonst mit Beginn / Ende eingegeben werden muss

                            if (IsAlone(gtnew, null, null))
                            {
                                Monteur.GTAbsenz.Add(gtnew);
                                // Beginn Defect 5921
                                // the end of Krankheit/Unfall will be generated automatically  
                                // in case of one more GTAbsenz day exists in the same month already
                                // and warning message will be displayed
                                if (dAutoKrankEnde != DateTime.MinValue)
                                {
                                    gtauto = new dbGTAbsenz(Monteur);
                                    gtauto.AllowUpdate = false;
                                    gtauto.AllowInsert = true;

                                    switch (Convert.ToInt32(gtnew.Params.GTABSENZID.Value))
                                    {
                                        case dbGTAbsenz.gtKrankheit_begin:
                                            ParamVal.SetParameter(gtauto.Params.GTABSENZID, dbGTAbsenz.gtKrankheit_ende.ToString());
                                            ParamVal.SetParameter(gtauto.Params.GTABSENZTXT, dbGTAbsenz.gtKrankheit_ende_txt);
                                            break;
                                        case dbGTAbsenz.gtUnfall_begin:
                                            ParamVal.SetParameter(gtauto.Params.GTABSENZID, dbGTAbsenz.gtUnfall_ende.ToString());
                                            ParamVal.SetParameter(gtauto.Params.GTABSENZTXT, dbGTAbsenz.gtUnfall_ende_txt);
                                            break;
                                    }
                                    ParamVal.SetParameter(gtauto.Params.DATUM, dAutoKrankEnde.ToString());
                                    Monteur.GTAbsenz.Add(gtauto);
                                    string warning = "Achtung! Der zugehörige Ende Stempel wird automatisch generiert weil es schon im selben Monat eine GT Absenz gibt!";
                                    // Defect 5973 begin
                                    //System.Windows.Forms.MessageBox.Show(warning);
                                    lbInfo.Text = warning;
                                    Session["showMessage"] = true;
                                    // Defect 5973 ende
                                }

                                // Ende Defect 5921
                                btnSave.Enabled = true; // Defect 4099
                            }
                            else
                            {
                                lblError.Visible = true;
                                lblError.ForeColor = System.Drawing.Color.Red;
                                lblError.Text = "Die am " + Convert.ToDateTime(gtnew.Params.DATUM.Value).ToShortDateString() + " eingegebene Absenz grenzt an eine weitere Absenz, bitte mit Beginn/Ende Stempel erfassen.";
                                doInsert = false;
                            }
                            //g.Save(); // Defect 4099, Save in DB erst mit Button btnSave
                        }
                        else
                        {
                            // Defect  5661 GN 25.11.2007
                            // Überprüfung auf Fenstertage eingebaut
                            //BAF 530042 Verwendung von AZMKalenderTage statt AZM Aufrufen 
                            if (Monteur.AZMKalenderTage.ContainsKey(dv))
                            {
                                if (Monteur.AZMKalenderTage[dv].IstArbeitstag || Monteur.AZMKalenderTage[dv].IstFenstertag)
                                {
                                    // GT-Absenz eintragen
                                    gtnew = new dbGTAbsenz(Monteur);
                                    gtnew.AllowUpdate = false;
                                    gtnew.AllowInsert = true; // Defect 4099
                                    ParamVal.SetParameter(gtnew.Params.GTABSENZID, DDL_Absenzart.DDL.SelectedValue);
                                    ParamVal.SetParameter(gtnew.Params.GTABSENZTXT, DDL_Absenzart.DDL.SelectedItem.ToString());
                                    ParamVal.SetParameter(gtnew.Params.DATUM, dv.ToString());
                                    Monteur.GTAbsenz.Add(gtnew);
                                    btnSave.Enabled = true; // Defect 4099
                                    //g.Save(); // Defect 4099, Save in DB erst mit Button btnSave
                                }
                                else
                                {
                                    if (dv.Ticks == db.Ticks) // Defect 5220, Ausgabe der Meldung nur, wenn genau ein Tag erfasst wurde
                                    {
                                        lblError.Visible = true;
                                        lblError.ForeColor = System.Drawing.Color.Red;
                                        lblError.Text = "Am " + dv.ToShortDateString() + " können keine ganztägigen Absenzen eingetragen werden, da es sich um keinen Arbeitstag handelt.";
                                    }
                                }
                            } //BAF 530042 Ende
                            else
                            {
                                if (Monteur.IstArbeitstag(dv) || Monteur.IstFenstertag(dv)) // sollte heute was hackeln
                                {
                                    // GT-Absenz eintragen
                                    gtnew = new dbGTAbsenz(Monteur);
                                    gtnew.AllowUpdate = false;
                                    gtnew.AllowInsert = true; // Defect 4099
                                    ParamVal.SetParameter(gtnew.Params.GTABSENZID, DDL_Absenzart.DDL.SelectedValue);
                                    ParamVal.SetParameter(gtnew.Params.GTABSENZTXT, DDL_Absenzart.DDL.SelectedItem.ToString());
                                    ParamVal.SetParameter(gtnew.Params.DATUM, dv.ToString());
                                    Monteur.GTAbsenz.Add(gtnew);
                                    btnSave.Enabled = true; // Defect 4099
                                    //g.Save(); // Defect 4099, Save in DB erst mit Button btnSave
                                }
                                else
                                {
                                    if (dv.Ticks == db.Ticks) // Defect 5220, Ausgabe der Meldung nur, wenn genau ein Tag erfasst wurde
                                    {
                                        lblError.Visible = true;
                                        lblError.ForeColor = System.Drawing.Color.Red;
                                        lblError.Text = "Am " + dv.ToShortDateString() + " können keine ganztägigen Absenzen eingetragen werden, da es sich um keinen Arbeitstag handelt.";
                                    }
                                }
                            }
                        }
                        dv = dv.AddDays(1);
                    }
                    TapWebTextBox1.TextBoxText = "";
                    TapWebTextBox2.TextBoxText = "";
                }
            }
            Page.SetFocus(btnSave);
            phTable.Controls.Clear();
            phTable.Controls.Add(GTAbsenzTable());
            //Page_Load(null, null); / Defect 4099
        }
        else
        {
            lblErrorMA.Visible = true;
            lblErrorMA.ForeColor = System.Drawing.Color.Red;
            lblErrorMA.Text = "* Bitte zuerst einen Mitarbeiter auswählen";
        }
    }

    protected void Btn_CellSave_Click(object sender, EventArgs e)
    {
        dbGTAbsenz gtmod = new dbGTAbsenz(Monteur);
        DateTime dtDatumnew = Convert.ToDateTime(TapWebTextBox1.TextBoxText); // new value
        DateTime dtDatumold = Convert.ToDateTime(TapWebTextBox2.TextBoxText); // old value
        ParamVal.SetParameter(gtmod.Params.GTABSENZID, DDL_Absenzart.DDL.SelectedValue);
        ParamVal.SetParameter(gtmod.Params.GTABSENZTXT, DDL_Absenzart.DDL.SelectedItem.ToString());
        ParamVal.SetParameter(gtmod.Params.DATUM, dtDatumnew.ToString());

        // Beginn Defect 5361
        // Überprüfung ob für neu eingegebenes Datum ein Eintrag existiert
        lblError.Visible = false;

        bool doInsert = true;

        if (dtDatumnew != dtDatumold)
        {
            foreach (dbGTAbsenz gt in Monteur.GTAbsenz)
            {
                if (gt.Params.DATUM.Value.ToString() == dtDatumnew.ToString() && !gt.Deleted)  // Defect 5921 - added "&& !gt.Deleted"
                {
                    // Es existiert bereits ein Eintrag für diesen Tag
                    if (Convert.ToInt32(gtmod.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                        Convert.ToInt32(gtmod.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende ||
                        Convert.ToInt32(gtmod.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                        Convert.ToInt32(gtmod.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende)
                    {
                        if (Convert.ToInt32(gtmod.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin &&
                            (Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende ||
                             Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit))
                        {
                        }
                        else
                        {
                            if (Convert.ToInt32(gtmod.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende &&
                                (Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                                 Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit))
                            {
                            }
                            else
                            {
                                if (Convert.ToInt32(gtmod.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende &&
                                   (Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                                    Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall))
                                {
                                }
                                else
                                {
                                    if (Convert.ToInt32(gtmod.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin &&
                                        (Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende ||
                                         Convert.ToInt32(gt.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall))
                                    {
                                    }
                                    else
                                    {
                                        doInsert = false;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        doInsert = false;
                    }

                    if (!doInsert)
                    {
                        lblError.Visible = true;
                        lblError.ForeColor = System.Drawing.Color.Red;
                        lblError.Text = "Zum <" + dtDatumnew.ToShortDateString() + "> gibt es bereits einen Eintrag.";
                    }
                }
            }
        }
        // Ende Defect 5361

        if (doInsert) // Defect 5361
        {
            int iGTAbsenz = 0;
            if (!CheckKVOption())
                return;
            foreach (dbGTAbsenz gt in Monteur.GTAbsenz)
            {
                if (!gt.Deleted)
                {
                    // zu ändernden Eintrag gefunden
                    if (Convert.ToDateTime(gt.Params.DATUM.Value) == dtDatumold)
                    {
                        // Datum wurde geändert, daher alten Satz löschen
                        // un neuen Satz anlegen (Update funktioniert auf Primary key nicht)
                        if (dtDatumnew != dtDatumold)
                        {
                            // zu ändernde Absenz gefunden
                            ((dbGTAbsenz)Monteur.GTAbsenz[iGTAbsenz]).Deleted = true;
                            gtmod.AllowUpdate = false;
                            gtmod.AllowInsert = true;
                            Monteur.GTAbsenz.Insert(iGTAbsenz, gtmod);
                            break;
                        }
                        else
                        {
                            ParamVal.SetParameter(((dbGTAbsenz)Monteur.GTAbsenz[iGTAbsenz]).Params.GTABSENZID,
                                                  Convert.ToString(gtmod.Params.GTABSENZID.Value));
                            ParamVal.SetParameter(((dbGTAbsenz)Monteur.GTAbsenz[iGTAbsenz]).Params.GTABSENZTXT,
                                                  Convert.ToString(gtmod.Params.GTABSENZTXT.Value));
                            ((dbGTAbsenz)Monteur.GTAbsenz[iGTAbsenz]).AllowUpdate = true;
                        }
                    }
                }
                iGTAbsenz++;
            }

            DDL_Absenzart.DDL.SelectedIndex = 0;
            TapWebTextBox1.TextBoxText = "";
            TapWebTextBox2.TextBoxText = "";
            TapWebTextBox2.Visible = true;
            Btn_CellCancel.Enabled = false;
            Btn_CellSave.Enabled = false;
            btnInsert.Enabled = true;
            btnSave.Enabled = true;
            Page.SetFocus(btnSave);

            phTable.Controls.Clear();
            phTable.Controls.Add(GTAbsenzTable());
        }
    }

    private bool CheckKVOption()
    {
        try
        {
            if (DDL_Absenzart.DDL.Items[DDL_Absenzart.DDL.SelectedIndex].Text.StartsWith("Freizeitoption lt. KV") && (Monteur.KVOption == null || Monteur.KVOption == false))
            {
                lblError.Visible = true;
                lblError.ForeColor = System.Drawing.Color.Red;
                lblError.Text = "Freizeitoption lt. KV in AZM für den Mitarbeiter ist nicht freigeschaltet";
                return false;
            }
            else
                return true;
        }
        catch(Exception ex)
        {
            lblError.Visible = true;
            lblError.ForeColor = System.Drawing.Color.Red;
            lblError.Text = "CheckKVOption Exception: " + ex.Message;
            return false;
        }
    }

    protected void Btn_CellCancel_Click(object sender, EventArgs e)
    {
        DDL_Absenzart.DDL.SelectedIndex = 0;
        TapWebTextBox1.TextBoxText = "";
        TapWebTextBox2.TextBoxText = "";
        TapWebTextBox2.Visible = true;
        Btn_CellCancel.Enabled = false;
        Btn_CellSave.Enabled = false;
        btnInsert.Enabled = true;
    }
    // Ende Defect 4099

    private bool IsAlone(dbGTAbsenz gtToCheck, dbGTAbsenz gtPrev, dbGTAbsenz gtNext)
    {
        bool bAlone = true;

        //BAF 530016 - unter DATABGLKZ = "X" werden alleinstehende Krankheiten/Unfälle abgespeichert
        if (gtToCheck.Params.DATABGLKZ.Value != DBNull.Value && gtToCheck.Params.DATABGLKZ.Value.ToString() == "X")
            return true;

        if (gtPrev != null)
        {
            if (Convert.ToDateTime(gtToCheck.Params.DATUM.Value).AddDays(1) == Convert.ToDateTime(gtPrev.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(gtPrev.Params.DATUM.Value).Second * -1) &&
                (Convert.ToInt32(gtPrev.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit ||
                 Convert.ToInt32(gtPrev.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                 Convert.ToInt32(gtPrev.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende))
            {
                bAlone = false;
            }
            if (Convert.ToDateTime(gtToCheck.Params.DATUM.Value).AddDays(1) == Convert.ToDateTime(gtPrev.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(gtPrev.Params.DATUM.Value).Second * -1) &&
                (Convert.ToInt32(gtPrev.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall ||
                 Convert.ToInt32(gtPrev.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                 Convert.ToInt32(gtPrev.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende))
            {
                bAlone = false;
            }
        }

        if (gtNext != null)
        {
            if (Convert.ToDateTime(gtToCheck.Params.DATUM.Value).AddDays(-1) == Convert.ToDateTime(gtNext.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(gtNext.Params.DATUM.Value).Second * -1) &&
                (Convert.ToInt32(gtNext.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit ||
                 Convert.ToInt32(gtNext.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                 Convert.ToInt32(gtNext.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende))
            {
                bAlone = false;
            }
            if (Convert.ToDateTime(gtToCheck.Params.DATUM.Value).AddDays(-1) == Convert.ToDateTime(gtNext.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(gtNext.Params.DATUM.Value).Second * -1) &&
                (Convert.ToInt32(gtNext.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall ||
                 Convert.ToInt32(gtNext.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                 Convert.ToInt32(gtNext.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende))
            {
                bAlone = false;
            }
        }

        if (gtPrev == null &&
            gtNext == null)
        {
            int iGTIndex = 0;

            while (iGTIndex < Monteur.GTAbsenz.Count)
            {
                dbGTAbsenz g = (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndex]);

                if (Convert.ToDateTime(g.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(g.Params.DATUM.Value).Second * -1) == Convert.ToDateTime(gtToCheck.Params.DATUM.Value) &&
                    !g.Deleted) // Defect 5364: gelöschte Absenzen nicht berücksichtigen
                {
                    int iGTIndexPrev = iGTIndex - 1;
                    int iGTIndexNext = iGTIndex + 1;

                    if (iGTIndexPrev >= 0 &&
                        iGTIndexNext < Monteur.GTAbsenz.Count)
                    {
                        if (IsAlone(g, (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndexPrev]), (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndexNext])))
                        {
                            bAlone = true;
                        }
                        else
                        {
                            bAlone = false;
                        }
                    }
                    else
                    {
                        if (iGTIndexPrev >= 0)
                        {
                            if (IsAlone(g, (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndexPrev]), null))
                            {
                                bAlone = true;
                            }
                            else
                            {
                                bAlone = false;
                            }
                        }
                        else
                        {
                            if (iGTIndexNext < Monteur.GTAbsenz.Count)
                            {
                                if (IsAlone(g, null, (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndexNext])))
                                {
                                    bAlone = true;
                                }
                                else
                                {
                                    bAlone = false;
                                }
                            }
                        }
                    }
                }
                iGTIndex++;
            }
        }

        return bAlone;
    }

    private bool IsAllowedToDel(DateTime dtToCheck)
    {
        bool bAllowed = true;

        if (dtMonthNotChangeable != null)
        {
            foreach (DateTime dtMonth in dtMonthNotChangeable)
            {
                if (dtMonth.Year == dtToCheck.Year &&
                    dtMonth.Month == dtToCheck.Month)
                {
                    bAllowed = false;
                }
            }
        }
        return bAllowed;
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (DDLBearbeiter.DDL.SelectedIndex > 0)
        {
            // Nach Eingabe von Krankheit/Unfall Beginn Stempel
            // wird geprüft, ob es danach Arbeitszeiten gibt
            foreach (dbGTAbsenz g in Monteur.GTAbsenz)
            {
                if (!g.Deleted)
                {
                    if (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                        Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin)
                    {
                        ArrayList AzTage = SelectAZTag((int)Monteur.Params.PERSKEY.Value);
                        int iAzInd;
                        for (iAzInd = AzTage.Count - 1; iAzInd >= 0; iAzInd--)
                        {
                            DateTime d = (DateTime)AzTage[iAzInd];
                            if (d.Ticks >= Convert.ToDateTime(g.Params.DATUM.Value).Ticks)
                            {
                                lblError.Visible = true;
                                lblError.ForeColor = System.Drawing.Color.Red;
                                lblError.Text = "Am " + d.ToShortDateString() + " sind bereits Arbeitszeiten eingetragen. Bitte entsprechenden Ende Stempel erfassen!";
                                return;
                            }
                        }
                    }
                    if (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende ||
                        Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende)
                    {
                        break;
                    }
                }
            }

            lblError.Visible = false;
            int iGTIndex = 0;

            while (iGTIndex < Monteur.GTAbsenz.Count)
            {
                dbGTAbsenz g = (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndex]);
                // alle Einträge = Unfall(220) und Krankheit (210) löschen,
                // diese werden danach neu generiert
                if (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit ||
                    Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall)
                {
                    //bool bDel = true;

                    // Prüfen ob Löschen erlaubt (nicht genehmigte)
                    if (IsAllowedToDel(Convert.ToDateTime(g.Params.DATUM.Value)))
                    {
                        //bDel = false;
                        // nur löschen, wenn nicht alleinstehend (einzelne Tage, kein Bereich)
                        if (!IsAlone(g, null, null))
                        {
                            g.Deleted = true;
                            g.Save();
                            Monteur.GTAbsenz.RemoveAt(iGTIndex);
                            continue;
                        }
                    }
                    else
                    {
                        // Defect 5364: Krankenstand/Unfall aus Liste löschen damit nachfolgende Logik funktioniert,
                        // aber nicht aus DB, da diese bereits genehmigt wurden
                        Monteur.GTAbsenz.RemoveAt(iGTIndex);
                        continue;
                    }

                    //if (IsAlone(g, null, null))
                    //{
                    //  bDel = false;
                    //}

                    //if (bDel)
                    //{
                    //  g.Deleted = true;
                    //  g.Save();
                    //  Monteur.GTAbsenz.RemoveAt(iGTIndex);
                    //  continue;
                    //}
                    //else // Beginn Defect 5364
                    //{
                    //  // Krankenstand/Unfall aus Liste löschen damit nachfolgende Logik funktioniert,
                    //  // aber nicht aus DB, da diese bereits genehmigt wurden
                    //  Monteur.GTAbsenz.RemoveAt(iGTIndex); 
                    //  continue;
                    //}
                    //// Ende Defect 5364
                }
                iGTIndex++;
            }

            #region Absenzen für einen Tag vorher abarbeiten
            iGTIndex = 0;
            int iBeginInd = -1;
            DateTime dtBeginDate = DateTime.MinValue;

            while (iGTIndex < Monteur.GTAbsenz.Count)
            {
                dbGTAbsenz g = (dbGTAbsenz)(Monteur.GTAbsenz[iGTIndex]);
                DateTime dtCurDate = Convert.ToDateTime(g.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(g.Params.DATUM.Value).Second * -1);

                if (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                    Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin)
                {
                    iBeginInd = iGTIndex;
                    dtBeginDate = Convert.ToDateTime(g.Params.DATUM.Value);
                }

                if ((Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende ||
                     Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende) &&
                    (dtCurDate.AddDays(-1) == dtBeginDate ||
                     dtCurDate == dtBeginDate))
                {
                    ((dbGTAbsenz)Monteur.GTAbsenz[iBeginInd]).Deleted = true;
                    ((dbGTAbsenz)Monteur.GTAbsenz[iGTIndex]).Deleted = true;
                    iBeginInd = -1;
                    dtBeginDate = DateTime.MinValue;
                }

                iGTIndex++;
            }

            int iEndeInd = -1;
            DateTime dtEndeDate = DateTime.MinValue;

            for (int iGTBeginnInd = 0, iGTEndeInd = Monteur.GTAbsenz.Count; iGTBeginnInd < iGTEndeInd; iGTBeginnInd++)
            {
                dbGTAbsenz g = (dbGTAbsenz)(Monteur.GTAbsenz[iGTBeginnInd]);
                DateTime dtCurDate = Convert.ToDateTime(g.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(g.Params.DATUM.Value).Second * -1);

                if (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende ||
                    Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende)
                {
                    iEndeInd = iGTBeginnInd;
                    dtEndeDate = Convert.ToDateTime(g.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(g.Params.DATUM.Value).Second * -1);
                }

                if ((Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                     Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin) &&
                    (dtCurDate.AddDays(-1) == dtEndeDate ||
                     dtCurDate == dtEndeDate))
                {
                    ((dbGTAbsenz)Monteur.GTAbsenz[iEndeInd]).Deleted = true;
                    ((dbGTAbsenz)Monteur.GTAbsenz[iGTBeginnInd]).Deleted = true;
                    iEndeInd = -1;
                    dtEndeDate = DateTime.MinValue;

                    // GT-Absenz eintragen bei Krankheit und Unfall
                    dbGTAbsenz gtOneDay = new dbGTAbsenz(Monteur);
                    gtOneDay.AllowUpdate = false;
                    gtOneDay.AllowInsert = true;
                    // Beginn Defect 5506
                    // In Abhängigkeit von Beginn/Ende Stempel den entsprechenden Eintrag erzeugen
                    int GTAbsenzIdtmp = 0;
                    switch (Convert.ToInt32(g.Params.GTABSENZID.Value))
                    {
                        case dbGTAbsenz.gtUnfall_begin:
                        case dbGTAbsenz.gtUnfall_ende:
                            GTAbsenzIdtmp = dbGTAbsenz.gtUnfall;
                            ParamVal.SetParameter(gtOneDay.Params.DATABGLKZ, "X"); //BAF 530016
                            break;
                        case dbGTAbsenz.gtKrankheit_begin:
                        case dbGTAbsenz.gtKrankheit_ende:
                            GTAbsenzIdtmp = dbGTAbsenz.gtKrankheit;
                            ParamVal.SetParameter(gtOneDay.Params.DATABGLKZ, "X"); //BAF 530016
                            break;
                    }
                    ParamVal.SetParameter(gtOneDay.Params.GTABSENZID, GTAbsenzIdtmp.ToString());
                    DDL_Absenzart.DDL.SelectedValue = GTAbsenzIdtmp.ToString();

                    // ParamVal.SetParameter(gtOneDay.Params.GTABSENZID, dbGTAbsenz.gtKrankheit.ToString());
                    // DDL_Absenzart.DDL.SelectedValue = dbGTAbsenz.gtKrankheit.ToString();
                    // Ende Defect 5506

                    ParamVal.SetParameter(gtOneDay.Params.GTABSENZTXT, DDL_Absenzart.DDL.SelectedItem.ToString());
                    ParamVal.SetParameter(gtOneDay.Params.DATUM, dtCurDate.ToString());
                    Monteur.GTAbsenz.Add(gtOneDay);
                }
            }

            #endregion

            //if (Page.IsValid)
            //{
            // Defect 4099
            // CG - Defect 4312 Logik f. Ganztägige Absenzen:
            // Begin und Ende Absenz einfügen
            // bool beginSet = false;
            bool endeSet = false;
            DateTime dtBeginn = new DateTime(0);
            DateTime dtEnde = new DateTime(0);
            int GTAbsenzId = 0;
            dbGTAbsenz gtnew;

            //for (int iGTBeginnInd = 0, iGTEndeInd = Monteur.GTAbsenz.Count; iGTBeginnInd < iGTEndeInd; iGTBeginnInd++) Defect 5506
            //for (int iGTBeginnInd = 0, iGTEndeInd = Monteur.GTAbsenz.Count - 1; iGTBeginnInd < iGTEndeInd; iGTBeginnInd++) // Defect 5506, iGTEndeInd korr.
            // Defect 5618, Endebedingung (iGTBeginnInd <= iGTEndeInd) korr. 
            for (int iGTBeginnInd = 0, iGTEndeInd = Monteur.GTAbsenz.Count - 1; iGTBeginnInd <= iGTEndeInd; iGTBeginnInd++) // Defect 5618, Endebedingung (iGTBeginnInd <= iGTEndeInd) korr. 
            {
                dbGTAbsenz g = (dbGTAbsenz)(Monteur.GTAbsenz)[iGTBeginnInd];

                if (!g.Deleted)
                {
                    switch (Convert.ToInt32(g.Params.GTABSENZID.Value))
                    {
                        case dbGTAbsenz.gtUnfall_begin:
                        case dbGTAbsenz.gtUnfall_ende:
                            GTAbsenzId = dbGTAbsenz.gtUnfall;
                            break;
                        case dbGTAbsenz.gtKrankheit_begin:
                        case dbGTAbsenz.gtKrankheit_ende:
                            GTAbsenzId = dbGTAbsenz.gtKrankheit;
                            break;
                    }

                    // Defect 5734, nur die Absenzen Krankheit/Unfall dürfen berücksichtigt werden
                    if (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                        Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                        Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende ||
                        Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende)
                    {
                        if (dtEnde.Ticks == 0)
                        {
                            DateTime dttmp = Convert.ToDateTime(g.Params.DATUM.Value);
                            dtEnde = dttmp.AddDays(System.DateTime.DaysInMonth(dttmp.Year, dttmp.Month) - dttmp.Day);
                            dtBeginn = dtEnde;
                        }

                        if (Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                            Convert.ToInt32(g.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin)
                        {
                            dtBeginn = Convert.ToDateTime(g.Params.DATUM.Value);
                        }

                        if (Convert.ToInt32(g.Params.GTABSENZID.Value) != dbGTAbsenz.gtKrankheit_begin &&
                            Convert.ToInt32(g.Params.GTABSENZID.Value) != dbGTAbsenz.gtUnfall_begin)
                        {
                            dtEnde = Convert.ToDateTime(g.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(g.Params.DATUM.Value).Second * -1);
                            endeSet = true;
                        }

                        if (Convert.ToDateTime(g.Params.DATUM.Value) > dtBeginn)
                        {
                            dtEnde = Convert.ToDateTime(g.Params.DATUM.Value);
                        }
                        bool IstZeitspanne = (dtBeginn.Ticks < dtEnde.Ticks);

                        while (IstZeitspanne)
                        {
                            dtBeginn = dtBeginn.AddDays(1);
                            IstZeitspanne = (dtBeginn.Ticks < dtEnde.Ticks);

                            // GT-Absenz eintragen bei Krankheit und Unfall
                            gtnew = new dbGTAbsenz(Monteur);
                            gtnew.AllowUpdate = false;
                            gtnew.AllowInsert = true;
                            if (dtBeginn == dtEnde)
                            {
                                if (endeSet)
                                {
                                    continue;
                                }
                            }
                            ParamVal.SetParameter(gtnew.Params.GTABSENZID, GTAbsenzId.ToString());
                            if (Convert.ToInt32(gtnew.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_begin ||
                                Convert.ToInt32(gtnew.Params.GTABSENZID.Value) == dbGTAbsenz.gtKrankheit_ende ||
                                Convert.ToInt32(gtnew.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_begin ||
                                Convert.ToInt32(gtnew.Params.GTABSENZID.Value) == dbGTAbsenz.gtUnfall_ende)
                            {
                                DDL_Absenzart.DDL.SelectedValue = GTAbsenzId.ToString();
                                ParamVal.SetParameter(gtnew.Params.GTABSENZTXT, DDL_Absenzart.DDL.SelectedItem.ToString());
                            }
                            ParamVal.SetParameter(gtnew.Params.DATUM, dtBeginn.ToString());
                            Monteur.GTAbsenz.Add(gtnew);
                        }
                    }
                }
            }

            // Beginn Defect 5361
            // zuerst alle zu löschenden Absenzen bearbeiten und aus DB entfernen und
            // gelöschte Einträge aus der Liste entfernen
            int iGTDelIndex = 0;
            while (iGTDelIndex < Monteur.GTAbsenz.Count)
            {
                dbGTAbsenz g = ((dbGTAbsenz)Monteur.GTAbsenz[iGTDelIndex]);

                if (g.Deleted)
                {
                    bool bChange = true;

                    if (!IsAllowedToDel(Convert.ToDateTime(g.Params.DATUM.Value)))
                    {
                        bChange = false;
                    }

                    if (bChange)
                    {
                        ParamVal.SetParameter(g.Params.DATUM, Convert.ToDateTime(g.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(g.Params.DATUM.Value).Second * -1).ToString());
                        g.Save();
                        Monteur.GTAbsenz.RemoveAt(iGTDelIndex);
                        iGTDelIndex = 0;
                        continue; // Defect 5506, Schleif von vorne starten
                    }
                }
                iGTDelIndex++;
            }
            // Ende Defect 5361

            // Änderungen in DB speichern
            foreach (dbGTAbsenz g in Monteur.GTAbsenz)
            {
                bool bChange = true;

                if (!IsAllowedToDel(Convert.ToDateTime(g.Params.DATUM.Value)))
                {
                    bChange = false;
                }

                if (bChange)
                {
                    ParamVal.SetParameter(g.Params.DATUM, Convert.ToDateTime(g.Params.DATUM.Value).AddSeconds(Convert.ToDateTime(g.Params.DATUM.Value).Second * -1).ToString());
                    g.Save();
                }

                btnSave.Enabled = false;
            }
        }

        phTable.Controls.Clear();
        phTable.Controls.Add(GTAbsenzTable());
    }
}
