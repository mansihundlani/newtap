﻿//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : TapWebTextBox.ascx.cs
//
// Description  : Custom Eingabe
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 30.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 5190, 5211
//                Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt löschen
//
//=============== V1.0.0029 ===================================================
//
// Date         : 06. Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using TapMontage.Misc;
using System.Collections.Generic;

public partial class TapWebTextBox : System.Web.UI.UserControl
{
    /// <summary>
    /// must return True if Valid
    /// </summary>
    /// <param name="Source"></param>
    /// <param name="args"></param>
    /// <returns></returns>
    public delegate bool TWTextBoxCustomValidator(object Source, ServerValidateEventArgs args);
    public TWTextBoxCustomValidator CustValidatorDelegee;

    /// <summary>
    /// must return (object as TextBox).Text or modified value
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    /// <returns></returns>
    public delegate string TWTextBoxTextChanged(object sender, EventArgs e);
    public TWTextBoxTextChanged TextBoxChangedDelegee;

    private string mDataField = "";
    private TapWebTextBoxType mBoxType = TapWebTextBoxType.Text;
    public enum TapWebTextBoxType
    {
        Text = 0,
        TextArea = 1,
        Date = 2,
        Time = 3,
        DateTime = 4,
        Integer = 5,
        Float = 6,
        MußText = 7
    }

    private string inputNames = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        // System.Diagnostics.Debug.WriteLine("holo");        
        //txtTextBox.ValidationGroup = "RDZeile";
    }

    public TextBox TB
    {
        get { return txtTextBox; }
        set { txtTextBox = value; }
    }

    public string TextBoxClientID
    {
        get { return txtTextBox.ClientID; }
    }

    public void FocusOnMe()
    {
        txtTextBox.Focus();
    }

    public bool AutoPostback
    {
        set
        {
            txtTextBox.AutoPostBack = value;
        }
        get 
        { 
            return txtTextBox.AutoPostBack; 
        }
    }

    public bool CheckRequired
    {
        get
        {
            return ReqValidator.Enabled;
        }
        set
        {
            ReqValidator.Enabled = value;
        }
    }

    public bool CheckValid
    {
        get
        {
            return CustValidator.Enabled;
        }
        set
        {
            CustValidator.Enabled = value;
        }
    }

    public string LabelText
    {
        set { lblTextBox.Text = value; }
        get { return lblTextBox.Text; }
    }

    public string TextBoxText
    {
        set { txtTextBox.Text = value; }
        get { return txtTextBox.Text; }
    }

    public int TextBoxWidth
    {
        set { txtTextBox.Width = value; }
        get { return Convert.ToInt16(txtTextBox.Width.Value); }
    }

    public int LabelWidth
    {
        set { lblTextBox.Width = value; }
        get { return Convert.ToInt16(lblTextBox.Width.Value); }
    }

    public string DataField
    {
        set { mDataField = value; }
        get { return mDataField; }
    }

    public string ValidationGroup
    {
        set { txtTextBox.ValidationGroup = value; }
        get { return txtTextBox.ValidationGroup; }
    }

    public bool ShowCalendar
    {
        set
        {
            this.CalendarPopup.Visible = value;
        }
        get
        {
            return this.CalendarPopup.Visible;
        }
    }

    //Intermediate solution for finding out the name of an input field
    public string InputNames
    {
        set
        {
            this.inputNames = value;
        }
        get
        {
            return this.inputNames;
        }
    }


    // Beginn #5190, 5211 - Erfassen KFZ-Daten , anzeigen falsches Kalendermonat; KFZ-Fahrt löschen
    public string SelectedDate
    {
        set
        {            
            Literal l = new Literal();
            l.Text = "<a Onclick=\"window.open('../DatePicker.aspx?backf=" + inputNames + "&selectedDate=" + value + "', 'calendarPopup', 'width=180,height=190,left=' + (window.screenLeft+window.event.clientX-180) + ', top=' + (window.screenTop+window.event.clientY));\"><img valign=\"bottom\" src=\"../images/dreieck.gif\"/></a>";//left=' + l + ',top=' + t + ',resizable=no')
            CalendarPopup.Controls.Clear();
            CalendarPopup.Controls.Add(l);
        }
    } 
    // Ende #5190, 5211

    public TapWebTextBoxType TextBoxType
    {
        set
        {
            mBoxType = value;
            switch (mBoxType)
            {
                case TapWebTextBoxType.Date:
                    txtTextBox.TextMode = TextBoxMode.SingleLine;
                    // currently disabled - don't confuse users
                    //lnkButton.Visible = true;
                    txtTextBox.Width = Convert.ToInt16(txtTextBox.Width.Value - lnkButton.Width.Value);

                    Literal l = new Literal();
                    l.Text = "<a Onclick=\"window.open('../DatePicker.aspx?backf=" + inputNames + "', 'calendarPopup', 'width=180,height=190,left=' + (window.screenLeft+window.event.clientX-180) + ', top=' + (window.screenTop+window.event.clientY));\"><img valign=\"bottom\" src=\"../images/dreieck.gif\"/></a>";//left=' + l + ',top=' + t + ',resizable=no')                     
                    
                    CalendarPopup.Controls.Add(l);
                    break;
                case TapWebTextBoxType.TextArea:
                    txtTextBox.TextMode = TextBoxMode.MultiLine;
                    txtTextBox.Rows = 3;
                    break;
                default:
                    txtTextBox.TextMode = TextBoxMode.SingleLine;
                    lnkButton.Visible = false;
                    lnkButton.Width = 0;
                    break;
            }
        }
        get { return mBoxType; }
    }

    public bool SetDataReader(SqlDataReader DR)
    {
        for (int i = 0; i < DR.FieldCount; i++)
        {
            if (mDataField == DR.GetName(i))
            {
                txtTextBox.Text = DR.GetValue(i).ToString();
                return true;
            }
        }
        return false;
    }

    public bool Enabled
    {
        set { txtTextBox.Enabled = value; }
        get { return txtTextBox.Enabled; }
    }

    public void Validator()
    {
        CustValidator.Validate();
    }

    protected void CustValidator_ServerValidate(object source, ServerValidateEventArgs args)
    {
        switch (mBoxType)
        {
            case TapWebTextBoxType.Date:
                args.IsValid = RangeCheck.IsDate(RangeCheck.FixDate(txtTextBox.Text));
                if (!args.IsValid) CustValidator.ErrorMessage = "Geben Sie bitte ein gültiges Datum an, z.B.: " + DateTime.Now.ToShortDateString();
                break;
            case TapWebTextBoxType.DateTime:
                break;
            case TapWebTextBoxType.MußText:
                if (txtTextBox.Text != "")
                    args.IsValid = true;
                else
                    args.IsValid = false;
                if (!args.IsValid) CustValidator.ErrorMessage = "Geben Sie bitte ein Text an";
                break;
            case TapWebTextBoxType.Text:
                args.IsValid = true;
                break;
            case TapWebTextBoxType.TextArea:
                args.IsValid = true;
                break;
            case TapWebTextBoxType.Time:
                args.IsValid = RangeCheck.IsTime(RangeCheck.FixTime(txtTextBox.Text));
                if (!args.IsValid) CustValidator.ErrorMessage = "Geben Sie bitte eine gültige Uhrzeit an, z.B.: " + DateTime.Now.ToShortTimeString();
                break;
            case TapWebTextBoxType.Integer:
                args.IsValid = RangeCheck.IsInteger(txtTextBox.Text);
                if (!args.IsValid) CustValidator.ErrorMessage = "Geben Sie bitte eine ganze Zahl an.";
                break;
            case TapWebTextBoxType.Float:
                args.IsValid = RangeCheck.IsNumeric(txtTextBox.Text);
                double x = 10101.99;
                if (!args.IsValid) CustValidator.ErrorMessage = "Geben Sie bitte eine Zahl an, z.B.: " + x.ToString("N");
                break;
        }
        if (CustValidatorDelegee != null)
            args.IsValid = CustValidatorDelegee(source, args);
    }

    protected void txtTextBox_TextChanged(object sender, EventArgs e)
    {
        switch (mBoxType)
        {
            case TapWebTextBoxType.Date:
                txtTextBox.Text = RangeCheck.FixDate(txtTextBox.Text);
                break;
            case TapWebTextBoxType.DateTime:
                break;
            case TapWebTextBoxType.Text:
                break;
            case TapWebTextBoxType.TextArea:
                break;
            case TapWebTextBoxType.Time:
                txtTextBox.Text = RangeCheck.FixTime(txtTextBox.Text);
                break;
            case TapWebTextBoxType.Integer:
                break;
            case TapWebTextBoxType.Float:
                txtTextBox.Text = RangeCheck.FixNumeric(txtTextBox.Text);
                break;
        }
        if (TextBoxChangedDelegee != null) txtTextBox.Text = TextBoxChangedDelegee(sender, e);
    }
}
