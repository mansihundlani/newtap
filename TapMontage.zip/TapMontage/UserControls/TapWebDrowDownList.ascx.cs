﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : TapWebDrowDownList.ascx.cs
//
// Description  : Datenbankzugriffe - Funktionen zur Befüllung d.GUI-Objekte
//                (ComboBox, listen, ...)
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2013
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//                
//=============== V1.0.0047 ===============================================
//
// Date         : 24.Juni 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-42
//                Berichtsmonat fürs Rücksetzmaske
//
//=============== V1.0.0042 ===============================================
//
// Date         : 24.Juni 2008
// Author       : Joldic Dzevad
// Defect#      : MC49359
//                Ortsangabe bei Inlandsreisen ist Mussfeld
//
//=============== V1.0.0037 ===============================================
//
// Date         : 18.Jänner 2008
// Author       : Joldic Dzevad
// Defect#      : 5750
//                Initialisierung des Objekts "DDL.Berichtsmonat" eingefügt 
//
//=============== V1.0.0033 ===============================================
//
// Date         : 03. September 2007
// Author       : Wolfgang Patrman
// Defect#      : 5415
//                Logik eingeschränkt auf Maske Erfassen EB
//
//=============== V1.0.0032 ===============================================
//
// Date         : 07. August 2007
// Author       : Adam Kiefer
// Defect#      : 4116
//                Filter mit 1. Ergebnis
//
//=============== V1.0.0029 ===============================================
//
// Date         : 12. Juli 2007
// Author       : Wolfgang Patrman
// Defect#      : 5234
//                EnableItem eingebaut
//
//=============== V1.0.0028 ===============================================
//
// Date         : 13. Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4099
//                Anzeige ab Monat der ganztägigen Absenzen
//
//=============== V1.0.0028 ===============================================
//
// Date         : 01. Juni 2007
// Author       : Adam Kiefer
// Defect#      : 3278
//                Suchen Projekt
//
//=============== V1.0.0028 ===============================================
//
// Date         : 30. Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4079
//                Liste aller zu genehmigenden Mitarbeiter
//
//=============== V1.0.0028 ===============================================
//
// Date         : 30. Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4077
//                Abrechnungsmonat und Liste Mitarbeiter sofort anzeigen
//
//=============== V1.0.0027 ===============================================
//
// Date         : 14. Mai 2007
// Author       : GN
// Defect#      : 4931
//                Neue Liste Mitfahrt
//
//=============== V1.0.0022 ===============================================
//
// Date         : 21. Februar 2007
// Author       : Wolfgang Patrman
// Defect#      : 4655
//                Anzeige EB und RA, neues DropDown AnzBerichtsmonat, MAStatus
//
//=========================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using TapMontage.dbObjects;

public partial class TapWebDropDownList : System.Web.UI.UserControl
{
    //MA:private string mSQL = "";
    private string mSelVal = "";
    private string mDataField = "";
    private bool initialized = false;
    public delegate void TWDDLSelectedIndexChangedDelegee(object sender, EventArgs e);
    public TWDDLSelectedIndexChangedDelegee SelIndexChanged;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (lblDDL == null) lblDDL = new Label();
        if (WebDDL == null) WebDDL = new DropDownList();
        if ((!Page.IsPostBack) & (!initialized))
            SetInitsSQL(" ", mSelVal);
        //MA: else
        //    if (WebDDL.SelectedIndex >= 0) DDLSelectedValue = WebDDL.SelectedValue;
    }

    // Beginn #4116 - Filter mit 1. Ergebnis
    protected void Page_PreRender(object sender, EventArgs e)
    {
        // Nur 1 Eintrag (nicht ausgewählt) -> automatisch aswählen und vorbelegen, Nur Seite 'EB_Zeiten.aspx'
        // Defect 5415, Logik auf Maske 'Einsatzbericht erfassen' eingeschränkt'
        if ((WebDDL.Items.Count == 2) && (WebDDL.SelectedIndex != 1) && (Request.Url.PathAndQuery.Contains("EB_Zeiten.aspx")))
        {
            WebDDL.SelectedIndex = 1;
            WebDDL_SelectedIndexChanged(WebDDL, null);
        }
    }
    // Ende #4116

    public void SetInitsSQL(string SQL, string SelectedValue)
    {
        dbBearbeiter c = (dbBearbeiter)Session["Bearbeiter"];
        dbMontBer m = (dbMontBer)Session["MBericht"];
        switch (mListType)
        {
            case DDLObjListe.Absenzarten_Ganztägig:
                WebDDL = m.Bearbeiter.Commons.DDL2(WebDDL, SelectedValue, m.Bearbeiter.Commons.GTAbsenzID, m.Bearbeiter.KVOption);
                break;
            case DDLObjListe.Absenzarten_Stundenweise:
                WebDDL = m.Bearbeiter.Commons.DDL2(WebDDL, SelectedValue, m.Bearbeiter.Commons.STDAbsenzID, m.Bearbeiter.KVOption);
                break;
            case DDLObjListe.Baustellenoffen:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Baustellenoffen);
                break;
            case DDLObjListe.BaustellenMitAZM:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.BaustellenMitAZM);
                break;
            case DDLObjListe.AlleBaustellen:
                //dbBaustelle b = (dbBaustelle)Session["Baustelle"];
                //b.DDLBaustellen("", ref WebDDL);
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.AlleBaustellen);
                break;
            case DDLObjListe.BaustellenNr:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.BaustellenNr);
                break;
            case DDLObjListe.Baustellenstati:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Baustellenstati);
                break;
            case DDLObjListe.Berichtsmonat:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Berichtsmonat);
                // Selektion des vorigen Monats
                WebDDL.SelectedIndex = WebDDL.Items.Count - 2; // Defect #5750
                break;

            // Beginn #4077 - Abrechnungsmonat und Liste Mitarbeiter sofort anzeigen          
            case DDLObjListe.Berichtsmonat_Genehmigung:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Berichtsmonat);
                WebDDL.SelectedIndex = WebDDL.Items.Count - 2;
                break;
            // Ende #4077

            // Beginn #4079 - Liste aller zu genehmigenden Mitarbeiter
            case DDLObjListe.StatusFilter:
                WebDDL = c.Commons.DDL(WebDDL, "alle", c.Commons.StatusFilter);
                break;
            // Ende #4079
            // Beginn CR 4655: Berichtsmonat für Anzeige EB und RA befüllen
            // und defaultmässig das vorige Monat selektieren
            case DDLObjListe.AnzBerichtsmonat:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.AnzBerichtsmonat);
                // Selektion des vorigen Monats
                WebDDL.SelectedIndex = WebDDL.Items.Count - 2;
                break;
            // Ende CR 4655
            // Beginn TAPM-42
            case DDLObjListe.RuecksetzenBerichtsmonat:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.RuecksetzenBerichtsmonat);
                // Selektion des vorigen Monats
                WebDDL.SelectedIndex = 0;
                break;
            // Ende TAPM-42
            case DDLObjListe.GK_Auftrag:
                WebDDL = m.Bearbeiter.Commons.DDL(WebDDL, SelectedValue, m.Bearbeiter.Commons.GK_Auftrag);
                break;
            case DDLObjListe.Laender:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Laender);
                break;
            case DDLObjListe.Leistungsart:
                WebDDL = m.Bearbeiter.Commons.DDL(WebDDL, SelectedValue, m.Bearbeiter.Commons.Leistungsart);
                break;
            case DDLObjListe.Auslagenarten:
                WebDDL = m.Bearbeiter.Commons.DDL(WebDDL, SelectedValue, m.Bearbeiter.Commons.Auslagenarten);
                //                WebDDL = m.Bearbeiter.Commons.DDL(WebDDL, SelectedValue, c.Commons.Auslagenarten);
                break;
            case DDLObjListe.Mitarbeiter_Alle:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Mitarbeiter_Alle);
                break;
            case DDLObjListe.Mitarbeiter_Sicht_Montageleiter:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Mitarbeiter_Sicht_Montageleiter);
                break;
            case DDLObjListe.Standorte:
                //c.Standort.DDLStandort(ref WebDDL);
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Standorte);
                break;
            case DDLObjListe.Verkehrsmittel:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Verkehrsmittel);
                break;
            case DDLObjListe.Bereitstellungsarten:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Bereitstellungsarten);
                break;
            case DDLObjListe.Projekte_Kaufmann:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Projekte_Kaufmann);
                break;
            case DDLObjListe.ProjekteKO_Kaufmann:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.ProjekteKO_Kaufmann);
                break;
            case DDLObjListe.Projekte_Montageleiter:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Projekte_Montageleiter);
                break;
            case DDLObjListe.Projekt_AusZulagen:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.Projekt_AusZulagen);
                break;
            case DDLObjListe.GTAbsenze:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.GTAbsenze);
                break;
            case DDLObjListe.SEG_Punkte:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.SEGPunkte);
                break;
            // Beginn CR 4655: MAStatus (inaktive, aktive, alle) für Anzeige EB und RA befüllen
            // und defaultmässig aktive Mitarbeiter selektieren
            case DDLObjListe.MAStatus:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.MAStatus);
                WebDDL.SelectedIndex = 0;
                break;
            // Ende CR 4655

            //CR 4931
            //GN 14.5.2007
            //Beginn
            case DDLObjListe.AnzMitfahrer:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.AnzMitfahrer);
                break;
            //Ende

            // Beginn Defect 4099:
            // Anzeige ab Monat der ganztägigen Absenzen
            // default: Berichtsmonat -1
            case DDLObjListe.AbsenzMonat:
                WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.AbsenzMonat);
                WebDDL.SelectedIndex = WebDDL.Items.Count - 3;
                break;
            // Ende Defect 4099
            //MC49359 - die Ortschaften von der Baustellen ermitteln
            case DDLObjListe.Ortschaften:
                try
                {
                    //Wegen über 19.000 Einträge, DDL Laden erst nachdem der Filter eingeschaltet ist
                    bool readData = (bool)Session["FilterOrtschaften"];
                    if (readData == true)
                        WebDDL = c.Commons.DDL(WebDDL, SelectedValue, c.Commons.AlleOrtschaften);
                }
                catch { }
                break;
        }
        if (lStartEmpty)
            WebDDL.Items.Insert(0, new ListItem("", "-1"));
        Session["Bearbeiter"] = c;
        //MA:if (WebDDL.SelectedIndex >= 0)
        //mSelVal = WebDDL.SelectedValue;
        //DDLSelectedValue = WebDDL.SelectedValue;
    }

    public enum DDLObjListe
    {
        Keine_Liste,
        Absenzarten_Ganztägig,
        Absenzarten_Stundenweise,
        Auslagenarten,
        AlleBaustellen,
        Baustellenoffen,
        BaustellenMitAZM,
        BaustellenNr,
        Baustellenstati,
        Bereitstellungsarten,
        Berichtsmonat,
        Berichtsmonat_Genehmigung, //Adam Kiefer 4077 ergänzt, Abrechnungsmonat und Liste Mitarbeiter sofort anzeigen
        GK_Auftrag,
        GTAbsenze,
        Laender,
        Leistungsart,
        Mitarbeiter_Alle,
        Mitarbeiter_Sicht_Montageleiter,
        Mitarbeiter_Sicht_Genehmiger,
        Monat_Berichtsmonat,
        Projekt_AusZulagen,
        Projekte_Montageleiter,
        ProjekteKO_Montageleiter,
        Projekte_Kaufmann,
        ProjekteKO_Kaufmann,
        SEG_Punkte,
        Standorte,
        Standard_AusZulage,
        StatusFilter, //Adam Kiefer 4079 ergänzt, Liste aller zu genehmigenden Mitarbeiter
        Verkehrsmittel,
        AnzBerichtsmonat, // CR 4655 ergänzt, Berichtsmonate für Anzeige
        MAStatus, // CR 4655 ergänzt, Status Mitarbeiter
        AnzMitfahrer, //CR 4931 14.5.07 GN ergänzt, Anzahl Mitfahrer für Reisezeilen
        AbsenzMonat, // Defect 4099, Anzeige ab Monat der ganztägigen Absenzen
        Ortschaften, // MC49359, die Ortschaften von der Baustellen
        RuecksetzenBerichtsmonat //TAPM-42
    };

    public string ValidationGroup
    {
        set { WebDDL.ValidationGroup = value; }
        get { return WebDDL.ValidationGroup; }
    }

    public DropDownList DDL
    {
        get { return WebDDL; }
        set { WebDDL = value; }
    }

    public string DDLClientID
    {
        get { return WebDDL.ClientID; }
    }

    public void FocusOnMe()
    {
        WebDDL.Focus();
    }

    private bool lStartEmpty = false;
    public bool StartEmpty
    {
        get { return lStartEmpty; }
        set { lStartEmpty = value; }
    }

    private DDLObjListe mListType = new DDLObjListe();
    public DDLObjListe ListType
    {
        set { mListType = value; }
        get { return mListType; }
    }

    private bool lAutoPostback = false;
    public bool AutoPostback
    {
        set
        {
            WebDDL.AutoPostBack = value;
            lAutoPostback = value;
        }
        get { return lAutoPostback; }
    }

    public string LabelText
    {
        set { lblDDL.Text = value; }
        get { return lblDDL.Text; }
    }

    public int DDLWidth
    {
        set { WebDDL.Width = value; }
        get { return Convert.ToInt16(WebDDL.Width.Value); }
    }

    public string DDLDataField
    {
        set { mDataField = value; }
        get { return mDataField; }
    }

    private string mFilter;
    public string Filter
    {
        get { return mFilter; }
        set
        {
            mFilter = value;
            SetInitsSQL("", "");
            if (mFilter != "")
                if (WebDDL.Items.Count > 0)
                    // Beginn #3278 - Suchen Projekt
                    for (int i = WebDDL.Items.Count - 1; i >= 1; i--)
                        if ((WebDDL.Items[i].Text.ToUpper().IndexOf(Filter.ToUpper()) < 0) & (WebDDL.Items[i].Value != "-1")) WebDDL.Items.RemoveAt(i);
            // Ende #3278
        }
    }

    public string DDLSelectedValue
    {
        set
        {
            //WebDDL.SelectedValue = value;
            //mSelVal = value;
            SetInitsSQL("", value);
            initialized = true;
        }
        get
        {
            //MA:return mSelVal;
            return WebDDL.SelectedValue;
        }
    }

    public int LabelWidth
    {
        set { lblDDL.Width = value; }
        get { return Convert.ToInt16(lblDDL.Width.Value); }
    }

    public bool Enabled
    {
        set { WebDDL.Enabled = value; }
        get { return WebDDL.Enabled; }
    }
    protected void WebDDL_SelectedIndexChanged(object sender, EventArgs e)
    {
        //MA:mSelVal = WebDDL.SelectedValue;
        if (SelIndexChanged != null) SelIndexChanged(sender, e);
    }

    // Beginn Defect 4099
    public void DisableItem(string strItemValue)
    {
        foreach (ListItem li in WebDDL.Items)
        {
            if (li.Value == strItemValue)
            {
                li.Enabled = false;
            }
        }
    }
    // Ende Defect 4099

    // Beginn Defect 5234
    public void EnableItem(string strItemValue)
    {
        foreach (ListItem li in WebDDL.Items)
        {
            if (li.Value == strItemValue)
            {
                li.Enabled = true;
            }
        }
    }
    // Ende Defect 5234
}
