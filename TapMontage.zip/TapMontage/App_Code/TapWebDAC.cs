﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : TapWebDAC.cs
//
// Description  : TapWebDAC
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0029 ===============================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=========================================================================

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Net;


/// <summary>
/// Summary description for objDAC
/// </summary>

    public class TapWebDAC
    {
        SqlConnection SissiConnection = null;
        public int PerskeyLogin = 0;
        public int PerskeyVertretener = 0;
        public TapWebDAC()
        {
            SissiConnection = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
        }

        public bool SQLSelectResult(string SQL, ref SqlDataReader OR)
        {

            try
            {
                if (SissiConnection.State == ConnectionState.Open)
                    SissiConnection.Close();
                  using (SqlCommand OB = new SqlCommand(SQL, SissiConnection)) // Defect 5436, using eingeführt
                  {
                    SissiConnection.Open();
                    OR = OB.ExecuteReader(CommandBehavior.CloseConnection);
                    if (OR.HasRows)
                      return true;
                    else
                      return false;
                  }
            }
            catch (Exception e)
            {
                e.Data.Add("TapWebDAC::SQLSelectResult::Parameters::SQL", SQL);
                throw e;  
            }
        }

        public bool SQLExecuteResult(string SQL)
        {
            try
            {
                if (SissiConnection.State == ConnectionState.Open)
                    SissiConnection.Close();
                  using (SqlCommand OB = new SqlCommand(SQL, SissiConnection)) // Defect 5436
                  {
                    SissiConnection.Open();
                    return (OB.ExecuteNonQuery() > 0);
                  }
            }
            catch
            {
                return false;
            }
        }

        public int GetNewMaxID(string TableName, string ValueField)
        {
            SqlDataReader DR = null;
            if (SQLSelectResult("select max(" + ValueField + ") from " + TableName, ref DR) == true)
            {
                DR.Read();
                return Convert.ToInt32(DR[0]) + 1;
            }
            else
                return 1;
        }

        public SqlDataAdapter GetDataAdapter(string SQL)
        {
            if (SissiConnection.State == ConnectionState.Open)
                SissiConnection.Close();
            SqlDataAdapter tmp = new SqlDataAdapter(SQL, SissiConnection);
            SqlCommandBuilder tmpCMD = new SqlCommandBuilder(tmp);
            tmp.UpdateCommand = tmpCMD.GetUpdateCommand();
            return tmp;
        }

        public string GetUpdateSQLString(string TableName, string KeyString, ControlCollection Controls)
        {
            string tmpSQL = "update " + TableName + " set ";
            foreach (Control Box in Controls)
            {
                if (Box.GetType().Name.Contains("_webtextbox_"))
                {

                    //((WebTextBox)Box).TextBoxText = "hallo";
                }
            }
            tmpSQL += " where " + KeyString;
            return tmpSQL;
        }

        public string GetSingleSQLResult(string SQL)
        {
            SqlDataReader DR = null;
            if (SQLSelectResult(SQL,ref DR)==true)
            {
                DR.Read();
                return DR[0].ToString();
            }
            return "";
        }
    }
