//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : RangeCheck.cs
//
// Description  : Checken des Datentyps
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using System.Text.RegularExpressions;

namespace TapMontage.Misc
{
    /// <summary>
    /// Summary description for RangeCheck
    /// </summary>
    public static class RangeCheck
    {

        public static bool IsNumeric(string NumText)
        {
            try
            {
                decimal Sepp = Convert.ToDecimal(NumText);
            }
            catch
            {
                return false;
            }
            return true;
        }
        public static string FixNumeric(string NumText)
        {
            try
            {
                return Convert.ToDecimal(NumText).ToString("N");
            }
            catch
            {
                return "";
            }
        }
        public static bool IsInteger(string NumText)
        {
            try
            {
                long Sepp = Convert.ToInt64(NumText);
            }
            catch
            {
                return false;
            }
            return true;
        }
        public static bool IsDate(string DateText)
        {
            try
            {
                DateTime Sepp = Convert.ToDateTime(DateText);
            }
            catch
            {
                return false;
            }
            return true;
        }
        public static bool IsTime(string TimeText)
        {
            try
            {
                DateTime Sepp = Convert.ToDateTime(TimeText);
            }
            catch
            {
                return false;
            }
            return true;
        }
        public static string FixDate(string dateString)
        {
            string ds = dateString;
            ds = ds.Replace(".", "");
            ds = ds.Replace(",", "");
            ds = ds.Replace(" ", "");
            ds = ds.Replace("/", "");
            if (ds.Length >= 6)
            {
                ds = ds.Substring(0, 2) + "." + ds.Substring(2, 2) + "." + ds.Substring(4);
                try
                {
                    DateTime d = Convert.ToDateTime(ds);
                }
                catch
                {
                    return dateString;
                }
                return ds;
            }
            else return dateString; //could not fix it
        }

        private static string CreateTimeString(int hour, int minute)
        {
            if (hour < 0 || hour > 24) throw new Exception();
            if (minute < 0 || minute > 59) throw new Exception();
            if (hour == 24 && minute != 0) throw new Exception();

            string hourstring = hour.ToString();
            if (hour < 10) hourstring = "0" + hourstring;

            string minutestring = minute.ToString();
            if (minute < 10) minutestring = "0" + minutestring;

            return hourstring + ":" + minutestring;
        }

        //Tries to create a string in the format xx:yy from the given input where xx=00-23 and yy=00-59
        public static string FixTime(string input)
        {
            
            input = input.Trim();
            if (input == "") return input;
            if (input.Length == 0 || input.Length > 5) return input;

            if (input.Length == 1)
            {
                if (!Regex.IsMatch(input, "\\d")) return input; //One digit
                return "0" + input + ":00"; //If input is one digit, output is 00:00 - 09:00
            }

            if (input.Length == 2)
            {
                if (!Regex.IsMatch(input, "\\d\\d")) return input; ; //2 digits
                int hour = Int16.Parse(input);

                return CreateTimeString(hour, 0); //If input is two digits <= 24, output is 00:00 - 23:00
            }

            if (input.Length == 3)
            {
                if (!Regex.IsMatch(input, "\\d\\d\\d")) return input;
                int hour = Int16.Parse(input.Substring(0,1));
                int minute = Int16.Parse(input.Substring(1,2));

                return CreateTimeString(hour, minute);                  //If input is one digit, separator, output is 00:00 - 09:59
            }

            if (input.Length == 4)
            {
                if (Regex.IsMatch(input, "\\d[\\.,\\040/:]\\d\\d")) //1 digit, separator(., /:), 2 digits
                { 
                    int hour = Int16.Parse(input.Substring(0, 1));
                    int minute = Int16.Parse(input.Substring(2, 2));

                    return CreateTimeString(hour, minute); //If input is one digit, separator, output is 00:00 - 09:59
                }
                else if (Regex.IsMatch(input, "\\d\\d\\d\\d")) //4 digits
                {
                    int hour = Int16.Parse(input.Substring(0, 2));
                    int minute = Int16.Parse(input.Substring(2, 2));

                    string hourstring = hour.ToString();
                    string minutestring = minute.ToString();

                    return CreateTimeString(hour, minute); //If input is one digit, separator, output is 00:00 - 09:59

                } else return input;
            }

            if (input.Length == 5)
            {
                if (!Regex.IsMatch(input, "\\d\\d[\\.,\\040/:]\\d\\d")) return input;//2 digits, separator(., /:), 2 digits
                int hour = Int16.Parse(input.Substring(0, 2));
                int minute = Int16.Parse(input.Substring(3, 2));

                return CreateTimeString(hour, minute); //If input is two digits <= 24, separator, 2 digits < 60 output is 00:00 - 23:59
            }

            return input; //Report a bug =)



        }
        public static string DateDayShort(string DateString)
        {
            string[] day = new string[] { "So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa" };
            try
            {
                DateTime Date = Convert.ToDateTime(FixDate(DateString));
                return day[(int)Date.DayOfWeek];
            }
            catch { return "---"; };
        }
        public static string DateDayLong(string DateString)
        {
            string[] day = new string[] { "Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag" };
            try
            {
                DateTime Date = Convert.ToDateTime(FixDate(DateString));
                return day[(int)Date.DayOfWeek];
            }
            catch { return "---"; };
        }
    }
}