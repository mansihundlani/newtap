// ---------------------------------------------------------------------------
//
// Projekt      : TAP_Montage
//
// File         : MessageIDs
//
// Description  : Allgemeine Konstante f�r das AutoIVZ
//
//--------------- V1.0.0025 --------------------------------------------------- 
//
// Date         : 24. April 2007
// Author       : CG
// Defect#      : 4993
//
// Auswertung/Behandlung des Monatstatus (AZM-R�ckgabewert bei d. EB-Genehmigung):
// Dispo-wert 0 (Monat notReadyfordispo) bzw. 2 (Dispo bereits freigegeben). 
// Neue Konstante definieren 
//
// -----------------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for ErrorIDs
/// </summary>
public static class MessageIDs
{
    //AutoIVZ 100 bis 199
    public const int AutoIVZRequestInfo = 100;
    public const int AutoIVZCommError = 101;
    public const int AutoIVZResponseInfo = 102;
    public const int AutoIVZCommErrGTAbsenz = 103;
    public const int AutoIVZCommErrZeitstempel = 104;
    public const int AutoIVZCommWarningZeitstempel = 105;
    public const int AutoIVZCommErrGsaldo = 106;
    public const int AutoIVZCommErrTagfreigabe = 107;
    public const int AutoIVZCommErrZulagen = 108;
    public const int AutoIVZCommErrTaggenehmigung = 109;
    public const int AutoIVZCommErrGetDispo = 110;
    public const int AutoIVZCommErrSetDispo = 111;
    public const int AutoIVZCommErrorCrypt = 112;
    public const int AutoIVZCommErrorCheckDispo = 114;              // Defect # 4993
}
