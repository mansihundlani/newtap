//-----------------------------------------------------------------------------
//
// Projekt      : TAP_Montage
//
// File         : AssemblyInfo.cs
//
// Description  : Global Assembly Informations
//
// Date         : 28.August 2007
// Author       : Adam Kiefer
//-----------------------------------------------------------------------------

using System.Reflection;
[assembly: AssemblyCompany("Atos")]
[assembly: AssemblyProduct("TAP-Montage")]
[assembly: AssemblyVersion("1.2.0030.*")]