﻿//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : TapWebTools.cs
//
// Description  : TapWebTools
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for TapWebTools
/// </summary>
public class TapWebTools
{
	public TapWebTools()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}
