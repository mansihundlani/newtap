﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : Config.cs
//
// Description  : Konfigurationseinträge aus web.config lesen
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' aus der web.config lesen und
//                in einer statischen Variablen abspeichern
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' aus der web.config lesen und
//                in einer statischen Variablen abspeichern
//
//=========================================================================

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// liest Werte aus der Web.config
/// </summary>
public class Config
{
  static private string myRowlock = "";
  static public string Rowlock
  {
    get
    {
      if (myRowlock == "")
      {
        myRowlock = ConfigurationManager.AppSettings["Rowlock"].ToString();
      }
      return myRowlock;
    }

    set
    {
      myRowlock = value;
    }
  }
  // Beginn Defect 5771
  // neue Variable myNolock, wird aus Web.config gelesen
  // findet Verwendung bei DB-select Aufrufen um ohne Sperre Daten zu lesen
  static private string myNolock = "";
  static public string Nolock
  {
    get
    {
      if (myNolock == "")
      {
        myNolock = ConfigurationManager.AppSettings["Nolock"].ToString();
      }
      return myNolock;
    }

    set
    {
      myNolock = value;
    }
  }
  // Ende Defect 5771
}
