//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbBaustelle.cs
//
// Description  : Definieren der Baustellen - Parameter,
//                Anlegen einer Baustelle
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 13.Dezember 2007
// Author       : Georg Nebehay
// Defect#      : 5674
//                Fehler beim �ndern von Baustellenstandorten
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for dbBaustelle
/// </summary>
/// 
namespace TapMontage.dbObjects
{

  public class dbBaustelleParams
  {
    //dbParamVal ParamVal;
    public SqlParameter BAUID = new SqlParameter("@BAUID", Int32.MinValue);
    public SqlParameter BAUNR = new SqlParameter("@BAUNR", (string)"");
    public SqlParameter NAME = new SqlParameter("@NAME", (string)"");
    public SqlParameter BESCHREIBUNG = new SqlParameter("@BESCHREIBUNG", (string)"");
    public SqlParameter STRASSE = new SqlParameter("@STRASSE", (string)"");
    public SqlParameter ORT = new SqlParameter("@ORT", (string)"");
    public SqlParameter PLZ = new SqlParameter("@PLZ", (string)"");
    public SqlParameter LAND = new SqlParameter("@LAND", (string)"");
    public SqlParameter TELEFONNUMMER = new SqlParameter("@TELEFONNUMMER", (string)"");
    public SqlParameter DATVON = new SqlParameter("@DATVON", ParamVal.Date0);
    public SqlParameter DATBIS = new SqlParameter("@DATBIS", ParamVal.Date0);
    public SqlParameter BAUSTAT = new SqlParameter("@BAUSTAT", Int32.MinValue);
    public SqlParameter DATLA = new SqlParameter("@DATLA", ParamVal.Date0);
    public SqlParameter AENPERSKEY = new SqlParameter("@AENPERSKEY", Int32.MinValue);
    public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
    public ArrayList List = new ArrayList();

    public dbBaustelleParams()
    {
      List.Add(BAUID);
      List.Add(BAUNR);
      List.Add(NAME);
      List.Add(BESCHREIBUNG);
      List.Add(STRASSE);
      List.Add(ORT);
      List.Add(PLZ);
      List.Add(LAND);
      List.Add(TELEFONNUMMER);
      List.Add(DATVON);
      List.Add(DATBIS);
      List.Add(BAUSTAT);
      List.Add(DATLA);
      List.Add(AENPERSKEY);
      List.Add(MANDANT);
      List = ParamVal.SetDefaultValues(List);
    }

  }

  public class dbBaustelle
  {
    public dbBaustelleParams Params = new dbBaustelleParams();
    public dbBearbeiter Bearbeiter;
    public bool StandorteEdit = false;
    //dbParamVal ParamVal;

    /// <summary>
    /// Properties
    /// </summary>
    ArrayList lStandorte = null;
    public ArrayList Standorte
    {
      get
      {
        if (lStandorte == null)
        {
          dbBaustelleStandort BaustelleStandort = new dbBaustelleStandort(this, null);
          lStandorte = BaustelleStandort.SelectAllforBaustelle();
        }
        return lStandorte;
      }
      set
      {
        lStandorte = value;
      }
    }

    public ArrayList barauslagen = null;
    public ArrayList Barauslagen
    {
      get
      {
        if (barauslagen == null)
        {
          dbBarauslagen _dbBarauslage = new dbBarauslagen(this);
          barauslagen = _dbBarauslage.SelectAllforBaustelle();
        }
        return barauslagen;
      }
      set
      {
        barauslagen = value;
      }
    }

    ArrayList lProjekte = new ArrayList();
    public ArrayList Projekte
    {
      get
      {
        return lProjekte;
      }
      set { }
    }


    /// <summary>
    /// Private Properties
    /// </summary>
    public bool AllowUpdate = false;

    public dbBaustelle(dbBearbeiter bearb)
    {
      Params = new dbBaustelleParams();
      Bearbeiter = bearb;
    }

    public bool Insert()
    {
      Params.BAUID.Value = Bearbeiter.Commons.GetNextID(10, "Auftrag");
      ParamVal.InsertValid(Params.List);
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          SqlCommand cmd = new SqlCommand("sp_TM_BaustelleInsert", cnx);
          cmd.CommandType = CommandType.StoredProcedure;
          Params.MANDANT.Value = Bearbeiter.Params.MANDANT.Value;
          foreach (SqlParameter s in Params.List)
            cmd.Parameters.Add(s);
          int nRecs = cmd.ExecuteNonQuery();
          foreach (SqlParameter s in Params.List)
            cmd.Parameters.Remove(s);
          AllowUpdate = (nRecs > 0);

          if (lStandorte != null)
          {
            for (int i = Standorte.Count - 1; i >= 0; i--)
            {
              if ((Standorte[i] as dbBaustelleStandort).Deleted)
                (Standorte[i] as dbBaustelleStandort).Delete();
              else
                (Standorte[i] as dbBaustelleStandort).Insert();
            }
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return AllowUpdate;
    }

    public bool Select()
    {
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          using (SqlCommand cmd = new SqlCommand("sp_TM_BaustelleSelect", cnx)) // Defect 5436, using eingef�hrt
          {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(Params.BAUID);
            //cmd.Parameters.Add(Bearbeiter.Params.MANDANT);
            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
            {
              cmd.Parameters.Remove(Params.BAUID);
              //cmd.Parameters.Remove(Bearbeiter.Params.MANDANT);
              ParamVal.SetDefaultValues(Params.List);
              while (rd.Read())
              {
                //ParamVal.DataReader2Params(rd, Params.List);
                AllowUpdate = true;
                if (!rd.IsDBNull(0)) Params.BAUID.Value = rd.GetValue(0);
                if (!rd.IsDBNull(1)) Params.BAUNR.Value = rd.GetValue(1);
                if (!rd.IsDBNull(2)) Params.NAME.Value = rd.GetValue(2);
                if (!rd.IsDBNull(3)) Params.BESCHREIBUNG.Value = dbText.GetText(rd, 3);
                if (!rd.IsDBNull(4)) Params.STRASSE.Value = rd.GetValue(4);
                if (!rd.IsDBNull(5)) Params.ORT.Value = rd.GetValue(5);
                if (!rd.IsDBNull(6)) Params.PLZ.Value = rd.GetValue(6);
                if (!rd.IsDBNull(7)) Params.LAND.Value = rd.GetValue(7);
                if (!rd.IsDBNull(8)) Params.TELEFONNUMMER.Value = rd.GetValue(8);
                if (!rd.IsDBNull(9)) Params.DATVON.Value = rd.GetValue(9);
                if (!rd.IsDBNull(10)) Params.DATBIS.Value = rd.GetValue(10);
                if (!rd.IsDBNull(11)) Params.BAUSTAT.Value = rd.GetValue(11);
                if (!rd.IsDBNull(12)) Params.DATLA.Value = rd.GetValue(12);
                if (!rd.IsDBNull(13)) Params.AENPERSKEY.Value = rd.GetValue(13);
                if (!rd.IsDBNull(14)) Params.MANDANT.Value = rd.GetValue(14);
              }
            }
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return AllowUpdate;
    }

    public bool ExistName(string strName)
    {
      bool isNameExist = false;
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          // Defect 5725, Config.Rowlock eingef�hrt
          // Defect 5771, Config.Rowlock eingef�hrt
          using (SqlCommand cmd = new SqlCommand("select Count(*) from baustelle " + Config.Nolock + " where Name='" + strName + "'", cnx)) // Defect 5436
          {
            using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
            {
              while (rd.Read())
              {
                if ((int)rd.GetValue(0) > 0)
                  isNameExist = true;
                else
                  isNameExist = false;
              }
            }
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return isNameExist;
    }

    public bool ExistBauNr(string strBauNr)
    {
      bool isBauNrExist = false;
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          // Defect 5725, Config.Rowlock eingef�hrt
          // Defect 5771, Config.Nolock eingef�hrt
          using (SqlCommand cmd = new SqlCommand("select Count(*) from baustelle " + Config.Nolock + " where Baunr='" + strBauNr + "'", cnx)) // Defect 5436
          {
            using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
            {
              while (rd.Read())
              {
                if ((int)rd.GetValue(0) > 0)
                  isBauNrExist = true;
                else
                  isBauNrExist = false;
              }
            }
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return isBauNrExist;
    }

    public dbBaustelle BauDatenPerBauId(dbBaustelle baustelle)
    {
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          // Defect 5725, Config.Rowlock eingef�hrt
          // Defect 5771, Config.Rowlock eingef�hrt
          using (SqlCommand cmd = new SqlCommand("select name, Baunr from baustelle " + Config.Nolock + " where Bauid='" + baustelle.Params.BAUID.Value.ToString() + "'", cnx)) // Defect 5436
          {
            using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
            {
              while (rd.Read())
              {
                baustelle.Params.NAME.Value = (string)rd.GetValue(0);
                baustelle.Params.BAUNR.Value = (string)rd.GetValue(1);
              }
            }
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return baustelle;
    }

    // Defect 5436, wird nicht verwendet
    //public ArrayList SelectAll(string StrWhere)
    //{
    //  ArrayList al = new ArrayList();
    //  using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
    //  {
    //    try
    //    {
    //      cnx.Open();
    //      string strProc = "sp_TM_BaustelleSelectAll";
    //      if (StrWhere != "") strProc += "Where";
    //      using (SqlCommand cmd = new SqlCommand(strProc, cnx)) // Defect 5436
    //      {
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        Params.NAME.Value = Convert.ToString("%" + StrWhere + "%");
    //        if (StrWhere != "") cmd.Parameters.Add(Params.NAME);
    //        cmd.Parameters.Add(Bearbeiter.Params.MANDANT);
    //        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
    //        {
    //          cmd.Parameters.Remove(Bearbeiter.Params.MANDANT);
    //          if (StrWhere != "") cmd.Parameters.Remove(Params.NAME);
    //          while (rd.Read())
    //          {
    //            dbBaustelle lb = new dbBaustelle(Bearbeiter);
    //            ParamVal.DataReader2Params(rd, lb.Params.List);
    //            lb.AllowUpdate = true;
    //            al.Add(lb);
    //          }
    //        }
    //      }
    //    }
    //    catch (Exception ex) { throw ex; }
    //    finally { cnx.Close(); }
    //  }
    //  return al;
    //}

    public bool Update()
    {
      int tempstdid = 0;
      if (!AllowUpdate) return Insert();
      else
      {
        ParamVal.InsertValid(Params.List);
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
          try
          {
            cnx.Open();
            SqlCommand cmd = new SqlCommand("sp_TM_BaustelleUpdate", cnx);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter s in Params.List)
              cmd.Parameters.Add(s);
            int nRecs = cmd.ExecuteNonQuery();
            foreach (SqlParameter s in Params.List)
              cmd.Parameters.Remove(s);
            AllowUpdate = (nRecs > 0);
            if (!AllowUpdate)
            {
              Exception ex = new Exception("dbBaustelle::Update: Update failed!");
              throw ex;
            }
            if (lStandorte != null)
            {
              for (int i = Standorte.Count - 1; i >= 0; i--)
              {
                if (!(Standorte[i] as dbBaustelleStandort).Deleted)
                {

                  int iEinsatztyp = (int)(Standorte[i] as dbBaustelleStandort).EinsatzTyp;
                  if (iEinsatztyp > (int)dbBaustelleStandort.Einsatz.BaustZuQuartier)
                    iEinsatztyp = (int)dbBaustelleStandort.Einsatz.BaustZuBaust;
                  switch (iEinsatztyp)
                  {
                    case (int)dbBaustelleStandort.Einsatz.StandOrtZuBaust:  //  StandOrtZuBaust
                    case (int)dbBaustelleStandort.Einsatz.BaustZuBaust:     //  BaustZuBaust

                      if ((int)(Standorte[i] as dbBaustelleStandort).Params.WEGZEIT.Value > 0)
                      {
                        if ((int)(Standorte[i] as dbBaustelleStandort).Params.STDID.Value > 0)
                        {
                          tempstdid = (int)(Standorte[i] as dbBaustelleStandort).Params.STDID.Value;
                          dbBaustelleStandort bs = new dbBaustelleStandort(null, null);
                          bs = (Standorte[i] as dbBaustelleStandort);
                          bs.Params.STDID.Value = (Standorte[i] as dbBaustelleStandort).Params.WEGZEIT.Value;

                          int stdid = (int)bs.Params.STDID.Value;
                            
                          //Defect 5674
                          //GN 13.12.2007
                          //L�schung wird nur durchgef�hrt, wenn kein Standort mit dieser ID vorhanden ist.
                          bool doit = true;
                          foreach (dbBaustelleStandort std in Standorte)
                          {
                              if ((int)std.Params.STDID.Value == stdid)
                              {
                                  doit = false;
                              }
                          }

                              if(doit) bs.Delete();

                          (Standorte[i] as dbBaustelleStandort).Params.STDID.Value = tempstdid;
                          //5121 Hier stand Insert
                          (Standorte[i] as dbBaustelleStandort).Update();
                        }
                        else
                        {
                          tempstdid = (int)(Standorte[i] as dbBaustelleStandort).Params.BAUID_STDW.Value;
                          dbBaustelleStandort bs = new dbBaustelleStandort(null, null);
                          bs = (Standorte[i] as dbBaustelleStandort);
                          bs.Params.BAUID_STDW.Value = (Standorte[i] as dbBaustelleStandort).Params.WEGZEIT.Value;
                          bs.Delete();
                          (Standorte[i] as dbBaustelleStandort).Params.BAUID_STDW.Value = tempstdid;
                          (Standorte[i] as dbBaustelleStandort).Insert();
                        }
                      }
                      else
                      {
                        if ((Standorte[i] as dbBaustelleStandort).Deleted)
                        {
                          //(Standorte[i] as dbBaustelleStandort).Delete();
                        }
                        else
                        {
                          (Standorte[i] as dbBaustelleStandort).Update();
                        }
                      }
                      break;

                    case (int)dbBaustelleStandort.Einsatz.BaustZuQuartier:  //BaustZuQuartier
                      (Standorte[i] as dbBaustelleStandort).Params.BAUID_STDW.Value = (int)dbBaustelleStandort.Einsatz.BaustZuQuartier;
                      int iSaveKey = (Standorte[i] as dbBaustelleStandort).iSaveDBRecIdent;
                      if (iSaveKey > 0)
                      {
                        (Standorte[i] as dbBaustelleStandort).Params.STDID.Value = iSaveKey;
                      }
                      else
                      {
                        // neuer Satz, behalte den neuen Schl�ssel
                      }
                      (Standorte[i] as dbBaustelleStandort).Update();
                      break;
                    default:
                      break;
                  }


                }
              }

            }
          }
          catch (Exception ex) { throw ex; }
          finally { cnx.Close(); }
        }
      }
      return AllowUpdate;
    }

    // Beginn, Defect 5725, wird nicht verwendet
    //public bool Delete()
    //{
    //  if (AllowUpdate)
    //  {
    //    ParamVal.InsertValid(Params.List);
    //    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
    //    {
    //      try
    //      {
    //        cnx.Open();
    //        // Defect 5725, Config.Rowlock eingef�hrt
    //        SqlCommand cmd = new SqlCommand("Delete from Baustelle " + Config.Rowlock + " where BAUID = " + Params.BAUID.Value.ToString(), cnx);
    //        int nRecs = cmd.ExecuteNonQuery();
    //        AllowUpdate = (nRecs > 0);
    //        if (!AllowUpdate)
    //        {
    //          Exception ex = new Exception("dbBaustelle::Delete: Delete failed!");
    //          throw ex;
    //        }
    //      }
    //      catch (Exception ex) { throw ex; }
    //      finally { cnx.Close(); }
    //    }
    //  }
    //  AllowUpdate = false;
    //  return !AllowUpdate;
    //}
    // Ende Defect 5725

    /// <summary>
    /// F�llt d mit Text:Namen/Value:BauIDs aller Baustellen
    /// </summary>
    /// <param name="namensfilter">Filter �ber Name, wird intern um "% ... %" erweitert</param>
    /// <param name="d">DropDownList: wird ge-clear-ed und gef�llt, SelectedValue ist Value von this.BAUID</param>
    // Defect 5436, wird nicht verwendet
    //public void DDLBaustellen(string namensfilter, ref DropDownList d)
    //{
    //  d.Items.Clear();
    //  ArrayList al = SelectAll(namensfilter);
    //  foreach (dbBaustelle b in al)
    //  {
    //    d.Items.Add(new ListItem(ParamVal.GetParameter(b.Params.NAME), ParamVal.GetParameter(b.Params.BAUID)));
    //    if (b.Params.BAUID.Value == Params.BAUID.Value)
    //      d.SelectedIndex = d.Items.Count - 1;
    //  }
    //}
  }
}
