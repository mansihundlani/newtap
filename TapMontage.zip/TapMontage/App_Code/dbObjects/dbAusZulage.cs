//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbAusZulage.cs
//
// Description  : Objekt f�r Aus- und Zulagen
//
//=============== V1.2.0011 ===================================================
//
// Date         : 27.September 2011
// Author       : Joldic Dzevad
// Defect#      : KMS BAN 500256 TAP-Montage: Erweiterte Zulagenpr�fung
//                Max Anzahl an Zulagen hinzuf�gt  
//
//=============== 1.2.0007 ================================================
//
// Date         : 05.Oktober 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530047
//                TAP-Montage.Zulagen nur auf prod.Einsatz kontieren
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.Januar 2010
// Author       : Joldic Dzevad
// Defect#      : BAN 500091
//                Lohnartenumstellung am TAP, neue LA ab 01.01.2010
//
//=============== V1.0.0038 ===============================================
//
// Date         : 15.J�nner 2008
// Author       : Joldic Dzevad
// Defect#      : 5940
//                Zulage bei ZA ganzt�gig bei B&I (MG) 
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0022 ===============================================
//
// Date         : 27.Februar 2007
// Author       : CL
// Defect#      : 4684
//
// Das Speichern der SEG-Zulagen in die DB-Tabelle 'Zulage'
// muss ebenfalls an der DB-Transaktion teilnehmen. 
// Die Transaktion wird als Parameter an die Funktionen 'InsertSEG' und 'UpdateSEG' �bergeben.
//
//--------------- V1.0.0022  --------------------------------------------------------------------------
//
// Date         : 24.Februar 2007
// Author       : GN
// Defect#      : 4625
//                Wir haben in der Datenbank f�r Berichtsmonat J�nner ca. 800 R/W Zeilen ohne Leistungsart.
//                Transaktionsthema
//
// -------------- V1.0.0022  --------------------------------------------------------------------------
//
// Date         : 22.Februar 2007
// Author       : CL
// Defect#      : 4660
//                Zulagen mit Anzahl = 0 werden auch nach Speichern 
//                des EB weiterhin in der Liste dargestellt.
//
// -------------- V1.0.0022  --------------------------------------------------------------------------
//
// Date         : 13.Februar 2007
// Author       : CL
// Defect#      : 4513
//                Nur Zulagen mit Anzahl > 0 werden in die DB-Tabelle 'Zulage' gespeichert.
//
// -------------- V1.0.0022  --------------------------------------------------------------------------
//
// Date         : 3.Februar 2007
// Author       : CL
// Defect#      : 4493
//                Auch die SEG-Zulagen werden in die DB-Tabelle 'Zulage' gespeichert.
//
//--------------- V1.0.0020  --------------------------------------------------------------------------
//
// Date         : 29.J�nner 2007
// Author       : GN
// Defect#      : 4443
//
// Beim L�schen der ersten Arbeitszeit, wurde ein Datenbanktrigger ausgel�st, der die an diesem Tag gespeicherten Zulagen ebenfalls l�schte.
// Programmintern wurde aber immer noch angenommen, dass sich die Zulagen in der Datenbank bef�nden und im Zuge des Abspeicherns des
// Einsatzberichts versucht, die betreffenden Zulagen mit einem UPDATE-Statement auf den neuen ersten Tag umzuh�ngen, was deswegen zu einem
// Fehler f�hrte, weil in der betroffenen Stored Procedure zwar eine �berpr�fung auf genau diesen Fall durchgef�hrt wurde, au�er der
// ausgegebenen eher kryptischen Fehlermeldung aber keine weiteren Ma�nahmen gesetzt wurden. 
// Zur Behebung dieses Fehlers wird nun nach einem fehlgeschlagenen UPDATE ein INSERT versucht, was in unserem Fall zu einem Erfolg f�hrt.
//
// ----------------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for dbAusZulage
/// </summary>
namespace TapMontage.dbObjects
{
    public class dbAusZulageParams
    {
        public SqlParameter AZID = new SqlParameter("@AZID", int.MinValue);
        public SqlParameter LFDNR = new SqlParameter("@LFDNR", int.MinValue);
        public SqlParameter LOHNART = new SqlParameter("@LOHNART", (string) "");
        public SqlParameter LOHNARTKZ = new SqlParameter("@LOHNARTKZ", (string) "");
        public SqlParameter LOHNARTTXT = new SqlParameter("@LOHNARTTXT", (string)"");
        public SqlParameter ANZAHL = new SqlParameter("@ANZAHL", float.MinValue);
        public SqlParameter BETRAG = new SqlParameter("@BETRAG", float.MinValue);
        public SqlParameter WAEHRKZ = new SqlParameter("@WAEHRKZ", (string) "");
        public SqlParameter BEMERKUNG = new SqlParameter("@BEMERKUNG", (string) "");
        public SqlParameter DATLA = new SqlParameter("@DATLA", ParamVal.Date0);
        public SqlParameter AENPERSKEY = new SqlParameter("@AENPERSKEY", int.MinValue);
        public SqlParameter DATNEU = new SqlParameter("@DATNEU", ParamVal.Date0);
        public SqlParameter DATUGEOS = new SqlParameter("@DATUGEOS", ParamVal.Date0);
        public SqlParameter EBID = new SqlParameter("@EBID", int.MinValue);
        public ArrayList List = new ArrayList();

        public dbAusZulageParams()
        {
            List.Add(AZID);
            List.Add(LFDNR);
            List.Add(LOHNART);
            List.Add(LOHNARTKZ);
            List.Add(LOHNARTTXT);
            List.Add(ANZAHL);
            List.Add(BETRAG);
            List.Add(WAEHRKZ);
            List.Add(BEMERKUNG);
            List.Add(DATLA);
            List.Add(AENPERSKEY);
            List.Add(DATNEU);
            List.Add(DATUGEOS);
            List.Add(EBID);

        }
    }

    public class dbAusZulage
    {
        public dbAusZulageParams Params = new dbAusZulageParams();
        public dbMontBer MontBer;

        public bool AllowUpdate = false;
        public bool Deleted = false;

        private static string strFlagZulage = "Z"; // Defect #4513

        public float MaxAnzahl = 0f;

        public dbAusZulage(dbMontBer mber)
        {
            MontBer = mber;
            if (MontBer == null) MontBer = new dbMontBer(null, null);
        }

        public ArrayList SelectAusZulforEinsatzbericht()
        {
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Umstellung von storageprocedure auf Text
                    // 0 -> AZID (int)
                    // 1 -> LFDNR (int)
                    // 2 -> LOHNART (string)
                    // 3 -> ANZAHL (float)
                    // 4 -> BETRAG
                    // 5 -> WAEHRKZ
                    // 6 -> BEMERKUNG
                    // 7 -> DATLA
                    // 8 -> AENPERSKEY
                    // 9 -> DATNEU
                    // 10 -> DATUGEOS
                    // 11- > LOHNARTTXT
                    // 12 -> LOHNARTKZ

                    /*using (SqlCommand cmd = new SqlCommand("SELECT ZULAGE.AZID, ZULAGE.LFDNR, ZULAGE.LOHNART, ZULAGE.ANZAHL, 0 AS BETRAG, '' AS WAEHRKZ, '' AS BEMERKUNG, " +
                                                      " ZULAGE.DATLA, ZULAGE.AENPERSKEY, ZULAGE.DATNEU, ZULAGE.DATUGEOS, Y_LOHNART3.LOHNARTTXT, Y_LOHNART3.LOHNARTKZ " +
                                                      " FROM ZULAGE " + Config.Nolock + " INNER JOIN Y_LOHNART3 " + Config.Nolock + " ON ZULAGE.LOHNART = Y_LOHNART3.LOHNART " +
                                                      " INNER JOIN BAUPROJEKT_AUSZUL " + Config.Nolock + " ON ZULAGE.LOHNART = BAUPROJEKT_AUSZUL.LOHNART " +
                                                      " WHERE (Y_LOHNART3.LOHNARTKZ <> 'A') AND (BAUPROJEKT_AUSZUL.PROJID = @PROJID) AND " +
                                                      " EXISTS (SELECT * FROM Y_LASOZGRP " + Config.Nolock + " WHERE Y_LASOZGRP.SOZGRP = (SELECT SOZSTELL FROM BEARBTECH " + Config.Nolock + " WHERE BEARBTECH.PERSKEY = @PERSKEY)) " +
                                                      " AND (ZULAGE.ebid = @EBID) AND (Y_LOHNART3.MANDANT = @MANDANT) " +
                                                      " UNION " +
                                                      " SELECT AUSLAGE.AZID, AUSLAGE.LFDNR, AUSLAGE.LOHNART, AUSLAGE.ANZAHL, AUSLAGE.BETRAG, AUSLAGE.WAEHRKZ, AUSLAGE.BEMERKUNG, " +
                                                      " AUSLAGE.DATLA, AUSLAGE.AENPERSKEY, AUSLAGE.DATNEU, AUSLAGE.DATUGEOS, Y_LOHNART3.LOHNARTTXT, Y_LOHNART3.LOHNARTKZ " +
                                                      " FROM AUSLAGE " + Config.Nolock + " INNER JOIN Y_LOHNART3 " + Config.Nolock + " ON AUSLAGE.LOHNART = Y_LOHNART3.LOHNART " +
                                                      " INNER JOIN BAUPROJEKT_AUSZUL " + Config.Nolock + " ON AUSLAGE.LOHNART = BAUPROJEKT_AUSZUL.LOHNART " +
                                                      " WHERE (Y_LOHNART3.LOHNARTKZ = 'A') AND (BAUPROJEKT_AUSZUL.PROJID = @PROJID) AND " +
                                                      " EXISTS (SELECT * FROM Y_LASOZGRP " + Config.Nolock + " WHERE Y_LASOZGRP.SOZGRP = (SELECT SOZSTELL FROM BEARBTECH " + Config.Nolock + " WHERE BEARBTECH.PERSKEY = @PERSKEY)) " +
                                                      " AND (AUSLAGE.ebid = @EBID) AND (Y_LOHNART3.MANDANT = @MANDANT) ORDER BY Y_LOHNART3.LOHNARTTXT ", cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@PROJID", MontBer.Projekt.Params.PROJID.Value));
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", MontBer.Bearbeiter.Params.PERSKEY.Value));
                        cmd.Parameters.Add(new SqlParameter("@EBID", MontBer.Params.EBID.Value));
                        cmd.Parameters.Add(new SqlParameter("@MANDANT", MontBer.Params.MANDANT.Value));
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Clear();
                            while (rd.Read())
                            {
                                dbAusZulage azl = new dbAusZulage(MontBer);
                                ParamVal.SetDefaultValues(azl.Params.List);
                                azl.Params.EBID.Value = MontBer.Params.EBID.Value;
                                azl.Params.AZID.Value = rd.GetValue(0);
                                azl.Params.LFDNR.Value = rd.GetValue(1);
                                azl.Params.LOHNART.Value = rd.GetValue(2);
                                azl.Params.ANZAHL.Value = rd.GetValue(3);
                                azl.Params.BETRAG.Value = rd.GetValue(4);
                                azl.Params.WAEHRKZ.Value = rd.GetValue(5);
                                azl.Params.BEMERKUNG.Value = rd.GetValue(6);
                                azl.Params.DATLA.Value = rd.GetValue(7);
                                azl.Params.AENPERSKEY.Value = rd.GetValue(8);
                                azl.Params.DATNEU.Value = rd.GetValue(9);
                                azl.Params.DATUGEOS.Value = rd.GetValue(10);
                                azl.Params.LOHNARTTXT.Value = rd.GetValue(11);
                                azl.Params.LOHNARTKZ.Value = rd.GetValue(12);
                                azl.AllowUpdate = true;
                                azl.Deleted = false;
                                al.Add(azl);
                            }
                        }
                    }*/
                    using (SqlCommand cmd = new SqlCommand("SELECT Y_LOHNART3.LOHNARTTXT, Y_LOHNART3.LOHNART, Y_LOHNART3.LOHNARTKZ " +
                        "FROM Y_LOHNART3 " + Config.Nolock + " INNER JOIN BAUPROJEKT_AUSZUL " + Config.Nolock + " ON Y_LOHNART3.LOHNART = BAUPROJEKT_AUSZUL.LOHNART " +
                        "WHERE (BAUPROJEKT_AUSZUL.PROJID = @PROJID) AND Y_LOHNART3.MANDANT = @MANDANT AND " +
                        "EXISTS (SELECT * FROM Y_LASOZGRP " + Config.Nolock + " WHERE Y_LASOZGRP.LOHNART = Y_LOHNART3.LOHNART AND " + 
                        "Y_LASOZGRP.SOZGRP = (SELECT SOZSTELL FROM BEARBTECH " + Config.Nolock + " WHERE BEARBTECH.PERSKEY = @PERSKEY))", cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@PROJID", MontBer.Projekt.Params.PROJID.Value));
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", MontBer.Bearbeiter.Params.PERSKEY.Value));
                        cmd.Parameters.Add(new SqlParameter("@MANDANT", MontBer.Projekt.Params.MANDANT.Value));

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();
                            while (rd.Read())
                            {
                                dbAusZulage azl = new dbAusZulage(MontBer);
                                ParamVal.SetDefaultValues(azl.Params.List);
                                azl.Params.LOHNARTTXT.Value = rd.GetValue(0);
                                azl.Params.LOHNART.Value = rd.GetValue(1);
                                azl.Params.LOHNARTKZ.Value = rd.GetValue(2);
                                azl.Params.EBID.Value = MontBer.Params.EBID.Value;
                                using (SqlConnection cnx2 = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                                {
                                    try
                                    {
                                        cnx2.Open();
                                        using (SqlCommand cmd2 = new SqlCommand("sp_TM_SelectAusZulforEB", cnx2)) // Defect 5436
                                        {
                                            cmd2.CommandType = CommandType.StoredProcedure;
                                            cmd2.Parameters.Add(MontBer.Params.EBID);
                                            cmd2.Parameters.Add(azl.Params.LOHNART);
                                            cmd2.Parameters.Add(azl.Params.LOHNARTKZ);
                                            using (SqlDataReader rd2 = cmd2.ExecuteReader()) // Defect 5436
                                            {
                                                cmd2.Parameters.Clear();
                                                while (rd2.Read())
                                                {
                                                    azl.Params.AZID.Value = rd2.GetValue(0);
                                                    azl.Params.LFDNR.Value = rd2.GetValue(1);
                                                    azl.Params.ANZAHL.Value = rd2.GetValue(3);
                                                    azl.Params.BETRAG.Value = rd2.GetValue(4);
                                                    azl.Params.WAEHRKZ.Value = rd2.GetValue(5);
                                                    azl.Params.BEMERKUNG.Value = rd2.GetValue(6);
                                                    azl.Params.DATLA.Value = rd2.GetValue(7);
                                                    azl.Params.AENPERSKEY.Value = rd2.GetValue(8);
                                                    azl.Params.DATNEU.Value = rd2.GetValue(9);
                                                    azl.Params.DATUGEOS.Value = rd2.GetValue(10);
                                                    azl.AllowUpdate = true;
                                                    azl.Deleted = false;
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception ex2) { throw ex2; }
                                    finally { cnx2.Close(); }
                                }
                                if( ConfigurationManager.AppSettings["MAX_ANZAHL_LOHNART"] != null )
                                {
                                    try
                                    {
                                       azl.MaxAnzahl = Convert.ToSingle(ConfigurationManager.AppSettings["MAX_ANZAHL_LOHNART"].ToString());
                                    }
                                    catch
                                    {
                                        //do nothing
                                    }
                                }
                                if (ConfigurationManager.AppSettings["MAX_ANZAHL_LOHNART_" + azl.Params.LOHNART.Value.ToString()] != null)
                                {
                                    try
                                    {
                                        azl.MaxAnzahl = Convert.ToSingle(ConfigurationManager.AppSettings["MAX_ANZAHL_LOHNART_" + azl.Params.LOHNART.Value.ToString()].ToString());
                                    }
                                    catch
                                    {
                                        //do nothing
                                    }

                                }
                                al.Add(azl);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return al;
            /*    
              #region �nderung MA 9.8.06: Ber�cksichtigung der Sozailen Stellung bei der Auswahl der Aus/Zulagen im EB
              //sp_TM_SelectAusZulforProj 
              //zus�tzlicher Parameter Perskey, f�r die Abfrage von Y_LASOZGRP und Bearbtech.SOZSTELL
              using (SqlCommand cmd = new SqlCommand("sp_TM_SelectAusZulforProj", cnx)) // Defect 5436, using eingef�hrt
              {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(MontBer.Projekt.Params.PROJID);
                cmd.Parameters.Add(MontBer.Bearbeiter.Params.PERSKEY);
                using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                {
                  cmd.Parameters.Remove(MontBer.Projekt.Params.PROJID);
                  cmd.Parameters.Remove(MontBer.Bearbeiter.Params.PERSKEY);

              #endregion
                  while (rd.Read())
                  {
                    dbAusZulage azl = new dbAusZulage(MontBer);
                    ParamVal.SetDefaultValues(azl.Params.List);
                    azl.Params.LOHNARTTXT.Value = rd.GetValue(0);
                    azl.Params.LOHNART.Value = rd.GetValue(1);
                    azl.Params.LOHNARTKZ.Value = rd.GetValue(2);
                    azl.Params.EBID.Value = MontBer.Params.EBID.Value;
                    using (SqlConnection cnx2 = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                    {
                      try
                      {
                        cnx2.Open();
                        using (SqlCommand cmd2 = new SqlCommand("sp_TM_SelectAusZulforEB", cnx2)) // Defect 5436
                        {
                          cmd2.CommandType = CommandType.StoredProcedure;
                          cmd2.Parameters.Add(MontBer.Params.EBID);
                          cmd2.Parameters.Add(azl.Params.LOHNART);
                          cmd2.Parameters.Add(azl.Params.LOHNARTKZ);
                          using (SqlDataReader rd2 = cmd2.ExecuteReader()) // Defect 5436
                          {
                            cmd2.Parameters.Remove(MontBer.Params.EBID);
                            cmd2.Parameters.Remove(azl.Params.LOHNART);
                            cmd2.Parameters.Remove(azl.Params.LOHNARTKZ);
                            while (rd2.Read())
                            {
                              azl.Params.AZID.Value = rd2.GetValue(0);
                              azl.Params.LFDNR.Value = rd2.GetValue(1);
                              azl.Params.ANZAHL.Value = rd2.GetValue(3);
                              azl.Params.BETRAG.Value = rd2.GetValue(4);
                              azl.Params.WAEHRKZ.Value = rd2.GetValue(5);
                              azl.Params.BEMERKUNG.Value = rd2.GetValue(6);
                              azl.Params.DATLA.Value = rd2.GetValue(7);
                              azl.Params.AENPERSKEY.Value = rd2.GetValue(8);
                              azl.Params.DATNEU.Value = rd2.GetValue(9);
                              azl.Params.DATUGEOS.Value = rd2.GetValue(10);
                              azl.AllowUpdate = true;
                              azl.Deleted = false;
                            }
                          }
                        }
                      }
                      catch (Exception ex2) { throw ex2; }
                      finally { cnx2.Close(); }
                    }
                    al.Add(azl);
                  }
                }
              }
            }
            catch (Exception ex) { throw ex; }
            finally { cnx.Close(); }
          }
            return al;*/
        }

        private int FirstAZId
        {
            get
            {
                int firstID = 0;
                foreach (dbArbTag at in MontBer.Tage)
                    foreach (dbArbZeit az in at.Zeiten)
                        if (!az.Deleted)
                            if(az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz)
                                if (((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MontBer.Params.EBID.Value) &
                                ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value > 0))
                                {
                                    //BAF 530047 Beginn
                                    if( firstID == 0 )
                                        firstID = (int)(az.Params as dbAZ_ARBZEITParams).AZID.Value; //wir merken uns die erste AZ
                                    if (az.ZeitTyp == dbArbZeit.ArbZeitType.produktiv || az.STDAbsenzID == STDAbsenzIDs.Ersatzruhe) //diese sind produktiv
                                    {
                                        firstID = (int)(az.Params as dbAZ_ARBZEITParams).AZID.Value; //dann �berschreiben wir firstId und zur�ck;
                                        return firstID;
                                    }
                                    //return (int)(az.Params as dbAZ_ARBZEITParams).AZID.Value;
                                }
                //return 0;
                return firstID; //falls dies kommen sollte, dann hat EB keine Produktivstunden...pech
                // BAF 530047 Ende
            }
        }

        public bool Insert()
        {
            return Insert(null);
        }

      public bool Insert(SqlTransaction tx)
      {
        bool inTransaction = tx != null;
        ParamVal.InsertValid(Params.List);
        Params.EBID.Value = MontBer.Params.EBID.Value;
        Params.AZID.Value = FirstAZId;
        Params.DATLA.Value = DateTime.Now;
        Params.DATNEU.Value = DateTime.Now;
        //LFDNR --> zuerst die laufende Nummer f�r diesen AZID ermitteln.
        SqlConnection cnx = null;
        try
        {

          if (!inTransaction)
          {
            cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
            cnx.Open();
          }
          else cnx = tx.Connection;

          string sql = "";
          // Defect 5725, Config.Rowlock eingef�hrt
          if (Params.LOHNARTKZ.Value.ToString() == "A")
          {
            sql = "Select MAX(LFDNR) from AUSLAGE " + Config.Rowlock + " where AZID = @AZID";
          }
          else
          {
            sql = "Select MAX(LFDNR) from ZULAGE  " + Config.Rowlock + " where AZID = @AZID";
          }
          using (SqlCommand cmd2 = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
          {
            cmd2.Parameters.Add(Params.AZID);
            using (SqlDataReader rd = cmd2.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
            {
              cmd2.Parameters.Remove(Params.AZID);
              int iLfdnr = 0;
              while (rd.Read())
              {
                if (!rd.IsDBNull(0)) iLfdnr = (int)rd.GetInt32(0);
              }

              if (iLfdnr > 0)
              {
                Params.LFDNR.Value = iLfdnr + 1; //LFDNR wird um 1 erh�ht. 
              }
              else
              {
                Params.LFDNR.Value = 1; //LFDNR wird mit 1 inisializiert. 
              }
            }
          }
        }
        catch (Exception ex2) { throw ex2; }
        finally { if (!inTransaction)cnx.Close(); }

        try
        {
          if (!inTransaction)
          {
            cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
            cnx.Open();
          }
          else cnx = tx.Connection;
          string sql = "sp_TM_AusZulageInsert";
          using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
          {
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter s in Params.List)
              cmd.Parameters.Add(s);
            int nRecs = cmd.ExecuteNonQuery();
            foreach (SqlParameter s in Params.List)
              cmd.Parameters.Remove(s);
            AllowUpdate = (nRecs > 0);
          }
        }
        catch (Exception ex) { throw ex; }
        finally { if (!inTransaction)cnx.Close(); }

        return AllowUpdate;
      }

        public bool Update()
        {
            return Update(null);
        }

        //Defect 4443 GN 29.01.2007
        //Wenn Update fehlschl�gt, wird ein Insert versucht
        //Start
      public bool Update(SqlTransaction tx)
      {
        bool inTransaction = tx != null;
        bool tryInsert = false;

        if (!AllowUpdate) return Insert();

        else
        {
          Params.AZID.Value = FirstAZId;
          ParamVal.InsertValid(Params.List);
          SqlConnection cnx = null;
          SqlCommand cmd = null;
          try
          {
            if (!inTransaction)
            {
              cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
              cnx.Open();
            }
            else cnx = tx.Connection;
            string sql = "sp_TM_AusZulageUpdate";
            using (cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
            {
              cmd.CommandType = CommandType.StoredProcedure;
              foreach (SqlParameter s in Params.List)
                cmd.Parameters.Add(s);
              int nRecs = cmd.ExecuteNonQuery();
              foreach (SqlParameter s in Params.List)
                cmd.Parameters.Remove(s);
              AllowUpdate = (nRecs > 0);
              if (!AllowUpdate)
              {
                Exception ex = new Exception("dbAusZulage::Update: Update failed!");
                throw ex;
              }
            }
          }
          catch
          {
              tryInsert = true;
          }

          // 20.02.2007 / CL
          // Auch hier SQL Connection nur dann schliessen,
          // wenn nicht in Transaktion !
          finally { if (!inTransaction) cnx.Close(); }
          if (tryInsert)
          {
            foreach (SqlParameter s in Params.List)
              cmd.Parameters.Remove(s);
            return Insert(tx);
          }
        }

        return AllowUpdate;
      }
        //Ende

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren

        public bool Delete()
        {
            return Delete(null);
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.

        public bool Delete(SqlTransaction tx)
        {
            bool inTransaction = tx != null;

            ParamVal.InsertValid(Params.List);
            if (AllowUpdate)
            {
                SqlConnection cnx = null;
                try
                {

                    if (!inTransaction)
                    {
                        cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                        cnx.Open();
                    }
                    else cnx = tx.Connection;

                    SqlCommand cmd;
                    // Defect 5725, Config.Rowlock eingef�hrt
                    if (Params.LOHNARTKZ.Value.ToString() == "A")
                    {
                        string sql = "Delete from AUSLAGE " + Config.Rowlock + " where AZID = @AZID and LFDNR = @LFDNR and EBID = @EBID";
                        cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx);
                    }
                    else
                    {
                      string sql = "Delete from ZULAGE  " + Config.Rowlock + " where AZID = @AZID and LFDNR = @LFDNR and EBID = @EBID";
                        cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx);
                    }

                    cmd.Parameters.Add(Params.AZID);
                    cmd.Parameters.Add(Params.LFDNR);
                    cmd.Parameters.Add(Params.EBID);
                    int nRecs = cmd.ExecuteNonQuery();
                    cmd.Parameters.Remove(Params.AZID);
                    cmd.Parameters.Remove(Params.LFDNR);
                    cmd.Parameters.Remove(Params.EBID);
                }
                catch (Exception ex) { throw ex; }
                finally { if (!inTransaction)cnx.Close(); }
            }
            return AllowUpdate;
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren

        public void Save()
        {
            Save(null);
        }



        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.

        public void Save(SqlTransaction tx)
        {
            if (FirstAZId != 0)
            {
                bool blnDeletedChangedToTrue = false; // Defect #4660

                /* Beginn Defect #4513: Bei Zulagen wird die Anzahl gepr�ft,
                 * Insert erfolgt nur bei Anzahl > 0, ebenso Update,
                 * statt Update auf 0 wird Delete durchgef�hrt.
                 * */
                try
                {
                    if (Params.LOHNARTKZ.Value.ToString() == strFlagZulage)
                    {
                        // Zulagenzeile: Anzahl pr�fen
                        if (System.Convert.ToDouble(Params.ANZAHL.Value) <= 0)
                        {
                            // Anzahl ist Null, Flag 'Deleted' auf true setzen
                            /* Beginn Defect #4660: Falls das Delete-Flag jetzt
                             * wegen korrekter Speicherung umgesetzt werden muss,
                             * ist es auch notwendig, das Flag nach Update wieder
                             * zur�ck zu setzen, damit die Anzeige weiterhin
                             * funktioniert. Zulagen mit Anzahl 0 werden weiterhin
                             * zur neuerlichen Eingabe angezeigt.
                             * */
                            if (!Deleted)
                            {
                                Deleted = true;
                                blnDeletedChangedToTrue = true;
                            }
                            // Ende Defect #4660
                        }
                    }
                }
                catch (Exception ex)
                {
                    string strErrMessage = ex.Message;
                    /* Beginn Defect #4660: Flag auch im Exception-Fall
                     * zur�cksetzen */
                    if (blnDeletedChangedToTrue)
                    {
                        Deleted = false;
                    }
                    // Ende Defect #4660
                }
                // Ende Defect #4513

                if (AllowUpdate)
                {
                    if (!Deleted) Update(tx);
                    else Delete(tx);
                }
                else
                {
                    if (!Deleted) Insert(tx);
                    //else do_nothing();
                }
                /* Beginn Defect #4660: Falls das Delete-Flag auf true gesetzt
                 * wurde, muss es jetzt wieder zur�ckgesetzt werden. */
                if (blnDeletedChangedToTrue)
                {
                    Deleted = false;
                }
                // Ende Defect #4660
            }
            else
                if (!Deleted) Delete(tx);

        }

        // Defect #4493: Eigene Funktion f�r Speichern von SEG-Zulagen
        //               in Tabelle 'Zulagen'
        // Defect #4684: Auch SaveSEG muss an der Transaktion teilnehmen:
        //               Parameter 'tx'
        public void SaveSEG(dbKG_SEGZulage dbSEG, SqlTransaction tx)
        {
            /* Beginn Defect #4513: Bei SEG-Zulagen wird die Anzahl der 
             * Basisstunden gepr�ft, Insert erfolgt nur bei Anzahl > 0.
             * */
            bool blnInsert = true;
            try
            {
                if (dbSEG.BasisStunden > 0)
                {
                    blnInsert = true;
                }
                else
                {
                    blnInsert = false;
                }
            }
            catch (Exception ex)
            {
                string strErrMessage = ex.Message;
                blnInsert = true;
            }
            if (blnInsert)
            { // Ende Defect #4513
                // Zun�chst wird Insert durchgef�hrt
                if (!InsertSEG(dbSEG, tx)) // Defect #4684
                {
                    // Insert erfolglos, also sollte eigentlich ein Update
                    // durchgef�hrt werden.
                    // NICHT aktiv, weil: Wie kann man die SEG-Zulagezeilen von
                    // den manuellen Zulagenzeilen unterscheiden ?
                    // UpdateSEG(dbSEG, tx); // Defect #4684
                }
            } // Defect #4513
        }

      // Defect #4684: 'InsertSEG' verwendet die offene Transaktion:
      //               Parameter 'tx'
      private bool InsertSEG(dbKG_SEGZulage dbSEG, SqlTransaction tx)
      {
        bool blnInsertSuccess = false;
        bool blnInTransaction = tx != null; // Defect #4684

        ParamVal.InsertValid(Params.List);
        Params.LOHNARTKZ.Value = "Z";
        Params.AZID.Value = FirstAZId;
          // Beginn Defect #5940
        if (dbSEG.lohnArt != "")
        {
            Params.LOHNART.Value = dbSEG.lohnArt;
            Params.ANZAHL.Value = dbSEG.AnzTage;
        }
        else
        {
            Params.LOHNART.Value = dbSEG.SEGPKT;
            Params.ANZAHL.Value = dbSEG.BasisStunden;
        }
        Params.AENPERSKEY.Value = dbSEG.Perskey;
          //Ende Defect #5940
        Params.EBID.Value = MontBer.Params.EBID.Value;
        Params.DATLA.Value = DateTime.Now;
        Params.DATNEU.Value = DateTime.Now;

        /* Beginn Defect #4684: Connection der Transaktion verwenden */
        SqlConnection cnx = null;

        try
        {
          if (!blnInTransaction)
          {
            cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
            cnx.Open();
          }
          else
          {
            cnx = tx.Connection;
          }
          // Ende Defect #4684

          // LFDNR --> zuerst die laufende Nummer f�r diesen AZID ermitteln.
          // Defect 5725, Config.Rowlock eingef�hrt
          string sql = "Select MAX(LFDNR) from ZULAGE " + Config.Rowlock + " where AZID = @AZID";

          /* Beginn Defect #4684: SqlCommand mit Transaction */
          using (SqlCommand cmd2 = (blnInTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
          {
            /* Ende Defect #4684 */
            cmd2.Parameters.Add(Params.AZID);
            using (SqlDataReader rd = cmd2.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
            {
              cmd2.Parameters.Remove(Params.AZID);
              int iLfdnr = 0;
              while (rd.Read())
              {
                if (!rd.IsDBNull(0)) iLfdnr = (int)rd.GetInt32(0);
              }

              rd.Close(); // Defect #4684: Close data reader

              if (iLfdnr > 0)
              {
                Params.LFDNR.Value = iLfdnr + 1; //LFDNR wird um 1 erh�ht. 
              }
              else
              {
                Params.LFDNR.Value = 1; //LFDNR wird mit 1 inisializiert. 
              }
            }
          }
        }
        catch (Exception ex2) { throw ex2; }
        /* Beginn Defect #4684: Close connection nur, wenn nicht in
         *                      Transaktion. Diese wird f�r Insert
         *                      weiter verwendet. */
        finally { if (!blnInTransaction) cnx.Close(); }

        try
        {
          if (!blnInTransaction)
          {
            cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
            cnx.Open();
          }
          else
          {
            cnx = tx.Connection;
          }
          string sql = "sp_TM_AusZulageInsert";
          using (SqlCommand cmd = (blnInTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
          {
            // Ende Defect #4684
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Clear();
            foreach (SqlParameter s in Params.List)
              cmd.Parameters.Add(s);
            int nRecs = cmd.ExecuteNonQuery();
            foreach (SqlParameter s in Params.List)
              cmd.Parameters.Remove(s);
            blnInsertSuccess = (nRecs > 0);
          }
        }
        catch (Exception ex) { throw ex; }
        /* Beginn Defect #4684: Close connection nur, wenn nicht in
         *                      Transaktion. */
        finally { if (!blnInTransaction) cnx.Close(); }
        // Ende Defect #4684


        return blnInsertSuccess;
      }

      // Defect 5436, Funktion wird nicht verwendet
      // Defect #4684: 'UpdateSEG' verwendet die offene Transaktion:
      //               Parameter 'tx'
      //private bool UpdateSEG(dbKG_SEGZulage dbSEG, SqlTransaction tx)
      //{
      //  bool blnUpdateSuccess = false;
      //  bool blnInTransaction = tx != null; // Defect #4684

      //  Params.LOHNARTKZ.Value = "Z";
      //  Params.AZID.Value = FirstAZId;
      //  Params.LOHNART.Value = dbSEG.SEGPKT;
      //  Params.ANZAHL.Value = dbSEG.BasisStunden;
      //  Params.AENPERSKEY.Value = 0;
      //  Params.EBID.Value = MontBer.Params.EBID.Value;
      //  Params.DATLA.Value = DateTime.Now;
      //  ParamVal.InsertValid(Params.List);
      //  SqlConnection cnx = null; // Defect #4684
      //  SqlCommand cmd = null;

      //  /* Beginn Defect #4684: Connection der Transaktion verwenden */
      //  try
      //  {
      //    if (!blnInTransaction)
      //    {
      //      cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
      //      cnx.Open();
      //    }
      //    else
      //    {
      //      cnx = tx.Connection;
      //    }
      //    // Ende Defect #4684

      //    Params.DATLA.Value = DateTime.Now;
      //    String strUpdStmt = "UPDATE ZULAGE SET " +
      //                        "ANZAHL = @ANZAHL, " +
      //                        "DATLA = @DATLA " +
      //                        "WHERE EBID = @EBID and LOHNART = @LOHNART";
      //    /* Beginn Defect #4684: SqlCommand mit Transaction */
      //    using (cmd = (blnInTransaction) ? new SqlCommand(strUpdStmt, cnx, tx) : new SqlCommand(strUpdStmt, cnx)) // Defect 5436
      //    {
      //      // Ende Defect #4684
      //      cmd.Parameters.Clear();
      //      cmd.Parameters.Add(Params.ANZAHL);
      //      cmd.Parameters.Add(Params.DATLA);
      //      cmd.Parameters.Add(Params.EBID);
      //      cmd.Parameters.Add(Params.LOHNART);

      //      int nRecs = cmd.ExecuteNonQuery();
      //      foreach (SqlParameter s in Params.List)
      //        cmd.Parameters.Remove(s);
      //      blnUpdateSuccess = (nRecs > 0);
      //      if (!blnUpdateSuccess)
      //      {
      //        Exception ex = new Exception("dbAusZulage::UpdateSEG(): Update failed!");
      //        throw ex;
      //      }
      //    }
      //  }
      //  catch (Exception ex)
      //  {
      //    throw ex;
      //  }
      //  /* Beginn Defect #4684: Close connection nur, wenn nicht in
      //   *                      Transaktion. */
      //  finally { if (!blnInTransaction) cnx.Close(); }
      //  // Ende Defect #4684

      //  return blnUpdateSuccess;
      //}
      // Ende Defect #4493

        public ArrayList SelectAll()
        {
            ArrayList al = new ArrayList();
            return al;
        }
    }
}

