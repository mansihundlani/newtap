//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbStandort.cs
//
// Description  : Definieren der Parameter von Standort der Baustelle
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0029 ===============================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{
    public class dbStandortParams
    {
        public SqlParameter STDID = new SqlParameter("@STDID", Int32.MinValue);
        public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
        public SqlParameter NAME1 = new SqlParameter("@NAME1", (string)"");
        public SqlParameter STRASSE = new SqlParameter("@STRASSE", (string)"");
        public SqlParameter LKZ = new SqlParameter("@LKZ", (string)"");
        public SqlParameter PLZZ = new SqlParameter("@PLZZ", (string)"");
        public SqlParameter ORT = new SqlParameter("@ORT", (string)"");
        public SqlParameter TELEFON = new SqlParameter("@TELEFON", (string)"");
        public ArrayList List = new ArrayList();


        public dbStandortParams()
        {
            List.Add(STDID);
            List.Add(MANDANT);
            List.Add(NAME1);
            List.Add(STRASSE);
            List.Add(LKZ);
            List.Add(PLZZ);
            List.Add(ORT);
            List.Add(TELEFON);
            List = ParamVal.SetDefaultValues(List);
        }

    }
    /// <summary>
    /// Summary description for dbStandort
    /// </summary>
    public class dbStandort
    {
        public dbStandortParams Params = new dbStandortParams();
        dbBearbeiter Bearbeiter;

        public dbStandort(dbBearbeiter Bearb)
        {

            Params = new dbStandortParams();
            Bearbeiter = Bearb;
            if (Bearb != null)
                Params.MANDANT = Bearbeiter.Params.MANDANT;
        }

        public bool AllowUpdate = false;

        public bool Select()
        {
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    Params.STDID.Value = Bearbeiter.Params.STDSTDID.Value;
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    string sql = "Select STDID, MANDANT, NAME1, STRASSE, LKZ, PLZZ, ORT, TELEFON from STANDORT " + Config.Nolock + " where STDID = @STDID";
                    using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436, using eingef�hrt
                    {
                      cmd.Parameters.Add(Params.STDID);
                      using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                      {
                        cmd.Parameters.Remove(Params.STDID);
                        while (rd.Read())
                        {
                          ParamVal.DataReader2Params(rd, Params.List);
                          AllowUpdate = true;
                        }
                      }
                    }
                }
                catch (Exception ex) { throw ex; }
            }
            return AllowUpdate;
        }

      // Defect 5436, Code wird nicht verwendet
        //public ArrayList SelectbyMandant()
        //{
        //    ArrayList al = new ArrayList();
        //    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        //    {
        //        try
        //        {
        //            cnx.Open();
        //            using (SqlCommand cmd = new SqlCommand("sp_TM_StandortSelectbyMandant", cnx)) // Defect 5436
        //            {
        //              cmd.CommandType = CommandType.StoredProcedure;
        //              cmd.Parameters.Add(Params.MANDANT);
        //              using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
        //              {
        //                cmd.Parameters.Remove(Params.MANDANT);
        //                while (rd.Read())
        //                {
        //                  dbStandort st = new dbStandort(Bearbeiter);
        //                  ParamVal.DataReader2Params(rd, st.Params.List);
        //                  st.AllowUpdate = true;
        //                  al.Add(st);
        //                }
        //              }
        //            }
        //        }
        //        catch (Exception ex) { throw ex; }
        //        finally { cnx.Close(); }
        //    }
        //    return al;
        //}

      // Defect 5436, Code wird nicht verwendet
        //public void DDLStandort(ref DropDownList d)
        //{
        //    d.Items.Clear();
        //    ArrayList al = SelectbyMandant();
        //    foreach (dbStandort st in al)
        //    {
        //        d.Items.Add(new ListItem(ParamVal.GetParameter(st.Params.NAME1), ParamVal.GetParameter(st.Params.STDID)));
        //        if (st.Params.STDID.Value == Params.STDID.Value)
        //            d.SelectedIndex = d.Items.Count - 1;
        //    }
        //}

        /// <summary>
        /// Liest alle Standorte zu Bearbeiter.Mandant.MANDANT aus der DB
        /// </summary>
        /// <returns></returns>
        public ArrayList SelectAll()
        {
            ArrayList al = new ArrayList();
            
            return al;
        }

    }
}