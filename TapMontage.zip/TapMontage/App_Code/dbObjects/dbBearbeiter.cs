//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbBearbeiter.cs
//
// Description  : Datenbankzugriffe f�r Einstiegsmaske Kontrolle, Genehmigung
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2010
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0027 ------------------------------------------------------------------------
//
// Date         : 09. Mai 2007
// Author       : Caleb Gebhardt
// Defect#      : 5008
//
// Die Ermittlung der Fenstertage basiert im Moment auf den Eintr�gen in 
// ALLG_Feiertage aus den AZM Stammdaten, es soll dazu auch der jeweilige Status 
// (welche Feiertage gelten f�r diesen Mitarbeiter) ausgewertet werden.
//
//--------------- V1.0.0023 ------------------------------------------------------------------------
//
// Date         : 21. M�rz 2007
// Author       : CL
// Defect#      : 4827
//
// Ber�cksichtigung von Religionskennzeichen des Mitarbeiters und
// Feiertags-Kennzeichen (Gesetzlich - Religi�s) beim Lesen der Feiertage
//
//--------------- V1.0.0022 ------------------------------------------------------------------------
//
// Date         : 27.Februar 2007
// Author       : Caleb GEBHARDT
// Defect#      : 4594 
//                'Kein Arbeitszeitmodell f�r Mitarbeiter gefunden'
//                Merkvariable f. d. selektierten EB - Monat
//
// -------------- V1.0.0022 ------------------------------------------------------------------------
//
// Date         : 15.Februar 2007
// Author       : CL
// Defect#      : 4524
//                'Kontrollieren'-Button ist disabled, falls der Mitarbeiter noch nicht alle EB freigegeben hat.
//
//--------------- V1.0.0020 ------------------------------------------------------------------------
//
// Date         : 23.J�nner 2007
// Author       : Patrman Wolfgang
// Defect#      : 4268
//                select statement f�r Einsatzberichte korr., 
//
//--------------- V1.0.0017 ------------------------------------------------------------------------
//
// Date         : 04.J�nner 2007
// Author       : CG
// Defect#      : 4202
//                Korrekte Erkennung der Fenstertage im Dezember
//
//--------------- V1.0.0010 ------------------------------------------------------------------------
//
// Date         : 12.November 2006
// Author       : Georg Nebehay
// Defect#      : 3596
//                Darstellung Link Button 'kontrollieren' korrigiert
//
//--------------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

namespace TapMontage.dbObjects
{

    public class dbBearbTechParams
    {
        public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", int.MinValue);
        public SqlParameter DST = new SqlParameter("@DST", (string)"");
        public SqlParameter STANDORT = new SqlParameter("@STANDORT", (string)"");
        public SqlParameter TITEL = new SqlParameter("@TITEL", (string)"");
        public SqlParameter TECHGRP = new SqlParameter("@TECHGRP", (string)"");
        public SqlParameter WARTBEZ = new SqlParameter("@WARTBEZ", (string)"");
        public SqlParameter STRASSE = new SqlParameter("@STRASSE", (string)"");
        public SqlParameter ORT = new SqlParameter("@ORT", (string)"");
        public SqlParameter PLZ = new SqlParameter("@PLZ", (string)"");
        public SqlParameter LANDKZ = new SqlParameter("@LANDKZ", (string)"");
        public SqlParameter KFZ = new SqlParameter("@KFZ", (string)"");
        public SqlParameter KFZKZ = new SqlParameter("@KFZKZ", (string)"");
        public SqlParameter LAGERORT = new SqlParameter("@LAGERORT", (string)"");
        public SqlParameter TAPEINSKZ = new SqlParameter("@TAPEINSKZ", int.MinValue);
        public SqlParameter TAPEINSDAT = new SqlParameter("@TAPEINSDAT", ParamVal.Date0);
        public SqlParameter DATLA = new SqlParameter("@DATLA", ParamVal.Date0);
        public SqlParameter AENPERSKEY = new SqlParameter("@AENPERSKEY", int.MinValue);
        public SqlParameter DATNEU = new SqlParameter("@DATNEU", ParamVal.Date0);
        public SqlParameter KST = new SqlParameter("@KST", (string)"");
        public SqlParameter SOZSTELL = new SqlParameter("@SOZSTELL", Int16.MinValue);
        public SqlParameter AZMAB = new SqlParameter("@AZMAB", ParamVal.Date0);
        public SqlParameter MONTZULKZ = new SqlParameter("@MONTZULKZ", (string)"");
        public ArrayList List = new ArrayList();

        public dbBearbTechParams()
        {
            List.Add(PERSKEY);
            List.Add(DST);
            List.Add(STANDORT);
            List.Add(TITEL);
            List.Add(TECHGRP);
            List.Add(WARTBEZ);
            List.Add(STRASSE);
            List.Add(ORT);
            List.Add(PLZ);
            List.Add(LANDKZ);
            List.Add(KFZ);
            List.Add(KFZKZ);
            List.Add(LAGERORT);
            List.Add(TAPEINSKZ);
            List.Add(TAPEINSDAT);
            List.Add(DATLA);
            List.Add(AENPERSKEY);
            List.Add(DATNEU);
            List.Add(KST);
            List.Add(SOZSTELL);
            List.Add(AZMAB);
            List.Add(MONTZULKZ);
        }
    }

    public class dbBearbeiterParams
    {
        public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", Int32.MinValue);
        public SqlParameter PERSNR = new SqlParameter("@PERSNR", (string)"");
        public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
        public SqlParameter PTYP = new SqlParameter("@PTYP", (string)"");
        public SqlParameter VORNAME = new SqlParameter("@VORNAME", (string)"");
        public SqlParameter NACHNAME = new SqlParameter("@NACHNAME", (string)"");
        public SqlParameter ABTEILUNG = new SqlParameter("@ABTEILUNG", (string)"");
        public SqlParameter ASPID = new SqlParameter("@ASPID", Int32.MinValue);
        public SqlParameter INNEND = new SqlParameter("@INNEND", Int32.MinValue);
        public SqlParameter BELOGIN = new SqlParameter("@BELOGIN", (string)"");
        public SqlParameter KWORT = new SqlParameter("@KWORT", (string)"");
        public SqlParameter STDSTDID = new SqlParameter("@STDSTDID", Int32.MinValue);
        public SqlParameter STDMND = new SqlParameter("@STDMND", (string)"");
        public SqlParameter STDREG = new SqlParameter("@STDREG", (string)"");
        public SqlParameter STATUS = new SqlParameter("@STATUS", Int16.MinValue);

        public ArrayList List = new ArrayList();

        public dbBearbeiterParams()
        {
            //dbParamVal ParamVal;
            List.Add(PERSKEY);
            List.Add(PERSNR);
            List.Add(MANDANT);
            List.Add(PTYP);
            List.Add(VORNAME);
            List.Add(NACHNAME);
            List.Add(ABTEILUNG);
            List.Add(ASPID);
            List.Add(INNEND);
            List.Add(BELOGIN);
            List.Add(KWORT);
            List.Add(STDSTDID);
            List.Add(STDMND);
            List.Add(STDREG);
            List.Add(STATUS);
            List = ParamVal.SetDefaultValues(List);
        }
    }
    /// <summary>
    /// Summary description for dbBearbeiter
    /// </summary>
    public class dbBearbeiter
    {
        public dbBearbeiterParams Params = new dbBearbeiterParams();
        public dbBearbTechParams TechParams = new dbBearbTechParams();
        public dbCommons Commons;
        //BA1-500392 Beginn
        private bool? lKVOption;
        public bool? KVOption
        {
            get
            {
                if (lKVOption == null)
                {
                    lKVOption = false;
                    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                    {
                        try
                        {
                            cnx.Open();
                            string sql = "SELECT [MA_KV_Option_Freizeit] FROM [MA_Stamm] " + Config.Nolock + " where MA_PersNummer = '";
                            sql += Params.PERSNR.Value.ToString().Substring(2) + "' and MA_FKN = '" + this.Firmenkennung.ToString() + "'";
                            using (SqlCommand cmd = new SqlCommand(sql, cnx))
                            {
                                using (SqlDataReader rd = cmd.ExecuteReader())
                                {
                                    while (rd.Read())
                                    {
                                        lKVOption = (rd.IsDBNull(0) == true) ? false : Convert.ToBoolean(rd.GetValue(0));
                                    }
                                    rd.Close();
                                }
                            }
                        }
                        catch
                        {
                        }
                        finally
                        {
                            cnx.Close();
                        }
                    }
                }
                return lKVOption;
            }
            set
            {
                lKVOption = value;
            }
        }
        //BA1-500392 Ende
        public dbBearbeiter BearbInRole;
        private dbBearbeiter lVorgesetzter = null;
        public dbBearbeiter Vorgesetzter
        {
            get
            {
                if (lVorgesetzter == null)
                {
                    lVorgesetzter = new dbBearbeiter((int)Params.PERSKEY.Value);
                    lVorgesetzter.SelectVorgesetzter();

                }
                return lVorgesetzter;
            }
            set { lVorgesetzter = value; }
        }
        public ArrayList lVertritt = null;
        public ArrayList Vertritt
        {
            get
            {
                if (lVertritt == null)
                {
                    lVertritt = new ArrayList();
                    dbBearbeiter b = new dbBearbeiter((int)Params.PERSKEY.Value);
                    lVertritt = b.SelectVertritt();
                }
                return lVertritt;
            }
            set { lVertritt = value; }
        }

        // Defect 5436, wird nicht verwendet
        //private ArrayList lMitarbeiter = null;
        //public ArrayList Mitarbeiter
        //{
        //  get
        //  {
        //    if (lMitarbeiter == null)
        //    {
        //      lMitarbeiter = SelectMitarbeiter();
        //    }
        //    return lMitarbeiter;
        //  }
        //  set
        //  {
        //    lMitarbeiter = value;
        //  }
        //}
        public dbMandant Mandant;
        private ArrayList lMBerichte = null;
        public ArrayList MBerichte
        {
            get
            {
                if (lMBerichte == null)
                {
                    if (BerichtsMonat == 0)
                    {
                        Exception ex = new Exception("dbBearbeiter::MBerichte.get: BerichtsMonat not set or == 0!");
                        throw ex;
                    }
                    lMBerichte = SelectMBerichte();
                }
                return lMBerichte;
            }
            set { lMBerichte = value; }
        }
        // BAF 530042 Beginn
        private int lBerichtsMonat = 0;
        public int BerichtsMonat
        {
            get { return lBerichtsMonat; }
            set
            {
                if (value > 0)
                {
                    lBerichtsMonat = value;
                    int Year = Convert.ToInt32(Math.Truncate((double)lBerichtsMonat / 100));
                    int Month = Convert.ToInt32(((double)lBerichtsMonat) - Year * 100);
                    DateTime rd = DateTime.Now;
                    rd = rd.AddDays(-rd.Day + 1);
                    rd = rd.AddMonths(-rd.Month + Month);
                    rd = rd.AddYears(-rd.Year + Year);
                    MinDatum = Convert.ToDateTime(rd.ToShortDateString() + " 00:00:00");
                    MaxDatum = MinDatum.AddMonths(2);
                    MinDatum = MinDatum.AddDays(-3); //wegen AZ_Starres_Modell
                }
            }
        }
        private DateTime MinDatum = ParamVal.Date0;
        private DateTime MaxDatum = ParamVal.Date0;
        //BAF 530042 Ende
        public bool IstFeiertag(DateTime Datum)
        {
            return AZModell.Feiertag(Datum);
        }
        /* Defect 5008  - Kode deaktivierung
            public bool IstFenstertag(DateTime Datum)
            {
                // Defect# 4202: CG - Erkennung der Fenstertage
                if ((Datum.Day == 27 || Datum.Day == 28 || Datum.Day == 29) && (Datum.Year == 2006) && (Datum.Month == 12))
                    return true;  // Fenstertage lt. AZM
                if ((Datum.Day == 25 && Datum.Month == 12 && Datum.Year == 2006))
                    return false;  // Fenstertage lt. Feiertag
                // Ende Defect# 4202

                if (Datum.DayOfWeek.ToString() == "Monday")
                    if (IstFeiertag(Datum.AddDays(1)))
                        return true;
                if (Datum.DayOfWeek.ToString() == "Friday")
                    if (IstFeiertag(Datum.AddDays(-1)))
                        return true;
                return false;
            }
         
           */

        // Defect #5008: �berrpr�fung, ob das �bergebene Datum
        //               ein Fenstertag ist oder nicht
        public bool IstFenstertag(DateTime Datum)
        {
            return AZModell.Fenstertag(Datum);
        }

        //Defect# 4594 
        public int EBSelectedMonat = 0;
        //Ende Defect# 4594
        public bool IstKaufmann
        {
            get
            {
                return (TechParams.TECHGRP.Value.ToString() == "K");
            }
        }

        public int KaufmannPerskey
        {
            get
            {
                if (IstKaufmann) return (int)Params.PERSKEY.Value;
                if ((int)Params.PERSKEY.Value == (int)Vorgesetzter.Params.PERSKEY.Value) return 0;
                return Vorgesetzter.KaufmannPerskey;
            }
        }

        // Defect 5436, Code wird nicht verwendet
        // Defect 4516
        //private DateTime lMA_gueltig_von = ParamVal.Date0;
        //public DateTime MA_gueltig_von
        //{
        //  get
        //  {
        //    bool found = false;
        //    DateTime datfrom = lMA_gueltig_von;
        //    if (lMA_gueltig_von == ParamVal.Date0)
        //    {
        //      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
        //      {
        //        try
        //        {
        //          cnx.Open();
        //          string sql = "Select max(MA_AZ_g�ltig_von) from MA_AZ_Modell where MA_PersNummer = '";
        //          sql += Params.PERSNR.Value.ToString().Substring(2) + "' and ma_fkn ='" +
        //                 Firmenkennung + "'";
        //          using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
        //          {
        //            using (SqlDataReader rd = cmd.ExecuteReader()) // Deefct 5436
        //            {
        //              while (rd.Read())
        //              {
        //                datfrom = Convert.ToDateTime(rd.GetValue(0).ToString());
        //                found = true;
        //              }
        //              rd.Close();
        //            }
        //          }
        //        }
        //        catch (Exception ex) { if (found == false) datfrom = ParamVal.Date0; }
        //        finally { cnx.Close(); }
        //      }
        //      lMA_gueltig_von = datfrom;
        //    }
        //    return lMA_gueltig_von;
        //  }
        //}
        //private DateTime lMA_gueltig_bis = ParamVal.Date0;
        //public DateTime MA_gueltig_bis
        //{
        //  get
        //  {
        //    bool found = false;
        //    string gueltig_von = MA_gueltig_von.ToString("u").Substring(0, MA_gueltig_von.ToString("u").Length - 1);
        //    DateTime datbis = lMA_gueltig_bis;
        //    if (lMA_gueltig_bis == ParamVal.Date0)
        //    {
        //      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
        //      {
        //        try
        //        {
        //          cnx.Open();
        //          string sql = "Select MA_AZ_g�ltig_bis from MA_AZ_Modell where MA_PersNummer = '";
        //          sql += Params.PERSNR.Value.ToString().Substring(2) + "' and ma_fkn ='" +
        //                 Firmenkennung + "' and MA_AZ_g�ltig_von = '" + gueltig_von + "'";
        //          using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
        //          {
        //            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
        //            {
        //              while (rd.Read())
        //              {
        //                lMA_gueltig_bis = Convert.ToDateTime(rd.GetValue(0).ToString());
        //                found = true;
        //              }
        //              rd.Close();
        //            }
        //          }
        //        }
        //        catch (Exception ex) { if (found == false) datbis = ParamVal.Date0; }
        //        finally { cnx.Close(); }
        //      }
        //      lMA_gueltig_von = datbis;
        //    }
        //    return lMA_gueltig_von;
        //  }
        //}
        // Ende Defect 4516
        private dbStandort lStandort;
        public dbStandort Standort
        {
            get
            {
                if (lStandort == null)
                {
                    lStandort = new dbStandort(this);
                    lStandort.Select();
                }
                return lStandort;
            }
            set
            {
                lStandort = value;
            }
        }

        private dbKG_Monat lKGMonat;
        public dbKG_Monat KGMonat
        {
            get
            {
                if (lKGMonat == null)
                    lKGMonat = new dbKG_Monat(this, BerichtsMonat);
                return lKGMonat;
            }
            set
            {
                lKGMonat = value;
            }
        }

        private ArrayList lGTAbsenz = null;
        public ArrayList GTAbsenz
        {
            set { lGTAbsenz = value; }
            get
            {
                if (lGTAbsenz == null)
                {
                    dbGTAbsenz gt = new dbGTAbsenz(this);
                    lGTAbsenz = gt.Select();
                }
                return lGTAbsenz;
            }
        }

        private string lfk = "";
        public string Firmenkennung
        {
            get
            {
                if (lfk == "")
                    lfk = SelectFirmenkennung(Params.PERSNR.Value.ToString().Substring(0, 2));
                return lfk;
            }
        }

        private dbAZModell lAZModell;
        public dbAZModell AZModell
        {
            get
            {
                if (lAZModell == null)
                {
                    if (BerichtsMonat == 0)
                        lAZModell = new dbAZModell(this, DateTime.Now);
                    else
                        lAZModell = new dbAZModell(this, BerichtsMonat);
                }
                return lAZModell;
            }
            set
            {
                lAZModell = value;
            }
        }

        public dbBearbeiter(int lPersKey)
        {
            Params.PERSKEY.Value = lPersKey;
            Commons = new dbCommons(this);
            Mandant = new dbMandant(this);
            Select(false);
            BearbInRole = this;
        }

        public dbBearbeiter(string Username)
        {
            Params.BELOGIN.Value = Username;
            Commons = new dbCommons(this);
            Mandant = new dbMandant(this);
            Select(true);
            BearbInRole = this;
        }

        public bool IstArbeitstag(DateTime Date)
        {
            //wochenenden und Feiertage/Fenstertage nicht
            DateTime wt = DateTime.Now;
            if (this.AZModell.AZTage != null)
                wt = Convert.ToDateTime((this.AZModell.AZTage[(int)Date.DayOfWeek] as dbAZTag).Params.AZ_Begin.Value.ToString());
            else
                if ((Mandant.AZModell.Tage[(int)Date.DayOfWeek] as dbMandantAZModellTag).Params.NAZBEG.Value.ToString() == "")
                    wt = ParamVal.Date0;
                else
                    wt = Convert.ToDateTime((Mandant.AZModell.Tage[(int)Date.DayOfWeek] as dbMandantAZModellTag).Params.NAZBEG.Value);

            if (wt != ParamVal.Date0) //sollte heute was hackeln
            {
                //return !IstFeiertag(Date);  //Defect 5008
                return !IstFeiertag(Date) & !IstFenstertag(Date);  //Defect 5008 - check Fenstertag added
            }
            return false;
        }
        public bool Select(bool ByBELogin)
        {
            using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
            {
                try
                {
                    cnx.Open();
                    string beLogin = "";
                    if (ByBELogin) beLogin = "BELOGIN";
                    using (SqlCommand cmd = new SqlCommand("sp_TM_BearbeitSelect" + beLogin, cnx)) // Defect 5436, using eingef�hrt
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (ByBELogin)
                            cmd.Parameters.Add(Params.BELOGIN);
                        else
                            cmd.Parameters.Add(Params.PERSKEY);
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            if (ByBELogin)
                                cmd.Parameters.Remove(Params.BELOGIN);
                            else
                                cmd.Parameters.Remove(Params.PERSKEY);
                            while (rd.Read())
                                ParamVal.DataReader2Params(rd, Params.List);
                            rd.Close();
                        }
                        cmd.CommandText = "sp_TM_BearbTechSelect";
                        cmd.Parameters.Add(Params.PERSKEY);
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Remove(Params.PERSKEY);
                            while (rd.Read())
                                ParamVal.DataReader2Params(rd, TechParams.List);
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return ((int)Params.PERSKEY.Value != Int32.MinValue);
        }

        private bool SelectVorgesetzter()
        {
            using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
            {
                try
                {
                    
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("sp_TM_BearbeitVSelect", cnx)) // Defect 5436
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(Params.PERSKEY);
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Remove(Params.PERSKEY);
                            while (rd.Read())
                            {
                                Params.PERSKEY.Value = rd.GetInt32(0);
                                Select(false);
                            }
                        }
                    }
                    
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return ((int)Params.PERSKEY.Value != 0);
        }

        private ArrayList SelectVertritt()
        {
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("sp_TM_BearbeitSSelect", cnx)) // Defect 5436
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(Params.PERSKEY);
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Remove(Params.PERSKEY);
                            while (rd.Read())
                            {
                                dbBearbeiter b = new dbBearbeiter(rd.GetInt32(0));
                                al.Add(b);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return al;
        }

        // Defect 5436, wird nicht verwendet
        //private ArrayList SelectMitarbeiter()
        //{
        //  ArrayList al = new ArrayList();
        //  using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        //  {
        //    try
        //    {
        //      cnx.Open();
        //      using (SqlCommand cmd = new SqlCommand("sp_TM_BearbeitMSelect", cnx)) // Defect 5436
        //      {
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.Add(Params.PERSKEY);
        //        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
        //        {
        //          cmd.Parameters.Remove(Params.PERSKEY);
        //          while (rd.Read())
        //          {
        //            dbBearbeiter b = new dbBearbeiter(rd.GetInt32(0));
        //            dbMitarbeiter m = new dbMitarbeiter(rd.GetInt32(0), rd.GetString(1), b.Firmenkennung, BerichtsMonat, b.Params.VORNAME.Value.ToString(), b.Params.NACHNAME.Value.ToString());
        //            al.Add(m);
        //          }
        //        }
        //      }
        //    }
        //    catch (Exception ex) { throw ex; }
        //    finally { cnx.Close(); }
        //  }
        //  return al;
        //}

        private ArrayList SelectMBerichte()
        {
            dbMontBer mb = new dbMontBer(null, this);
            return mb.SelectAllByPerskey(BerichtsMonat, (int)Params.PERSKEY.Value);
        }
        public string SelectFirmenkennung(string firmenkz)
        {
            string Firmenkennung = "";
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("select Firmapers from x_con_fkz " + Config.Nolock + " where firmenkz= @FIRMAKZ", cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(new SqlParameter("@FIRMAKZ", firmenkz));
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            while (rd.Read())
                            {
                                Firmenkennung = (string)rd.GetValue(0);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return Firmenkennung;
        }
        //BAF 530042 Beginn
        private const String strRelFtFlag = "R";        //Flag f�r religi�sen Feiertag
        private const String stFnstFlag = "F";          //Flag f�r Fensterfeiertage
        private Dictionary<DateTime, KalenderAZMTag> lAZMKalenderTage = null;
        public Dictionary<DateTime, KalenderAZMTag> AZMKalenderTage
        {
            get
            {
                if (lAZMKalenderTage != null)
                    return lAZMKalenderTage;

                lAZMKalenderTage = new Dictionary<DateTime, KalenderAZMTag>();

                if (this.MinDatum == ParamVal.Date0 ||
                    this.Firmenkennung == "" ||
                    Convert.ToInt32(this.Params.PERSNR.Value) <= 0)
                    return lAZMKalenderTage;


                string azmSelect = "SELECT BS_BerechneteSalden.BS_Datum, AZ_Tag.AZ_Begin, AZ_Tag.AZ_Ende, AZ_Tag.AZ_SollarbeitStd, allg_feiertage.allg_bezeichnung , ma_stamm.ma_rel_feiertag, AZ_Modelle.AZ_Starres_Modell " +
                    " FROM BS_BerechneteSalden " + Config.Nolock +
                    " LEFT JOIN ma_stamm " + Config.Nolock + " on BS_BerechneteSalden.MA_FKN = ma_stamm.MA_FKN AND BS_BerechneteSalden.MA_PersNummer = ma_stamm.MA_PersNummer " +
                    " LEFT JOIN allg_feiertage " + Config.Nolock + " on ma_stamm.ma_kal_id = allg_feiertage.kal_id and BS_BerechneteSalden.BS_Datum = allg_feiertage.allg_datum " +
                    " LEFT JOIN MA_AZ_Modell " + Config.Nolock + " ON BS_BerechneteSalden.MA_FKN = MA_AZ_Modell.MA_FKN " +
                    " AND BS_BerechneteSalden.BS_Datum >= MA_AZ_Modell.MA_AZ_g�ltig_von AND BS_BerechneteSalden.BS_Datum <= MA_AZ_Modell.MA_AZ_g�ltig_bis " +
                    " AND BS_BerechneteSalden.MA_PersNummer = MA_AZ_Modell.MA_PersNummer " +
                    " LEFT JOIN AZ_Tag " + Config.Nolock + " ON MA_AZ_Modell.AZ_Modell_Nummer = AZ_Tag.AZ_Modell_Nummer " +
                    " AND datepart(dw,BS_BerechneteSalden.BS_Datum) = AZ_Tag.AZ_Wochentag " +
                    " LEFT JOIN AZ_Modelle " + Config.Nolock + " ON AZ_Tag.AZ_Modell_Nummer = AZ_Modelle.AZ_Modell_Nummer AND AZ_Tag.SYS_ID = AZ_Modelle.SYS_ID AND AZ_Tag.SYS_ID = AZ_Modelle.SYS_ID" +
                    " WHERE BS_BerechneteSalden.MA_FKN = '" + this.Firmenkennung + "' AND BS_BerechneteSalden.MA_PersNummer = '" + Params.PERSNR.Value.ToString().Substring(2) + "' " +
                    " AND BS_BerechneteSalden.BS_Datum >= '" + this.MinDatum.ToString("yyyy-MM-dd") + "'" + //@MINDATE" +
                    " AND BS_BerechneteSalden.BS_Datum <= '" + this.MaxDatum.ToString("yyyy-MM-dd") + "'" + //@MAXDATE " +
                    " ORDER BY BS_Datum";
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        using (SqlCommand cmd = new SqlCommand(azmSelect, cnx))
                        {
                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                DateTime dt = this.MinDatum;
                                bool AZ_Starres_Modell = false;
                                while (rd.Read())
                                {
                                    while (rd.GetDateTime(0) > dt)
                                        dt = dt.AddDays(1);

                                    if (rd.GetDateTime(0) == dt)
                                    {
                                        KalenderAZMTag kt = new KalenderAZMTag();
                                        if (!rd.IsDBNull(1)) //BEi Samstag & Sonntag ist es null
                                            kt.AZ_Begin = rd.GetDateTime(1);
                                        if (!rd.IsDBNull(2))
                                            kt.AZ_Ende = rd.GetDateTime(2);
                                        if (!rd.IsDBNull(3))
                                            kt.AZ_SollarbeitStd = rd.GetFloat(3);
                                        if (!rd.IsDBNull(4)) // Feiertag oder Fenstertag
                                        {
                                            if ((rd.GetString(4) != strRelFtFlag) ||
                                                (rd.GetString(4) == strRelFtFlag && rd.GetBoolean(5) == true))
                                            {
                                                if (rd.GetString(4) == stFnstFlag)
                                                {
                                                    kt.IstFenstertag = true;
                                                }
                                                kt.IstFeiertag = true;
                                            }
                                        }
                                        if (kt.AZ_Begin != ParamVal.Date0 &&
                                            !kt.IstFeiertag &&
                                            !kt.IstFenstertag)
                                            kt.IstArbeitstag = true;

                                        if (!rd.IsDBNull(6))
                                            AZ_Starres_Modell = rd.GetBoolean(6);
                                        kt.AZ_Starres_Modell = AZ_Starres_Modell;
                                        lAZMKalenderTage.Add(dt, kt);
                                    }
                                    dt = dt.AddDays(1);
                                }
                                rd.Close();
                            }
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
                return lAZMKalenderTage;
            }
        }
        public bool MAMorgens(DateTime Kommen)
        {
            if (Kommen.Ticks == ParamVal.Date0.Ticks) return false;
            if (AZMKalenderTage[Kommen.Date].IstFeiertag && !AZMKalenderTage[Kommen.Date].IstFenstertag) return true;
            if (AZMKalenderTage[Kommen.Date].AZ_Begin == ParamVal.Date0) return true;
            if (Convert.ToDateTime(Kommen.ToShortDateString() + " " + AZMKalenderTage[Kommen.Date].AZ_Begin.ToShortTimeString()).Ticks > Kommen.Ticks) return true;
            return false;
        }

        public bool MAAbends(DateTime Gehen)
        {
            if (Gehen.Ticks == ParamVal.Date0.Ticks) return false;
            if (AZMKalenderTage[Gehen.Date].IstFeiertag && !AZMKalenderTage[Gehen.Date].IstFenstertag) return true;
            if (AZMKalenderTage[Gehen.Date].AZ_Ende == ParamVal.Date0) return true;
            if (Convert.ToDateTime(Gehen.ToShortDateString() + " " + AZMKalenderTage[Gehen.Date].AZ_Ende.ToShortTimeString()).Ticks < Gehen.Ticks) return true;
            return false;
        }
        //Erg�nzung zur "Performance Verbesserung"
        public DateTime NazBeginn(DateTime Kommen)
        {
            if (AZMKalenderTage[Kommen.Date].IstFeiertag && !AZMKalenderTage[Kommen.Date].IstFenstertag) return ParamVal.Date0;
            if (AZMKalenderTage[Kommen.Date].AZ_Begin == ParamVal.Date0) return ParamVal.Date0;
            return Convert.ToDateTime(Kommen.ToShortDateString() + " " + AZMKalenderTage[Kommen.Date].AZ_Begin.ToShortTimeString());
        }
 
        public DateTime NazEnde(DateTime Gehen)
        {
            if (AZMKalenderTage[Gehen.Date].IstFeiertag && !AZMKalenderTage[Gehen.Date].IstFenstertag) return ParamVal.Date0;
            if (AZMKalenderTage[Gehen.Date].AZ_Ende == ParamVal.Date0) return ParamVal.Date0;
            return Convert.ToDateTime(Gehen.ToShortDateString() + " " + AZMKalenderTage[Gehen.Date].AZ_Ende.ToShortTimeString());
        }
    }
    /// <summary>
    /// KalenderAZMTag
    /// beinhaltet alle AZM Relevanten Daten f�r TAP Abrechnung
    /// </summary>
    public class KalenderAZMTag
    {
        public DateTime AZ_Begin = ParamVal.Date0;
        public DateTime AZ_Ende = ParamVal.Date0;
        public Single AZ_SollarbeitStd = 0;
        //public string Tagtyp = "";
        public bool IstFeiertag = false;
        public bool IstFenstertag = false;
        public bool IstArbeitstag = false;
        public bool AZ_Starres_Modell = false;
        //public DateTime Uestd100Beg1 = ParamVal.Date0;
        //public DateTime Uestd50Beg1 = ParamVal.Date0;
        //public DateTime Uestd50Beg2 = ParamVal.Date0;
        //public DateTime Uestd100Beg2 = ParamVal.Date0;
        public KalenderAZMTag()
        {
        }
    }
    //BAF 530042 Ende

    //public class dbMitarbeiter
    //{

    //  private class ATag
    //  {
    //    public int Tag;
    //    public bool ok;
    //    public ATag(int iTag)
    //    {
    //      Tag = iTag;
    //      ok = true;
    //    }
    //  }
    //  ArrayList ATage = new ArrayList();

    //  private const String strRelFtFlag = "R"; // Defect #4827: Flag f�r religi�sen Feiertag

    //  DateTime MonatMin;
    //  DateTime MonatMax;
    //  private int lBerichtsmonat = 0;
    //  public int Berichtsmonat
    //  {
    //    get
    //    {
    //      return lBerichtsmonat;
    //    }
    //    set
    //    {
    //      lBerichtsmonat = value;
    //      if (value != 0)
    //      {
    //        MonatMin = Convert.ToDateTime("01-" + value.ToString().Substring(4, 2) + "-" + value.ToString().Substring(0, 4));
    //        MonatMax = MonatMin.AddMonths(1).AddSeconds(-1);
    //      }
    //    }
    //  }
    //  // Defect #4524: Flag f�r EB mit Status 10 (= nicht freigegeben)
    //  private bool lblnEBWithStat10 = false;
    //  public bool blnEBWithStat10
    //  {
    //    get
    //    {
    //      return lblnEBWithStat10;
    //    }
    //    set
    //    {
    //      lblnEBWithStat10 = value;
    //    }
    //  }
    //  // Ende Defect #4524

    //  private bool eb_vorhanden = false;
    //  private int lPerskey;
    //  public int Perskey
    //  {
    //    get
    //    {
    //      return lPerskey;
    //    }
    //    set
    //    {
    //      lPerskey = value;
    //      if (Berichtsmonat != 0) SelectStd();
    //    }
    //  }
    //  public string Vorname = "";
    //  public string Nachname = "";
    //  public string PersNr = "";
    //  public string Firma = "";
    //  public ArrayList MBs = new ArrayList();
    //  public dbMitarbeiter(int persKey, string Persnr, string firma, int berichtsMonat, string vorName, string nachName)
    //  {
    //    Berichtsmonat = berichtsMonat;
    //    PersNr = Persnr;
    //    Firma = firma;
    //    Vorname = vorName;
    //    Nachname = nachName;
    //    SelectMBs(persKey);
    //    Perskey = persKey;
    //  }
    //  private void SelectMBs(int iPerskey)
    //  {
    //    dbBearbeiter b = new dbBearbeiter(iPerskey);
    //    dbMontBer mb = new dbMontBer(null, b);
    //    MBs = mb.SelectAllByPerskey(Berichtsmonat, iPerskey);
    //  }

    //  public double NormStunden = 0;
    //  public double UE50 = 0;
    //  public double UE100 = 0;
    //  public double SummeStunden = 0;
    //  public double DavonGK = 0;
    //  public int GTAbsenzen = 0;
    //  public bool EBerichteOK = false;
    //  public bool EBerichteGenehmigt = false;

    //  public string EBLinktext
    //  {
    //    get
    //    {
    //      if (EBerichteGenehmigt)
    //        if (EBerichteOK) return "genehmigt";
    //        else return "fehlt";
    //      // Defect 3596
    //      // Darstellung Link Button 'kontrollieren' korrigiert
    //      else
    //        if (eb_vorhanden == false && EBerichteOK == false)
    //          return "fehlt";
    //        else
    //          return "kontrollieren";
    //    }
    //  }
    //  public string EBStatusText
    //  {
    //    get
    //    {
    //      if (EBerichteOK) return "vollst�ndig";
    //      else return "unvollst�ndig";
    //    }
    //  }

    //  private void SelectStd()
    //  {
    //    for (int i = MonatMin.Day; i <= MonatMax.Day; i++) ATage.Add(new ATag(i));

    //    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
    //    {
    //      try
    //      {
    //        cnx.Open();
    //        using (SqlCommand cmd = new SqlCommand("select wochentag from y_azmodell where mandant = (select Mandant from bearbeit where perskey = @PERSKEY) and nazbeg is not null", cnx)) // Defect 5436
    //        {
    //          cmd.Parameters.Add(new SqlParameter("@PERSKEY", lPerskey));
    //          using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
    //          {
    //            while (rd.Read())
    //            {
    //              foreach (ATag a in ATage)
    //                if ((int)MonatMin.AddDays(a.Tag - 1).DayOfWeek == ((int)rd.GetInt16(0) - 1)) a.ok = false;//(ATage[a.Tag - 1] as ATag).ok = false;
    //            }
    //            rd.Close();
    //          }
    //        }

    //        using (SqlCommand cmd = new SqlCommand("select sum(normstd) as NORMSTD, sum(uestd50) as UESTD50, sum(uestd100) as UESTD100, auftrnr from arbzeit where Datum >= @VON and Datum <= @BIS  and kzaz='A' and Perskey = @PERSKEY group by auftrnr", cnx)) // Defect 5436
    //        {
    //          cmd.Parameters.Add(new SqlParameter("@PERSKEY", lPerskey));
    //          cmd.Parameters.Add(new SqlParameter("@VON", MonatMin));
    //          cmd.Parameters.Add(new SqlParameter("@BIS", MonatMax));
    //          using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
    //          {
    //            while (rd.Read())
    //            {
    //              NormStunden += Convert.ToDouble(rd.GetInt32(0)) / 60;
    //              UE50 += Convert.ToDouble(rd.GetInt32(1)) / 60;
    //              UE100 += Convert.ToDouble(rd.GetInt32(2)) / 60;
    //              SummeStunden = NormStunden + UE100 + UE50;
    //              if (rd.GetString(3).Trim() != "")
    //              {
    //                bool bistgk = true;
    //                foreach (dbMontBer b in MBs) //TODO: Sonderfall: Reisezeit aus Vormaonat wird hier leider als GK ausgegeben, wir l�sen das sp�ter (Tritt so gut wie nie auf!)
    //                  if (b.Projekt.Params.KTOBJ.Value.ToString() == rd.GetString(3).Trim()) bistgk = false;
    //                if (bistgk) DavonGK += Convert.ToDouble(rd.GetInt32(0) + rd.GetInt32(1) + rd.GetInt32(2)) / 60;
    //              }
    //            }
    //            rd.Close();
    //          }
    //        }

    //        using (SqlCommand cmd = new SqlCommand("select ebstat,ebid from einsber where bermon = @VON and Perskey = @PERSKEY order by ebid", cnx)) // Defect 5436
    //        {
    //          cmd.Parameters.Add(new SqlParameter("@PERSKEY", lPerskey));
    //          cmd.Parameters.Add(new SqlParameter("@VON", MonatMin));
    //          using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
    //          {
    //            int iRecCount = 0;
    //            string ebstat;
    //            EBerichteOK = true;
    //            EBerichteGenehmigt = true; // Defect: 4268, Status initialisieren

    //            /* Defect: 4268 Beginn
    //             * Code entfernt
    //             while (EBerichteOK && rd.Read())
    //             {
    //                ++iRecCount;
    //                ebstat = rd.GetValue(0).ToString();
    //                if (Int32.Parse(ebstat) < 30)
    //                {
    //                    EBerichteOK = false;

    //                }
    //             }
    //             if (iRecCount == 0) EBerichteOK = false;
    //                else eb_vorhanden = true;
    //             * Defect: 4268 Ende */

    //            /* Defect: 4268 Beginn
    //             * select nur einmal ben�tigt, EBerichteOK und EBerichteGenehmigt
    //             * mit einem select ermitteln
    //             */

    //            // Beginn Defect #4524: Alle EB auf Status 10 durchsuchen
    //            // und gegebenenfalls Flag setzen
    //            lblnEBWithStat10 = false;
    //            while (rd.Read())
    //            // while ((EBerichteOK || EBerichteGenehmigt) && rd.Read())
    //            // Ende Defect #4524
    //            {
    //              ++iRecCount;
    //              eb_vorhanden = true;
    //              ebstat = rd.GetValue(0).ToString();
    //              // Beginn Defect #4524: Pr�fung auf EB-Status 10
    //              if (Int32.Parse(ebstat) == 10)
    //              {
    //                lblnEBWithStat10 = true;
    //              }
    //              // Ende Defect #4524
    //              if (Int32.Parse(ebstat) < 30)
    //              {
    //                EBerichteOK = false;
    //              }
    //              if (Int32.Parse(ebstat) < 40)
    //              {
    //                EBerichteGenehmigt = false;
    //              }
    //            }
    //            if (iRecCount == 0)
    //            {
    //              EBerichteOK = false;
    //              EBerichteGenehmigt = false;
    //            }
    //            /* Defect: 4268 Ende */

    //            rd.Close();
    //          }
    //        }

    //        /* Defect: 4268 Beginn
    //         * Code entfernt
    //        cmd = new SqlCommand("select ebstat,ebid from einsber where bermon = @VON and Perskey = @PERSKEY", cnx);
    //        cmd.Parameters.Add(new SqlParameter("@PERSKEY", lPerskey));
    //        cmd.Parameters.Add(new SqlParameter("@VON", MonatMin));
    //        rd = cmd.ExecuteReader();

    //        if (iRecCount > 0)
    //        {
    //            iRecCount = 0;
    //            EBerichteGenehmigt = true;
    //            while (EBerichteGenehmigt && rd.Read())
    //            {
    //                ++iRecCount;
    //                ebstat = rd.GetValue(0).ToString();
    //                if (Int32.Parse(ebstat) < 40)
    //                {
    //                    EBerichteGenehmigt = false;
    //                }
    //            }

    //            if (iRecCount == 0) EBerichteGenehmigt = false;
    //        }
    //        else
    //        {
    //          EBerichteGenehmigt = false;                    
    //        }
    //        rd.Close();
    //        Defect: 4268 Ende */

    //        if (EBerichteOK)
    //        {
    //          using (SqlCommand cmd = new SqlCommand("select Datum from KALTAG where Datum >= @VON and Datum <= @BIS  and Perskey = @PERSKEY", cnx)) // Defect 5436
    //          {
    //            cmd.Parameters.Add(new SqlParameter("@PERSKEY", lPerskey));
    //            cmd.Parameters.Add(new SqlParameter("@VON", MonatMin));
    //            cmd.Parameters.Add(new SqlParameter("@BIS", MonatMax));
    //            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
    //            {
    //              while (rd.Read())
    //              {
    //                GTAbsenzen++;
    //                DateTime d = rd.GetDateTime(0);
    //                (ATage[d.Day - 1] as ATag).ok = true;
    //              }
    //              rd.Close();
    //            }
    //          }

    //          // Defect: 4268, datum statt * im select verwendet
    //          // cmd = new SqlCommand("select count(*), datum  from arbzeit where Datum >= @VON and Datum <= @BIS and Perskey = @PERSKEY group by datum", cnx);
    //          using (SqlCommand cmd = new SqlCommand("select count(datum), datum  from arbzeit where Datum >= @VON and Datum <= @BIS and Perskey = @PERSKEY group by datum", cnx)) // Defect 5436
    //          {
    //            cmd.Parameters.Add(new SqlParameter("@PERSKEY", lPerskey));
    //            cmd.Parameters.Add(new SqlParameter("@VON", MonatMin));
    //            cmd.Parameters.Add(new SqlParameter("@BIS", MonatMax));
    //            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
    //            {
    //              while (rd.Read())
    //              {
    //                DateTime d = rd.GetDateTime(1);
    //                (ATage[d.Day - 1] as ATag).ok = true;
    //              }
    //              rd.Close();
    //            }
    //          }

    //          using (SqlConnection cnx2 = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
    //          {
    //            try
    //            {
    //              cnx2.Open();
    //              /* Beginn Defect #4827: Ber�cksichtigung der religi�sen Feiertage
    //               * und des Religionskennzeichens des Mitarbeiter in MA_STAMM */
    //              // SqlCommand cmd2 = new SqlCommand("select allg_datum from allg_feiertage where ALLG_Datum >= @VON and ALLG_Datum <= @BIS and KAL_ID = (select MA_Kal_ID from ma_stamm where MA_Persnummer = @PERSNR and MA_FKN = @MA_FKN)", cnx2);
    //              using (SqlCommand cmd2 = new SqlCommand(
    //                    "SELECT af.allg_datum, af.allg_bezeichnung, " +
    //                    "ma.ma_rel_feiertag FROM allg_feiertage af, ma_stamm ma " +
    //                    "WHERE af.ALLG_Datum >= @VON and " +
    //                    "af.ALLG_Datum <= @BIS " +
    //                    "and af.KAL_ID = ma.ma_kal_id " +
    //                    "AND ma.MA_Persnummer = @PERSNR" +
    //                    " and ma.MA_FKN = @MA_FKN", cnx2)) // Defect 5436
    //              {
    //                // Ende Defect #4827
    //                cmd2.Parameters.Add(new SqlParameter("@PERSNR", PersNr.Substring(2)));
    //                cmd2.Parameters.Add(new SqlParameter("@MA_FKN", Firma));
    //                cmd2.Parameters.Add(new SqlParameter("@VON", MonatMin));
    //                cmd2.Parameters.Add(new SqlParameter("@BIS", MonatMax));
    //                using (SqlDataReader rd2 = cmd2.ExecuteReader()) // Defect 5436
    //                {
    //                  while (rd2.Read())
    //                  {
    //                    /* Beginn Defect #4827: Die religi�sen Feiertage werden nur
    //                     * bei Mitarbeitern mit Rel-Flag = 1 ber�cksichtigt */
    //                    if ((rd2.GetString(1) != strRelFtFlag) ||
    //                        (rd2.GetString(1) == strRelFtFlag && rd2.GetBoolean(2) == true))
    //                    {
    //                      DateTime d = rd2.GetDateTime(0);
    //                      (ATage[d.Day - 1] as ATag).ok = true;
    //                    } // Ende Defect #4827
    //                  }
    //                  rd2.Close();
    //                }
    //              }
    //            }
    //            catch (Exception xx) { throw xx; }
    //            finally { cnx2.Close(); }
    //          }
    //        }
    //      }
    //      catch (Exception ex) { throw ex; }
    //      finally { cnx.Close(); }
    //      foreach (ATag a in ATage) EBerichteOK = EBerichteOK & a.ok;
    //    }
    //  }
    //}
}