//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbArbZeit.cs
//
// Description  : DB-Zugriffe f�r Arbeitszeiten
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2010
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//
//=============== V1.0.0047 ===============================================
//
// Date         : 16.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-27
//                AZ �ber Monatsgr�nze - AZM falsch
//
//=============== V1.0.0046 ===============================================
//
// Date         : 09.Dezember 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-35
//                verschobene AZ
//
//=============== V1.0.0044 ===============================================
//
// Date         : 26.August 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-20
//                Rufbereitschaft
//
//=============== V1.0.0038 ===============================================
//
// Date         : 20.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : 5833
//                Falsche Berechnung der Mittagspause 
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.J�nner 2008
// Author       : Joldic Dzevad
// Defect#      : 5620
//                Korrektur f�r AUTOIVZ �bertragung von stundenweise Absenzen
//                Bei Pausenberechnung werden Einsatzberichte mit stundenweise
//                Absenzen mit dem ID "110" (Zeitausgleich) ignoriert. 
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
// Date         : 9.Jaenner 2008
// Author       : Norbert Krizek
// Defect#      : 5696
//                Wegzeit wird bei Sonntagsreise nicht gespeichert
//
//=============== V1.0.0036 ===============================================
//
// Date         : 17.Dezember 2007
// Author       : Joldic Dzevad
// Defect#      : 5690
//                Pausenberechnung bei Mitternachts�berschreitung falsch
//
// Date         : 14.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 29.November 2007
// Author       : Joldic Dzevad
// Defect#      : 5643
//                Falscher Abzug der Pause
//
// Date         : 28.November 2007
// Author       : Krizek Norbert
// Defect#      : 5390
//                keine unterbrechung der reduzierung bei eint�giger reise auf andere bs
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 14.August 2007
// Author       : Adam Kiefer
// Defect#      : 5285
//                Falsche Produktivierung TAP_Montage - std. Absenzen
//
//
// Date         : 10.August 2007
// Author       : Georg Nebehay
// Defect#      : 4665, 5337
//                Mitarbeiter-AZM wurde durch Projekt-AZM �berschrieben (Fehler in #5322)
//
//--------------- V1.0.0031 ---------------------------------------------------
//
// Date         : 31.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 5322
//                Projekt-AZM wird durch Mitarbeiter AZM �berschrieben
//
//--------------- V1.0.0030 ---------------------------------------------------
// Date         : 31.Juli 2007
// Author       : Adam Kiefer
// Defect#      : 5320
//                Auf bereits erfasste EBs kann nicht mehr zugegriffen werden
//
//--------------- V1.0.0029 --------------------------------------------------- *
// Date         : 10. Juli 2007
// Author       : NK
// Defect#      : 4936
// Fehlermeldung bei �berpr�fung  Reisen im Vormonat
// hier wurde die routine CalcWorktime welche eine fm ausgiebt wenn zeiten nicht zusammenpasse entschaerft
// sodass beim laden der vormonate diese nicht ausgeben wird
//
// Date         : 27.Juni 2007
// Author       : Adam Kiefer
// Defect#      : 4616, 4617, 4940
//                AZ-Modell
//
//--------------- V1.0.0028 --------------------------------------------------------------------------
//
// Date         : 6. Juni 2007
// Author       : Krizek Norbert
// Defect#      : 4972
//                Neue Bool-Var f�r RNG (kreuzerl-liste in Maske)
//
//--------------- V1.0.0028 --------------------------------------------------------------------------
//
// Date         : 21. Juni 2007
// Author       : Caleb Gebhardt 
// Defect#      : 4164
//
// Bei mehreren AZ - Zeilen erfolgt der Pausenabzug nicht vollst�ndig. Es wird nur
// auf der ersten AZ - Zeile abgezogen; der Rest ignoriert. 
// 
// Jetzt mu� gelten: erst nach 6 Stunden Arbeit eine Pause bis zu  max. 30 min
// abzuziehen. Alle AZ - Zeilen m�ssen ber�cksichtigt werden (Normalarbeitszeiten 
// und STD Absenzen)
//
//--------------- V1.0.0028 --------------------------------------------------------------------------
//
// Date         : 15.Juni 2007
// Author       : Caleb Gebhardt
// Defect#      : 5024, 5082
//        
// Summenberechnung f. Wochenende falsch
// Stundenweise Absenzen in der DB nicht gespeichert
// Berechnung und Anzeige der STD - Abszendauer bei allen STD Absenzarten
//
//--------------- V1.0.0027 --------------------------------------------------------------------------
//
// Date         : 09. Mai 2007
// Author       : Caleb Gebhardt
// Defect#      : 5008
//                Fenstertagstempel richtig vorbelegen  
//
//--------------- V1.0.0022 --------------------------------------------------------------------------
//
// Date         : 24.Februar 2007
// Author       : GN
// Defect#      : 4625
//                Wir haben in der Datenbank f�r Berichtsmonat J�nner ca. 800 R/W Zeilen ohne Leistungsart.
//                Transaktionsthema
//
//--------------- V1.0.0022 --------------------------------------------------------------------------
//
// Date         : 6. Februar 2007
// Author       : CL
// Defect#      : 4520
//
// Die laufende Zeilennummer wird aufsteigend nach Kommen-Stempel in die
// Tabelle Arbzeit eingetragen.
//
//--------------- V1.0.0022 --------------------------------------------------------------------------
//
// Date         : 8. Februar 2007
// Author       : CG
// Defect#      : 4464, 4534 und 4669
//
// Die Auftragsnummer ist f�lschlicherweise auf leer in AZ-Zeile. 
// Dadurch wird dieser Auftrag beim SAP-Check als nicht bebuchbar ausgewertet. Die �nderungen
// tragen die korrekt ktobj in d. Aufragsnummer.
//
//--------------- V1.0.0022 --------------------------------------------------------------------------
//
// Date         : 8. Februar 2007
// Author       : CG
// Defect#      : 4444
//
// Im Einsatzbericht wird die ganzt�gige  Ersatzruhe nicht mit dem AZ-Zeichen
// "E" abgespeichert, ( zur Zeit als "A"), daher werden die Auswertungen �ber 
//  die produktiven Ersatzruhe bei der I &S falsch,
//  Ersatzruhen werden generell (egal ob ganzt�gig oder stundenweise) im Einsatzbericht 
//  mit dem AZ-Kennzeichen "E" abgespeichert.
//
//--------------- V1.0.0020 --------------------------------------------------------------------------
//
// Date         : 11. J�nner 2007
// Author       : GN
// Defect#      : 4258,4267,4317
//
// Fehler in der Berechnung der Arbeitszeiten im TAP-Montage - Fehler wurde verursacht
// durch einen Wechsel des AZM von einem Monat auf den n�chsten und dem Versuch den
// 2. Monat zu genehmigen. Dabei wurde f�lschlicherweise bei der Rollung des Vormonats
// das neue AZM auf den alten Monat angewendet, wodurch das Programm selber bemerkte,
// dass etwas nicht stimmt und eine Fehlermeldung ausgab. Behoben wird der Fehler dadurch,
// dass bei der Berechnung der Arbeitszeiten des Vormonats nun das zugeh�rige AZM herangezogen wird.
//
//
// Date         : 19.J�nner 2007
// Author       : CG
// Defect#      : 4311, 4296
//                
// Auftrag nicht bebuchbar ... Fehler anzeigen, nur wenn  auch andere Werte vorbelegt sind
//
//--------------- V1.0.0001 --------------------------------------------------------------------------
//
// Date         : 20. Oktober 2006
// Author       : EW
// Defect#      : 3327
//
// Korrekte Berechnung der Arbeitszeiten (Ersatzruhe - Arbeit �ber Mitternacht)
//
// ---------------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{
    // CG - Defect#  : 5024, 5082#
    // Definition einer glob. Klasse f�r die STD Absenzen id
    // Diese ID sind Schl�ssel Attributen in der Tabelle Y_STDabsenz
    public static class STDAbsenzIDs
    {
        public const string Pflegefreistellung = "10";
        public const string Krank = "30";
        public const string Unfall = "40";
        public const string ArbeitsausfallBetrieblich = "60";
        public const string ArbeitsausfallAu�erbetr = "70";
        public const string Ersatzruhe = "90";
        public const string Sonstiges = "100";
        public const string Zeitausgleich = "110";
        public const string KVOption = "120";
    }
    // Ende Defect# 5024, 5082

    // Defect 4444
    public static class GTAbsenzIDs
    {
        public const string Ersatzruhe="10";
        public const string Gesch�ftlichAbwesend="20";
        public const string Karenzurlaub="30";
        public const string Pflegefreistellung="40";
        public const string Pr�senzdienst="50";
        public const string SonderurlaubAusland="60";
        public const string sonstigeAbwesenheit="70";
        public const string Truppen�bung="80";
        public const string Urlaub="90";
        public const string UrlaubEigeneKosten="100";
        public const string Wochenhilfe="110";
        public const string ZAganztaegig="120";
        public const string Paragraph8="130";
        public const string ArbeitsausfallBetrieblich="140";
        public const string ArbeitsausfallAu�erbetr="150";
        public const string Betriebsrat="160";
        public const string GestzlFreizeitKV="170";
        public const string Studienurlaub="180";
        public const string Jubil�umstag="190";
        public const string Sabbatical="200";
        public const string Krankheit="210";
        public const string KrankheitBeginn="212";
        public const string KrankheitEnde="214";
        public const string Unfall="220";
        public const string UnfallBeginn="222";
        public const string UnfallEnde="224";
        public const string FirmensonderurlaubBVI="226";
        public const string FeiertagimAusland="228";
        public const string Bildungsfreistellung="230";
    }
    // Ende Defect 4444
    public class dbArbTag : Page
    {
        public dbMontBer MBericht;
        public dbKG_Rabrech RabRech = null;
        public int Tag;
        public DateTime TagesDatum;
        public DateTime TagMin;
        public DateTime TagMax;
        private bool lPausenAbzug = true;
        public bool Relevanz = false;
        public bool RNG = false;  //defect 4972

        //wir ermittelen dann hier die reisetage un ihre baustelle (letzte BAUID des tages)
        public bool RNGReisetag = false;    //defect 5390 ist es ein tag auf dem eine reise passiert ?
        public int RNGBaust = -10;            //defect 5390 welche bauid 
        public bool RNGBaustWechsel = false;            //defect 5390 hat bauid tags�ber gewechselt ?

        public bool RNGkand = false;        // defect 5390 kann dieser tag reduziert werden ?

        public bool pauseBerechnen = true;

        public bool PausenAbzug
        {
            get
            {
                return lPausenAbzug;
            }
            set
            {
                lPausenAbzug = value;
            }
        }

        public enum ArbTagContent { ArbeitsZeiten = 0, ReiseZeiten = 1 };
        public ArbTagContent Contains = ArbTagContent.ArbeitsZeiten;

        /// <summary>
        /// int: Anzahl der nicht gel�schten Zeiten an diesem Tag
        /// </summary>
        public int AnzahlZeiten
        {
            get
            {
                if (lZeiten == null) return 0;
                int i = 0;
                foreach (dbArbZeit a in lZeiten)
                    if (!a.Deleted) i++;
                return i;
            }
        }
        /*public int AnzahlMBZeiten
        {
            get
            {
                if (MBZeiten == null) return 0;
                int i = 0;
                foreach (dbArbZeit a in MBZeiten)
                    if (!a.Deleted) i++;
                return i;
            }
        }
        public ArrayList MBZeiten
        {
            get
            {
                ArrayList al = new ArrayList();
                foreach (dbArbZeit az in Zeiten)
                    //if (((az.Params as dbAZ_ARBZEITParams) != null) && ((az.Params as dbAZ_ARBZEITParams).EBID.Value == MBericht.Params.EBID.Value))
                    if (((az.Params as dbAZ_ARBZEITParams) != null))
                        al.Add(az);
                return al;
            }
        }
*/
        /// <summary>
        /// Liefert die Uhrzeit f�r das n�chste Kommen nach der letzten nicht gel�schten Arbeitszeit des Tages
        /// </summary>
        public DateTime NextKommen
        {
            get
            {
                if (AnzahlZeiten == 0)
                {
                    dbArbZeit a = new dbArbZeit(this, dbArbZeit.ArbZeitType.produktiv, true);
                    return a.Kommen;
                }
                DateTime nk = DateTime.MinValue;
                foreach (dbArbZeit a in lZeiten)
                    if ((!a.Deleted)& (a.Gehen.Ticks > nk.Ticks)) nk = a.Gehen;
                return nk;
            }
        }

        private ArrayList lZeiten = null;
        /// <summary>
        /// enth�lt die liste der Arbeitszeiten des Tages, g�ltig sind nur jene, deren .Deleted == false
        /// </summary>
        public ArrayList Zeiten
        {
            get
            {
                if ((lZeiten == null) & (Tag > 0))
                {
                    Select();
                }
                return lZeiten;
            }
            set { lZeiten = value; }
        }
        /// <summary>
        /// enth�lt dieser Tag eine ganzt�gige Absenz (und sonst n�mlich nix!)
        /// </summary>
        public bool GTAbsenz
        {
            get
            {
                foreach (dbArbZeit z in Zeiten)
                {
                    if (z.ZeitTyp == dbArbZeit.ArbZeitType.gtAbsenz) return true;
                }
                return false;
            }
            
        }
        //defect 4972 ermitteln der absenz-id
        public int GTAbsenzID
        {

            get
            {
                int ret =-1;
                foreach (dbArbZeit z in Zeiten)
                    ret = z.GTAbsenzID;
                return (ret);
            } 
        }
        //ende defect 4972
        /// <summary>
        /// dbArbTag stellt eine Sammlung von Arbeitszeiteintr�gen usw zur Verf�gung
        /// </summary>
        /// <param name="MontBericht">Montagebericht mit Projekt und Bearbeiter</param>
        /// <param name="iTag">1..31</param>
        public dbArbTag(dbMontBer MontBericht, int iTag)
        {
            Contains = ArbTagContent.ArbeitsZeiten;
            MBericht = MontBericht;
            Tag = iTag;
            int subTag = 1;
            if (iTag == 0) subTag = 0; //wir wollen trotzdem den richtigen Monat
            TagesDatum = MBericht.MinDatum.AddDays(-subTag + iTag);
            TagMin = Convert.ToDateTime(TagesDatum.ToShortDateString() + " 00:00:00");
            TagMax = Convert.ToDateTime(TagesDatum.ToShortDateString() + " 23:59:59");
        }

        public dbArbTag(dbMontBer MontBericht, dbKG_Rabrech rabrech, int iTag)
        {
            Contains = ArbTagContent.ReiseZeiten;
            MBericht = MontBericht;
            RabRech = rabrech;
            Tag = iTag;
            int subTag = 1;
            if (iTag == 0) subTag = 0; //wir wollen trotzdem den richtigen Monat
            TagesDatum = MBericht.MinDatum.AddDays(-subTag + iTag);
            TagMin = Convert.ToDateTime(TagesDatum.ToShortDateString() + " 00:00:00");
            TagMax = Convert.ToDateTime(TagesDatum.ToShortDateString() + " 23:59:59");
        }

        /// <summary>
        /// returniert eine ArrayList von dbArbTag sortiert von 1 bis Monatsletzter
        /// </summary>
        /// <returns></returns>
        public ArrayList SelectMonat()
        {
            ArrayList al = new ArrayList();
            for (int i = 1; i <= MBericht.MaxDatum.Day; i++)
            {
                dbArbTag at;
                if (Contains == ArbTagContent.ArbeitsZeiten)
                    at = new dbArbTag(MBericht, i);
                else 
                    at = new dbArbTag(MBericht, RabRech, i);
                al.Add(at);
            }
            return al;
        }

        public void Select()
        {
            dbArbZeit az = new dbArbZeit(this, dbArbZeit.ArbZeitType.alle);
            lZeiten = az.SelectTag();
            if(pauseBerechnen)
                PauseBerechnen();
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren
        public void Save()
        {
            Save(null);
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        public void Save(SqlTransaction tx)
        {
            foreach (dbArbZeit az in Zeiten)
                if (az.istReisezeit == false)  // defect 5696 nur dann pr�fen, wenns nicht der sonderfall sonntag ist
                {
                    if ((az.Kommen == ParamVal.Date0) & (az.Gehen == ParamVal.Date0)) az.Deleted = true;
                }
                else
                {
                    az.Arbeitstag.Relevanz = true; // defect 5696 relevanz f�r den tag setzten, damit das zeug wirklich in der db landet...
                }
            foreach (dbArbZeit az in Zeiten) az.Save(tx);
        }

        /// <summary>
        /// Liefert die Summe der produktiven ARBZEIT.NORMSTD+UESTD50+UESTD100 dieses Tages, die auf den Montagebericht (this.MBericht) gebucht wurden
        /// enth�lt keine GK, keine Reisezeiten, keine STD-Absenzen
        /// summiert alle AZ mit EBID == MBericht.EBID oder EBID == 0
        /// </summary>
        public double SummeProduktiveStunden
        {
            get
            {
                double n = 0;
                foreach (dbArbZeit az in Zeiten)
                    if ((az.Params is dbAZ_ARBZEITParams) & (!az.Deleted))
                        if (((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MBericht.Params.EBID.Value) 
                            |((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == 0))
                            if (az.ZeitTyp == dbArbZeit.ArbZeitType.produktiv) n += az.NormStunden+az.UEStunden50+az.UEStunden100;
                return n;
            }
        }
        /// <summary>
        /// Liefert die Summe der produktiven ARBZEIT.NORMSTD+UESTD50+UESTD100 dieses Tages, die auf den Montagebericht (this.MBericht) gebucht wurden
        /// enth�lt keine GK, keine Reisezeiten, keine STD-Absenzen
        /// </summary>
        public double SummeProduktiveStundenAlleMBs
        {
            get
            {
                double n = 0;
                foreach (dbArbZeit az in Zeiten)
                    if ((az.Params is dbAZ_ARBZEITParams) & (!az.Deleted))
                        if (az.ZeitTyp == dbArbZeit.ArbZeitType.produktiv) n += az.NormStunden + az.UEStunden50 + az.UEStunden100;
                return n;
            }
        }
        /// <summary>
        /// Liefert die Summe der ARBZEIT.NORMSTD dieses Tages, die auf den Montagebericht (this.MBericht) gebucht wurden
        /// enth�lt GK, Produktiv und Reisezeiten, alle anderen == 0
        /// summiert alle AZ mit EBID == MBericht.EBID oder EBID == 0
        /// </summary>
        public double NormStd
        {
            get
            {
                double n = 0;
                foreach (dbArbZeit az in Zeiten)
                    if ((az.Params is dbAZ_ARBZEITParams) & (!az.Deleted))
                        if (((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MBericht.Params.EBID.Value)
                            | ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == 0)) n += az.NormStunden;
                return n;
            }
        }
        /// <summary>
        /// Liefert die Summe der ARBZEIT.NORMSTD dieses Tages, die auf den Montagebericht (this.MBericht) gebucht wurden
        /// enth�lt GK, Produktiv und Reisezeiten, alle anderen == 0
        /// </summary>
        public double NormStdAlleEBs
        {
            get
            {
                double n = 0;
                foreach (dbArbZeit az in Zeiten)
                    if ((az.Params is dbAZ_ARBZEITParams) & (!az.Deleted))
                        n += az.NormStunden;
                return n;
            }
        }
        /// <summary>
        /// Liefert die Summe der ARBZEIT.UESTD50 dieses Tages, die auf den Montagebericht (this.MBericht) gebucht wurden
        /// enth�lt GK, Produktiv und Reisezeiten, alle anderen == 0
        /// summiert alle AZ mit EBID == MBericht.EBID oder EBID == 0
        /// </summary>
        public double UEStunden50
        {
            get
            {
                double n = 0;
                foreach (dbArbZeit az in Zeiten)
                    if ((az.Params is dbAZ_ARBZEITParams) & (!az.Deleted))
                        if (((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MBericht.Params.EBID.Value)
                            | ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == 0)) n += az.UEStunden50;
                return n;
            }
        }
        /// <summary>
        /// Liefert die Summe der ARBZEIT.UESTD50 dieses Tages, die auf den Montagebericht (this.MBericht) gebucht wurden
        /// enth�lt GK, Produktiv und Reisezeiten, alle anderen == 0
        /// </summary>
        public double UEStunden50AlleEBs
        {
            get
            {
                double n = 0;
                foreach (dbArbZeit az in Zeiten)
                    if ((az.Params is dbAZ_ARBZEITParams) & (!az.Deleted))
                        n += az.UEStunden50;
                return n;
            }
        }
        /// <summary>
        /// Liefert die Summe der ARBZEIT.UESTD100 dieses Tages, die auf den Montagebericht (this.MBericht) gebucht wurden
        /// enth�lt GK, Produktiv und Reisezeiten, alle anderen == 0
        /// summiert alle AZ mit EBID == MBericht.EBID oder EBID == 0
        /// </summary>
        public double UEStunden100
        {
            get
            {
                double n = 0;
                foreach (dbArbZeit az in Zeiten)
                    if ((az.Params is dbAZ_ARBZEITParams) & (!az.Deleted))
                        if (((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)MBericht.Params.EBID.Value)
                            | ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == 0)) n += az.UEStunden100;
                return n;
            }
        }
        /// <summary>
        /// Liefert die Summe der ARBZEIT.UESTD100 dieses Tages, die auf den Montagebericht (this.MBericht) gebucht wurden
        /// enth�lt GK, Produktiv und Reisezeiten, alle anderen == 0
        /// summiert alle AZ mit EBID == MBericht.EBID oder EBID == 0
        /// </summary>
        public double UEStunden100AlleEBs
        {
            get
            {
                double n = 0;
                foreach (dbArbZeit az in Zeiten)
                    if ((az.Params is dbAZ_ARBZEITParams) & (!az.Deleted))
                        n += az.UEStunden100;
                return n;
            }
        }
        /// <summary>
        /// Wird nach diesem Arbeitstag noch gearbeitet (keine Einschr�nkung auf aktuellen MBericht)
        /// Der letzte Arbeitstag der Woche kann auch davor liegen
        /// <b>true:</b> wenn nach diesem Tag bis Sonntag nicht mehr gearbeitet wird
        /// <b>true:</b> am Sonntag
        /// <b>false:</b> wenn der letzte Arbeitstag des Monats in dieser Woche liegt und bis 
        /// zum ersten Sonntag des n�chsten Monats ein Arbeitstag (lt. AZ-Modell u. ALLG_...) folgt
        /// </summary>
        public bool IstLetzterArbeitstagDerWoche
        {
            get
            {
                int nDays = 0;
                int i = Tag - 1;
                for (i = Tag - 1; i < MBericht.Tage.Count; i++)
                {
                    if (((MBericht.Tage[i] as dbArbTag).Zeiten.Count > 0) && (((MBericht.Tage[i] as dbArbTag).Zeiten[0] as dbArbZeit).Params is dbAZ_ARBZEITParams)
                        && (((MBericht.Tage[i] as dbArbTag).Zeiten[0] as dbArbZeit).Kommen != ParamVal.Date0))
                        nDays++; //inc counter when working
                    if ((MBericht.Tage[i] as dbArbTag).TagesDatum.DayOfWeek == DayOfWeek.Sunday) break;
                }
                //Monatsende, pr�fe ob theoretisch noch Arbeitstage im Folgemonat kommen k�nnten
                if ((i == MBericht.Tage.Count) && (nDays <= 1) && ((MBericht.Tage[i-1] as dbArbTag).TagesDatum.DayOfWeek != DayOfWeek.Sunday))
                {
                    DateTime d = (MBericht.Tage[i-1] as dbArbTag).TagesDatum.AddDays(1); //datum des letzten Arbeitstag des Monats
                    while (d.DayOfWeek != DayOfWeek.Sunday)
                    {
                        if (MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(d))//BAF 530042 Beginn
                        {
                            if (MBericht.Bearbeiter.AZMKalenderTage[d].IstArbeitstag)
                                nDays++;
                        } //BAF 530042 Ende
                        else
                        {
                            if (MBericht.Bearbeiter.IstArbeitstag(d)) nDays++;
                        }
                        d = d.AddDays(1);
                    }
                }
                return (nDays <= 1);
            }
        }

        // Beginn #5322 - Projekt-AZM wird durch Mitarbeiter AZM �berschrieben
        // Beginn #4616, 4617, 4940 - AZ-Modell
        //TAPM-35 reference "gelesen" w�rde eingef�gt 
        // true .... AT ist g�ltig ... BAZ notfalls korrigieren
        // false ... AT ist Samstag, Sonntag oder Feiertag ... BAZ wird nicht korriegiert
        public void AZTag_Aktualizieren(ref dbAZTag maAzt, ref bool gelesen)
        {
            //string vPersNum = MBericht.Bearbeiter.Params.PERSNR.Value.ToString().Substring(2, 5);
            string vPersNum = MBericht.Bearbeiter.Params.PERSNR.Value.ToString().Substring(2, MBericht.Bearbeiter.Params.PERSNR.Value.ToString().Length-2);
            string vMAName = MBericht.Bearbeiter.Params.NACHNAME.Value.ToString();
            string vMAVorame = MBericht.Bearbeiter.Params.VORNAME.Value.ToString();
            string vTag = TagesDatum.ToString("yyyy-MM-dd");
            string vProjId = MBericht.Projekt.Params.PROJID.Value.ToString();
            //bool AZM_Found_For_Project = false;

            if (vTag != "1900-01-01")
            {

                /* Defect 4665 5337
                 * GN 10.8.2007
                 * Mitarbeiterarbeitszeitmodell wurde f�lschlicherweise vom Projektarbeitszeitmodell �berschrieben
                 * 
                using (SqlConnection SissiConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    SissiConnection.Open();

                    string SissiSqlCommandText = "SELECT VON AS AZ_Begin, BIS AS AZ_Ende, (DATEDIFF(mi , VON , BIS) / 60.0) AS AZ_SollarbeitStd" +
                        " FROM BAUPROJEKT_AZMODELL WHERE PROJAZMID = '" + vProjId + "' AND TAG = (DATEPART(w , '" + vTag + "') -1)";

                    SqlCommand SissiSqlCommand = new SqlCommand(SissiSqlCommandText, SissiConnection);
                    SqlDataReader SissiReader = SissiSqlCommand.ExecuteReader();
                    while (SissiReader.Read())
                    {
                        try
                        {
                            if (
                                   (Convert.ToDateTime(SissiReader.GetValue(0).ToString()).Hour == 0)
                                   && (Convert.ToDateTime(SissiReader.GetValue(0).ToString()).Minute == 0)
                                   && (Convert.ToDateTime(SissiReader.GetValue(1).ToString()).Hour == 0)
                                   && (Convert.ToDateTime(SissiReader.GetValue(1).ToString()).Minute == 0)
                                )
                            {
                                AZM_Found_For_Project = false;
                            }
                            else
                            {
                                DateTime fromTime = Convert.ToDateTime(SissiReader.GetValue(0).ToString());
                                DateTime toTime = Convert.ToDateTime(SissiReader.GetValue(1).ToString());

                                /* Zeiten aktualisieren 

                                maAzt.Params.AZ_Begin.Value = fromTime;
                                maAzt.Params.AZ_Ende.Value = toTime;

                                AZM_Found_For_Project = true;
                            }
                        }
                        catch
                        {
                            AZM_Found_For_Project = false;
                        }
                    }
                    SissiReader.Close();
                    SissiConnection.Close();

                }*/

                //if (!AZM_Found_For_Project)
                {
                    using (SqlConnection AZMConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                    {
                        /* Aktuelle AZModell - Werte lesen */
                        AZMConnection.Open();

                        // Defect 5725, Config.Rowlock eingef�hrt
                        // Defect 5771, Config.Nolock eingef�hrt
                        // Beginn #5320 - Auf bereits erfasste EBs kann nicht mehr zugegriffen werden
                        string AZMSqlCommandText = "SELECT AZ_Begin, AZ_Ende, AZ_SollarbeitStd FROM AZ_Tag " + Config.Nolock +
                                                   " WHERE AZ_Modell_Nummer = (" +
                                                   " SELECT AZ_Modell_Nummer FROM MA_AZ_Modell " + Config.Nolock +
                                                   " WHERE (MA_AZ_g�ltig_von <= '" + vTag + "') AND (MA_AZ_g�ltig_bis >= '" + vTag + "') AND (MA_PersNummer = '" + vPersNum +
                                                   "') AND (MA_FKN = (SELECT MA_FKN FROM MA_Stamm " + Config.Nolock + " WHERE MA_PersNummer = '" + vPersNum + "' AND MA_Name = '" + vMAName + "' AND MA_Vorname = '" + vMAVorame + "'))" +
                                                   " ) AND AZ_Wochentag = DATEPART(w , '" + vTag + "')  ";
                        // Ende #5320

                        using (SqlCommand AZMSqlCommand = new SqlCommand(AZMSqlCommandText, AZMConnection)) // Defect 5436, using eingef�hrt
                        {
                          using (SqlDataReader AZMReader = AZMSqlCommand.ExecuteReader()) // Defect 5436
                          {
                            while (AZMReader.Read())
                            {
                              try
                              {
                                DateTime fromTime = Convert.ToDateTime(AZMReader.GetValue(0).ToString());
                                DateTime toTime = Convert.ToDateTime(AZMReader.GetValue(1).ToString());

                                /* Zeiten aktualisieren */

                                maAzt.Params.AZ_Begin.Value = fromTime;
                                maAzt.Params.AZ_Ende.Value = toTime;
                                gelesen = true;
                              }
                              catch { }
                            }
                            AZMReader.Close();
                            AZMConnection.Close();
                          }
                        }
                    }
                }
            }
        }
        // Ende #4616, 4617, 4940 
        // Ende #5322
        /// <summary>
        /// Berechnet nach 6 Stunden Arbeit eine Pause, aliquot bis zu 30 Minuten
        /// </summary>
        public void PauseBerechnen()
        {
            // Beginn #5690 1.Teil
            if (this.Tag == 1)
            {
                Session["tempStd"] = 0.0;
                Session["tempPause"] = 0.0;
                Session["tempGehen"] = new DateTime(0);
            }
            DateTime tempGehen = new DateTime(0);
            try
            {
                tempGehen = (DateTime)Session["tempGehen"];
            }
            catch { }
            // Ende #5690 1.Teil

            //TAPM-35 neu Variablen welche notwendig sind falls BAZ korrigiert werden soll
            bool aztag_gelesen = false;
            bool a100_valid = true;
            bool a50_valid = true;
            bool e50_valid = true;


            if (!lPausenAbzug) return;
            dbMandantAZModellTag azt = (dbMandantAZModellTag)MBericht.Bearbeiter.Mandant.AZModell.Tage[(int)TagesDatum.DayOfWeek];
            //BAF 530042 Beginn
            DateTime AZ_Begin = ParamVal.Date0;
            DateTime AZ_Ende = ParamVal.Date0;

            if (MBericht.Bearbeiter.BerichtsMonat == 0) MBericht.Bearbeiter.BerichtsMonat = MBericht.BerichtsMonat;
            if(MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(TagesDatum))
            {
                AZ_Begin = MBericht.Bearbeiter.AZMKalenderTage[TagesDatum].AZ_Begin;
                AZ_Ende = MBericht.Bearbeiter.AZMKalenderTage[TagesDatum].AZ_Ende;
                if( AZ_Begin != ParamVal.Date0 )
                    aztag_gelesen = true;
                if (MBericht.Bearbeiter.AZMKalenderTage[TagesDatum].IstFeiertag && 
                    !MBericht.Bearbeiter.AZMKalenderTage[TagesDatum].IstFenstertag)
                {
                    azt = (dbMandantAZModellTag)MBericht.Bearbeiter.Mandant.AZModell.Tage[0];
                    AZ_Begin = ParamVal.Date0; //wie Sonntag
                    AZ_Ende = ParamVal.Date0;
                    aztag_gelesen = false;
                }
            }//BAF 530042 Ende
            else
            {
                // Beginn #5643 1.Teil
                if (MBericht.Bearbeiter.IstFeiertag(TagesDatum) & !MBericht.Bearbeiter.IstFenstertag(TagesDatum))
                    azt = (dbMandantAZModellTag)MBericht.Bearbeiter.Mandant.AZModell.Tage[0]; //wie Sonntag
                // Ende #5643 1.Teil

                //dbAZTag maAzt = (dbAZTag)MBericht.Bearbeiter.AZModell.AZTage[(int)TagesDatum.DayOfWeek];
                // Beginn #4616, 4617, 4940 - AZ-Modell    
                dbAZTag maAzt = (dbAZTag)MBericht.Bearbeiter.AZModell.AZTage[(int)TagesDatum.DayOfWeek];
                AZTag_Aktualizieren(ref maAzt, ref aztag_gelesen);
                // Ende #4616, 4617, 4940

                // Beginn #5643 2.Teil
                if (MBericht.Bearbeiter.IstFeiertag(TagesDatum) & !MBericht.Bearbeiter.IstFenstertag(TagesDatum))
                    maAzt = (dbAZTag)MBericht.Bearbeiter.AZModell.AZTage[0]; //wie Sonntag
                // Ende #5643 2.Teil
                AZ_Begin = Convert.ToDateTime(maAzt.Params.AZ_Begin.Value);
                AZ_Ende = Convert.ToDateTime(maAzt.Params.AZ_Ende.Value);
            }
            DateTime a100 = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100BEG1.Value).ToShortTimeString());
            DateTime a50 = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50BEG1.Value).ToShortTimeString());
            //DateTime aNorm = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(maAzt.Params.AZ_Begin.Value).ToShortTimeString());
            //DateTime eNorm = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(maAzt.Params.AZ_Ende.Value).ToShortTimeString());
            DateTime aNorm = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + AZ_Begin.ToShortTimeString());
            DateTime eNorm = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + AZ_Ende.ToShortTimeString());

            //Wenn Problemm mit AZM weiterhin besteht - useBAZ
            bool useBAZ = false;
            try
            {
                if (ConfigurationManager.AppSettings["useBAZ"] == "true")
                    useBAZ = true;
                string strSozStell = MBericht.Bearbeiter.TechParams.SOZSTELL.Value.ToString();
                if (useBAZ && (strSozStell == "6" || strSozStell == "7"))
                {
                    aNorm = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.NAZBEG.Value).ToShortTimeString());
                    eNorm = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.NAZEND.Value).ToShortTimeString());
                }
            }
            catch
            {
                // bleibt false
            }
            //Ende useBAZ
            DateTime e50 = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50END2.Value).ToShortTimeString());
            if (Convert.ToDateTime(azt.Params.UESTD50END2.Value).Ticks == ParamVal.Date0.Ticks)
                e50 = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50END1.Value).ToShortTimeString());
            DateTime e100 = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100END2.Value).ToShortTimeString());
            if (Convert.ToDateTime(azt.Params.UESTD100END2.Value).Ticks == ParamVal.Date0.Ticks)
                e100 = Convert.ToDateTime(TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100END1.Value).ToShortTimeString());
            e100 = e100.AddDays(1);

            //TAPM-35 "TAPM35" ... falls was schief gehen sollte, die �berpr�fung kann im WebConfig ausgeschaltet werden
            try
            {
                if (ConfigurationManager.AppSettings["TAPM35"] == "true" && aztag_gelesen)
                {
                    //TAPM-35 a100 ist immer Mitternacht, falls AZ um Mitternacht beginnt, dann ist a100 invalid
                    if (aNorm == a100)
                    {
                        a100_valid = false; // es gibt dann keine a100 �bertunden
                        a50_valid = false; // theoretisch gibt es auch keine a50 Stunden
                    }
                    //TAPM-35 AZ beginnt zwischen 00:00 und 06:00 (vom a50)
                    if (aNorm > a100 && aNorm <= a50)
                    {
                        a50 = aNorm; // TAPM-35 wegen Berechnung der a100 Stunden
                        a50_valid = false; // Es gibt keine a50 Stunden
                    }
                    //TAPM-35 AZ endet nach e50, also e50 ist invalid
                    if (eNorm >= e50)
                    {
                        e50_valid = false;
                        e50 = eNorm; //TAP-35 aktualisiere e50 wegen Berechnung der e100 Stunden
                    }
                    //TAPM-35 Abfrage ob eNorm == e100 ist nicht notwendig, weil bei AZM der Tag �ndert 23:59:59 und nicht um 00:00
                }
            }
            catch
            {
                //do nothing
            }

            double sStd = 0;
            double sStdvorher = 0;
            // double sAbzug = 0; // #defect 5833 sAbzug ist nicht mehr notwendig
            // int AZZeilenr = 0;                                                          // Defect 4164 Z�hler der abgearbeiteten Arbeitszeitzeilen
            double ErrechnetePause = 0;                                                     // Defect 4164 kummulierte Pausendauer
            foreach (dbArbZeit az in Zeiten)
                if (az.Params is dbAZ_ARBZEITParams)
                {
                    // Defect 5620 Begin, stundenweise Absenz ZA nicht ber�cksichtigen
                    //AZZeilenr += 1;                                                      // Defect 4164: alle AZ - zeilen untersuchen
                    if (az.STDAbsenzID.Equals(STDAbsenzIDs.Zeitausgleich))
                    {
                        continue;
                    }
                    // Defect 5620 Ende
                    // Berechnung der Summen: NormStd, 50%-�berstunden, 100% -�berstunden
                    az.CalcWorktime();
                    //
                    // Beginn #5690 2.Teil
                    try
                    {
                        tempGehen = (DateTime)Session["tempGehen"];
                    }
                    catch
                    {
                        tempGehen = new DateTime(0);
                    }

                    if (!az.Kommen.Equals(ParamVal.Date0) &&
                        (az.Kommen == tempGehen))
                    {
                        sStd = (double)Session["tempStd"];
                        ErrechnetePause = (double)Session["tempPause"];
                    }
                    else
                    {
                        // hier sollte noch gepr�ft werden ob Zeit zwischen komme und letztes gehen
                        // doch eine Reise zwischen 2 T�tigkeiten, leider zu dem Zeitpunkt haben wir
                        // keine Angaben �ber die Reisen :-( somit fangen von neu an
                        // sAbzug = 0; nicht mehr notwendig
                        sStd = 0;
                        ErrechnetePause = 0;
                        Session["tempStd"] = 0.0;
                        Session["tempPause"] = 0.0;
                    }
                    // Ende #5690 2.Teil

                    sStdvorher = sStd;
                    sStd += (az.NormStunden + az.UEStunden100 + az.UEStunden50);
                    // ErrechnetePause += sAbzug;   #defect 5833 sAbzug ist nicht mehr notwendig                                               // Defect 4164                                   
                    // #defect 5833 isNotZASTDAbsenz wird auch nicht mehr gebraucht
                    // bool isNotZASTDAbsenz = ((az.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz) && (!STDAbsenzIDs.Zeitausgleich.Equals(az.STDAbsenzID)))||
                    //                         (az.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz);

                    // sAbzug = 0; #defect 5833 nicht mehr notwendig
                    if ((sStd > 6) & (ErrechnetePause * 60 < 30) & !az.Gehen.Equals(ParamVal.Date0))// & isNotZASTDAbsenz) //Defect 4164: pausendauer
                    {
                        // Pausen berechnen und die Summen verteilen
                        DateTime dtPause = az.Kommen.AddHours(6 - sStdvorher);
                        int PauseVerfuegbar = 30 - Convert.ToInt32(ErrechnetePause * 60);        // 0 Min. <=PauseVerfuegbar <= 30 Min.
                        TimeSpan tsPause = new TimeSpan(Math.Min(new TimeSpan(0, PauseVerfuegbar, 0).Ticks, az.Gehen.Ticks - dtPause.Ticks));
                        // sAbzug = tsPause.TotalHours; defect #5833 sAbzug ist nicht mehr notwendig
                        // az.Pause = sAbzug; defect #5833 sAbzug ist nicht mehr notwendig
                        az.Pause = tsPause.TotalHours; // #defect 5833 anstatt von die 2 Zeilen von oben
                        //TAPM-20 - bei Bereitschaft die PAuse soll von 100% �S abgezogen
                        bool istBereitschaft = false;
                        try
                        {
                            istBereitschaft = ((az.Params as dbAZ_ARBZEITParams).BEREIT.Value.ToString() == "1");
                        }
                        catch
                        { }
                        // Beginn #5690 3.Teil
                        if ((a100.ToShortTimeString() == "00:00" & e100.ToShortTimeString() == "00:00" &
                            a50.ToShortTimeString() == "00:00" & e50.ToShortTimeString() == "00:00") ||
                            istBereitschaft)
                        {
                            // Feiertag oder Sonntag
                            TimeSpan ts = new TimeSpan(az.Gehen.Ticks - dtPause.Ticks);
                            az.UEStunden100 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                            tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                            // if (((AZZeilenr >= Zeiten.Count) & tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                            //if (tsPause.TotalMinutes == 0) break;                                  // Defect 4164: alle AZ - zeilen untersuchen
                        }
                        else
                        {
                            TimeSpan ts = new TimeSpan(a50.Ticks - dtPause.Ticks);                  // 00:00 < Arbeitszeit 
                            if (ts.TotalHours > 0 && a100_valid)
                            {
                                //
                                // UESTD50BEG1 > Kommen Arbeit + 6 Std, z.Bsp. Nachtarbeit
                                // Pause f�llt in 100%-Uebstundenfenster
                                //
                                az.UEStunden100 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                // if ((AZZeilenr >= Zeiten.Count) & (tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen

                            }
                            ts = new TimeSpan(aNorm.Ticks - dtPause.Ticks);
                            if (ts.TotalHours > 0 && a50_valid)
                            {
                                az.UEStunden50 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                // if ((AZZeilenr >= Zeiten.Count) & (tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen

                            }
                            ts = new TimeSpan(eNorm.Ticks - dtPause.Ticks);
                            if (ts.TotalHours > 0)
                            {
                                //BAF 530042 Beginn
                                if(MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(az.Kommen.Date))
                                {
                                    if (MBericht.Bearbeiter.AZMKalenderTage[az.Kommen.Date].IstFeiertag &&
                                        !MBericht.Bearbeiter.AZMKalenderTage[az.Kommen.Date].IstFenstertag)
                                    {
                                        az.UEStunden100 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                        tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                        // if ((AZZeilenr >= Zeiten.Count) & (tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                        //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen
                                    }
                                    else
                                    {
                                        az.NormStunden -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                        tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                        // if ((AZZeilenr >= Zeiten.Count) & (tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                        //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen
                                    }
                                }//BAF 530042 Ende
                                else
                                {
                                    if (MBericht.Bearbeiter.IstFeiertag(az.Kommen) & !MBericht.Bearbeiter.IstFenstertag(az.Kommen))
                                    {
                                        az.UEStunden100 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                        tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                        // if ((AZZeilenr >= Zeiten.Count) & (tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                        //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen
                                    }
                                    else
                                    {
                                        az.NormStunden -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                        tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                        // if ((AZZeilenr >= Zeiten.Count) & (tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                        //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen
                                    }

                                }
                            }
                            ts = new TimeSpan(e50.Ticks - dtPause.Ticks);
                            if (ts.TotalHours > 0 && e50_valid)
                            {
                                //BAF 530042 Beginn
                                if(MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(az.Kommen.Date))
                                {
                                    if (MBericht.Bearbeiter.AZMKalenderTage[az.Kommen.Date].IstFeiertag &&
                                        !MBericht.Bearbeiter.AZMKalenderTage[az.Kommen.Date].IstFenstertag)
                                    {
                                        az.UEStunden100 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                        tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                        // if (((AZZeilenr >= Zeiten.Count) & tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                        //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen
                                    }
                                    else
                                    {
                                        az.UEStunden50 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                        tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                        // if (((AZZeilenr >= Zeiten.Count) & tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                        //if (tsPause.TotalMinutes == 0) break;                                  // Defect 4164: alle AZ - zeilen untersuchen
                                    }
                                }//BAF 530042 Ende
                                else
                                {
                                    if (MBericht.Bearbeiter.IstFeiertag(az.Kommen) & !MBericht.Bearbeiter.IstFenstertag(az.Kommen))
                                    {
                                        az.UEStunden100 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                        tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                        // if (((AZZeilenr >= Zeiten.Count) & tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                        //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen
                                    }
                                    else
                                    {
                                        az.UEStunden50 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                        tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                        // if (((AZZeilenr >= Zeiten.Count) & tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                        //if (tsPause.TotalMinutes == 0) break;                                  // Defect 4164: alle AZ - zeilen untersuchen
                                    }
                                }
                            }
                            ts = new TimeSpan(a100.Ticks - dtPause.Ticks);
                            if (ts.TotalHours > 0)
                            {
                                az.UEStunden100 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                // if (((AZZeilenr >= Zeiten.Count) & tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                                //if (tsPause.TotalMinutes == 0) break;                                 // Defect 4164: alle AZ - zeilen untersuchen

                            }
                            ts = new TimeSpan(e100.Ticks - dtPause.Ticks);
                            if (ts.TotalHours > 0)
                            {
                                az.UEStunden100 -= Math.Min(ts.TotalHours, tsPause.TotalHours);
                                tsPause = new TimeSpan(tsPause.Ticks - Math.Min(ts.Ticks, tsPause.Ticks));
                                //if (((AZZeilenr >= Zeiten.Count) & tsPause.TotalMinutes == 0)) break;   // Defect 4164, Zeilencounter dazu addiert
                            }
                        }
                    }
                    if (!az.Kommen.Equals(ParamVal.Date0)) //ToShortDateString() != "01.01.1900")
                    {
                        Session["tempStd"] = sStd;
                        Session["tempPause"] = ErrechnetePause + az.Pause; // defect #5833 die ErrechnetePause auch mitziehen
                        Session["tempGehen"] = az.Gehen;

                    }
                    else
                    {
                        Session["tempStd"] = 0.0;
                        Session["tempPause"] = 0.0;
                        Session["tempGehen"] = new DateTime(0); ;
                    }
                    // Ende #5690 3.Teil

                    // if (sStd > 6.5) break;                   // Defect 4164
                    // if (ErrechnetePause*60 > 30) break;        // Defect 4164
                }
        }
    }

    public class dbAZ_ARBZEITParams
    {
        public SqlParameter AZID = new SqlParameter("@AZID", int.MinValue); //
        public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string) ""  ); //Mandant des Monteurs
        public SqlParameter EBID = new SqlParameter("@EBID", int.MinValue);  // aus EB
        public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", int.MinValue); //Perskey von Monteur
        public SqlParameter DATUM = new SqlParameter("@DATUM", ParamVal.Date0); //
        public SqlParameter BEGINN = new SqlParameter("@BEGINN", ParamVal.Date0);
        public SqlParameter ENDE = new SqlParameter("@ENDE", ParamVal.Date0);
        public SqlParameter AZUMMOKZ = new SqlParameter("@AZUMMOKZ", int.MinValue); //not NULL !!!
        public SqlParameter AZUMABKZ = new SqlParameter("@AZUMABKZ", int.MinValue); //not NULL !!!
        public SqlParameter KZAZGUELTIG = new SqlParameter("@KZAZGUELTIG", int.MinValue); 
        public SqlParameter PAUSE = new SqlParameter("@PAUSE", Int16.MinValue);
        public SqlParameter NORMSTD = new SqlParameter("@NORMSTD", Int16.MinValue);
        public SqlParameter UESTD50 = new SqlParameter("@UESTD50", Int16.MinValue);
        public SqlParameter UESTD100 = new SqlParameter("@UESTD100", Int16.MinValue);
        public SqlParameter KZAZ = new SqlParameter("@KZAZ", (string) "" ); //not NULL !!!
        public SqlParameter STDABSENZID = new SqlParameter("@STDABSENZID", Int16.MinValue);
        public SqlParameter BEMERKUNG = new SqlParameter("@BEMERKUNG", (string) ""  );
        public SqlParameter KMLOHNART = new SqlParameter("@KMLOHNART", (string) ""  );
        public SqlParameter KM = new SqlParameter("@KM", int.MinValue); 
        public SqlParameter KMKZSG = new SqlParameter("@KMKZSG", int.MinValue); 
        public SqlParameter AUFTRNR = new SqlParameter("@AUFTRNR", (string) ""  );
        public SqlParameter SUBNR = new SqlParameter("@SUBNR", (string) ""  );// leer
        public SqlParameter KZTA = new SqlParameter("@KZTA", (string) ""  ); //?
        public SqlParameter CODE = new SqlParameter("@CODE", (string) ""  );//leer
        public SqlParameter KZVA = new SqlParameter("@KZVA", (string) ""  );//leer
        public SqlParameter BELEGNR = new SqlParameter("@BELEGNR", int.MinValue);//RAID! bei R und W sonst null
        public SqlParameter DATLA = new SqlParameter("@DATLA", ParamVal.Date0);
        public SqlParameter AENPERSKEY = new SqlParameter("@AENPERSKEY", int.MinValue); 
        public SqlParameter DATNEU = new SqlParameter("@DATNEU", ParamVal.Date0);
        public SqlParameter KZVK = new SqlParameter("@KZVK", (string) ""  );// ?
        public SqlParameter ZNR = new SqlParameter("@ZNR", Int16.MinValue);// ?? 
        public SqlParameter DATUGORK = new SqlParameter("@DATUGORK", ParamVal.Date0);
        public SqlParameter DATUGEOS = new SqlParameter("@DATUGEOS", ParamVal.Date0);
        public SqlParameter MA_BEGINN = new SqlParameter("@MA_BEGINN", ParamVal.Date0);
        public SqlParameter MA_ENDE = new SqlParameter("@MA_ENDE", ParamVal.Date0);
        public SqlParameter MA_STD = new SqlParameter("@MA_STD", Int16.MinValue);
        public SqlParameter MA_PAUSE = new SqlParameter("@MA_PAUSE", Int16.MinValue);
        public SqlParameter DATUGBEMO = new SqlParameter("@DATUGBEMO", ParamVal.Date0);
        public SqlParameter FLDTXT1 = new SqlParameter("@FLDTXT1", (string) ""  );
        public SqlParameter FLDTXT2 = new SqlParameter("@FLDTXT2", (string) ""  );
        public SqlParameter LEISTART = new SqlParameter("@LEISTART", (string) ""  );
        public SqlParameter BEREIT = new SqlParameter("@BEREIT", (string) ""  );
        public SqlParameter FLDTXT3 = new SqlParameter("@FLDTXT3", (string) ""  );
        public SqlParameter DATUGKORAM = new SqlParameter("@DATUGKORAM", ParamVal.Date0);
        public SqlParameter DATUGRUECKM = new SqlParameter("@DATUGRUECKM", ParamVal.Date0);
        public SqlParameter EQUIPMENTNR = new SqlParameter("@EQUIPMENTNR", (string) ""  );
        public SqlParameter INTF_ID = new SqlParameter("@INTF_ID", Int16.MinValue);
        public SqlParameter PORTFOLIO = new SqlParameter("@PORTFOLIO", (string)"");
        public ArrayList List = new ArrayList();
        
        public dbAZ_ARBZEITParams()
        {
            List.Add(AZID);
            List.Add(MANDANT);
            List.Add(EBID);
            List.Add(PERSKEY);
            List.Add(DATUM);
            List.Add(BEGINN);
            List.Add(ENDE);
            List.Add(AZUMMOKZ);
            List.Add(AZUMABKZ);
            List.Add(KZAZGUELTIG);
            List.Add(PAUSE);
            List.Add(NORMSTD);
            List.Add(UESTD50);
            List.Add(UESTD100);
            List.Add(KZAZ);
            List.Add(STDABSENZID);
            List.Add(BEMERKUNG);
            List.Add(KMLOHNART);
            List.Add(KM);
            List.Add(KMKZSG);
            List.Add(AUFTRNR);
            List.Add(SUBNR);
            List.Add(KZTA);
            List.Add(CODE);
            List.Add(KZVA);
            List.Add(BELEGNR);
            List.Add(DATLA);
            List.Add(AENPERSKEY);
            List.Add(DATNEU);
            List.Add(KZVK);
            List.Add(ZNR);
            List.Add(DATUGORK);
            List.Add(DATUGEOS);
            List.Add(MA_BEGINN);
            List.Add(MA_ENDE);
            List.Add(MA_STD);
            List.Add(MA_PAUSE);
            List.Add(DATUGBEMO);
            List.Add(FLDTXT1);
            List.Add(FLDTXT2);
            List.Add(LEISTART);
            List.Add(BEREIT);
            List.Add(FLDTXT3);
            List.Add(DATUGKORAM);
            List.Add(DATUGRUECKM);
            List.Add(EQUIPMENTNR);
            List.Add(INTF_ID);
            List.Add(PORTFOLIO);
            ParamVal.SetDefaultValues(List);
        }
    }

    public class dbAZ_KALTAGParams
    {
        public SqlParameter DATUM  = new SqlParameter("@DATUM",ParamVal.Date0);
        public SqlParameter PERSKEY  = new SqlParameter("@PERSKEY",int.MinValue);
        public SqlParameter ABGABEKZ  = new SqlParameter("@ABGABEKZ",int.MinValue);
        public SqlParameter MLMOKZ  = new SqlParameter("@MLMOKZ",int.MinValue);
        public SqlParameter MLABKZ  = new SqlParameter("@MLABKZ",int.MinValue);
        public SqlParameter GTABSENZID  = new SqlParameter("@GTABSENZID",Int16.MinValue);
        public SqlParameter GTAZMNR = new SqlParameter("@GTAZMNR", Int16.MinValue);
        public SqlParameter DATABGLKZ = new SqlParameter("@DATABGLKZ", (string)"");
        public SqlParameter DATLASRV  = new SqlParameter("@DATLASRV", ParamVal.Date0);
        public SqlParameter DATLA  = new SqlParameter("@DATLA",ParamVal.Date0);
        public SqlParameter AENPERSKEY  = new SqlParameter("@AENPERSKEY",int.MinValue);
        public SqlParameter DATNEU  = new SqlParameter("@DATNEU",ParamVal.Date0);
        public SqlParameter GTABSENZTXT = new SqlParameter("@GTABSENZTXT", (string)"");
        public SqlParameter EBID = new SqlParameter("@EBID", int.MinValue);  // aus EB
        public ArrayList List = new ArrayList();

        public dbAZ_KALTAGParams()
        {
            List.Add(DATUM);
            List.Add(PERSKEY);
            List.Add(ABGABEKZ);
            List.Add(MLMOKZ);
            List.Add(MLABKZ);
            List.Add(GTABSENZID);
            List.Add(GTAZMNR);
            List.Add(DATABGLKZ);
            List.Add(DATLASRV);
            List.Add(DATLA);
            List.Add(AENPERSKEY);
            List.Add(DATNEU);
            List.Add(GTABSENZTXT);
            List.Add(EBID);
            ParamVal.SetDefaultValues(List);
        }
    }

    /// <summary>
    /// Sortiert dbArbZeit-objekte in einer ArrayList nach SortByEnum.Kommen oder SortByEnum.Gehen
    /// </summary>
    public class dbArbZeitSort : IComparer
    {
        public enum SortByEnum { Kommen, Gehen };
        private SortByEnum SortBy;
        public dbArbZeitSort(SortByEnum SortByWhat)
        {
            SortBy = SortByWhat;
        }

        int IComparer.Compare(object o1, object o2)
        {
            dbArbZeit a1 = (dbArbZeit)o1;
            dbArbZeit a2 = (dbArbZeit)o2;
            if (SortBy == SortByEnum.Kommen)
                if (Convert.ToDateTime(a1.Kommen).CompareTo(Convert.ToDateTime(a2.Kommen)) != 0)
                    return Convert.ToDateTime(a1.Kommen).CompareTo(Convert.ToDateTime(a2.Kommen));
                else
                    return Convert.ToDateTime(a1.Gehen).CompareTo(Convert.ToDateTime(a2.Gehen));
            else
                if (Convert.ToDateTime(a1.Gehen).CompareTo(Convert.ToDateTime(a2.Gehen)) != 0)
                    return Convert.ToDateTime(a1.Gehen).CompareTo(Convert.ToDateTime(a2.Gehen));
                else
                    return Convert.ToDateTime(a1.Kommen).CompareTo(Convert.ToDateTime(a2.Kommen));
        }
    }
    /// <summary>
    /// Arbeitszeiten
    /// </summary>
    // Defect 4936, Ableitung erg�nzt um Sessionvariablen verwenden zu k�nnen
  //public class dbArbZeit
    public class dbArbZeit : System.Web.UI.Page
    {
        /* Vorbereiten f�rs LOadFromEBNew
        public enum ReisenVorherNacher
        {
            keine = 0,
            hinreise,
            rueckreise,
            standortwechsel,
        }
        public ReisenVorherNacher reiseVorher = ReisenVorherNacher.keine;
        public ReisenVorherNacher reiseNacher = ReisenVorherNacher.keine;
        public int reiseZeit = 0;
         */
        //public bool Bereitschaft = false; //TAPM-20 - Rufbereitschaft per default auf false setzten
        public bool AllowUpdate = false;
        public bool Deleted = false;
        public bool istReisezeit = false;  // defect 5696

        public enum ArbZeitType { produktiv = 0, gk = 1, stdAbsenz = 2, gtAbsenz = 3, alle = 4, ReiseInDienstzeit = 5, ReiseVorherNachher = 6}

        // Beginn Defect #4520: Znr wird in Tabelle Arbzeit gespeichert
        private Int32 lintZnr = 0;
        public Int32 intZnr
        {
            get { return lintZnr; }
            set
            {
                lintZnr = value;
            }
        }
        // Ende Defect #4520
        private ArbZeitType lZeitTyp;
        public ArbZeitType ZeitTyp
        {
            get { return lZeitTyp; }
            set
            {
                lZeitTyp = value;
                if ((ZeitTyp == ArbZeitType.gtAbsenz) & ((Params as dbAZ_KALTAGParams) == null))
                {
                    Params = new dbAZ_KALTAGParams();
                }
                if ((ZeitTyp != ArbZeitType.gtAbsenz) & ((Params as dbAZ_ARBZEITParams) == null))
                {
                     Params = new dbAZ_ARBZEITParams();
                    (Params as dbAZ_ARBZEITParams).KZAZ.Value = "A";
                    if (ZeitTyp == ArbZeitType.ReiseInDienstzeit) (Params as dbAZ_ARBZEITParams).KZAZ.Value = "W"; //nur f�r AZM interessant Reisezeit = Arbeitszeit
                    if (ZeitTyp == ArbZeitType.ReiseVorherNachher) (Params as dbAZ_ARBZEITParams).KZAZ.Value = "R"; //nur f�r TRM interessant, muss verrechnet werden, Reisender bkommt �ber TRM Boni ausbezahlt
                    if (ZeitTyp != ArbZeitType.gk) (Params as dbAZ_ARBZEITParams).AUFTRNR.Value = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString();
                }
                /*
                if (lZeitTyp == ArbZeitType.stdAbsenz)
                {
                    (Params as dbAZ_ARBZEITParams).AUFTRNR.Value = "AUFTRNR";
                }
                 */
            }
        }
        public object Params;
        public dbArbTag Arbeitstag;

        public dbArbZeit(dbArbTag ArbeitsTag, ArbZeitType UrlaubKrankAnwesendProduktiv, bool Vorbelegt)
        {
            doConstruct(ArbeitsTag, UrlaubKrankAnwesendProduktiv, Vorbelegt);
        }
        public dbArbZeit(dbArbTag ArbeitsTag, ArbZeitType UrlaubKrankAnwesendProduktiv)
        {
            doConstruct(ArbeitsTag, UrlaubKrankAnwesendProduktiv, false);
        }

        private void doConstruct(dbArbTag ArbeitsTag, ArbZeitType UrlaubKrankAnwesendProduktiv, bool Vorbelegt)
        {
            Arbeitstag = ArbeitsTag;
            ZeitTyp = UrlaubKrankAnwesendProduktiv;
            if (Vorbelegt)
                SetStandardWorkTime();
            intZnr = 0; // Defect #4520
        }

        private void SetStandardWorkTime()
        {
            if (Arbeitstag.AnzahlZeiten == 0)
            {
                if (Arbeitstag.MBericht.Projekt.AZModell.Exists)
                {
                    dbProjektAZModellParams azm = (dbProjektAZModellParams)Arbeitstag.MBericht.Projekt.AZModell.Tage[(int)Arbeitstag.TagesDatum.DayOfWeek];
                    if (Convert.ToDateTime(azm.VON.Value).Ticks != ParamVal.Date0.Ticks)
                    {
                        Kommen = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azm.VON.Value).ToShortTimeString());
                        Gehen = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azm.BIS.Value).ToShortTimeString());
                    }
                }
                else //Mitarbeiterspezifisches AZ-Modell
                {
                    //BAF 530042 Beginn
                    if(Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(Arbeitstag.TagesDatum))
                    {
                        DateTime AZ_Begin = Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage[Arbeitstag.TagesDatum].AZ_Begin;
                        DateTime AZ_Ende = Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage[Arbeitstag.TagesDatum].AZ_Ende;
                        if (AZ_Begin.Ticks != ParamVal.Date0.Ticks)
                        {
                            try { Kommen = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + AZ_Begin.ToShortTimeString()); }
                            catch { Kommen = ParamVal.Date0; }
                            try { Gehen = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + AZ_Ende.ToShortTimeString()); }
                            catch { Gehen = ParamVal.Date0; }
                        }
                    }//BAF 530042 Ende
                    else
                    {
                        dbAZTag azt = (dbAZTag)Arbeitstag.MBericht.Bearbeiter.AZModell.AZTage[(int)Arbeitstag.TagesDatum.DayOfWeek];
                        if (Convert.ToDateTime(azt.Params.AZ_Begin.Value).Ticks != ParamVal.Date0.Ticks)
                        {
                            try { Kommen = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.AZ_Begin.Value).ToShortTimeString()); }
                            catch { Kommen = ParamVal.Date0; }
                            try { Gehen = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.AZ_Ende.Value).ToShortTimeString()); }
                            catch { Gehen = ParamVal.Date0; }
                        }
                    }
                }
            }
            else
            {
                Kommen = Arbeitstag.NextKommen;
            }
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        private bool Update()
        {
            return Update(null);
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        /// <summary>
        /// F�gt eine neu Arbeitszeit in die DB ein wenn AllowUpdate = false und Deleted = false
        /// </summary>
        /// <returns></returns>
        private bool Update(SqlTransaction tx)
        {            
            bool inTransaction = (tx != null);
            /*bl�dsinn ... wer sagt da� es das n�chte Monat ist ? .. es kann aucheine Hinfahrt aus Vormonat sein
             * if (((ZeitTyp == ArbZeitType.ReiseInDienstzeit) | (ZeitTyp == ArbZeitType.ReiseVorherNachher))
                && (Kommen.Month != Arbeitstag.TagesDatum.Month)) //jaja, das gibts! N�mlich dann, wenn jemand nach einer Nachtschicht im n�chsten Monat nach Hause f�hrt ....
            { //wir erzeugen dann einfach einen neuen Einsatzbericht mit Status freigegeben f�r den n�chsten Monat und speichern diesen dann auch sogleich ab
                dbMontBer mb = new dbMontBer(Arbeitstag.MBericht.Projekt, Arbeitstag.MBericht.Bearbeiter);
                DateTime bm = Arbeitstag.TagesDatum.AddMonths(1);
                mb.BerichtsMonat = bm.Year * 100 + bm.Month;
                mb.Select();
                if (!mb.AllowUpdate)
                {
                    AllowUpdate = false;
                    dbArbZeit az = new dbArbZeit((dbArbTag)mb.Tage[0], ZeitTyp);
                    az.Kommen = Kommen;
                    az.Gehen = Gehen;
                    az.GKAuftragNR = GKAuftragNR;
                    az.Leistart = Leistart;
                    az.Datum.Value = mb.MinDatum;
                    foreach (dbArbTag at in mb.Tage)
                        foreach (dbArbZeit arz in at.Zeiten) arz.Deleted = true;
                    (mb.Tage[0] as dbArbTag).Zeiten.Add(az);
                    //noch unklar: muss EBSTAT einen anderen Status ausweisen?
                    mb.Params.EBSTAT.Value = (Int16)dbMontBer.EBStat.freigegeben;
                    mb.Params.PROJID.Value = 0;
                    mb.Save(tx);
                    //noch unklar: muss in RAZeile eine Referenz auf dieses Element gelegt werden?
                    return true;
                }
            }*/
            string sql = "sp_TM_Arbzeit";
            if (ZeitTyp == ArbZeitType.gtAbsenz)
            {
                ParamVal.InsertValid((Params as dbAZ_KALTAGParams).List);
                sql = "sp_TM_Kaltag";
            }
            else
            {
                ParamVal.InsertValid((Params as dbAZ_ARBZEITParams).List);
                if (!AllowUpdate) (Params as dbAZ_ARBZEITParams).AZID.Value = Arbeitstag.MBericht.Bearbeiter.Commons.GetNextID(14, "Arbeitszeit");
            } 
            string iu = "Insert";
            if (AllowUpdate)
            {
                iu = "Update";
                if (ZeitTyp == ArbZeitType.gtAbsenz)
                {
                    (Params as dbAZ_KALTAGParams).EBID.Value = Arbeitstag.MBericht.Params.EBID.Value;
                }
                else
                if (ZeitTyp == ArbZeitType.gk)
                {
                        string StrAuftrag = "";
                        StrAuftrag = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString();
                        Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value = (Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString();
                        if (GKAuftragNR.ToString() != Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString())
                        {
                            Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value = GKAuftragNR;
                        }
                        if (Arbeitstag.MBericht.Projekt.CheckSAP())
                        {
                            (Params as dbAZ_ARBZEITParams).INTF_ID.Value = Convert.ToInt16(Arbeitstag.MBericht.Projekt.INTF_ID);
                        }
                        else
                        {
                            // CG:
                            // Defect# 4311, 4296: AllInvalid - check eingef�hrt. Error anzeigen, wenn auch andere Werte vorbelegt sind
                            //
                            bool AllInvalid = StrAuftrag == "" &&
                                              Arbeitstag.MBericht.Params.MANDANT.Value.ToString() == "" &&
                                              Arbeitstag.MBericht.Params.EBID.Value.ToString() == "" &&
                                              Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString() == "";
                            if (!AllInvalid)
                            {
                                string errortxt = StrAuftrag + " " +
                                                  Arbeitstag.MBericht.Params.MANDANT.Value.ToString() + " " +
                                                  Arbeitstag.MBericht.Params.EBID.Value.ToString() + " " +
                                                  Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString();

                                errortxt += "Folgendes nicht bebuchbares Objekt (KTBOBJ, Mandant, EBID, PERSNR) ist diesem Einsatzbericht zugeordnet, " +
                                            "daher Abbruch der Bearbeitung : " + errortxt;
                                Exception ex = new Exception("Fehler in dbObjects.dbArbZeit::Update:" + errortxt);
                                throw ex;
                            }
                            return false;
                        }
                        if (StrAuftrag != "") Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value = StrAuftrag;
                    }
                    else
                    {
                        // CG:
                        // Defect# 4464, 4534 und 4669: neue Berechnung d. Auftragsnummer, falls es vom Beuntzer ge�ndert wurde.
                        //               damit wird die f�lschliche Meldung "Auftrag nicht bebuchbar" verhindert. 
                        if (ZeitTyp == ArbZeitType.produktiv || ((ZeitTyp == ArbZeitType.stdAbsenz) && Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString() !=""))
                        {
                        // end Defect # 4464, 4534 und 4669
                            if (Arbeitstag.MBericht.Projekt.CheckSAP())
                            {
                                // Defect # 4464, 4534 und 4669
                                if ((Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString() == "")
                                {
                                    // Die Auftragsnummer wurde durch den Anwender ge�ndert
                                    (Params as dbAZ_ARBZEITParams).AUFTRNR.Value = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString();
                                    (Params as dbAZ_ARBZEITParams).INTF_ID.Value = Convert.ToInt16(Arbeitstag.MBericht.Projekt.INTF_ID);
                                }
                                // end Defect # 4464, 4534 und 4669
                            }
                            else
                            {
                                bool AllInvalid = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString() == "" &&
                                                  Arbeitstag.MBericht.Params.MANDANT.Value.ToString() == "" &&
                                                  Arbeitstag.MBericht.Params.EBID.Value.ToString() == "" &&
                                                  Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString() == "";
                                if (!AllInvalid)
                                {
                                    string errortxt = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString() + " " +
                                                      Arbeitstag.MBericht.Params.MANDANT.Value.ToString() + " " +
                                                      Arbeitstag.MBericht.Params.EBID.Value.ToString() + " " +
                                                      Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString();

                                    errortxt += "Folgendes nicht bebuchbares Objekt (KTBOBJ, Mandant, EBID, PERSNR) ist diesem Einsatzbericht zugeordnet, " +
                                                "daher Abbruch der Bearbeitung : " + errortxt;
                                    Exception ex = new Exception("Fehler in dbObjects.dbArbZeit::Update:" + errortxt);
                                    throw ex;
                                }
                                return false;
                            } 
                        }
                    }
                    // Defect# 4444 Kennzeichen auf "E" setzen nur f. Ersatzruhe        

                if (ZeitTyp == ArbZeitType.stdAbsenz && STDAbsenzID == STDAbsenzIDs.Ersatzruhe) (Params as dbAZ_ARBZEITParams).KZAZ.Value = "E";
                    // Ende Defect# 4444
            }
            else
            {
                if (ZeitTyp != ArbZeitType.gtAbsenz)
                {
                    (Params as dbAZ_ARBZEITParams).EBID.Value = Arbeitstag.MBericht.Params.EBID.Value;
                    (Params as dbAZ_ARBZEITParams).PERSKEY.Value = Arbeitstag.MBericht.Params.PERSKEY.Value;
                    (Params as dbAZ_ARBZEITParams).MANDANT.Value = Arbeitstag.MBericht.Params.MANDANT.Value;
                    (Params as dbAZ_ARBZEITParams).DATUM.Value = Arbeitstag.TagesDatum;
                    (Params as dbAZ_ARBZEITParams).DATLA.Value = DateTime.Now;
                    (Params as dbAZ_ARBZEITParams).AENPERSKEY.Value = Arbeitstag.MBericht.Projekt.Baustelle.Bearbeiter.Params.PERSKEY.Value;
                    (Params as dbAZ_ARBZEITParams).DATNEU.Value = DateTime.Now;
                    (Params as dbAZ_ARBZEITParams).DATUGBEMO.Value = DBNull.Value;
                    (Params as dbAZ_ARBZEITParams).DATUGEOS.Value = DBNull.Value;
                    (Params as dbAZ_ARBZEITParams).DATUGKORAM.Value = DBNull.Value;
                    (Params as dbAZ_ARBZEITParams).DATUGORK.Value = DBNull.Value;
                    (Params as dbAZ_ARBZEITParams).DATUGRUECKM.Value = DBNull.Value;
                    (Params as dbAZ_ARBZEITParams).KZAZ.Value = "A";

                    if (ZeitTyp == ArbZeitType.gk)
                    {
                        string StrAuftrag = "";
                        StrAuftrag = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString();
                        Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value = (Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString();

                      // Defect 5771, Warning entfernt
                        if (GKAuftragNR != Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString())
                        {
                            Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value = GKAuftragNR;
                        }
                        if (Arbeitstag.MBericht.Projekt.CheckSAP())
                        {
                            (Params as dbAZ_ARBZEITParams).INTF_ID.Value = Convert.ToInt16(Arbeitstag.MBericht.Projekt.INTF_ID);
                        }
                        else
                        {
                            // CG:
                            // Defect# 4311, 4296: AllInvalid - check eingef�hrt. Error anzeigen, wenn auch andere Werte vorbelegt sind
                            //
                            bool AllInvalid = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString() == "" &&
                                              Arbeitstag.MBericht.Params.MANDANT.Value.ToString() == "" &&
                                              Arbeitstag.MBericht.Params.EBID.Value.ToString() == "" &&
                                              Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString() == "";
                            if (!AllInvalid)
                            {
                                string errortxt = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString() + " " +
                                                  Arbeitstag.MBericht.Params.MANDANT.Value.ToString() + " " +
                                                  Arbeitstag.MBericht.Params.EBID.Value.ToString() + " " +
                                                  Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString();

                                errortxt += "Folgendes nicht bebuchbares Objekt (KTBOBJ, Mandant, EBID, PERSNR) ist diesem Einsatzbericht zugeordnet, " +
                                            "daher Abbruch der Bearbeitung : " + errortxt;
                                Exception ex = new Exception("Fehler in dbObjects.dbArbZeit::Update:" + errortxt);
                                throw ex;
                            }
                            return false;
                        }
                        if (StrAuftrag != "") Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value = StrAuftrag; 
                    }
                    else
                    {
                        if (Arbeitstag.MBericht.Projekt.CheckSAP())
                        {
                            (Params as dbAZ_ARBZEITParams).INTF_ID.Value = Convert.ToInt16(Arbeitstag.MBericht.Projekt.INTF_ID);
                        }
                        else
                        {
                            // CG:
                            // Defect# 4311, 4296: AllInvalid - check eingef�hrt. Error anzeigen, wenn auch andere Werte vorbelegt sind
                            //
                            bool AllInvalid = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString() == "" &&
                                              Arbeitstag.MBericht.Params.MANDANT.Value.ToString() == "" &&
                                              Arbeitstag.MBericht.Params.EBID.Value.ToString() == "" &&
                                              Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString() == "";
                            if (!AllInvalid)
                            {
                                string errortxt = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString() + " " +
                                                  Arbeitstag.MBericht.Params.MANDANT.Value.ToString() + " " +
                                                  Arbeitstag.MBericht.Params.EBID.Value.ToString() + " " +
                                                  Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString();

                                errortxt += "Folgendes nicht bebuchbares Objekt (KTBOBJ, Mandant, EBID, PERSNR) ist diesem Einsatzbericht zugeordnet, " +
                                            "daher Abbruch der Bearbeitung : " + errortxt;
                                Exception ex = new Exception("Fehler in dbObjects.dbArbZeit::Update:" + errortxt);
                                throw ex;
                            }
                            return false;
                        }
                    }
                    if (ZeitTyp == ArbZeitType.ReiseInDienstzeit) (Params as dbAZ_ARBZEITParams).KZAZ.Value = "W";
                    if (ZeitTyp == ArbZeitType.ReiseVorherNachher)
                    {
                        (Params as dbAZ_ARBZEITParams).KZAZ.Value = "R";
                        DateTime sqlBeginn = Convert.ToDateTime((Params as dbAZ_ARBZEITParams).BEGINN.Value);
                        DateTime sqlDatum = Convert.ToDateTime((Params as dbAZ_ARBZEITParams).DATUM.Value);
                        if (sqlDatum.DayOfYear != sqlBeginn.DayOfYear && 
                            sqlDatum.AddDays(-1).DayOfYear == sqlBeginn.DayOfYear &&
                            Arbeitstag.TagesDatum.AddDays(-1).DayOfYear == sqlBeginn.DayOfYear)
                        {
                            (Params as dbAZ_ARBZEITParams).DATUM.Value = Arbeitstag.TagesDatum.AddDays(-1);
                        }
                    }
                    if (ZeitTyp != ArbZeitType.gk) (Params as dbAZ_ARBZEITParams).AUFTRNR.Value = Arbeitstag.MBericht.Projekt.Params.KTOBJ.Value.ToString();

                    // Beginn #5285 - Falsche Produktivierung TAP_Montage - std. Absenzen
                    if ((ZeitTyp == ArbZeitType.stdAbsenz) && (STDAbsenzID != "90")) /* Ausgen.: Ersatzruhe(90) */
                    {                       
                        (Params as dbAZ_ARBZEITParams).INTF_ID.Value = -1;
                    } 
                    // Ende #5285

                    // Defect# 4444 Kennzeichen auf "E" setzen nur f. Ersatzruhe
                    if (ZeitTyp == ArbZeitType.stdAbsenz && STDAbsenzID == STDAbsenzIDs.Ersatzruhe) (Params as dbAZ_ARBZEITParams).KZAZ.Value = "E";
                    // Ende Defect# 4444
                }
                else
                {
                    (Params as dbAZ_KALTAGParams).EBID.Value = Arbeitstag.MBericht.Params.EBID.Value;
                    (Params as dbAZ_KALTAGParams).PERSKEY.Value = Arbeitstag.MBericht.Params.PERSKEY.Value;
                    (Params as dbAZ_KALTAGParams).DATUM.Value = Arbeitstag.TagesDatum;
                } 
            }

            // Beginn Defect #4520: Wenn nicht GT-Absenz, wird die Zeilennummer gesetzt
            if (ZeitTyp != ArbZeitType.gtAbsenz)
            {
                // Abspeichern der fortlaufenden Znr
                try
                {
                    (Params as dbAZ_ARBZEITParams).ZNR.Value = lintZnr;
                }
                catch (Exception ex)
                {
                    string strErrorMessage = ex.Message;
                }
            }
            // Ende Defect #4520

            sql += iu; ;


            SqlConnection cnx = null;
            try
            {

                if (!inTransaction)
                {
                    cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                    cnx.Open();
                }
                else cnx = tx.Connection;
                using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
                {
                  cmd.CommandType = CommandType.StoredProcedure;
                  if (ZeitTyp == ArbZeitType.gtAbsenz)
                    foreach (SqlParameter s in (Params as dbAZ_KALTAGParams).List) cmd.Parameters.Add(s);
                  else
                    foreach (SqlParameter s in (Params as dbAZ_ARBZEITParams).List) cmd.Parameters.Add(s);
                  AllowUpdate = (cmd.ExecuteNonQuery() > 0);
                  if (ZeitTyp == ArbZeitType.gtAbsenz)
                    foreach (SqlParameter s in (Params as dbAZ_KALTAGParams).List) cmd.Parameters.Remove(s);
                  else
                    foreach (SqlParameter s in (Params as dbAZ_ARBZEITParams).List) cmd.Parameters.Remove(s);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { if(!inTransaction)cnx.Close();}
            
            return AllowUpdate;
        }


        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren
        private bool Delete()
        {
            return Delete(null);
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        /// <summary>
        /// L�scht eine Arbeitszeit aus der DB wenn Deleted = true
        /// </summary>
        /// <returns></returns>
        private bool Delete(SqlTransaction tx)
        {
            bool inTransaction = tx != null;
            // Defect 5725, Config.Rowlock eingef�hrt
            string sql = "Delete from ARBZEIT " + Config.Rowlock + " where AZID = @AZID";
            if (ZeitTyp == ArbZeitType.gtAbsenz)
                sql = "Delete from KALTAG " + Config.Rowlock + " where Perskey = @PERSKEY and DATUM = @DATUM";

                SqlConnection cnx = null;
                try
                {
                    if (!inTransaction)
                    {
                        cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                        cnx.Open();
                    }
                    else cnx = tx.Connection;
                    using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
                    {
                      if (ZeitTyp == ArbZeitType.gtAbsenz)
                      {
                        cmd.Parameters.Add((Params as dbAZ_KALTAGParams).PERSKEY);
                        cmd.Parameters.Add((Params as dbAZ_KALTAGParams).DATUM);
                      }
                      else
                        cmd.Parameters.Add((Params as dbAZ_ARBZEITParams).AZID);
                      cmd.ExecuteNonQuery();
                      AllowUpdate = false;
                      if (ZeitTyp == ArbZeitType.gtAbsenz)
                      {
                        cmd.Parameters.Remove((Params as dbAZ_KALTAGParams).PERSKEY);
                        cmd.Parameters.Remove((Params as dbAZ_KALTAGParams).DATUM);
                      }
                      else
                        cmd.Parameters.Remove((Params as dbAZ_ARBZEITParams).AZID);
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { if(!inTransaction)cnx.Close(); }
            
            return AllowUpdate;
        }

        #region SQLStrings
        // Defect 5725, Config.Rowlock eingef�hrt
        // Defect 5771, Config.Nolock eingef�hrt
        private string SQL_Select_Tag_KALTAG = @"Select DATUM,PERSKEY,ABGABEKZ,MLMOKZ,MLABKZ,y.GTABSENZID as GTABSENZID,y.AZMNR as GTAZMNR,DATABGLKZ,DATLASRV,k.DATLA,k.AENPERSKEY,k.DATNEU,GTABSENZTXT from KALTAG k " + Config.Nolock + ", Y_GTABSENZ y " + Config.Nolock + " where PERSKEY = @PERSKEY and DATUM = @DATUM and y.GTABSENZID = k.GTABSENZID";
        private string SQL_Select_Tag_Arbzeit = @"Select AZID,MANDANT,EBID,PERSKEY,DATUM,BEGINN,ENDE,AZUMMOKZ,AZUMABKZ,KZAZGUELTIG,PAUSE,NORMSTD,UESTD50,UESTD100,KZAZ,STDABSENZID,BEMERKUNG,KMLOHNART,KM,KMKZSG,AUFTRNR,SUBNR,KZTA,CODE,KZVA,BELEGNR,DATLA,AENPERSKEY,DATNEU,KZVK,ZNR,DATUGORK,DATUGEOS,MA_BEGINN,MA_ENDE,MA_STD,MA_PAUSE,DATUGBEMO,FLDTXT1,FLDTXT2,LEISTART,BEREIT,FLDTXT3,DATUGKORAM,DATUGRUECKM,EQUIPMENTNR,INTF_ID from ARBZEIT " + Config.Nolock + " where PERSKEY = @PERSKEY and DATUM = @DATUM order by BEGINN asc";
        #endregion
        /// <summary>
        /// l�dt alle Arbeitszeiten und Abwesenheiten von Arbeitstag.Montagebericht.Bearbeiter zum betreffenden Tag
        /// </summary>
        /// <returns>ArrayList of dbArbZeit-Objekten</returns>
        public ArrayList SelectTag()
        {
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    dbAZ_KALTAGParams lParams = new dbAZ_KALTAGParams();
                    lParams.DATUM.Value = Arbeitstag.TagesDatum;
                    if (Arbeitstag.Contains == dbArbTag.ArbTagContent.ArbeitsZeiten)
                        lParams.PERSKEY.Value = Arbeitstag.MBericht.Bearbeiter.Params.PERSKEY.Value;
                    //else wei� ich noch nicht
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand(SQL_Select_Tag_KALTAG, cnx)) // Defect 5436
                    {
                      cmd.Parameters.Add(lParams.DATUM);
                      cmd.Parameters.Add(lParams.PERSKEY);
                      using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                      {
                        cmd.Parameters.Remove(lParams.DATUM);
                        cmd.Parameters.Remove(lParams.PERSKEY);
                        while (rd.Read())
                        {
                          dbArbZeit az = new dbArbZeit(Arbeitstag, ArbZeitType.gtAbsenz);
                          az.Params = new dbAZ_KALTAGParams();
                          ParamVal.DataReader2Params(rd, (az.Params as dbAZ_KALTAGParams).List);
                          az.AllowUpdate = true;
                          if (Arbeitstag.Contains == dbArbTag.ArbTagContent.ArbeitsZeiten) al.Add(az);
                        }
                      }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            if (al.Count == 0)
            {
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        dbAZ_ARBZEITParams lParams = new dbAZ_ARBZEITParams();
                        lParams.DATUM.Value = Arbeitstag.TagesDatum;
                        lParams.PERSKEY.Value = Arbeitstag.MBericht.Bearbeiter.Params.PERSKEY.Value;
                        cnx.Open();
                        using (SqlCommand cmd = new SqlCommand(SQL_Select_Tag_Arbzeit, cnx)) // Defect 5436
                        {
                          cmd.Parameters.Add(lParams.DATUM);
                          cmd.Parameters.Add(lParams.PERSKEY);
                          using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                          {
                            cmd.Parameters.Remove(lParams.DATUM);
                            cmd.Parameters.Remove(lParams.PERSKEY);
                            while (rd.Read())
                            {
                              dbArbZeit az = new dbArbZeit(Arbeitstag, ArbZeitType.produktiv);
                              az.Params = new dbAZ_ARBZEITParams();
                              ParamVal.DataReader2Params(rd, (az.Params as dbAZ_ARBZEITParams).List);
                              //RelevanzKZ-setzen
                              if ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)Arbeitstag.MBericht.Params.EBID.Value) Arbeitstag.Relevanz = true;
                              //Pause immer abziehen!
                              //Arbeitstag.PausenAbzug = (Arbeitstag.PausenAbzug | ((Int16)(az.Params as dbAZ_ARBZEITParams).PAUSE.Value > 0));
                              if ((az.Params as dbAZ_ARBZEITParams).STDABSENZID.Value.ToString().Length > 0)
                                if ((Int16)(az.Params as dbAZ_ARBZEITParams).STDABSENZID.Value > 0) az.ZeitTyp = ArbZeitType.stdAbsenz;
                              foreach (ValuePair vp in Arbeitstag.MBericht.Bearbeiter.Commons.GK_Auftrag)
                                if (vp.Value == (az.Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString())
                                  az.ZeitTyp = ArbZeitType.gk;
                              if ((az.Params as dbAZ_ARBZEITParams).KZAZ.Value.ToString() == "W") az.ZeitTyp = ArbZeitType.ReiseInDienstzeit;
                              if ((az.Params as dbAZ_ARBZEITParams).KZAZ.Value.ToString() == "R") az.ZeitTyp = ArbZeitType.ReiseVorherNachher;
                              az.AllowUpdate = true;
                              if ((az.IstArbeitsZeit) & (Arbeitstag.Contains == dbArbTag.ArbTagContent.ArbeitsZeiten)) al.Add(az);
                              else if ((!az.IstArbeitsZeit) & (Arbeitstag.Contains == dbArbTag.ArbTagContent.ReiseZeiten)) al.Add(az);
                              //if ((az.Params as dbAZ_ARBZEITParams).BEREIT.Value.ToString() == "1") az.Bereitschaft = true; //TAPM-20 RB wird erkannt
                            }
                          }
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            }
            //BAF 530042 Beginn
            if (Arbeitstag.MBericht.Bearbeiter.BerichtsMonat == 0)
                Arbeitstag.MBericht.Bearbeiter.BerichtsMonat = Arbeitstag.MBericht.BerichtsMonat;
            if(Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(Arbeitstag.TagesDatum))
            {
                if (Arbeitstag.Contains == dbArbTag.ArbTagContent.ArbeitsZeiten)
                    if (al.Count == 0) //kein Eintrag f�r diesen Tag -> neue Zeit mit Vorbelgung
                        if (((int)Arbeitstag.MBericht.Params.EBID.Value == 0) &&
                            !Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage[Arbeitstag.TagesDatum].IstFeiertag &&
                            !Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage[Arbeitstag.TagesDatum].IstFenstertag
                            )
                            al.Add(new dbArbZeit(Arbeitstag, ArbZeitType.produktiv, true));
                        else
                            al.Add(new dbArbZeit(Arbeitstag, ArbZeitType.produktiv, false));
            }//BAF 530042 Ende
            else
            {
                if (Arbeitstag.Contains == dbArbTag.ArbTagContent.ArbeitsZeiten)
                    if (al.Count == 0) //kein Eintrag f�r diesen Tag -> neue Zeit mit Vorbelgung
                        if (((int)Arbeitstag.MBericht.Params.EBID.Value == 0) &&
                            (!Arbeitstag.MBericht.Bearbeiter.IstFeiertag(Arbeitstag.TagesDatum)) &&
                            // Defect 5008
                            (!Arbeitstag.MBericht.Bearbeiter.IstFenstertag(Arbeitstag.TagesDatum))
                            // ende Defect 5008
                            )
                            al.Add(new dbArbZeit(Arbeitstag, ArbZeitType.produktiv, true));
                        else
                            al.Add(new dbArbZeit(Arbeitstag, ArbZeitType.produktiv, false));
            }
            dbArbZeitSort azSort = new dbArbZeitSort(dbArbZeitSort.SortByEnum.Kommen);
            al.Sort(azSort);
            return al;
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        public void Save(SqlTransaction tx)
        {
            if (Arbeitstag.Relevanz)
            {
                if (AllowUpdate)
                {
                    if (!Deleted) Update(tx);
                    else Delete(tx);
                }
                else
                {
                    if (!Deleted) Update(tx);
                }
            }
            else
            {
                if ((Params is dbAZ_ARBZEITParams) && ((int)(Params as dbAZ_ARBZEITParams).EBID.Value == (int)Arbeitstag.MBericht.Params.EBID.Value))
                    Delete(tx);
            }
        }

        // Beginn #5322 - Projekt-AZM wird durch Mitarbeiter AZM �berschrieben
        // Beginn #4616, 4617, 4940 - AZ-Modell
        // TAPM-35 reference "gelesen" w�rde eingef�gt 
        // true .... AT ist g�ltig ... BAZ notfalls korrigieren
        // false ... AT ist Samstag, Sonntag oder Feiertag ... BAZ wird nicht korriegiert
        // TAPM-27 ... "monatsende" wird true falls R�ckreise in n�chsten Monat enden sollte
        public void AZTag_Aktualizieren(ref dbAZTag maAzt, ref bool gelesen, bool monatsende)
        {
            //string vPersNum = Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString().Substring(2, 5);
            string vPersNum = Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString().Substring(2, Arbeitstag.MBericht.Bearbeiter.Params.PERSNR.Value.ToString().Length - 2);
            string vMAName = Arbeitstag.MBericht.Bearbeiter.Params.NACHNAME.Value.ToString();
            string vMAVorame = Arbeitstag.MBericht.Bearbeiter.Params.VORNAME.Value.ToString();
            string vTag = "";
            if (monatsende)
                vTag = Arbeitstag.TagesDatum.AddMonths(1).ToString("yyyy-MM-dd");
            else
                vTag = Arbeitstag.TagesDatum.ToString("yyyy-MM-dd");
            string vProjId = Arbeitstag.MBericht.Projekt.Params.PROJID.Value.ToString();
            //bool AZM_Found_For_Project = false;

            if (vTag != "1900-01-01")
            {

                /* Defect 4665, 5337
                 * GN 10.8.2007
                 * MA-AZM wurde f�lschlicherweise durch projektAZM �berschrieben
                 * 
                 * using (SqlConnection SissiConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    SissiConnection.Open();

                    string SissiSqlCommandText = "SELECT VON AS AZ_Begin, BIS AS AZ_Ende, (DATEDIFF(mi , VON , BIS) / 60.0) AS AZ_SollarbeitStd" +
                        " FROM BAUPROJEKT_AZMODELL WHERE PROJAZMID = '" + vProjId + "' AND TAG = (DATEPART(w , '" + vTag + "') -1)";

                    SqlCommand SissiSqlCommand = new SqlCommand(SissiSqlCommandText, SissiConnection);
                    SqlDataReader SissiReader = SissiSqlCommand.ExecuteReader();
                    while (SissiReader.Read())
                    {
                        try
                        {
                            if (
                                   (Convert.ToDateTime(SissiReader.GetValue(0).ToString()).Hour == 0)
                                   && (Convert.ToDateTime(SissiReader.GetValue(0).ToString()).Minute == 0)
                                   && (Convert.ToDateTime(SissiReader.GetValue(1).ToString()).Hour == 0)
                                   && (Convert.ToDateTime(SissiReader.GetValue(1).ToString()).Minute == 0)
                                )
                            {
                                AZM_Found_For_Project = false;
                            }
                            else
                            {
                                DateTime fromTime = Convert.ToDateTime(SissiReader.GetValue(0).ToString());
                                DateTime toTime = Convert.ToDateTime(SissiReader.GetValue(1).ToString());

                                /* Zeiten aktualisieren 

                                maAzt.Params.AZ_Begin.Value = fromTime;
                                maAzt.Params.AZ_Ende.Value = toTime;

                                AZM_Found_For_Project = true;
                            }
                        }
                        catch
                        {
                            AZM_Found_For_Project = false;
                        }
                    }
                    SissiReader.Close();
                    SissiConnection.Close();

                }*/

                //if (!AZM_Found_For_Project)
                {

                    using (SqlConnection AZMConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AZMConnectionString"].ConnectionString))
                    {
                        /* Aktuelle AZModell - Werte lesen */
                        AZMConnection.Open();

                        // Beginn #5320 - Auf bereits erfasste EBs kann nicht mehr zugegriffen werden
                        // Defect 5725, Config.Rowlock eingef�hrt
                        // Defect 5771, Config.Nolock eingef�hrt
                        string AZMSqlCommandText = "SELECT AZ_Begin, AZ_Ende, AZ_SollarbeitStd FROM AZ_Tag " + Config.Nolock +
                                                   " WHERE AZ_Modell_Nummer = (" +
                                                   " SELECT AZ_Modell_Nummer FROM MA_AZ_Modell " + Config.Nolock +
                                                   " WHERE (MA_AZ_g�ltig_von <= '" + vTag + "') AND (MA_AZ_g�ltig_bis >= '" + vTag + "') AND (MA_PersNummer = '" + vPersNum +
                                                   "')  AND (MA_FKN = (SELECT MA_FKN FROM MA_Stamm " + Config.Nolock + " WHERE MA_PersNummer = '" + vPersNum + "' AND MA_Name = '" + vMAName + "' AND MA_Vorname = '" + vMAVorame + "'))" +
                                                   " ) AND AZ_Wochentag = DATEPART(w , '" + vTag + "')  ";
                        // Ende #5320

                        using (SqlCommand AZMSqlCommand = new SqlCommand(AZMSqlCommandText, AZMConnection)) // Defect 5436
                        {
                          using (SqlDataReader AZMReader = AZMSqlCommand.ExecuteReader()) // Defect 5436
                          {
                            while (AZMReader.Read())
                            {
                              try
                              {
                                DateTime fromTime = Convert.ToDateTime(AZMReader.GetValue(0).ToString());
                                DateTime toTime = Convert.ToDateTime(AZMReader.GetValue(1).ToString());

                                /* Zeiten aktualisieren */

                                maAzt.Params.AZ_Begin.Value = fromTime;
                                maAzt.Params.AZ_Ende.Value = toTime;
                                gelesen = true;
                              }
                              catch { }
                            }
                            AZMReader.Close();
                            AZMConnection.Close();
                          }
                        }
                    }
                }
            }
        }
        // Ende #4616, 4617, 4940 
        // Ende #5322

        public void CalcWorktime()
        {
            if ((Params as dbAZ_ARBZEITParams) == null) return;
            dbAZ_ARBZEITParams az = (Params as dbAZ_ARBZEITParams);
            if (true)
            {
                bool azBisUeberMonatsgrenze = false; //TAPM-27 R�ckreise am ersten Tag des Folgemonats
                DateTime a = (DateTime)az.BEGINN.Value;
                DateTime e = (DateTime)az.ENDE.Value;
                //BAF 530042 Beginn
                // Wenn Hinreise in Vormonat beginnen sollte dann wird diese Zeit zu den ersten Arbeitstag zugewiesen aber die Zeiten bleiben 
                // in alten KGMonat. Dies f�hrt dazu dass gesamt Summe am ersten Arbeitstag nicht korrekt ist und Exception 
                // wird auftreten. Also wir �nder es und schreiben diese Stunden an dem Tag wo die Reise begonnen ist.
                DateTime attd = a.Date; // Arbeitstag.TagesDatum;
                //BAF 530042 Ende
                if ((e.Ticks > a.Ticks) & (e.Day == a.Day) & (e.DayOfYear != Arbeitstag.TagesDatum.DayOfYear)) //Sonderfall einer Arbeitszeit die wegen nachtarbeit aus einer R�ckreise am ersten Tag des Folgemonats entstanden ist -> heul!
                {
                    azBisUeberMonatsgrenze = true;
                    attd = Convert.ToDateTime(e.ToShortDateString() + " 00:00");
                }
                TimeSpan tsTotal = new TimeSpan(e.Ticks - a.Ticks);
                UEStunden100 = 0;
                UEStunden50 = 0;
                NormStunden = 0;
                if ((a.Ticks != ParamVal.Date0.Ticks) && (e.Ticks != ParamVal.Date0.Ticks) && (a.CompareTo(e) < 0)) //berechne Arbeitszeit anhand Mitarbeiter-AZ-Modell
                {
                    // Beginn Defect # 3327: Berechnung der Arbeitszeit (Ersatzruhe, Mitternacht)
                    bool bcont = true; // will be set to true ich work over midnight detected
                    //TAPM-20 wenn Bereitschaft dann sind es 100% �berstunden
                    if (az.BEREIT.Value.ToString() == "1")
                    {
                        TimeSpan ts = new TimeSpan(e.Ticks - a.Ticks);
                        UEStunden100 = ts.TotalHours;
                        Pause = 0;
                        bcont = false;
                    }
                    while (bcont)
                    {
                        //TAPM-35 neu Variablen welche notwendig sind falls BAZ korrigiert werden soll
                        bool aztag_gelesen = false;
                        bool a100_valid = true;
                        bool a50_valid = true;
                        bool e50_valid = true;
                        TimeSpan ts = new TimeSpan(e.Ticks - a.Ticks);
                        dbMandantAZModellTag azt = (dbMandantAZModellTag)Arbeitstag.MBericht.Bearbeiter.Mandant.AZModell.Tage[(int)attd.DayOfWeek];
                        DateTime AZ_Begin = ParamVal.Date0;
                        DateTime AZ_Ende = ParamVal.Date0;

                        //BAF 530042 Beginn
                        if (Arbeitstag.MBericht.Bearbeiter.BerichtsMonat == 0) Arbeitstag.MBericht.Bearbeiter.BerichtsMonat = Arbeitstag.MBericht.BerichtsMonat;
                        if(Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(attd))
                        {
                            AZ_Begin = Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage[attd].AZ_Begin;
                            AZ_Ende = Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage[attd].AZ_Ende;
                            if( AZ_Begin != ParamVal.Date0 )
                                aztag_gelesen = true;
                            if (Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage[attd].IstFeiertag &&
                                !Arbeitstag.MBericht.Bearbeiter.AZMKalenderTage[attd].IstFenstertag)
                            {
                                azt = (dbMandantAZModellTag)Arbeitstag.MBericht.Bearbeiter.Mandant.AZModell.Tage[0];
                                AZ_Begin = ParamVal.Date0; //wie Sonntag
                                AZ_Ende = ParamVal.Date0;
                                aztag_gelesen = false; //TAPM-35 ... BAZ wird nicht korrigiert
                            }
                        }//BAF 530042 Ende
                        else
                        {
                            if (Arbeitstag.MBericht.Bearbeiter.IstFeiertag(attd) & !Arbeitstag.MBericht.Bearbeiter.IstFenstertag(attd))
                                azt = (dbMandantAZModellTag)Arbeitstag.MBericht.Bearbeiter.Mandant.AZModell.Tage[0]; //wie Sonntag
                            //Defect 4317 - GN 11.01.07 - Bei Rollung muss das Arbeitszeitmodell des Vormonats geholt werden
                            // f�r diesen Defect mu� ein Konzept erstellt werden
                            //dbAZTag maAzt = (dbAZTag)new dbAZModell(Arbeitstag.MBericht.Bearbeiter, attd).AZTage[(int)attd.DayOfWeek];
                            dbAZTag maAzt = (dbAZTag)Arbeitstag.MBericht.Bearbeiter.AZModell.AZTage[(int)attd.DayOfWeek];
                            // Beginn #4616, 4617, 4940 - AZ-Modell                        
                            AZTag_Aktualizieren(ref maAzt, ref aztag_gelesen, azBisUeberMonatsgrenze);
                            // Ende #4616, 4617, 4940
                            if (Arbeitstag.MBericht.Bearbeiter.IstFeiertag(attd) & !Arbeitstag.MBericht.Bearbeiter.IstFenstertag(attd))
                            {
                                maAzt = (dbAZTag)Arbeitstag.MBericht.Bearbeiter.AZModell.AZTage[0]; //wie Sonntag
                                aztag_gelesen = false; //TAPM-35 ... BAZ wird nicht korrigiert
                                // Defect 4317, Konzept notwendig
                                //maAzt = (dbAZTag)new dbAZModell(Arbeitstag.MBericht.Bearbeiter, attd).AZTage[0];
                            }
                            AZ_Begin = Convert.ToDateTime(maAzt.Params.AZ_Begin.Value);
                            AZ_Ende = Convert.ToDateTime(maAzt.Params.AZ_Ende.Value);
                        }
                        DateTime a100 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100BEG1.Value).ToShortTimeString());
                        DateTime a50 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50BEG1.Value).ToShortTimeString());
                        DateTime aNorm = Convert.ToDateTime(attd.ToShortDateString() + " " + AZ_Begin.ToShortTimeString());
                        DateTime eNorm = Convert.ToDateTime(attd.ToShortDateString() + " " + AZ_Ende.ToShortTimeString());
                        //Wenn Problemm mit AZM weiterhin besteht - useBAZ
                        bool useBAZ = false;
                        try
                        {
                            if (ConfigurationManager.AppSettings["useBAZ"] == "true")
                                useBAZ = true;
                            string strSozStell = Arbeitstag.MBericht.Bearbeiter.TechParams.SOZSTELL.Value.ToString();
                            if (useBAZ && (strSozStell == "6" || strSozStell == "7"))
                            {
                                aNorm = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.NAZBEG.Value).ToShortTimeString());
                                eNorm = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.NAZEND.Value).ToShortTimeString());
                            }
                        }
                        catch
                        {
                            // bleibt false
                        }
                        //Ende useBAZ
                        DateTime e50 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50END2.Value).ToShortTimeString());
                        if (Convert.ToDateTime(azt.Params.UESTD50END2.Value).Ticks == ParamVal.Date0.Ticks)
                            e50 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50END1.Value).ToShortTimeString());
                        DateTime e100 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100END2.Value).ToShortTimeString());
                        if (Convert.ToDateTime(azt.Params.UESTD100END2.Value).Ticks == ParamVal.Date0.Ticks)
                            e100 = Convert.ToDateTime(attd.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100END1.Value).ToShortTimeString());
                        //if (e100.Ticks < e50.Ticks)//Ende um 00:00 Uhr -> Add 1 Day
                        e100 = e100.AddDays(1);
                        //TAPM-35 "TAPM35" ... falls was schief gehen sollte, die �berpr�fung kann im WebConfig ausgeschaltet werden
                        try
                        {
                            if (ConfigurationManager.AppSettings["TAPM35"] == "true" && aztag_gelesen)
                            {
                                //TAPM-35 a100 ist immer Mitternacht, falls AZ um Mitternacht beginnt, dann ist a100 invalid
                                if (aNorm == a100)
                                    a100_valid = false;
                                //TAPM-35 AZ beginnt zwischen 00:00 und 06:00
                                if (aNorm > a100 && aNorm <= a50)
                                {
                                    a50 = aNorm; // TAPM-35 wegen Berechnung der a100 Stunden
                                    a50_valid = false; // Es gibt keine a50 Stunden
                                }
                                //TAPM-35 AZ endet nach e50, also e50 ist invalid
                                if (eNorm >= e50)
                                {
                                    e50_valid = false;
                                    e50 = eNorm; //TAP-35 wegen Berechnung der e100 Stunden
                                }
                                //TAPM-35 Abfrage ob eNorm == e100 ist nicht notwendig, weil bei AZM der Tag �ndert 23:59:59 und nicht um 00:00
                            }
                        }
                        catch
                        {
                            //do nothing
                        }//TAPM-35 Ende

                        TimeSpan tsm100 = new TimeSpan();
                        if (a100_valid) //TAPM-35 falls NAZ um 00:00 berginnen sollte, dann gibt es keine a100 �STD
                        {
                            //100%�S Morgens: Fr�here(Ende,Zeitgrenze50% morgens)-Sp�tere(Anfang, Zeitgrenze 100% Morgens)
                            tsm100 = new TimeSpan(Math.Min(e.Ticks, a50.Ticks) - Math.Max(a.Ticks, a100.Ticks));
                            if (tsm100.TotalMinutes < 0) tsm100 = new TimeSpan(); //ausnullen falls negativ
                        }

                        TimeSpan tsm50 = new TimeSpan();
                        if (a50_valid)
                        {
                            //50%�S Morgens: Fr�here(Ende,Zeitgrenze Beginn Normal) - Sp�tere(Anfang, Zeitgrenze50% morgens)
                            tsm50 = new TimeSpan(Math.Min(e.Ticks, aNorm.Ticks) - Math.Max(a.Ticks, a50.Ticks));
                            if (tsm50.TotalMinutes < 0) tsm50 = new TimeSpan();
                        }
                        //Normalarbeitszeit: Fr�here(Ende, Zeitgrenze Ende Normal) - Sp�tere(Anfang, Zeitgrenze Beginn Normal)
                        TimeSpan tsnorm = new TimeSpan(Math.Min(e.Ticks, eNorm.Ticks) - Math.Max(a.Ticks, aNorm.Ticks));
                        if (tsnorm.TotalMinutes < 0) tsnorm = new TimeSpan();

                        TimeSpan tsa50 = new TimeSpan();
                        if (e50_valid)
                        {
                            //50%�S Abends: Fr�here(Ende, Zeitgrenze50% Abends) - sp�tere(Anfang, ap�tere(Zeitgrenze Ende Normal, Anfang 50[falls keine NormAZ an diesem Tag]))
                            tsa50 = new TimeSpan(Math.Min(e.Ticks, e50.Ticks) - Math.Max(a.Ticks, Math.Max(eNorm.Ticks, a50.Ticks)));
                            if (tsa50.TotalMinutes < 0) tsa50 = new TimeSpan();
                        }
                        //100%�S Abends: Fr�here(Ende, Zeitgrenze100% Abends) - sp�tere(Anfang, Zetgrenze50% Abends)
                        TimeSpan tsa100 = new TimeSpan(Math.Min(e.Ticks, e100.Ticks) - Math.Max(a.Ticks, e50.Ticks));
                        if (tsa100.TotalMinutes < 0) tsa100 = new TimeSpan();
                        Pause = 0;
                        NormStunden += tsnorm.TotalHours;
                        UEStunden50 += tsa50.TotalHours + tsm50.TotalHours;
                        UEStunden100 += tsa100.TotalHours + tsm100.TotalHours;
                        bcont = false;
                        if (e.Day != a.Day)
                        {
                            e = e.AddDays(-1);
                            a = attd;
                            bcont = true;
                        }
                    }
                    // Ende Defect # 3327
                    
                    // Beginn Defect 4936 sessionvar pruefen damit nicht immer die fm ausgegeben wird wenn wir auf die vormonate zugreifen
                    dbKG_Monat KGMonat = null;
                    if (Session["KGMonat"] != null)
                    {
                        KGMonat = (dbKG_Monat)Session["KGMonat"];
                    }
                    if (KGMonat != null &&
                        a != null)
                    {
                        if (KGMonat.MinDatum.Month == a.Month)
                        {
                            // Ende Defect 4936
                            if (Convert.ToInt32(tsTotal.TotalHours * 60) != Convert.ToInt32((NormStunden + UEStunden50 + UEStunden100) * 60))
                            {
                              Exception ex = new Exception("Fehler in der Berechnung der Arbeitszeiten!");
                              throw ex;
                            } // Defect 4936
                        } // Defect 4936
                    }
                }
            }
        }
        public void CalcWorktimeOld()
        {
            if ((Params as dbAZ_ARBZEITParams) == null) return;
            dbAZ_ARBZEITParams az = (Params as dbAZ_ARBZEITParams);
            if (ZeitTyp == ArbZeitType.stdAbsenz)
            {
                ParamVal.SetParameter(az.NORMSTD, "0");
                ParamVal.SetParameter(az.UESTD50, "0");
                ParamVal.SetParameter(az.UESTD100, "0");
                ParamVal.SetParameter(az.PAUSE, "0");
            }
            else
            {
                DateTime a = (DateTime)az.BEGINN.Value;
                DateTime e = (DateTime)az.ENDE.Value;
                UEStunden100 = 0;
                UEStunden50 = 0;
                NormStunden = 0;
                if (a.CompareTo(e) < 0) //berechne Arbeitszeit anhand Mitarbeiter-AZ-Modell
                {
                    TimeSpan ts = new TimeSpan(e.Ticks - a.Ticks);
                    dbMandantAZModellTag azt = (dbMandantAZModellTag)Arbeitstag.MBericht.Bearbeiter.Mandant.AZModell.Tage[(int)Arbeitstag.TagesDatum.DayOfWeek];
                    dbAZTag maAzt = (dbAZTag)Arbeitstag.MBericht.Bearbeiter.AZModell.AZTage[(int)Arbeitstag.TagesDatum.DayOfWeek];
                    DateTime a100 = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100BEG1.Value).ToShortTimeString());
                    DateTime a50 = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50BEG1.Value).ToShortTimeString());
                    DateTime aNorm = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(maAzt.Params.AZ_Begin.Value).ToShortTimeString());
                    DateTime eNorm = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(maAzt.Params.AZ_Ende.Value).ToShortTimeString());
                    DateTime e50 = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50END2.Value).ToShortTimeString());
                    if (Convert.ToDateTime(azt.Params.UESTD50END2.Value).Ticks == ParamVal.Date0.Ticks)
                        e50 = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD50END1.Value).ToShortTimeString());
                    DateTime e100 = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100END2.Value).ToShortTimeString());
                    if (Convert.ToDateTime(azt.Params.UESTD100END2.Value).Ticks == ParamVal.Date0.Ticks)
                        e100 = Convert.ToDateTime(Arbeitstag.TagesDatum.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.UESTD100END1.Value).ToShortTimeString());
                    //if (e100.Ticks < e50.Ticks)//Ende um 00:00 Uhr -> Add 1 Day
                    e100 = e100.AddDays(1);
                    if (a.Ticks < a50.Ticks) //100% in der Fr�h
                    {
                        TimeSpan sv100 = new TimeSpan(a50.Ticks - a.Ticks);
                        UEStunden100 += sv100.TotalHours;
                        a = a50;
                    }
                    if (a.Ticks < aNorm.Ticks) //50% in der Fr�h
                    {
                        TimeSpan sv50 = new TimeSpan(aNorm.Ticks - a.Ticks);
                        UEStunden50 += sv50.TotalHours;
                        a = aNorm;
                    }
                    if (a.Ticks < Math.Min(eNorm.Ticks, e.Ticks)) //jetzt die Normalarbeitszeit
                    {
                        TimeSpan sn = new TimeSpan(Math.Min(eNorm.Ticks, e.Ticks) - a.Ticks);
                        NormStunden += sn.TotalHours;
                        a = eNorm;
                    }
                    if (a.Ticks < Math.Min(e50.Ticks, e.Ticks))
                    {
                        TimeSpan sn50 = new TimeSpan(Math.Min(e.Ticks, e50.Ticks) - a.Ticks);
                        UEStunden50 += sn50.TotalHours;
                        a = e50;
                    }
                    if (a.Ticks < Math.Min(e100.Ticks, e.Ticks))
                    {
                        TimeSpan sn100 = new TimeSpan(Math.Min(e.Ticks, e100.Ticks) - a.Ticks);
                        UEStunden100 += sn100.TotalHours;
                    }
                }
            }
        }

        public SqlParameter Datum
        {
            get 
            { 
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        return (Params as dbAZ_ARBZEITParams).DATUM;
                    case ArbZeitType.gtAbsenz:
                        return (Params as dbAZ_KALTAGParams).DATUM;
                }
                //Muste never reach here!!!
                return (Params as dbAZ_KALTAGParams).DATUM;
            }
            set
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        (Params as dbAZ_ARBZEITParams).DATUM = value;
                        break;
                    case ArbZeitType.gtAbsenz:
                        (Params as dbAZ_KALTAGParams).DATUM = value;
                        break;
                }
            }
        }

        private DateTime lKommen = ParamVal.Date0;
        public DateTime Kommen
        {
            set
            {
                lKommen = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        (Params as dbAZ_ARBZEITParams).BEGINN.Value = lKommen;
                        //CalcWorktime();
                        break;
                }
            }
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        lKommen = Convert.ToDateTime((Params as dbAZ_ARBZEITParams).BEGINN.Value);
                        break;
                    case ArbZeitType.gtAbsenz:
                        lKommen = Arbeitstag.TagMin;
                        break;
                }
                return lKommen;
            }
        }
        private DateTime lGehen = ParamVal.Date0;
        public DateTime Gehen
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        lGehen = Convert.ToDateTime((Params as dbAZ_ARBZEITParams).ENDE.Value);
                        break;
                    case ArbZeitType.gtAbsenz:
                        lGehen = Arbeitstag.TagMax;
                        break;
                }
                return lGehen;
            }
            set
            {
                lGehen = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        (Params as dbAZ_ARBZEITParams).ENDE.Value = lGehen;
                        CalcWorktime();
                        break;
                }
            }
        }
        private double lNormStunden = 0;
        /// <summary>
        /// ARBZEIT.NORMSTD bei GK, Produktiv und Reise, alle anderen Zeittypen = 0
        /// Ausnahme STDAbsenz mit ID == 90
        /// </summary>
        public double NormStunden
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        if ((Int16)(Params as dbAZ_ARBZEITParams).NORMSTD.Value > 0)
                        {
                            double d = Convert.ToDouble((Int16)(Params as dbAZ_ARBZEITParams).NORMSTD.Value);
                            d = d / 60.0;
                            lNormStunden = d;
                        }
                        break;
                    case ArbZeitType.stdAbsenz:
                    //
                    //  CG: Defect 5024, 5082
                    // STDAbsenzdauer bei alle STD Absenzen in der Datenbank speichern
                    //
 //                       if (STDAbsenzID == STDAbsenzIDs.Ersatzruhe)
                            if ((Int16)(Params as dbAZ_ARBZEITParams).NORMSTD.Value > 0)
                            {
                                double d = Convert.ToDouble((Int16)(Params as dbAZ_ARBZEITParams).NORMSTD.Value);
                                d = d / 60.0;
                                lNormStunden = d;
                            }
                        else lNormStunden = 0;
                        break;
                    case ArbZeitType.gtAbsenz:
                        lNormStunden = (0);
                        break;
                }
                return lNormStunden;
            }
            set
            {
                lNormStunden = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        double d = lNormStunden * 60;
                        (Params as dbAZ_ARBZEITParams).NORMSTD.Value = Convert.ToInt16(d);
                        break;
                    case ArbZeitType.stdAbsenz:
                        //
                        // CG: Defect  5024, 5082
                        // STDAbsenzdauer bei alle STD Absenzen berechnen und in der Datenbank speichern
                        //
                        //if (STDAbsenzID == STDAbsenzIDs.Ersatzruhe)
                        // {
                            double x = lNormStunden * 60;
                            (Params as dbAZ_ARBZEITParams).NORMSTD.Value = Convert.ToInt16(x);
 //                       }
                        break;
                }
            }
        }
        private double lUEStunden50 = 0;
        /// <summary>
        /// ARBZEIT.USTD50 bei GK, Produktiv und Reise, alle anderen Zeittypen = 0
        /// </summary>
        public double UEStunden50
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        if ((Int16)(Params as dbAZ_ARBZEITParams).UESTD50.Value > 0)
                        {
                            double d = Convert.ToDouble((Int16)(Params as dbAZ_ARBZEITParams).UESTD50.Value);
                            d = d / 60.0;
                            lUEStunden50 = d;
                        }
                        break;
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.gtAbsenz:
                        lUEStunden50 = 0;
                        break;
                }
                return lUEStunden50;
            }
            set
            {
                lUEStunden50 = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        double d = lUEStunden50 * 60.0;
                        (Params as dbAZ_ARBZEITParams).UESTD50.Value = Convert.ToInt16(d);
                        break;
                }
            }
        }
        private double lUEStunden100 = 0;
        /// <summary>
        /// ARBZEIT.USTD100 bei GK, Produktiv und Reise, alle anderen Zeittypen = 0
        /// </summary>
        public double UEStunden100
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        if ((Int16)(Params as dbAZ_ARBZEITParams).UESTD100.Value > 0)
                        {
                            double d = Convert.ToDouble((Int16)(Params as dbAZ_ARBZEITParams).UESTD100.Value);
                            d = d / 60.0;
                            lUEStunden100 = d;
                        }
                        break;
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.gtAbsenz:
                        lUEStunden100 = 0;
                        break;
                }
                return lUEStunden100;
            }
            set
            {
                lUEStunden100 = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        double d = lUEStunden100 * 60.0;
                        (Params as dbAZ_ARBZEITParams).UESTD100.Value = Convert.ToInt16(d);
                        break;
                }
            }
        }
        private double lPause = 0;
        /// <summary>
        /// ARBZEIT.PAUSE bei GK, Produktiv und Reise, alle anderen Zeittypen = 0
        /// Ausnahme STDAbsenz mit ID == 90
        /// </summary>
        public double Pause
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        if ((Int16)(Params as dbAZ_ARBZEITParams).PAUSE.Value > 0)
                        {
                            double d = Convert.ToDouble((Int16)(Params as dbAZ_ARBZEITParams).PAUSE.Value);
                            d = d / 60.0;
                            lPause = d;
                        }
                        break;
                    case ArbZeitType.stdAbsenz:
                        // CG: Defect 5024, 5082
                        // Alle Stundenweisen Absenzen bei der Pausenberechnungen ber�cksichhtigen
                        //
                        //if (STDAbsenzID == STDAbsenzIDs.Ersatzruhe)
                        if ((Int16)(Params as dbAZ_ARBZEITParams).PAUSE.Value > 0)
                            {
                                double d = Convert.ToDouble((Int16)(Params as dbAZ_ARBZEITParams).PAUSE.Value);
                                d = d / 60.0;
                                lPause = d;
                            }
                        break;
                    case ArbZeitType.gtAbsenz:
                        lPause = 0;
                        break;
                }
                return lPause;
            }
            set
            {
                lPause = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        double d = lPause * 60.0;
                       (Params as dbAZ_ARBZEITParams).PAUSE.Value = Convert.ToInt16(d);
                        break;
                    case ArbZeitType.stdAbsenz:
                        // CG: Defect 5024, 5082
                        // Alle Stundenweisen Absenzen bei der Pausenberechnungen ber�cksichhtigen
                        //
                        //if (STDAbsenzID == STDAbsenzIDs.Ersatzruhe)
                            double x = lPause * 60.0;
                            (Params as dbAZ_ARBZEITParams).PAUSE.Value = Convert.ToInt16(x);
                        break;
                }
            }
        }
        private string lLeistart = "";
        /// <summary>
        /// ARBZEIT.LEISTART bei GK, Produktiv und Reise, alle anderen Zeittypen = ""
        /// </summary>
        public string Leistart
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        lLeistart = (Params as dbAZ_ARBZEITParams).LEISTART.Value.ToString();
                        break;
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.gtAbsenz:
                        lLeistart = "";
                        break;
                }
                return lLeistart;
            }
            set
            {
                lLeistart = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        (Params as dbAZ_ARBZEITParams).LEISTART.Value = lLeistart;
                        break;
                }
            }
        }
        private string lGKAuftragNR = "";
        /// <summary>
        /// ARBZEIT.AUFTRNR bei GK, Produktiv, StdAbsenz und Reise,  "" bei GT-Absenz
        /// </summary>
        public string GKAuftragNR
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        lGKAuftragNR = (Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString();
                        break;
                    case ArbZeitType.gtAbsenz:
                        lGKAuftragNR = "";
                        break;
                }
                return lGKAuftragNR;
            }
            set
            {
                lGKAuftragNR = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        (Params as dbAZ_ARBZEITParams).AUFTRNR.Value = lGKAuftragNR;
                        break;
                }
            }
        }
        /// <summary>
        /// readonly ARBZEIT.AUFTRNR bei Produktiv und Reise,  "" bei allen anderen Zeittypen
        /// </summary>
        public string AuftragNr
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                    case ArbZeitType.stdAbsenz:          
                    // Defect 5024, 5082
                    return (Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString();
                }
                return "";
            }
        }
        private Int16 lGTAbsenzID = 0;
        public Int16 GTAbsenzID
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        lGTAbsenzID = 0;
                        return lGTAbsenzID;
                    case ArbZeitType.gtAbsenz:
                        lGTAbsenzID = (Int16)(Params as dbAZ_KALTAGParams).GTABSENZID.Value;
                        return lGTAbsenzID;
                }
                return lGTAbsenzID;
            }
            set
            {
                lGTAbsenzID = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gtAbsenz:
                        (Params as dbAZ_KALTAGParams).GTABSENZID.Value = lGTAbsenzID;
                        break;
                }
            }
        }

        private Int16 lGTAzmNR = 0;
        public Int16 GTAzmNR
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        lGTAzmNR = 0;
                        return lGTAzmNR;
                    case ArbZeitType.gtAbsenz:
                        lGTAzmNR = (Int16)(Params as dbAZ_KALTAGParams).GTAZMNR.Value;
                        return lGTAzmNR;
                }
                return lGTAzmNR;
            }
            set
            {
                lGTAzmNR = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gtAbsenz:
                        (Params as dbAZ_KALTAGParams).GTAZMNR.Value = lGTAzmNR;
                        break;
                }
            }
        }

        private string lGTAbsenzTXT = "";
        public string GTAbsenzTXT
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        lGTAbsenzTXT = "";
                        return lGTAbsenzTXT;
                    case ArbZeitType.gtAbsenz:
                        lGTAbsenzTXT = (Params as dbAZ_KALTAGParams).GTABSENZTXT.Value.ToString();
                        return lGTAbsenzTXT;
                }
                return lGTAbsenzTXT;
            }
            set
            {
                lGTAbsenzTXT = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.gtAbsenz:
                        (Params as dbAZ_KALTAGParams).GTABSENZTXT.Value = lGTAbsenzTXT;
                        break;
                }
            }
        }
        private string lSTDAbsenzID = "";
        public string STDAbsenzID
        {
            get
            {
                switch (ZeitTyp)
                {
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        lSTDAbsenzID = (Params as dbAZ_ARBZEITParams).STDABSENZID.Value.ToString();
                        break;
                    case ArbZeitType.gtAbsenz:
                        lSTDAbsenzID = "";
                        break;
                }
                return lSTDAbsenzID;
            }
            set
            {
                lSTDAbsenzID = value;
                switch (ZeitTyp)
                {
                    case ArbZeitType.stdAbsenz:
                    case ArbZeitType.gk:
                    case ArbZeitType.produktiv:
                    case ArbZeitType.ReiseInDienstzeit:
                    case ArbZeitType.ReiseVorherNachher:
                        (Params as dbAZ_ARBZEITParams).STDABSENZID.Value = lSTDAbsenzID;
                        break;
                }
            }
        }
        public string StdAbsenzTxt
        {
            get
            {
                return SelectStdAbsenzText(STDAbsenzID);
            }
        }
        private string SelectStdAbsenzText(string StdAbID)
        {
            string StrStdAbTxt = "";
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("Select STDABSENZTXT from Y_STDABSENZ " + Config.Nolock + " where Status = 20 and STDABSENZID = @StdAbID", cnx)) // Defect 5436
                    {
                      cmd.Parameters.Add(new SqlParameter("@StdAbID", StdAbID));
                      using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                      {
                        while (rd.Read())
                        {
                          StrStdAbTxt = (string)rd.GetValue(0);
                        }
                      }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return StrStdAbTxt;
        }
        /// <summary>
        /// readonly: Ist diese ArbZeit die letzte nicht gel�schte des Arbeitstages
        /// </summary>
        public bool IstLetzteZeitdesTages
        {
            get
            {

                dbArbZeit zz = null;
                foreach (dbArbZeit z in Arbeitstag.Zeiten)
                    if (!z.Deleted) zz = z;
                return (zz == this);
            }
        }
        /// <summary>
        /// readonly: Ist diese Arbeitszeit die letzte nicht gel�schte der Woche
        /// </summary>
        public bool IstLetzteZeitderWoche
        {
            get
            {
                if (((Arbeitstag.MBericht.Tage[Arbeitstag.Tag - 1] as dbArbTag).IstLetzterArbeitstagDerWoche) &&
                    (IstLetzteZeitdesTages))
                    return true;
                return false;
            }
        }
        /// <summary>
        /// readonly: Ist diese Arbeitszeit die erste nicht gel�schte des Arbeitstages
        /// </summary>
        public bool IstErsteZeitDesTages
        {
            get
            {
                dbArbZeit zz = null;
                foreach (dbArbZeit z in Arbeitstag.Zeiten)
                    if (!z.Deleted)
                    {
                        zz = z;
                        break;
                    }
                return (zz == this);
            }
        }
        /// <summary>
        /// readonly: Ist diese Arbeitszeit vom Type ARBZEIT(=Stunden) oder KALTAG(=GT-Absenz)
        /// </summary>
        public bool IstArbeitsZeit
        {
            get
            {
                bool b = (Params is dbAZ_ARBZEITParams);
                b = (b & ((ZeitTyp == ArbZeitType.gk) | (ZeitTyp == ArbZeitType.produktiv) | (ZeitTyp == ArbZeitType.stdAbsenz)));
                return b;
            }
        }
        /// <summary>
        /// readonly: Ist diese Arbeitszeit eine Dienstreise innerhalb der Dienstzeit (nur �berpr�fung von Param und ZeitTyp)
        /// </summary>
        public bool IstReiseZeitInDZ
        {
            get
            {
                bool b = (Params is dbAZ_ARBZEITParams);
                b = (b & (ZeitTyp == ArbZeitType.ReiseInDienstzeit));
                return b;
            }
        }
        /// <summary>
        /// readonly: Ist diese Arbeitszeit eine Dienstreise au�erhalb der Dienstzeit (nur �berpr�fung von Param und ZeitTyp)
        /// </summary>
        public bool IstReiseZeitAusserDZ
        {
            get
            {
                bool b = (Params is dbAZ_ARBZEITParams);
                b = (b & (ZeitTyp == ArbZeitType.ReiseVorherNachher));
                return b;
            }
        }
    }
}
