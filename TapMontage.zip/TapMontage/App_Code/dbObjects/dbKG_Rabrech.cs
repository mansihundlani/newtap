//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbKG_Rabrech.cs
//
// Description  : Erstellung Reiseabrechnungen
//
//=============== V1.2.0013 ===============================================
//
// Date         : 02.November 2012
// Author       : Joldic Dzevad
// Defect#      : BAF xxxxxx
//                1) Fernbaustelle �ber Jahreswechsel fixed
//                2) Bearbeiter (Genehmiger) als Reisen�nderer eintragen
//=============== V1.2.0010 ===============================================
//
// Date         : 30.Juni 2011
// Author       : Joldic Dzevad
// Defect#      : BAF xxxxxx
//                Kein quartierfahrt bei monatswechsel(Teilabrechnung)
//=============== V1.2.0008 ===============================================
//
// Date         : 10.November 2010
// Author       : Joldic Dzevad
// Defect#      : BAF xxxxxx
//                AddMinute(1) bei RR nach TA wenn bei Baustelle -> Standort
//                keine Reisezeiten definiert sind.(T�gliche Reisen)
//=============== V1.2.0008 ===============================================
//
// Date         : 10.November 2010
// Author       : Joldic Dzevad
// Defect#      : BAF xxxxxx
//                AddMinute(1) bei RR nach TA wenn bei Baustelle -> Standort
//                keine Reisezeiten definiert sind.(T�gliche Reisen)
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//                Fehler bei Reisengenerierung (H auf W)
//=============== 1.2.0004 ================================================
//
// Date         : 08.April 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530037
//                Projektkontonummer wird beim Beleg nicht angezeigt. 
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== V1.0.0048 ===============================================
//
// Date         : 08.May 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-29
//                Hinreise folgt auf Hinreise - Absturz bei SAP-Reiseverarbeitung
//
//=============== V1.0.0047 ===============================================
//
// Date         : 10.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-27
//                Reise �ber Monatsgr�nze
//
//=============== V1.0.0046 ===============================================
//
// Date         : 17.Dezember 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-35
//                verschobene AZ
//
//=============== V1.0.0043 ===============================================
//
// Date         : 21.Juni 2008
// Author       : Joldic Dzevad
// Defect#      : 5981
//                Neue Reisetyp - Fernmontage ueber 120 km
//
// Date         : 10.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : 6097
//                Falsche bzw. keine RA wenn ganzt�gigen GK Stunden vorhanden sind
//
// Date         : 30.Juni 2008
// Author       : Joldic Dzevad
// Defect#      : 6108
//                Erweiterung bei finde_UZA_block
//
// Date         : 30.Juni 2008
// Author       : Joldic Dzevad
// Defect#      : 6045
//                Standortwechsel bei Baustellenwechsel wird nicht generiert
//
//=============== V1.0.0041 ===============================================
//
// Date         : 21.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6042
//                Behandlung von TA korrigiert
//
// Date         : 19.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6036
//                Server Error bei Reisegenerierung
//
// Date         : 13.Mai 2008
// Author       : Frantisek Sabol
// Defect#      : 6044
//                Reisen falsch ausbezahlt
// Defect#      : 6012
//                �nderung der Bereitstellung
//
//=============== V1.0.0040 ===============================================
//
// Date         : 30.April 2008
// Author       : Joldic Dzevad
// Defect#      : 6031
//                Keine Hinreise am ersten Tag
//
//=============== V1.0.0039 ===============================================
//
// Date         : 22.April 2008
// Author       : Joldic Dzevad
// Defect#      : 5996
//                Kostenzuordnung der Reiseauslagen
//
// Date         : 21.April 2008
// Author       : Joldic Dzevad
// Defect#      : 5899
//                EBID aus Vormonat unterdrucken, aber Kontoobjekt bleibt
//
// Date         : 17.April 2008
// Author       : Joldic Dzevad
// Defect#      : 5991
//                Aufenhaltsort ermitteln um generierung von unn�ttigen
//                SW, RR und HR zu verhindern
//
// Date         : 10.April 2008
// Author       : Joldic Dzevad
// Defect#      : 5974
//                Exceptions verhindern falls AuftragNrAt bzw. AuftragNrVor
//                einen nullpointer verwendet.
//
//=============== V1.0.0038 ===============================================
//
// Date         : 22.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : 5822
//                Exceptions verhindern falls FindeReise einen nullpointer
//                zur�ckliefert.
//
//=============== V1.0.0037 ===============================================
//
// Date         : 24.Jaenner 2008
// Author       : Norbert Krizek
// Defect#      : 5764
//                Reisebelege werden nicht nach SAP gesendet
//
// Date         : 19.J�nner 2008
// Author       : Krizek Norbert
// Defect#      : 5702
//                �nderung der Kontoinformation durch Benutzer -> falsche Nr. gespeicher
//
// Date         : 16.Jaenner 2008
// Author       : Norbert Krizek
// Defect#      : 5698
//                Fehler bei autom. Reisegenerierung wenn Vormonat nicht in TAP erfasst
//
// Date         : 10.Jaenner 2008
// Author       : Norbert Krizek
// Defect#      : 5704
//                Autom. gen. R�ckreise am Monatsanfang -> falsche Baustelle genommen
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
// Date         : 10.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5762
//                Initialisierung erg�nzt
//
// Date         : 9.Jaenner 2008
// Author       : Norbert Krizek
// Defect#      : 5696
//                Wegzeit wird bei Sonntagsreise nicht gespeichert
//
//=============== V1.0.0036 ===============================================
//
// Date         : 14.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
// Date         : 10. Dezember 2007
// Author       : NK
// Defect#      : 5701
//                Reisen �ber Mitternacht im letzten Monat--> Absturz in Reisemaske
//
// Date         : 10. Dezember 2007
// Author       : NK
// Defect#      : 5191
//                Generierung von identischen T Zeilen f�r Beginn und Ende
//
// Date         : 14. Dezember 2007
// Author       : NK
// Defect#      : 5479, 5703
//                T-Zeilen Umwandlung bei eint�gigen Urlaub  am Montag
//
//=============== V1.0.0035 ===============================================
//
// Date         : 29. November 2007
// Author       : Joldic Dzevad
// Defect#      : 5376
//                dbKG_ReiseZeileSort Compare Funktion erweitert
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
// Date         : 27. November 2007
// Author       : NK
// Defect#      : 5390
//                keine unterbrechung der reduzierung bei eint�giger reise auf andere bs
//
//
// Date         : 23. November 2007
// Author       : Georg Nebehay
// Defect#      : 5616
//                Abbruch bei "keine reise" im Einsatzbericht verhindert
//
// Date         : 23. November 2007
// Author       : Georg nebehay
// Defect#      : 3428, 5596
//                Reisezeile aus dem Vormonat jetzt korrekt bearbeitbar, GK-Auftr�ge ausw�hlbar
// Date         : 15. November 2007
// Author       : NK
// Defect#      : 5593_5604
//                9367117 Janca harald reisezeit falsch, R�ckreise Fehlt
//
// Date         : 15. November 2007
// Author       : NK
// Defect#      : 5590
//                Zulagen werden an Tagen ohne Reise nicht zur Reise abgespeichert
//
//=============== V1.0.0034 ===================================================
//
// Date         : 18. Oktober 2007
// Author       : NK
// Defect#      : 5338
//                Aenderung der Bereitstellung f�r mehr als eine Reise
//
// Date         : 15. Oktober 2007
// Author       : GN
// Defect#      : 5419
//                Beim Bearbeiten der Kontierung von Reisezeilen kamen falsche Vorbelegungen vor.
//
// Date         : 09. Oktober 2007
// Author       : NK
// Defect#      : 4944
//                W�chentliche Heimreise wurde nicht generiert: auch problem bei auto-rr bei monatsende verbessert,
//                da hier nur am freitag die rr generiert wurde - jetzt erst nach dem 2.monat auf der gleichen baustelle.   
//
//=============== V1.0.0033 ===================================================
// Date         : 12. September 2007
// Author       : NK
// Defect#      : 5430_5432
//                L�schen von reisezeilen  nach AB/an-zeit suchen
//
// Date         : 12. September 2007
// Defect#      : 5440
//                r�ckreise bzw hinreise wir in teilabrechnungen umgewandelt obwohl t�gliche entsendung
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 21. August 2007
// Author       : NK
// Defect#      : 5389
//                Reisart bei monatlicher/t�gl.entsendung falsch (R oder N bzw. D oder E
//
// Date         : 14.August 2007
// Author       : Adam Kiefer
// Defect#      : 5376
//                Sortierung der Reisen und Standortwechsel falsch
//
// Date         : 2. August 2007
// Author       : NK
// Defect#      : 5333
//                Generierung von Reisen f�r taegliche entsendung vor und nach ZA-TAG
//
// Date         : 2. August 2007
// Author       : NK
// Defect#      : 5329
//                T-Zeilen Problematik mit Reduziertem Naechtigungsgeld am Monatsanfang
// 
// Date         : 2. August 2007
// Author       : NK
// Defect#      : 5308
//                Entfernen von Standortwechsel bei �nderungen von anderen Reisezeilen
//                auch f�r wechsel bereitstellung und fahrt am dienstort
//
//--------------- V1.0.0029 --------------------------------------------------- *
// Date         : 11. Juli 2007
// Author       : NK
// Defect#      : 5242
// Generierung von Teilabrechnung - Problematik bei Urlauben
// ein paar aenderungen wg:
// - T-Zeilen und mehrere Einzelabsenzen in einem Monat (Klammerung falsch)
// - T-Zeilen und R�ckreisen an einem Tag (Reduzierung beginnt an R�ckreisetag)
// - Einzeltage entstehen durch eint�gige Absenzen (Hin- und R�ckreise wird zB. f�r Freitag nach ZA generiert) 
// - Reduzierung wird vorgenommen obwohl bereits Reduzierung vorhanden
//
// Date         : 11. Juli 2007
// Author       : NK
// Defect#      : 5243
// Modifikation von Reisen
// ein paar aenderungen wg:
// - Hinzuf�gen von Standortwechsel nicht m�glich
// - Entfernen von Standortwechsel bei �nderungen von  anderen Reisezeilen
// - L�schen der R�ckreise erzeugt keine T-Zeile
//
// Date         : 11. Juli 2007
// Author       : NK
// Defect#      : 5241
// Null Pointer Exception bei Reisezeilenpr�fung
// hier wurde die routine PruefeReiseZeilen das exception handling f�r die objekte zhin/zrck ergaenzt
//
// Date         : 10. Juli 2007
// Author       : NK
// Defect#      : 4936
// Fehlermeldung bei �berpr�fung  Reisen im Vormonat
// hier wurde die routine GetBaustelleStandort welche hier auf den vormonat zugreift gefixed

// Date         : 7. Juli 2007
// Author       : NK
// Defect#      : 5155
// Bei Teilabrechnungen sind die Beistellungen zu ber�cksichtigen.
// die initialisierung der T-Zeilen ist fix mit 0 (keine bereitstellung vorbelegt, anstatt 
// die werte von der letzten hinreise zu nehmen
// bei modifikationen bzw neuerfassungen von reisen muss der erfasste wert f�r die ganze reise ziehen
//
//--------------- V1.0.0028 --------------------------------------------------- *
// Date         : 22. Juni 2007
// Author       : GN
// Defect#      : 5150
//                Obifahrten wurden gelegentlich nicht mitgeneriert.
//
//
// Date         : 4. Juni 2007
// Author       : NK
// Defect#      : 4972
//
// Reisegenerierung bei Urlaub/ZA
// Derzeit wird bei einer Unterbrechung einer Reise durch Urlaub/Za nicht automatisch
// eine Unterbrechung generiert.
// Dieser Umstand wurde im Zuge der Gespr�che zu Defect# 4971 
//     - 'Reisegenerierung f�r Abbildung reduziertes N�chtigungsgeld Inland' 
// betrachtet und deshalb in einer Beschreibung zusammengefasst.
//
//
// Date         : 30. Mai 2007
// Author       : NK
// Defect#      : 5128
//
// Neue T�tigkeitsart(Reiseart in TAP) f�r B&I bei 7-10 km.
// Die neue T�tigkeitsart f�r Montagen im Nahbereich zwischen 7 u. 10 KM wurde mit 0 (Null) festgelegt.
//
//--------------- V1.0.0027 -----------------------------------------------------------------
//
// Date         : 25. Mai 2007
// Author       : Caleb Gebhardt
// Defect#      : 5046
//                Barauslagen mit 0 EUR werden nicht in der RAZEILE �bertragen
//
//
// Date         : 16. Mai 2007
// Author       : GN
// Defect#      : 4931
//                Eine neue Auswahlliste f�r die Anzahl der Mitfahrer wurde hinzugef�gt
//
//
// Date         : 15. Mai 2007
// Author       : GN
// Defect#      : 4479, 4618
//
// Ein Fehler wurde behoben, der zur Folge hatte, dass in der Reise�bersicht keine Reisezeilen mehr
// eingetragen werden konnten, wenn vorher schon Obifahrten eingetragen worden waren.
//
//
// Date         : 10. Mai 2007
// Author       : NK
// Defect#      : 4970
//
// Neue Reisearten f�r SAP
// F�r SAP m�ssen neue Reisearten in der Schnittstelle generiert werden laut untenstehnder Tabelle:
// RART	Reiseart, T�tigkeitsart		
//	R	au�erhalb Nahbereich, volles N�chtigungsgeld	
//	N	Reise > 25km < 120km wenn kein Hotellbeleg vorhanden (steuerfrei)	
//	D	au�erhalb Nahbereich, reduziertes N�chtigungsgeld	
//	E	Reise > 25km < 120km wenn kein Hotellbeleg vorhanden (steuerfrei)	
//
//
// Date         : 7. Mai 2007
// Author       : NK
// Defect#      : 5033
//
// Reduziertes N�chtigungsgeld nach Monatswechsel
// Durch die falsche Versorgung der Von-Bis Zeiten in den internen Reiseobjekten erfolgt die Auswertung der red.NG. 
// fehlerhaft (z.B.: Tag des Standortwechsels wird als Reiseende eingetragen)
//
//--------------- V1.0.0025 -----------------------------------------------------------------
//
// Date         : 18. April 2007
// Author       : NK
// Defect#      : 4971
//                Reisegenerierung f�r Abbildung reduziertes N�chtigungsgeld Inland (Schnelll�sung)
//
//--------------- V1.0.0024 -----------------------------------------------------------------
//
// Date         : 11. April 2007
// Author       : GN
// Defect#      : 4918
//                
// Fehlendes T bei L�schen der R�ckreise: 
// Kam dann zustande, wenn es sonst nur eine Teilabrechnung im EB vorhanden war
// Abfrage erweitert
//
//
// Date         : 10. April 2007
// Author       : GN
// Defect#      : 4715, 4719, 4720
//
// Es wurden bei Nah- und Fernmontagen f�lschlicherweise Reisen generiert,
// wenn sich bei 2 aufeinanderfolgenden Arbeitszeiten das Projekt, nicht aber
// die Baustelle ge�ndert hatte. Eine explizite �berpr�fung auf diesen Fall
// wurde eingebaut.
//
//
// Date         : 28. M�rz 2007
// Author       : CG
// Defect#      : 4378
//
// Verkehrsmittelkennzeichen TAP analog von SAP TRM
// Derzeit ist im Code die Zuordnung des Verkehrsmittels f�r
// "OBI-Fahrten fix mit dem Kennzeichen �E� codiert. 
// Soll nun, mittels eines Parameters im web.config, der Verkehrsmitteltext aus
// der Datenbank gelesen werden.
//
//--------------- V1.0.0023 -----------------------------------------------------------------
//
// Date         : 8. M�rz 2007
// Author       : GN
// Defect#      : 4698_4722_4764_4766_4778
//
// Hinreise folgt auf Hinreise, Standortwechsel unzul�ssig
// Die Zeilen, die dem letzten Monat zugeordnet werden, sich aber eigentlich noch im aktuellen Monat befinden, werdeen auch noch in ComputeSAP miteinbezogen
//
//--------------- V1.0.0022 -----------------------------------------------------------------
//
// Date         : 27. J�nner 2007
// Author       : GN
// Defect#      : 4393
//
// ComputeSAP(): 
// Es bestand die M�glichkeit, einen Standortwechsel als erste Reisezeile einzutragen. 
// Wenn der Benutzer die letzte R�ckreise l�scht, wurde bis jetzt keine Teilabrechnung gemacht. 
// Au�erdem wurde dann die letzte Reise gar nicht ber�cksichtigt.
// Teilabrechnung wird jetzt IMMER um 23:59 am Monatsende erzeugt.
//
//
// Date         : 22. Februar 2007
// Author       : GN
// Defect#      : 4626
//
// GN 22.02.2007
// Barauslagen wurden bis jetzt nur nach der Einsatzberichtsnummer den Reisen 
// zugeteilt. Umgestellt auf eine Datums�berpr�fung
// 
//
// Date         : 21. Februar 2007
// Author       : CL
// Defect#      : 4588
//
// Bei Quartierfahrten wurde als Von bzw. Nach StandortID 0 ('S0') eingetragen.
// Von und Nach werden mit dem gleichen Wert versorgt (= BauID bzw. Aufenthaltsort).
//
//
// Date         : 07. Februar 2007
// Author       : GN
// Defect#      : 4624
//
// Die erste Barauslage wurde nicht ber�cksichtigt, weil deren Datum mit dem 
// Beginn der Reise gegengecheckt wurde, die Zeit der Auslage aber auf 00:00 
// gesetzt war.
//
//--------------- V1.0.0022 -----------------------------------------------------------------
//
// Date         : 05. Februar 2007
// Author       : CG
// Defect#      : 4464, 4534 und 4669
//
// Folgende Zeiteintr�ge im EB f�hrten zum Defect# 4311, 4296 (s.o)
// 	... -> A -> A - STDAbsenz -> ...
//	... -> A -> A - STDAbsenz -> STDAbsenz
// Korrekur: Beim STD-Absenz ist die Aufragsnr SAPm�ssisg zu checken nur,
// wenn diese nicht leer ist.
//
//--------------- V1.0.0021 -----------------------------------------------------------------
//
// Date         : 03. Februar 2007
// Author       : GN
// Defect#      : 4525
//
// Defect 4525# - Monat beginnt mit R�ckreise
// Die Reisen werden jetzt vor weiterer  Bearbeitung sortiert, damit sollten
// einige weitere Probleme mit falschen Hin und R�ckreisen behoben sein.
//
//--------------- V1.0.0020 -----------------------------------------------------------------
//
// Date         : 02. Februar 2007
// Author       : GN
// Defect#      : 4507
//                Kontierung auf Kostenstelle f�r Mandant MP eingef�hrt
// 
//
// Date         : 25. J�nner 2007
// Author       : GN
// Defect#      : 4341
//                Reiseart von B&I Nahmontage auf R ge�ndert
//
//
// Date         : 25. J�nner 2007
// Author       : GN
// Defect#      : 3685, 3870, 4293
//
// �nderung der Reisegenerierung: 
// Betroffene Methoden sind GobackHome() und Getroute(). 
// Neue Methode ObiFahrten(). 
// Mit der alten Reisegenerierung war es nicht m�glich, 
// in vern�nftiger Art und Weise Baustellenwechsel zu generieren.
// Die neue Reisegenerierung zieht die letzte generierte Reisezeile in Betracht,
// weswegen keine falsche Zeilenfolge mehr Zustande kommen sollte.
// 
//
// Date         : 17. J�nner 2007
// Author       : GN
// Defect#      : 4393
//  
// ComputeSAP(): 
// Es bestand die M�glichkeit, einen Standortwechsel als erste Reisezeile einzutragen. 
// Wenn der Benutzer die letzte R�ckreise l�scht,
// wurde bis jetzt keine Teilabrechnung gemacht. Au�erdem wurde dann die letzte
// Reise gar nicht ber�cksichtigt. 
// Teilabrechnung wird jetzt IMMER um 23:59  am Monatsende erzeugt.
// 
//
// Date         : 17. J�nner 2007
// Author       : CG
// Defect#      : 4259
//
// �nderungen betreffen alle Reisezeile - Fuktionen; 
// Nachkorrektur:  F�r Mandant 'ME' od. 'MG'muss in d. Reisezeile-daten (Feld: Beschreib) 
// die Kostenstelle statt d. Auftragsnummer verwendet werden.
// R�ckreise-Generierung, wenn die Reise lang genug war (dtz. 2 Monate).
// 
//
// Date         : 19. J�nner 2007
// Author       : CG
// Defect#      : 4311, 4296
//                Auftrag nicht bebuchbar ... Fehler anzeigen, nur wenn auch andere Werte vorbelegt sind
// 
//--------------- V1.0.0017 -----------------------------------------------------------------
//
// Date         : 05. J�nner 2007
// Author       : GN
// Defect#      : 4020
//                Korrekte Bearbeitung von Nachtarbeit
// 
// Defect#      : 3987
//                Ber�cksichtigung von eingegebenen KFZ-Fahrten
//
// Defect#      : 3822
//                Fehlende Km in der Reiseabrechnung
//
// Defect#      : 3823, 3832, 4177
//                Falsche Kontierung von Reisezeilen, falsche Abfolge von Reisezeilen
//
//--------------- V1.0.0016 -----------------------------------------------------------------
//
// Date         : 10. Dezember 2006
// Author       : GN
// Defect#      : 3930
//                Bei Aufrollung des Vormonats NULL-Eintr�ge abfragen
//
//
// Date         : 14. Dezember 2006
// Author       : CG
// Defect#      : 3975
//                Generierung Reisezeilen laut RA-Matrix
//
//
// Date         : 16. Dezember 2006
// Author       : GN
// Defect#      : 3965, 3992
//                In der Reiseabrechnung wird beim Reisetyp "Montage au�erhalb Nahbereich (bis 25 km)"
//                die Reiseart �R� generiert
//
// Date         : 18. Dezember 2006
// Author       : GN
// Defect#      : 4011
//                f�r Fernmontage Reiseart = 'R' erzeugen
//
//--------------- V1.0.0015 -----------------------------------------------------------------
//
// Date         : 07. Dezember 2006
// Author       : GN
// Defect#      : 3930
//                NULL-Eintr�ge abfragen
//
//--------------- V1.0.0011 -----------------------------------------------------------------
//
// Date         : 29. November 2006
// Author       : GN
// Defect#      : 3794
//                Bei der R�ckfahrt �ber Mitternacht wird die Fahrt auf 2 Zeilen gesplittet.
//                Der Fehler war, dass bei der 2. Zeile nicht das Datum des folgenden Tages
//                eingetragen wurde. Dies wurde behoben. 
//
//--------------- V1.0.0010 -----------------------------------------------------------------
//
// Date         : 23. November 2006
// Author       : GN
// Defect#      : 3649
//                Bei der R�ckfahrt �ber Mitternacht wird die Fahrt auf 2 Zeilen gesplittet.
//            
//--------------- V1.0.0005 -----------------------------------------------------------------
//
// Date         : 08. November 2006
// Author       : CG
// Defect#      : 3593
//                OBI-Fahrt: Verkehrsmitteltext versorgen 
//
//--------------- V1.0.0005 -----------------------------------------------------------------
//
// Date         : 03. November 2006
// Author       : GN
// Defect#      : 3794
//                Die Fahrzeugart (Verkehrsmittel) und Text bei Standortwechsel versorgen
//
//
// Date         : 23. Oktober 2006
// Author       : Caleb Gebhardt
// Defect#      : 3411
//                Keinen Standortwechsel generieren, wenn Mitarbeiter auf einer
//                Baustelle auf 2 Projekten t�tig ist.
//
//--------------- V1.0.0003 -----------------------------------------------------------------
//
// Date         : 30. Oktober 2006
// Author       : Caleb Gebhardt
// Defect#      : 3425
//                Keinen Standortwechsel generieren, wenn Mitarbeiter auf einer
//                Baustelle auf zwei Projekten t�tig ist
//
//--------------- V1.0.0002 -----------------------------------------------------------------
//
// Date         : 28. Oktober 2006
// Author       : Caleb Gebhardt
// Defect#      : 3267
//                Wenn eine Reise durch einen Urlaub (bwz. generell lange Absenz)
//                unterbrochen ist, muss dies mit R und H ber�cksichtigt werden. 
//                Eine solche Absenz muss mindestens 1 Tag dauern.
//
//------------------------------------------------------------------------------------------

using System.Diagnostics;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{

    public enum dbKG_ReiseHeimfahrtTyp { taeglich = 0, woechentlich = 1, monatlich = 2 };
    public enum dbKG_ReiseZeilenTyp { Hinfahrt = 0, Rueckfahrt = 1, FahrtAmDienstort = 2, StandortWechsel = 3, Teilabrechnung = 4, WechselBereitstellung = 5, Belegzeile = 6, Barauslage = 7 };
    public enum dbKG_ReiseZielTyp { Baustelle = 0, Standort = 1, Quartier };

    public static class dbKG_ReiseZeilenKZ
    {
        public static string GetKZ(dbKG_ReiseZeilenTyp typ)
        {
            string[] ZeileKZ = new string[] { "H", "R", "K", "S", "T", "W", "L", "B" };
            return ZeileKZ[(int)typ];
        }
        public static string GetKZText(dbKG_ReiseZeilenTyp typ)
        {
            //string[] ZeileKZ = new string[] { "Hinreise", "R�ckreise", "am Dienstort", "Wechsel Standort", "Teilabrechnung", "Wechsel Bereitst.", "Belegzeile", "Barauslage" };
            //BAF 530042 - Beginn Text angepasst
            string[] ZeileKZ = new string[] { "Hinreise", "R�ckreise", "am Dienstort", "Wechsel Standort", "Teilabrechnung", "Wechsel Bereitst./Kontierung/Reiseart", "Belegzeile", "Barauslage" };
            //BAF 530042 Ende
            return ZeileKZ[(int)typ];
        }
        public static dbKG_ReiseZeilenTyp GetTyp(string KZ)
        {
            switch (KZ)
            {
                case "H": return dbKG_ReiseZeilenTyp.Hinfahrt;
                case "R": return dbKG_ReiseZeilenTyp.Rueckfahrt;
                case "K": return dbKG_ReiseZeilenTyp.FahrtAmDienstort;
                case "S": return dbKG_ReiseZeilenTyp.StandortWechsel;
                case "T": return dbKG_ReiseZeilenTyp.Teilabrechnung;
                case "W": return dbKG_ReiseZeilenTyp.WechselBereitstellung;
                case "B": return dbKG_ReiseZeilenTyp.Barauslage;
                default /*case "L"!!*/: return dbKG_ReiseZeilenTyp.Belegzeile;
            }
        }
        public static bool ZeilenFolgeValid(dbKG_ReiseZeile ZeileVorher, dbKG_ReiseZeile ZeileNachher)
        {
            if (ZeileNachher.Typ == dbKG_ReiseZeilenTyp.Barauslage || ZeileVorher.Typ == dbKG_ReiseZeilenTyp.Barauslage) return true;
            int[,] zValid = new int[7, 7]  {
                                        //        H  R  K  S  T  W  L
                                        /* H */ {11, 1, 1, 1, 1, 1, 1 },                /// 0: Nein, 1: Ja, >10 Kommt drauf an
                                        /* R */ {13,14, 1, 0, 0, 0, 1 },
                                        /* K */ {15, 0, 1, 0,16, 0, 1 },
                                        /* S */ { 0, 1, 1, 1, 1, 1, 1 },              // CG: Defect# 3975, Regel wieder aktiviert
                                        /* T */ { 0, 1, 1, 1, 1, 1, 1 }, 
                                        /* W */ { 0, 1, 0, 1, 1, 1, 1 }, ///* W */ { 0, 0, 0, 0, 0, 0, 1 }, 
                                        /* L */ {17,17,17,17,17,17, 1 } };
            switch (zValid[(int)ZeileVorher.Typ, (int)ZeileNachher.Typ])
            {
                case 0:
                    return false;
                case 1:
                    return true;
                case 11:
                case 14: //nur g�ltig wenn erste Reise um Mitternacht endet und zweite danach beginnt
                    //TAPM-29 - stimmt nicht mehr, die Reise �ber Mitternacht ist mit implementierung von SW gel�st
                    //DateTime d1 = ZeileVorher.An;
                    //DateTime d2 = ZeileNachher.Ab;
                    //TimeSpan ts = new TimeSpan(d2.Ticks - d1.Ticks);
                    //return (ts.TotalMinutes <= 1);
                    //TAPM-29 case 11 "H auf H" und case 14 "R auf R" ist grundsetzlich nicht erlaubt, keine Ausnahmen
                    return false;
                case 12:
                    return true;
                case 13:
                    return true;
                case 15:
                    return true;
                case 16:
                    return true;
                case 17:
                    return true;
            }
            return false;
        }
    }

    public class dbKG_Rabrech : Page
    {
        public const string cNullrefZT = "00:00";
        public const string ckorrZT_0000 = "00:00";
        public const string ckorrZT_0001 = "00:01";
        public const string ckorrZT_2359 = "23:59";
        public const int BAUSTELLE_OHNE_RA = 99;            // Defect 3850
        public int cAnzKalTageBisReduzierung = Convert.ToInt16(ConfigurationManager.AppSettings["RED_NG_ANZ_TAGE"].ToString());     // defect 4971 reduziertes ng anzahl der kalendertage (7.Reisetag noch ohne reduzierung) ab dem die reduzierung gilt
        public string cReiseartFERN_RED_NG = ConfigurationManager.AppSettings["ReiseartFERN_RED_NG"].ToString(); // =="D" / defect 4970: Kennzeichen der Reiseart f�r Fernmontage, reduziertes Naechtigungsgeld
        public string cReiseartNAH_RED_NG = ConfigurationManager.AppSettings["ReiseartNAH_RED_NG"].ToString();   // =="E" / defect 4970: Kennzeichen der Reiseart f�r Reise > 25km < 120km wenn kein Hotellbeleg vorhanden (steuerfrei)
        public string cReiseartNAH = ConfigurationManager.AppSettings["ReiseartNAH"].ToString();                 // =="R" / defect 4970: Kennzeichen der Reiseart f�r ausserhalb Nahbereich
        public string cReiseartFERN = ConfigurationManager.AppSettings["ReiseartFERN"].ToString();               // =="N" / defect 4970: Kennzeichen der Reiseart f�r Reise > 25km < 120km

        public enum RaStat { InArbeit = 10, Fertig = 20, Freigegeben = 30, Genehmigt = 40, Uebertragen = 80 }
        private ArrayList lDBAbRech = null;
        public ArrayList DBAbRech
        {
            set { lDBAbRech = value; }
            get
            {
                if (lDBAbRech == null)
                {
                    dbRaKopf r = new dbRaKopf(Monat.Monteur, Monat.Monat, new dbKG_Reise(this, null));
                    lDBAbRech = r.SelectAll();
                }
                return lDBAbRech;
            }
        }
        public ArrayList Reisen = null;
        public ArrayList Reisetage = null; //dbArbTage mit dbArbZeite
        public ArrayList ReisenALL = null; //  alle reisen die wir betrachten wollen...(defect 4971)
        public ArrayList ArbzeitenALL = null;  //defect 5390 public machen
        public dbKG_Monat Monat;
        public dbKG_Monat VorMonat;
        public ArrayList VorMonate = new ArrayList();
        public ArrayList Auftraege = new ArrayList();
        private bool lInitialized = false;
        public bool Initialized
        {
            get
            {
                return lInitialized;
            }
            set
            {
                lInitialized = value;
                if (!lInitialized)
                    Select(true, 0);
            }
        }
        public bool AutoGenerated = false;
        public bool KorrekturVormonat = true;
        public bool VormonatVer�ndert = false;
        public dbKG_Rabrech(dbKG_Monat monat)
        {
            Monat = monat;
            Reisen = new ArrayList();
        }

        private dbKG_ReiseHeimfahrtTyp GetReiseArt(int raTyp)
        {
            dbKG_ReiseHeimfahrtTyp enumtyp = 0;
            switch (raTyp)
            {
                case 0:              // < 10km
                case 3:              // < 25km
                case 5: enumtyp = dbKG_ReiseHeimfahrtTyp.taeglich; // 7-10km b&i
                    break;
                case 1:             // < 70km
                case 4: enumtyp = dbKG_ReiseHeimfahrtTyp.woechentlich; // < 50km
                    break;
                case 6: //Defect #5981 - neu Reisetyp 
                case 2: enumtyp = dbKG_ReiseHeimfahrtTyp.monatlich; // > 70km
                    break;
                default: enumtyp = dbKG_ReiseHeimfahrtTyp.taeglich; //Sollte nicht passieren
                    break;
            }
            return enumtyp;
        }

        //Defect 4552 - Monat beginnt mit R�ckreise
        //GN 5.2.2007
        //Das ist ein Reisensortierer, der die Variable Von zum Sortieren verwendet
        //Start
        class ReisenComparer : IComparer
        {
            public int Compare(object obj1, object obj2)
            {
                dbKG_Reise reise1 = (dbKG_Reise)obj1;
                dbKG_Reise reise2 = (dbKG_Reise)obj2;

                return DateTime.Compare(reise1.Von, reise2.Von);
            }
        }
        //Ende

        // defect beginn 4972 nicht verwendet
        // lesen der reisen aus den razeilen, welche wirklich erzeugt wurden
        //ArrayList SelectReisenMonat(DateTime berdat)
        //{
        //    ArrayList az = new ArrayList(); // Liste der Reisezeilen des Berichtsmonats

        //    // Selektion der RA Zeilen
        //    using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        //    {
        //      try
        //      {
        //        cnx.Open();
        //        // Defect 5725, Config.Rowlock eingef�hrt
        //        using (SqlCommand cmd = new SqlCommand("SELECT r.ebid, r.dat, r.an, r.ab, r.zeilenkz, " +
        //                                        "(SELECT y1.rakztxt " +
        //                                        " FROM y_rakz y1 " + Config.Rowlock +
        //                                        " WHERE y1.rakzid = 'VM' " +
        //                                        " AND y1.rakz = r.verkehrsmittel) AS vm, " +
        //                                        "(SELECT y2.rakztxt " +
        //                                        " FROM y_rakz y2 " + Config.Rowlock +
        //                                        " WHERE y2.rakzid = 'B' " +
        //                                        " AND y2.rakz = r.bereitst) AS bs, " +
        //                                        "r.gefkm, " +
        //                                        "r.beschreib, " +
        //                                        "r.reiseart " +
        //                                        "FROM razeile r " + Config.Rowlock +
        //                                        "WHERE r.ebid in " +
        //                                        "(SELECT ebid " +
        //                                        " FROM einsber " + Config.Rowlock +
        //                                        " WHERE perskey = @PERSKEY " +
        //                                        " AND DATEPART(year, bermon) = @YEAR " +
        //                                        " AND DATEPART(month, bermon) = @MONTH) " +
        //                                        " AND zeilenkz IS NOT NULL " +
        //                                        "ORDER BY r.dat", cnx)) // Defect 5436
        //        {
        //          cmd.Parameters.Add(new SqlParameter("@PERSKEY", Monat.Monteur.Params.PERSKEY.Value));
        //          cmd.Parameters.Add(new SqlParameter("@YEAR", berdat.Year));
        //          cmd.Parameters.Add(new SqlParameter("@MONTH", berdat.Month));

        //          using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436, using eingef�hrt
        //          {
        //            cmd.Parameters.Clear();

        //            while (rd.Read())
        //            {
        //              DateTime ab = new DateTime();
        //              DateTime an = new DateTime();
        //              string zeilenkz = "";
        //              string VM_text = "";
        //              string BS_text = "";
        //              string auftrnr = "";
        //              string gefkm = "";
        //              string reiseart = "";

        //              if (!rd.IsDBNull(2))
        //              {
        //                an = Convert.ToDateTime(rd.GetValue(2));
        //              }

        //              if (!rd.IsDBNull(3))
        //              {
        //                ab = Convert.ToDateTime(rd.GetValue(3));
        //              }

        //              if (!rd.IsDBNull(4))
        //              {
        //                zeilenkz = rd.GetValue(4).ToString();
        //              }

        //              if (!rd.IsDBNull(5))
        //              {
        //                VM_text = rd.GetValue(5).ToString();
        //              }

        //              if (!rd.IsDBNull(6))
        //              {
        //                BS_text = rd.GetValue(6).ToString();
        //              }

        //              if (!rd.IsDBNull(7))
        //              {
        //                gefkm = rd.GetValue(7).ToString();
        //              }

        //              if (!rd.IsDBNull(8))
        //              {
        //                auftrnr = rd.GetValue(8).ToString();
        //              }

        //              if (!rd.IsDBNull(9))
        //              {
        //                reiseart = rd.GetValue(9).ToString();
        //              }

        //              //az.Add(new dbKG_Reise (dbKG_Rabrech rAbrech, dbKG_ReiseZeile KGReiseZeile;
        //              dbKG_ReiseZeile KGReiseZeile = new dbKG_ReiseZeile(new dbKG_Reise(Monat.Rabrech, null), null);
        //              dbKG_Reise r_gef = null;  //defect 5243
        //              bool bret = Monat.Rabrech.InsertReiseZeile(KGReiseZeile, ref r_gef, true); //defect 5243
        //              /*
        //            az.Add(new Reise(rd.GetInt32(0), // ebid
        //                             rd.GetDateTime(1), // dat
        //                             0, // NormStd
        //                             ab, // ab
        //                             an, // an
        //                             zeilenkz, // zeilenkz
        //                             0, // uestd50
        //                             0, // uestd100
        //                             0, // gkstd
        //                             VM_text, // Verkehrsmittel rakztxt
        //                             auftrnr, // auftrnr
        //                             BS_text, // Bereitstellungstext
        //                             gefkm, // gefKM
        //                             reiseart // reiseart
        //                             ));*/
        //            }
        //          }
        //        }
        //      }
        //      catch (Exception ex) { throw ex; }
        //      finally { cnx.Close(); }
        //    }
        //    return az;
        //}
        // ende defect 4972

        public string Select(bool RecurseVormonat, int genMonat) //true l�dt Vormonat // defect 5390 err-text return // defect 5701 paramter f�rs aktuelle monat
        {
            Debug.WriteLine("dbKGRabrech:Select Beginn at " + DateTime.Now.ToLongTimeString());
            int c_RED_NG_ANZ_VORMONATE_laden = Convert.ToInt16(ConfigurationManager.AppSettings["RED_NG_ANZ_VORMONATE"].ToString());    // defect 4936 anzahl der kalendermonate laden vor aktuellem monat zb: akt monat = 6: 2 = lade 4,5,6 
            //BAF 530042 Beginn - nicht laden wenn es nicht notwendig ist
            if (RecurseVormonat)
            {
                c_RED_NG_ANZ_VORMONATE_laden = BerechneAnzahlderRecurseMonate();
            }
            //BAF 530042 Ende
            string ret_err_txt = "";  //defect 5390
            bool bAktMonatisBerMonat = false;  //defect 5701

            if (Initialized)
            {
                //defect 4972 loeschen von t-zeilen
                ret_err_txt = ComputeSAP(false, false, false);  // defect 5155 3. parameter  // defect 5390 err text zur�ck
                return (ret_err_txt);  // defect 5390 err text zur�ck
            }
            Reisen = new ArrayList();


            foreach (dbRaKopf k in DBAbRech) //aus DB Lesen
            {
                // hole alle RA-S�tze ( RAKOPF, RAZEILE) f�r den PERSKEY, 
                // DES VORMONATS  
                // 
                Reisen.Add(new dbKG_Reise(this, k));
                if (genMonat > 0) // defect 5701 problem reisen ins aktuelle bermonat (�ber mitternacht des monatswechsels
                {
                    if (k.Berichtsmonat == genMonat)
                    {
                        bAktMonatisBerMonat = true;
                    }
                }
                // ende defect 5701
            }
            //DateTime before = DateTime.Now;
            foreach (dbKG_Reise re in Reisen) //ArbZeit-en zuordnen
            {
                //Defect 5991 - Aufenthaltsort ermitteln
                if (re.Aufenthaltsort == 0 && re.EBID != 0)
                    re.Aufenthaltsort = GetBauIDfromEBID(re.EBID);
                try
                {
                    //Hiermit soll das laden schneller werden
                    re.Von = re.ersteHSoderT.An;
                    re.Bis = re.letzteHRoderT.Ab;
                    bool totalbreak = false;
                    int raTyp = (int)GetBaustelleStandort(Convert.ToInt32(re.letzteHRoderT.Zeile.Params.EBID.Value)).Params.RATYP.Value;
                    re.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                    if (ArbzeitenALL == null)
                        ArbzeitenALL = get_ArbzeitenALL(ArbzeitenALL);
                    foreach (dbArbTag at in ArbzeitenALL)
                    {
                        at.pauseBerechnen = false;
                        foreach (dbArbZeit az in at.Zeiten)
                        {
                            if (re.ErsteAZ == null && az.Kommen >= re.Von)
                                re.ErsteAZ = az;
                            if (az.Kommen >= re.Bis)
                            {
                                totalbreak = true;
                                break;
                            }
                            else
                                re.LetzteAZ = az;
                        }
                        if (totalbreak)
                            break;

                    }
                }
                catch
                {
                    foreach (dbMontBer m in Monat.Monteur.MBerichte)
                        if ((int)m.Params.EBID.Value == (int)re.Kopf.Params.ABRNR.Value)
                        {
                            foreach (dbArbTag t in m.Tage)
                            {
                                foreach (dbArbZeit z in t.Zeiten)
                                {
                                    if ((z.AllowUpdate) && (z.Params is dbAZ_ARBZEITParams) &&
                                        ((int)(z.Params as dbAZ_ARBZEITParams).EBID.Value == (int)m.Params.EBID.Value))
                                    {
                                        // Defect 3930
                                        // Null Eintr�ge abfragen um Absturz zu vermeiden
                                        if (re.ErsteAZ == null)
                                        {
                                            if (re.ersteHSoderT != null)
                                            {
                                                re.Von = re.ersteHSoderT.An;
                                                re.Aufenthaltsort = re.ersteHSoderT.Nach;
                                                re.Bis = re.letzteHRoderT.Ab;
                                                int raTyp = (int)GetBaustelleStandort(re.EBID).Params.RATYP.Value;
                                                re.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                                                re.ErsteAZ = z;
                                            }
                                        }
                                        re.LetzteAZ = z;
                                    }
                                }
                            }
                            break;
                        }
                }
            }
            //DateTime after = DateTime.Now;

            //Defect 4525 - Monat beginnt mit R�ckreise
            //GN 5.2.2007
            //Das ist ein Reisensortierer, der die Variable Von zum Sortieren verwendet
            //Start
            Reisen.Sort(new ReisenComparer());
            //Ende
            int anzReisen = Reisen.Count;  // defect 5701 beginn wenn wir im aktuellen ber-monat sind, dan tun wir so wie wenn es keine reisen gibt...
            if (bAktMonatisBerMonat == true)
            {
                anzReisen = 0;
            }
            //bool bAuto = ((Reisen.Count == 0) && (RecurseVormonat));
            bool bAuto = ((anzReisen == 0) && (RecurseVormonat));
            // defect 5701 ende
            if (RecurseVormonat)
            {
                int i_monat = Monat.MinDatum.Month - (c_RED_NG_ANZ_VORMONATE_laden + 1); // defect 4936 beginn nur mehr 2 monate holen
                if (i_monat < 0)
                {
                    i_monat = 0;
                }
                // defect ende 4936 nur mehr c_RED_NG_ANZ_VORMONATE_laden - monate holen

                dbBearbeiter vMonteur = null;
                /*
                for (; ; )
                {
                    i_monat++;
                    if (i_monat == Monat.MinDatum.Month)
                        break;

                    vMonteur = new dbBearbeiter((int)Monat.Monteur.Params.PERSKEY.Value);
                    vMonteur.BerichtsMonat = Monat.MinDatum.Year * 100 + i_monat;
                    VorMonat = new dbKG_Monat(vMonteur, vMonteur.BerichtsMonat);
                    VorMonat.Rabrech.Select(false, Monat.Monat);
                    VorMonate.Add(VorMonat);
                }

                vMonteur = new dbBearbeiter((int)Monat.Monteur.Params.PERSKEY.Value);
                vMonteur.BerichtsMonat = Monat.MinDatum.AddMonths(-1).Year * 100 + Monat.MinDatum.AddMonths(-1).Month;
                VorMonat = new dbKG_Monat(vMonteur, Monat.MinDatum.AddMonths(-1).Year * 100 + Monat.MinDatum.AddMonths(-1).Month);
                VorMonat.Rabrech.Select(false, Monat.Monat);*/
                // defect 4972 vormonate lesen
                //VorMonate.Add(VorMonat);
                //VorMonat.Rabrech.SelectReisenMonat(VorMonat.MinDatum);
                //BAF 530042 Beginn
                DateTime bm = Monat.MinDatum.AddMonths(-c_RED_NG_ANZ_VORMONATE_laden);
                while (bm != Monat.MinDatum)
                {
                    vMonteur = new dbBearbeiter((int)Monat.Monteur.Params.PERSKEY.Value);
                    vMonteur.BerichtsMonat = bm.Year * 100 + bm.Month;
                    VorMonat = new dbKG_Monat(vMonteur, vMonteur.BerichtsMonat);
                    VorMonat.Rabrech.Select(false, vMonteur.BerichtsMonat);
                    VorMonate.Add(VorMonat);
                    bm = bm.AddMonths(1);
                }//BAF 530042 Ende
                if (VorMonat != null)
                {
                    foreach (dbKG_Reise r in VorMonat.Rabrech.Reisen)
                    {
                        //Defect 5991 - Aufenthaltsort ermitteln
                        if (r.Aufenthaltsort == 0 && r.EBID != 0)
                            r.Aufenthaltsort = GetBauIDfromEBID(r.EBID);
                        Reisen.Add(r);
                    }
                }
            }
            if (bAuto)
            {
                // defect 5701 reisen im aktuelle monat umh�ngen auf das vormonat
                bool flg_moved = false;
                foreach (dbKG_Reise r in Monat.Rabrech.Reisen)
                {
                    foreach (dbKG_ReiseZeile z in r.Zeilen)
                    {
                        if ((z.Ab.Month == genMonat - z.Ab.Year * 100) && (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                        {
                            Reisen = new ArrayList();
                            flg_moved = true;
                            break;
                        }
                        if (flg_moved == true)
                        {
                            break;
                        }
                    }
                    if (flg_moved == true)
                    {
                        break;
                    }
                }
                /*
                if( Reisen.Count > 0)
                {
                    dbKG_Reise r =  (dbKG_Reise) Reisen[Reisen.Count-1];
                    dbKG_ReiseZeile rz = r.letzteHRoderT;
                    r.Aufenthaltsort = GetBauIDfromEBID(Convert.ToInt32(rz.Zeile.Params.EBID.Value));
                }*/

                // Reisen = new ArrayList();
                // defect 5701 ende
                //generiere Reiseabrechnung f�r aktuellen Monat automatisch weil noch nicht vorhanden
                AutoGenerated = true;
                Debug.WriteLine("dbKGRabrech:LoadFromEBs Beginn at " + DateTime.Now.ToLongTimeString());
                LoadFromEBs();
                //LoadFromEBsNew();
                Debug.WriteLine("dbKGRabrech:GetRoute Beginn at " + DateTime.Now.ToLongTimeString());
                GetRoute();
                Debug.WriteLine("dbKGRabrech:GoBackHome Beginn at " + DateTime.Now.ToLongTimeString());
                GoBackHome();

                //Defect 3685, 3870, 4293 Neuer Funktionsaufruf
                //Start
                Debug.WriteLine("dbKGRabrech:ObiFahrten Beginn at " + DateTime.Now.ToLongTimeString());
                ObiFahrten();
                //Ende
                // beg Defect 4972 aufruf stemplegen red_ng
                Debug.WriteLine("dbKGRabrech:ComputeSAP Beginn at " + DateTime.Now.ToLongTimeString());
                ret_err_txt = ComputeSAP(false, false, true);  //defect 5155 3.parameter hier werden die bereitstellungen aus den vorg�ngerreisen generiert // defect 5390 fm ausgeben
                // ende Defect 4972 aufruf stemplegen red_ng
            }
            Debug.WriteLine("dbKGRabrech:SortZeiten Beginn at " + DateTime.Now.ToLongTimeString());
            SortZeiten();
            Debug.WriteLine("dbKGRabrech:Select Ende at " + DateTime.Now.ToLongTimeString());
            return (ret_err_txt);  // defect 5390 err text zur�ck
        }
        //BAF 530042 Beginn
        private Int16 BerechneAnzahlderRecurseMonate()
        {
            Int16 ret = Convert.ToInt16(ConfigurationManager.AppSettings["RED_NG_ANZ_VORMONATE"].ToString());
            using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT TOP 1 RZ.REISEART, RZ.ZEILENKZ, bp.BAUID, bs.RATYP, k.BERMON " +
                        " FROM RAZEILE RZ " + Config.Nolock +
                        " INNER JOIN EINSBER E " + Config.Nolock + " ON E.EBID = RZ.EBID" +
                        " INNER JOIN BAUPROJEKT bp " + Config.Nolock + " ON bp.projid = e.projid" +
                        " INNER JOIN BEARBEIT b " + Config.Nolock + " ON b.perskey = @PERSKEY" +
                        " INNER JOIN BAUSTELLE_STD bs " + Config.Nolock + " ON bs.bauid = bp.bauid AND bs.STDID = b.STDSTDID" +
                        " INNER JOIN RAKOPF K " + Config.Nolock + " ON K.RAID = RZ.RAID" +
                        " WHERE RZ.RAID = (SELECT MAX(RAID) FROM RAKOPF R WHERE R.PERSKEY = @PERSKEY)" +
                        " AND RZ.ZEILENKZ IS NOT NULL ORDER BY RZ.AB DESC",cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", Monat.Monteur.Params.PERSKEY.Value));
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();
                            if (rd.HasRows && rd.Read())
                            {
                                if (!rd.IsDBNull(4)) //Bermon
                                {
                                    DateTime bm = rd.GetDateTime(4);
                                    if (Monat.MinDatum == bm.AddMonths(1)) // passt
                                    {
                                        string ra = "";
                                        string zeilenKZ = "";
                                        int ratyp = -1;
                                        if (!rd.IsDBNull(0))
                                            ra = rd.GetString(0);
                                        if (!rd.IsDBNull(1))
                                            zeilenKZ = rd.GetString(1);
                                        if (!rd.IsDBNull(3))
                                            ratyp = rd.GetInt32(3);
                                        if (zeilenKZ == "R" && ratyp != -1 && "035".Contains(ratyp.ToString()))
                                        {
                                            ret = 0; //weil letzte Reise war eine tages Reise und beendet mit eine r�ckreise
                                        }
                                        else
                                        {
                                            if ((zeilenKZ == "R" || zeilenKZ == "T") && ratyp != -1 && "01345".Contains(ratyp.ToString()))
                                            {
                                                ret = 1; //wochentliche Entsendung & T�giche Entsendung mit T am ende des Vormonats
                                            }
                                            else
                                            {
                                                if ((zeilenKZ == "R" || zeilenKZ == "T") && ratyp != -1 && "26".Contains(ratyp.ToString()) && (ra == "R" || ra == "N"))
                                                {
                                                    ret = 1; //fernmontage aber reduzierung noch nicht begonnen
                                                }
                                            }
                                        }
                                    }
                                    else
                                        ret = 0; // letzte Reise liegt nicht in Vormonat
                                }
                            }
                            rd.Close();
                        }
                    }
                }
                catch(Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
                finally
                {
                    cnx.Close();
                }
            }
            return ret;
        }
        //BAF 530042 Ende
        private ArrayList GetBaustelleBarauslagen(dbBaustelle b)
        {
            dbBarauslagen bau = new dbBarauslagen(b);
            return bau.SelectAllforBaustelle();
        }

        //private Hashtable baustelle_Barauslagen

        /// <summary>
        /// Erkennen der Reisen aus der Abfolge der Arbeitszeiten aus den EBs
        /// nur beim neu generieren
        /// </summary>
        private void LoadFromEBs()
        {
            int projid = 0;
            //int EbID = 0;
            bool wasgk = false;
            bool lastSet = false;

            if (Monat.Monteur.MBerichte.Count > 0)
            {
                dbKG_Reise r = null;
                foreach (dbArbTag t in (Monat.Monteur.MBerichte[0] as dbMontBer).Tage)
                {
                    foreach (dbArbZeit z in t.Zeiten)
                    {
                        if ((z.Kommen.Ticks != ParamVal.Date0.Ticks) & (z.AuftragNr != ""))
                            AddAuftrag(z.AuftragNr, z.Kommen);

                        if (Reisen.Count > 0 && !lastSet && z.Params is dbAZ_KALTAGParams) //Nur bei Wochentagen soll die n�chste AZ �berschrieben werden
                        {
                            (Reisen[Reisen.Count - 1] as dbKG_Reise).NachLetzteAZ = z;
                            lastSet = true;
                        }
                        //BAF 530042 Beginn Wenn STd Absenz durch den ganzen Tag erfast ist dann ist es GT Absenz
                        bool gtStdAbsenz = false;
                        if (z.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz)
                        {
                            gtStdAbsenz = true;
                            foreach (dbArbZeit az in t.Zeiten)
                            {
                                if (az.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz)
                                {
                                    gtStdAbsenz = false;
                                    break;
                                }
                            }
                        }
                        //BAF 530042 Ende
                        // Beginn Defect 3411
                        // Beginn Defect 3425
                        // Keinen Standortwechsel generieren, wenn Mitarbeiter auf einer
                        // Baustelle auf zwei Projekten t�tig ist
                        //if (z.Params is dbAZ_KALTAGParams || z.ZeitTyp == dbArbZeit.ArbZeitType.gtAbsenz) //Heimreise bei GT-Absenz
                        if (z.Params is dbAZ_KALTAGParams || z.ZeitTyp == dbArbZeit.ArbZeitType.gtAbsenz || gtStdAbsenz ) //Heimreise bei GT-Absenz
                        {
                            projid = 0;
                        }
                        else
                        {
                            if (z.Kommen.ToShortDateString() == t.TagesDatum.ToShortDateString())
                            {
                                dbMontBer mber = null; //suche den richtigen MBericht
                                foreach (dbMontBer mber2 in Monat.Monteur.MBerichte)
                                    if ((int)mber2.Params.EBID.Value == (int)(z.Params as dbAZ_ARBZEITParams).EBID.Value)
                                        mber = mber2;

                                bool gkHasChanged;

                                bool isGK = (z.ZeitTyp == dbArbZeit.ArbZeitType.gk);

                                if (wasgk != isGK)
                                    gkHasChanged = true;
                                else
                                    gkHasChanged = false;

                                //Defect #6097 - Ab V1.0.0043 keine Unterbrechung bei monatlichen und wochentlichen Reisen bei GK
                                //wir wissen nicht ob GK Arbeit auf Baustelle oder am Standort oder wo anders passiert (Einschulung ...)
                                //Falls GK auf einem anderen Standort als das Projekt ist, dann sollte man es in eigenem EB erfassen
                                if ((dbKG_ReiseHeimfahrtTyp)GetReiseArt((int)GetBaustelleStandort((int)mber.Params.EBID.Value).Params.RATYP.Value) != dbKG_ReiseHeimfahrtTyp.taeglich)
                                    gkHasChanged = false;

                                wasgk = isGK;

                                if ((int)mber.Projekt.Params.PROJID.Value != projid || gkHasChanged)
                                {
                                    lastSet = false;
                                    projid = (int)mber.Projekt.Params.PROJID.Value;
                                    //EbID = (int)(z.Params as dbAZ_ARBZEITParams).EBID.Value;
                                    r = new dbKG_Reise(this, null);
                                    dbRAKfzdaten kfz = new dbRAKfzdaten(mber);
                                    if (kfz.SelectEinsKfz(mber.Params.EBID.Value.ToString(), mber.Params.PERSKEY.Value.ToString(),
                                                          mber.Params.MANDANT.Value.ToString(), mber.Params.BERMON.Value.ToString()))
                                    {
                                        r.Kopf.Params.WAGENTYPE.Value = kfz.EingesetzterKfzTyp;
                                        r.Kopf.Params.POLKZ.Value = kfz.EingesetzterKfzPolKennz;
                                    }
                                    r.Aufenthaltsort = (int)mber.Projekt.Baustelle.Params.BAUID.Value;
                                    r.EBID = (int)mber.Params.EBID.Value;
                                    int raTyp = (int)GetBaustelleStandort(r.EBID).Params.RATYP.Value; //Wieso gibt es hier nur einen ratyp??? egal.
                                    r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);

                                    // CG- Defects 4464, 4534 und 4669
                                    // manche STD- Absenzen sind nicht m. einer Auftragsnr versehen
                                    // daher fallweise SAP-�berpr�fung zulassen
                                    //                                     
                                    if ((z.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz) || (z.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz && (z.Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString() != ""))
                                    {
                                        // ende defect 4464, 4534 und 4669
                                        string StrAuftrag = mber.Projekt.Params.KTOBJ.Value.ToString(); //BAF 530037 - merken das original KTOBJ.
                                        mber.Projekt.Params.KTOBJ.Value = (z.Params as dbAZ_ARBZEITParams).AUFTRNR.Value.ToString();
                                        if (mber.Projekt.CheckSAP())
                                        {
                                            r.IntfID = mber.Projekt.INTF_ID;
                                        }
                                        else
                                        {
                                            // CG:
                                            // Defect# 4311, 4296: AllInvalid - check eingef�hrt. Error anzeigen, wenn auch andere Werte vorbelegt sind
                                            //
                                            bool AllInvalid = mber.Projekt.Params.KTOBJ.Value.ToString() == "" &&
                                                              mber.Projekt.Params.MANDANT.Value.ToString() == "" &&
                                                              mber.Params.EBID.Value.ToString() == "" &&
                                                              mber.Bearbeiter.Params.PERSNR.Value.ToString() == "";
                                            if (!AllInvalid)
                                            {

                                                string errortxt = mber.Projekt.Params.KTOBJ.Value.ToString() + " " +
                                                                  mber.Projekt.Params.MANDANT.Value.ToString() + " " +
                                                                  mber.Params.EBID.Value.ToString() + " " +
                                                                  mber.Bearbeiter.Params.PERSNR.Value.ToString();

                                                errortxt += "Folgendes nicht bebuchbares Objekt (KTBOBJ, Mandant, EBID, PERSNR) ist diesem Einsatzbericht zugeordnet, " +
                                                            "daher Abbruch der Bearbeitung : " + errortxt;
                                                Exception ex = new Exception("Fehler in dbKG_Rabrech::LoadFromEBs:" + errortxt);
                                                throw ex;
                                            }
                                        }
                                        mber.Projekt.Params.KTOBJ.Value = StrAuftrag; //BAF 530037 - KTOBJ wiederstellen.
                                    }
                                    r.Von = z.Kommen;
                                    r.ErsteAZ = z;
                                    //Defect #5899 - ersteArbzeit im Monat ermitteln
                                    //wenn das Monat mit einer TA beginnt, dann wird dieser Reise das EBID aus Vormonat zugewiesen
                                    //Um das zu vermeinden wird EBID durch das EBID von ersten Arbzeit im Monat ersetzt.
                                    if (Monat.ersteArbzeitImMonat == null)
                                        Monat.ersteArbzeitImMonat = z;
                                    else
                                    {
                                        if (Monat.ersteArbzeitImMonat.Kommen > z.Kommen)
                                            Monat.ersteArbzeitImMonat.Kommen = z.Kommen;
                                    }
                                    //r.barAuslagen = GetBaustelleBarauslagen(mber.Projekt.Baustelle);
                                    // Defect 5991 Aufenthaltsort ermitteln
                                    if (r.Aufenthaltsort == 0 && r.EBID != 0)
                                        r.Aufenthaltsort = GetBauIDfromEBID(r.EBID);
                                    Reisen.Add(r);
                                }

                                (Reisen[Reisen.Count - 1] as dbKG_Reise).Bis = z.Gehen;
                                (Reisen[Reisen.Count - 1] as dbKG_Reise).LetzteAZ = z;
                            }
                        }
                        // Ende Defect 3411
                        // Ende Defect 3425
                    }
                }
            }
        }
        /// <summary>
        /// setzt die AB- und AN-Orte der ersten und letzten Zeilen je Reise
        /// f�gt die erste und die letzte Zeile einer Reise ein (T-H-R-S)
        ///  //Defect 3685, 3870, 4293 GetRoute komplett neu implementiert
        private void GetRoute()
        {
            ArrayList ralist = new ArrayList();
            int idx = 0;

            ArrayList bereitsVerwendeteBerichte = new ArrayList();
            ArrayList bereitsVerwendeteBaraulagen = new ArrayList();

            foreach (dbKG_Reise r in Reisen)
            {

                dbKG_Reise rv = null; //Die vorherige Reise
                if (idx > 0) rv = (dbKG_Reise)Reisen[idx - 1];
                int ratyp = Convert.ToInt16(GetBaustelleStandort(r.EBID).Params.RATYP.Value); //Art der Heimreise - monatlich etc

                // Defect 3850: neuer Reisetyp - Keine Reisegenerierung f. ratyp = BAUSTELLE_OHNE_RA
                // d.h. if - erweiterung
                if (!r.Kopf.AllowUpdate && ratyp != BAUSTELLE_OHNE_RA) //nur automatisch generierte Reisen, nix aus DB oder bei keiner Reise eingetragnars.
                {
                    // ende 3850
                    //Reise beginnen
                    if (rv == null)//wir beginnen mit einer Hinreise
                        r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), r.Von, r.IntfID, null));  // defect 5702 neuer par konto
                    else
                    {   // wir beginnen unsere Reise in Abh�ngigkeit zur vorangehenden Reise
                        dbKG_ReiseZeile vz = rv.letzteHRoderT;
                        if (vz != null)
                        {
                            // Defect #5991 - Aufenthaltsort ermitteln falls nicht vorhanden
                            try
                            {
                                if (r.Aufenthaltsort == 0)
                                    r.Aufenthaltsort = GetBauIDfromEBID(r.EBID);
                                if (rv.Aufenthaltsort == 0)
                                    rv.Aufenthaltsort = GetBauIDfromEBID(rv.EBID);
                                //rv.Aufenthaltsort = GetBauIDfromEBID(Convert.ToInt32(vz.Zeile.Params.EBID.Value));
                            }
                            catch { /* do nothing */ }
                            if (vz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            {
                                //Rollung Vormonat Teilabrechnung im Vormonat
                                if ((vz.Ab.Month != Monat.MinDatum.Month) &
                                    (rv.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich) &
                                    (rv.Aufenthaltsort != r.Aufenthaltsort) &
                                    (rv.LetzteAZ.IstLetzteZeitderWoche) &
                                    (KorrekturVormonat))
                                {
                                    /* defect 4944  mal raus mit dem zeug, dass kann die richtige routine h�chstens st�ren
                                    rv.letzteHRoderT.Zeile.Deleted = true;
                                    rv.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(rv, null), rv.LetzteAZ.Gehen,rv.IntfID));
                                    r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), r.ErsteAZ.Kommen, r.IntfID));
                                    VormonatVer�ndert = true;
                                     */
                                }
                                else
                                {
                                    DateTime leer = ParamVal.Date0;  //defect 5242:prufung bei t-zeilen wg doppelter
                                    //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), true, r.IntfID, leer, null)); //defect 5242 pr�fung doppelt-t
                                    //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                    dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), true, r.IntfID, leer, null); //defect 5242 pr�fung doppelt-t
                                    if (zt != null)
                                        r.Zeilen.Add(zt);
                                    //defect 5191 ende

                                    if (rv.Aufenthaltsort != r.Aufenthaltsort) //aha - da ist also ein Standortwechsel gewesen
                                    {
                                        r.Zeilen.Add(ZWechsel(new dbKG_ReiseZeile(r, null), rv.Aufenthaltsort, r.IntfID, null)); // defect 5702 neuer par konto
                                    }
                                    else //bleibt vor Ort
                                    {
                                        //Defect 3685, 3870, 4293 Code entfernt - verhinderte eine korrekte Reiseabrechnung
                                        //Start
                                        //r.ErsteAZ = rv.ErsteAZ; //Anreise war bereits im Vormonat -> erste AZ
                                        //Ende
                                    }
                                }
                            }
                            else
                            {
                                if (vz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                                    r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), r.Von, r.IntfID, null)); // defect 5702 neuer par konto
                                // CG: Defect# 3975
                                // elseif addiert, beim gleichbleibendem Standort T generieren
                                else
                                    if (rv.Aufenthaltsort == r.Aufenthaltsort)
                                    {
                                        r.Zeilen.Add(TWechsel(new dbKG_ReiseZeile(r, null), r.IntfID));
                                    }
                                    else
                                    {   // Beim Standortwechsel ein S generieren
                                        r.Zeilen.Add(ZWechsel(new dbKG_ReiseZeile(r, null), rv.Aufenthaltsort, r.IntfID, null)); // defect 5702 neuer par konto
                                    }
                            }
                        }
                    }

                    //Reise beenden ?
                    if (((r.LetzteAZ.IstLetzteZeitdesTages) && (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.taeglich)) ||
                        ((r.LetzteAZ.IstLetzteZeitderWoche) && (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.woechentlich)) ||
                         (r.NachLetzteAZ != null && (r.NachLetzteAZ.ZeitTyp == dbArbZeit.ArbZeitType.gtAbsenz || r.NachLetzteAZ.ZeitTyp == dbArbZeit.ArbZeitType.gk)) ||
                        // CG - �berpr�fung d. Stempel: defect #4259
                        //                       ((r.LetzteAZ.Arbeitstag.Tag == r.LetzteAZ.Arbeitstag.MBericht.Tage.Count) &&
                        ((r.LetzteAZ.Arbeitstag.Tag == r.LetzteAZ.Arbeitstag.MBericht.Tage.Count || !ZtStempelVorhandenAb(r.LetzteAZ.Arbeitstag.Tag)) &&
                        //
                         (r.LetzteAZ.IstLetzteZeitderWoche) &&
                         (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich) &&
                         (IstLangGenugDa(r, idx))))
                    {
                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), r.Bis, r.IntfID, null));
                        r.hatRueckReise = true;
                    }
                    else
                    {   //ma 3.8.06: Teilabrechnung nur am Monatsende
                        if (r == (dbKG_Reise)Reisen[Reisen.Count - 1])
                        {
                            //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null),false,r.IntfID, ParamVal.Date0, null)); //defect 5242 pr�fung doppelt-t
                            //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                            dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null); //defect 5242 pr�fung doppelt-t
                            if (zt != null)
                                r.Zeilen.Add(zt);
                            //defect 5191 ende

                        }
                    }


                    //Defect bei Reisezulagen GN 23.01.06
                    //Anscheinend wurden hier nicht alle Zulagen mitgenommen
                    dbMontBer mber = null; //suche den richtigen MBericht
                    foreach (dbMontBer mber2 in Monat.Monteur.MBerichte)
                        if ((int)mber2.Params.EBID.Value == r.EBID)
                            mber = mber2;

                    bereitsVerwendeteBerichte.Add(mber);

                    foreach (dbRAAuslage ra in mber.Reiseauslagen)
                        //Defect 4624
                        //GN 07.01.2007 Hier stand r.von <= ..., weswegen die erste Barauslage nicht mitgenommen wurde
                        if (r.ErsteAZ.Arbeitstag.TagesDatum <= (DateTime)ra.Params.DATUM.Value && (DateTime)ra.Params.DATUM.Value <= r.Bis && !bereitsVerwendeteBaraulagen.Contains(ra))
                        {
                            // Begin Defect 5046: nur Barauslagen mit Betrag gr��er als 0 zulassen
                            if (Convert.ToDouble(ra.Params.BETRAG.Value) > 0.0)
                            {
                                // Ende Defect 5046
                                r.Zeilen.Add(ZBeleg(new dbKG_ReiseZeile(r, null), ra, r.IntfID));
                                bereitsVerwendeteBaraulagen.Add(ra);
                            }
                        }
                }
                idx++;
            }
        }

        private bool IstLetzteZeitDerWoche(ArrayList Reisen, int k, int j, int i, dbArbZeit zeit)
        {

            dbArbZeit naechsteZeit = null;

            i++;

            bool found = false;

            for (; k < Reisen.Count && !found; k++)
            {
                dbKG_Reise r = (dbKG_Reise)Reisen[k];

                for (; j < r.ErsteAZ.Arbeitstag.MBericht.Tage.Count && !found; j++)
                {

                    dbArbTag t = (dbArbTag)r.ErsteAZ.Arbeitstag.MBericht.Tage[j];

                    for (; i < t.Zeiten.Count && !found; i++)
                    {
                        if (((dbArbZeit)t.Zeiten[i]).Kommen != ParamVal.Date0 && ((dbArbZeit)t.Zeiten[i]).ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz)
                        {
                            naechsteZeit = (dbArbZeit)t.Zeiten[i];
                            found = true;
                        }


                    }
                    i = 0;
                }
                j = 0;
            }

            if (naechsteZeit != null)
            {
                //Hier wird die Nummer des momentanen Wochentags gespeichert, z.b. 1 f�r Dienstag
                int wochtentag = ((int)zeit.Arbeitstag.TagesDatum.DayOfWeek + 6) % 7;
                //Hier wird die Nummer des Wochentags der n�chsten Arbeitszeit gespeichert, z.b. 0 f�r Montag
                int naechsterWochenTag = ((int)naechsteZeit.Arbeitstag.TagesDatum.DayOfWeek + 6) % 7;

                long ticks1 = zeit.Arbeitstag.TagesDatum.Ticks;
                long ticks2 = naechsteZeit.Arbeitstag.TagesDatum.Ticks;

                //Sp�testens Freitag
                if (wochtentag < 5)
                {
                    //Es muss entweder eine Woche zwischen zwei Zeiten sein oder der n�chste Wochentag liegt vor dem momentanen Wochentag
                    if (ticks1 + TimeSpan.TicksPerDay * 7 <= ticks2 || naechsterWochenTag < wochtentag) return true;
                }
                else
                {
                    //Defect 6045 nicht sp�testens Freitag, der MA kann auch am Samstag und Sonntag arbeiten
                    //wir �berpr�fen ob mindestens einen Tag zwischen den Eins�tzen vorhanden ist, erst dann
                    //beginnt das Wochenende
                    if ((ticks1 + TimeSpan.TicksPerDay) < ticks2) // es liegt einen freien Tag dazwischen
                        return true;
                }
                return false;
            }
            return true;
        }

        private bool IstLetzteZeitDesMonats(ArrayList Reisen, int k, int j, int i, dbArbZeit zeit)
        {
            dbArbZeit naechsteZeit = null;

            i++;

            bool found = false;

            for (; k < Reisen.Count && !found; k++)
            {
                dbKG_Reise r = (dbKG_Reise)Reisen[k];

                for (; j < r.ErsteAZ.Arbeitstag.MBericht.Tage.Count && !found; j++)
                {

                    dbArbTag t = (dbArbTag)r.ErsteAZ.Arbeitstag.MBericht.Tage[j];

                    for (; i < t.Zeiten.Count && !found; i++)
                    {
                        if (((dbArbZeit)t.Zeiten[i]).Kommen != ParamVal.Date0 && ((dbArbZeit)t.Zeiten[i]).ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz)
                        {
                            naechsteZeit = (dbArbZeit)t.Zeiten[i];
                            found = true;
                        }


                    }
                    i = 0;
                }
                j = 0;
            }

            if (naechsteZeit != null)
            {
                return false;
            }
            return true;
        }

        private dbKG_ReiseZeile LetzteReiseZeile(ArrayList Reisen, int k)
        {

            bool found = false;

            for (; k >= 0 && !found; k--)
            {
                dbKG_Reise r = (dbKG_Reise)Reisen[k];
                //Reisen[k-1]letzteHRoderT
                if (r.Zeilen.Count > 0 && ((dbKG_ReiseZeile)r.Zeilen[r.Zeilen.Count - 1]).Typ != dbKG_ReiseZeilenTyp.Belegzeile)
                {
                    //return (dbKG_ReiseZeile)r.Zeilen[r.Zeilen.Count - 1]; //defect 5329: das muss nicht die letzte reisezeile sein
                    if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                        return r.letzteHRSWoderT; //BAN 500059
                    else
                        return r.letzteHRoderT;     //defect 5329: wir ermittel die letzte zeile 
                }
            }
            return null;

        }


        /// <summary>
        /// Hier werden die restlichen Hinreisen, R�ckreisen und Standortwechsel generiert
        /// </summary>
        //Defect 3823, 3832
        //GN 5.1.2007
        //Reisezeilen wurden auf die falsche Kontonummer kontiert
        private void GoBackHome()
        {

            dbArbZeit letzteBearbeiteteArbeitsZeit = null;

            int letzteReiseZeit = 0;


            bool letzteZeitVonAndererReise = false;
            bool naechsteZeitVonAndererReise = false;
            bool monatsWechsel = false;
            int naechsteReiseZeit = 0;
            int letzteBauid = -1;
            int reiseZeitRRplusHR = 0; //Defect #6045 - Reisezeit BAU1 -> Standort -> BAU2


            dbBaustelleStandort diesebaustelle_naechsteBaustelle = null;
            dbBaustelleStandort letzteBaustelle_diesebaustelle = null;

            //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
            //in Sessionvariable wird gespeichert das letztes Aufenhaltsort aus Vormonat
            Session["letztesAufenhaltsort"] = "";

            for (int k = 0; k < Reisen.Count; k++)
            {
                dbKG_Reise r = (dbKG_Reise)Reisen[k];



                int ratyp = Convert.ToInt16(GetBaustelleStandort(r.EBID).Params.RATYP.Value);

                // Defect 3850: neuer Reisetyp - Keine Reisegenerierung f. ratyp = BAUSTELLE_OHNE_RA
                // d.h. if - erweiterung
                if (!r.Kopf.AllowUpdate && ratyp != BAUSTELLE_OHNE_RA) //nur automatisch generierte Reisen, nix aus DB
                {
                    // ende 3850!

                    dbBaustelleStandort quartier = GetQuartier(r.EBID);
                    dbBaustelleStandort bs = GetBaustelleStandort(r.EBID);
                    int bauid = GetBauIDfromEBID(r.EBID);
                    int reiseZeit = (int)bs.Params.REISEZEIT.Value;


                    bool gibtNaechsteReise = false;

                    int naechsteBauid = -1;


                    if (k < Reisen.Count - 1) gibtNaechsteReise = true;

                    if (gibtNaechsteReise)
                    {
                        dbBaustelleStandort bs2 = GetBaustelleStandort(((dbKG_Reise)Reisen[k + 1]).EBID);
                        naechsteReiseZeit = (int)bs2.Params.REISEZEIT.Value;
                        naechsteBauid = GetBauIDfromEBID(((dbKG_Reise)Reisen[k + 1]).EBID);
                        diesebaustelle_naechsteBaustelle = GetBaustelleZuBaustelle(r.EBID, ((dbKG_Reise)Reisen[k + 1]).EBID);
                    }


                    //Workaround: Alle Hin-und R�ckfahrten wieder entfernen, die aus GetRoute sind unbrauchbar

                    ArrayList toDelete = new ArrayList();

                    foreach (dbKG_ReiseZeile z in r.Zeilen)
                    {
                        if (z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt || z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt || z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel || z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            toDelete.Add(z);
                    }

                    foreach (dbKG_ReiseZeile z in toDelete)
                    {
                        r.Zeilen.Remove(z);
                    }


                    for (int j = 0; j < r.ErsteAZ.Arbeitstag.MBericht.Tage.Count; j++)
                    {
                        dbArbTag t = (dbArbTag)r.ErsteAZ.Arbeitstag.MBericht.Tage[j];
                        if ((t.Tag >= r.ErsteAZ.Arbeitstag.Tag) & (t.Tag <= r.LetzteAZ.Arbeitstag.Tag))
                        {



                            for (int i = 0; i < t.Zeiten.Count; i++)
                            {

                                dbArbZeit momentanBearbeiteteArbZeit = (dbArbZeit)t.Zeiten[i];

                                if (momentanBearbeiteteArbZeit.ZeitTyp == dbArbZeit.ArbZeitType.stdAbsenz) continue;


                                //In MBericht.Tage stehen die Zeiten f�r ALLE Reisen drin -> Fehlergefahr
                                if (!(momentanBearbeiteteArbZeit.Kommen < r.LetzteAZ.Gehen)) continue; //Die momentan bearbeitete Zeit darf nicht sp�ter sein als die letzte Zeit der Reise
                                if (!(momentanBearbeiteteArbZeit.Gehen > r.ErsteAZ.Kommen)) continue; //Vice versa f�r erste


                                if (letzteBearbeiteteArbeitsZeit == null)
                                {
                                    int m = k - 1; //Index f�r vorige Reise
                                    if (m != -1)
                                    {
                                        letzteBearbeiteteArbeitsZeit = ((dbKG_Reise)Reisen[m]).LetzteAZ;
                                        letzteZeitVonAndererReise = true;
                                        monatsWechsel = false;
                                        if (letzteBearbeiteteArbeitsZeit.Arbeitstag.TagesDatum.Month != momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.Month)
                                        {
                                            monatsWechsel = true;
                                            if ((momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.Month - letzteBearbeiteteArbeitsZeit.Arbeitstag.TagesDatum.Month) > 1)
                                            {
                                                monatsWechsel = false;
                                            }
                                        }
                                    }
                                }

                                dbArbZeit naechsteZuBearbeitendeArbeitsZeit = null;

                                for (int x = i + 1; x < t.Zeiten.Count; x++)
                                {
                                    if (((dbArbZeit)t.Zeiten[x]).ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz)
                                    {
                                        naechsteZuBearbeitendeArbeitsZeit = (dbArbZeit)t.Zeiten[x];
                                        naechsteZeitVonAndererReise = false;
                                        if (naechsteZuBearbeitendeArbeitsZeit.Kommen > r.LetzteAZ.Kommen)
                                        {
                                            naechsteZeitVonAndererReise = true;
                                            break; //Defect# 6045 - break fehlt 
                                        }
                                    }
                                }

                                if (naechsteZuBearbeitendeArbeitsZeit == null) //heute keine vern�nftigen zeiten mehr dagewesen
                                {

                                    int l = j + 1; //Z�hler f�r Tage

                                    //Suche die n�chste Arbeitszeit in MBericht.Tage
                                    //Wenn in diesem Monatsbericht keine Zeit mehr kommt, bleibt naechsteZuBearbeitendeArbeitsZeit auf null
                                    while (l < r.ErsteAZ.Arbeitstag.MBericht.Tage.Count)
                                    {
                                        dbArbTag tag = (dbArbTag)r.ErsteAZ.Arbeitstag.MBericht.Tage[l];

                                        dbArbZeit arbZeit = (dbArbZeit)tag.Zeiten[0];
                                        // wird m�glich erweitert !!!!
                                        /*
                                        foreach( dbArbZeit arbzeit in tag.Zeiten)
                                        {
                                            if( arbzeit.ZeitTyp != dbArbZeit.ArbZeitType.stdAbsenz )
                                            {
                                                arbZeit = arbzeit;
                                                break;
                                            }
                                            else
                                                arbZeit = null;
                                        }*/
                                        //if (arbZeit != null && arbZeit.Kommen != ParamVal.Date0) //Irgendein wahnsinniger hat sich ausgedacht, dass auch an freien Tagen eine Arbeitszeit mit kommen/gehen auf 1.1.1900 gesetzt ist.
                                        if (arbZeit.Kommen != ParamVal.Date0) //Irgendein wahnsinniger hat sich ausgedacht, dass auch an freien Tagen eine Arbeitszeit mit kommen/gehen auf 1.1.1900 gesetzt ist.
                                        {
                                            naechsteZuBearbeitendeArbeitsZeit = arbZeit;
                                            naechsteZeitVonAndererReise = false;
                                            if (naechsteZuBearbeitendeArbeitsZeit.Kommen > r.LetzteAZ.Kommen)
                                                naechsteZeitVonAndererReise = true;
                                            break;
                                        }
                                        l++;
                                    }
                                }

                                if (naechsteZuBearbeitendeArbeitsZeit == null)
                                {//Momentane Zeit war also die letzte Zeit der Reise
                                    int m = k + 1; //Index f�r n�chste Reise
                                    if (m != Reisen.Count)
                                    {
                                        naechsteZuBearbeitendeArbeitsZeit = ((dbKG_Reise)Reisen[m]).ErsteAZ;
                                        naechsteZeitVonAndererReise = true;
                                    }
                                }



                                if (momentanBearbeiteteArbZeit.Params is dbAZ_ARBZEITParams) //Das hei�t anscheinend produktiver Arbeitstag
                                {
                                    int reiseZeitDanach = 0;

                                    if (naechsteZeitVonAndererReise)
                                    {
                                        reiseZeitDanach = naechsteReiseZeit;
                                    }
                                    else
                                    {
                                        reiseZeitDanach = reiseZeit;
                                    }


                                    if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.taeglich)
                                    {

                                        dbKG_ReiseZeile zeile = LetzteReiseZeile(Reisen, k);
                                        // defect 4944 beginn: merken der letzten reisezeile der vorg�ngerreise
                                        dbKG_ReiseZeile zeile_vorher = null;
                                        dbKG_Reise r_vorher = null;

                                        if (k - 1 >= 0)
                                        {
                                            r_vorher = (dbKG_Reise)Reisen[k - 1];
                                            zeile_vorher = LetzteReiseZeile(Reisen, k - 1);
                                            try
                                            {
                                                r_vorher.Aufenthaltsort =
                                                    GetBauIDfromEBID(Convert.ToInt32(zeile_vorher.Zeile.Params.EBID.Value));
                                            }
                                            catch
                                            {
                                            }
                                        }
                                        // defect 4944 ende
                                        // Defect #5991 Aufenthaltsort ermitteln falls nicht vorhanden
                                        try
                                        {
                                            if (r.Aufenthaltsort == 0)
                                                r.Aufenthaltsort = GetBauIDfromEBID(r.EBID);
                                            if (r_vorher.Aufenthaltsort == 0)
                                                r_vorher.Aufenthaltsort = GetBauIDfromEBID(r_vorher.EBID);
                                            //r_vorher.Aufenthaltsort = GetBauIDfromEBID(Convert.ToInt32(zeile_vorher.Zeile.Params.EBID.Value));
                                        }
                                        catch { /* do nothing */ }
                                        if (zeile != null && zeile.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                                        {
                                            if (monatsWechsel)
                                            {
                                                // defect 4944 beginn auto-rr bei baustelenwechsel
                                                if ((r_vorher != null) && (zeile_vorher != null) && (r.Aufenthaltsort != r_vorher.Aufenthaltsort))
                                                {
                                                    //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), true, r_vorher.IntfID, ParamVal.Date0, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));
                                                    //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                    dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r_vorher, null), true, r_vorher.IntfID, ParamVal.Date0, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString());  //defect 5704
                                                    if (zt != null)
                                                        r.Zeilen.Add(zt);
                                                    //defect 5191 ende
                                                    r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r_vorher, null), Monat.MinDatum, r_vorher.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString())); //defect 5704
                                                    r_vorher.ebidAusVormonat = false; //defect #5899
                                                    r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), r.ErsteAZ.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                                }
                                                else
                                                {
                                                    //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), true, r.IntfID, ParamVal.Date0, null)); //defect 5242 pr�fung doppelt-t
                                                    //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                    dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), true, r.IntfID, ParamVal.Date0, null); //defect 5242 pr�fung doppelt-t
                                                    if (zt != null)
                                                        r.Zeilen.Add(zt);
                                                    //defect 5191 ende
                                                    //TAPM-27 Beginn
                                                    //Pr�fe ob R�ckreise im Vormonat begonnen hat
                                                    if (r_vorher.LetzteAZ != null)
                                                    {
                                                        try
                                                        {
                                                            if (r_vorher.LetzteAZ.Gehen.AddMinutes(1) == r.ErsteAZ.Kommen)
                                                            {
                                                                //arbeit wird �ber Monatsgr�nze fortgesetzt 
                                                            }
                                                            else
                                                            {
                                                                //wir schreiben die R�ckreise
                                                                //BAF xxxxx - wenn Reisezeit 0 ist, dann beginnt und endet die RR um 23:59 genau wie TA
                                                                //und somit, nach sortieren, wird RR vom TA angeh�ngt was bei ComputeSAP die Meldung
                                                                //"Reise beginnt mit R�ckreise" FM ausgibt. Editieren kann man auch nicht weil es im 
                                                                //diese Zeile im Vormonat liegt. 
                                                                if (Convert.ToInt32(GetBaustelleStandort(r.EBID).Params.REISEZEIT.Value) == 0)
                                                                    zeile_vorher = ZRueck(new dbKG_ReiseZeile(r, null), r_vorher.LetzteAZ.Gehen.AddMinutes(1), r.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString());
                                                                else
                                                                    zeile_vorher = ZRueck(new dbKG_ReiseZeile(r, null), r_vorher.LetzteAZ.Gehen, r.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString());
                                                                r.Zeilen.Add(zeile_vorher);
                                                                //r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), r_vorher.LetzteAZ.Gehen, r.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));
                                                            }
                                                        }
                                                        catch
                                                        {
                                                        }
                                                    }//TAPM-27 Ende
                                                    r.ebidAusVormonat = false; //defect #5899
                                                    /*
                                                     * Hier muss noch ein defect erfasst sein
                                                     * t�gliche entsendung + arbeit �ber mitternacht + �ber monatsgr�nze
                                                    if (momentanBearbeiteteArbZeit.Arbeitstag.Tag == 1 // erster im Monat
                                                        && momentanBearbeiteteArbZeit.Kommen.ToString("t").Equals(cNullrefZT) ) // begin AZ um 00:00
                                                    {
                                                       // Es ist ein Arbeit �ber Mitternacht und Monatwechsel
                                                    }
                                                    else
                                                       // falls der Vormonat mit eine Teilabrechnung abgeschlossen ist und 
                                                       // in neuen Monat am ersten um 00:00 keine Arbeit eingetragen ist, wird nun 
                                                       // eine R�ckreise generiert
                                                       r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r_vorher, null), Monat.MinDatum, r_vorher.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));
                                                    */
                                                }
                                                // defect 4944 ende
                                                monatsWechsel = false;
                                            }
                                        }
                                        if (letzteBearbeiteteArbeitsZeit == null) //Hier fehlt noch der Fall, dass im letzten Monat eine Teilbrechnung gewesen sein k�nnte (was aber bl�d w�re)
                                        {
                                            r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                        }
                                        else
                                        {
                                            long spanne = momentanBearbeiteteArbZeit.Kommen.Ticks - letzteBearbeiteteArbeitsZeit.Gehen.Ticks;
                                            spanne = spanne / (60 * 1000 * 1000 * 10); //->minuten

                                            if (!letzteZeitVonAndererReise)
                                            { //Also von der selben Reise
                                                if (spanne >= 2 * reiseZeit)
                                                {
                                                    r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                                }
                                            }
                                            else
                                            { //Von einer anderen Reise
                                                if (letzteBaustelle_diesebaustelle != null)
                                                {
                                                    //Defect #6045 - ist spanne kleiner als Reise BAUA1 -> Standort -> Bau2 ?
                                                    if (spanne <= reiseZeitRRplusHR)
                                                    {
                                                        //damit es zu keine �berschneidungen der AZ/RZ kommt
                                                        letzteBaustelle_diesebaustelle.Params.REISEZEIT.Value = spanne;
                                                        //nun generieren wir ein Standortwechsel zwischen 2 Baustellen
                                                        r.Zeilen.Add(WechselBaustelle(new dbKG_ReiseZeile(r, null), letzteBaustelle_diesebaustelle, "55", momentanBearbeiteteArbZeit));
                                                    }
                                                    else
                                                    {
                                                        //falls die spanne gr�sser ist, dann haben wir schon RR generiert und nun generiren wir eine neu HR
                                                        r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null));
                                                    }
                                                    letzteBaustelle_diesebaustelle = null;
                                                    /*
                                                    if (momentanBearbeiteteArbZeit.Arbeitstag.Tag != letzteBearbeiteteArbeitsZeit.Arbeitstag.Tag)
                                                    {//Wenn verschiedene Tage, trotzdem Heimreise
                                                        r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                                    }
                                                    else
                                                    {
                                                        r.Zeilen.Add(ZWechsel(new dbKG_ReiseZeile(r, null), ((dbKG_Reise)Reisen[k - 1]).Aufenthaltsort, ((dbKG_Reise)Reisen[k - 1]).IntfID, null)); // defect 5702 neuer par konto
                                                    }*/

                                                }
                                                else
                                                {
                                                    //Defect #6045 - verhindern 2 Hinreisen aufeinander zu generieren
                                                    bool zeileVorherIstHinreise = false;
                                                    try
                                                    {
                                                        if (zeile_vorher.Typ == dbKG_ReiseZeilenTyp.Hinfahrt || zeile_vorher.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung
                                                            || zeile_vorher.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung) //BAF 530042 - Damit keine H auf W generiert werden sollte
                                                            zeileVorherIstHinreise = true;
                                                    }
                                                    catch
                                                    {
                                                    }
                                                    //Defect 4715, 4719, 4720
                                                    //GN 10.4.2007
                                                    //Hinreise zur Baustelle soll nur erfolgen, wenn der Arbeiter noch nicht dort ist oder ein Tag dazwischen liegt.
                                                    if (!zeileVorherIstHinreise &&
                                                        (letzteBauid != bauid || letzteBearbeiteteArbeitsZeit.Arbeitstag.Tag != momentanBearbeiteteArbZeit.Arbeitstag.Tag ||
                                                        //Defect #6045 - Eine zweite HR am selben Tag - ist legitim
                                                        (letzteBauid == bauid && letzteBearbeiteteArbeitsZeit.Arbeitstag.Tag == momentanBearbeiteteArbZeit.Arbeitstag.Tag)))
                                                    {
                                                        /*
                                                        * Hier muss noch ein defect erfasst sein
                                                        * t�gliche entsendung + arbeit �ber mitternacht + �ber monatsgr�nze
                                                        if (momentanBearbeiteteArbZeit.Arbeitstag.Tag == 1 // erster in dem Monat
                                                            && momentanBearbeiteteArbZeit.Kommen.ToString("t").Equals(cNullrefZT) // begin AZ um 00:00
                                                            && r.Zeilen.Count == 1) // TeilAbrechnug generiert
                                                        {
                                                            // dann soll Hinreise nicht generiert werden
                                                        }
                                                        else
                                                         */
                                                        //Defect #5991 - die HR ist schon beim Monatswechsel hinzuf�gt
                                                        //Hinzuf�gen neu HR nur wenn kein Monatswechsel statgefunden hat
                                                        //if (r.Zeilen.Count == 0)
                                                        //    r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                                        //else
                                                        //{
                                                        //Defect #6031 Beginn
                                                        try
                                                        {
                                                            if ((r.Zeilen[r.Zeilen.Count - 1] as dbKG_ReiseZeile).Typ != dbKG_ReiseZeilenTyp.Hinfahrt)
                                                                r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null));
                                                        }
                                                        catch
                                                        {
                                                            //Count = 0
                                                            r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null));
                                                        }
                                                        //Defect #6031 Ende
                                                        //}
                                                    }
                                                }
                                            }
                                        }

                                        // Pr�fen ob Reisengenerierung f�r n�chste Arbziet notwendig ist
                                        bool keineReiseGenerierung = false;
                                        try
                                        {
                                            if (GetBaustelleStandort(Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value)).Params.RATYP.Value.ToString() == BAUSTELLE_OHNE_RA.ToString())
                                                keineReiseGenerierung = true;
                                        }
                                        catch
                                        {
                                            //nothing
                                        }
                                        if (naechsteZuBearbeitendeArbeitsZeit == null || keineReiseGenerierung)
                                        {
                                            //TAPM-27 Pr�fen ob AZ bis Ende des Monats dauert (23:59)
                                            //falls letzte Tag des Monats ist und gehen um 23:59 dann d wird das n�chste Monat 00:00
                                            DateTime d = momentanBearbeiteteArbZeit.Gehen.AddMinutes(1);
                                            if (d.Month == momentanBearbeiteteArbZeit.Gehen.Month || keineReiseGenerierung) //wie bisher
                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                            else
                                            {
                                                // wir schreiben TA am ende des Monats
                                                dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, momentanBearbeiteteArbZeit.Gehen, ckorrZT_2359);
                                                if (zt != null)
                                                    r.Zeilen.Add(zt);
                                            }
                                        }
                                        else
                                        {
                                            long spanne = naechsteZuBearbeitendeArbeitsZeit.Kommen.Ticks - momentanBearbeiteteArbZeit.Gehen.Ticks;
                                            spanne = spanne / (60 * 1000 * 1000 * 10); //->minuten

                                            if (!naechsteZeitVonAndererReise)
                                            { //Also von der selben Reise
                                                if (spanne >= 2 * reiseZeit)
                                                {
                                                    r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                }
                                            }
                                            else
                                            { //Von einer anderen Reise
                                                if (diesebaustelle_naechsteBaustelle != null) //Es gibt einen Standortwechsel zur n�chsten Baustelle
                                                {
                                                    //Defect #6045 - ist spanne zwischen 2 Arbeitszeiten kleiner als reisezeit Bau1->Standort->Bau2
                                                    if (spanne <= reiseZeit + naechsteReiseZeit)
                                                    {
                                                        //falls ja, ein standortwechsel zwischen 2 Baustellen generieren
                                                        letzteBaustelle_diesebaustelle = diesebaustelle_naechsteBaustelle;
                                                        reiseZeitRRplusHR = reiseZeit + naechsteReiseZeit;
                                                    }
                                                    else
                                                    {
                                                        //kein SW generieren, sondern RR, bei bearbeitung von naechsteZuBearbeitendeArbeitsZeit wird auch HR generiert
                                                        letzteBaustelle_diesebaustelle = null;
                                                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                    }
                                                    /*ansonst RR und HR
                                                    if (momentanBearbeiteteArbZeit.Arbeitstag.Tag != naechsteZuBearbeitendeArbeitsZeit.Arbeitstag.Tag)
                                                    { //Wenn verschiedene Tage, auf jeden Fall Hinreise
                                                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                    }
                                                    //Ansonsten nix, der Standortwechsel wird von der n�chsten Baustelle erzeugt. (Hoffentlich)
                                                     */
                                                }
                                                else
                                                { //Es gibt keinen eingetragenen Standortwechsel
                                                    //Defect 4715, 4719, 4720
                                                    //GN 10.4.2007
                                                    //R�ckreise von Baustelle soll nur erfolgen, wenn es eine andere Baustelle ist oder oder ein Tag dazwischen liegt.
                                                    if (naechsteBauid != bauid || naechsteZuBearbeitendeArbeitsZeit.Arbeitstag.Tag != momentanBearbeiteteArbZeit.Arbeitstag.Tag)
                                                    {
                                                        //Defect #6045 - sollen wir einen Standortwechsel generieren ?
                                                        if (spanne <= reiseZeit + naechsteReiseZeit)
                                                        {
                                                            if (momentanBearbeiteteArbZeit.Params is dbAZ_ARBZEITParams &&
                                                                naechsteZuBearbeitendeArbeitsZeit.Params is dbAZ_ARBZEITParams)
                                                            {
                                                                //wir generieren einen automatischen Standortwechsel
                                                                letzteBaustelle_diesebaustelle = new dbBaustelleStandort(GetBaustelleByBAUID(bauid), null);

                                                                // daten von der alte Baustelle
                                                                int ebid = Convert.ToInt32((momentanBearbeiteteArbZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                letzteBaustelle_diesebaustelle.Params.BAUID.Value = GetBauIDfromEBID(ebid);

                                                                // daten von der neue Baustelle
                                                                ebid = Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                dbBaustelleStandort bstd = GetBaustelleStandort(ebid);
                                                                letzteBaustelle_diesebaustelle.Params.BAUID_STDW.Value = bstd.Params.BAUID.Value;
                                                                letzteBaustelle_diesebaustelle.Params.REISEZEIT.Value = spanne;
                                                                letzteBaustelle_diesebaustelle.EinsatzTyp = (int)dbBaustelleStandort.Einsatz.BaustZuBaust;
                                                                letzteBaustelle_diesebaustelle.RAKZ_BTEXT = bstd.RAKZ_BTEXT;
                                                                letzteBaustelle_diesebaustelle.RAKZ_VMTEXT = bstd.RAKZ_VMTEXT;
                                                                letzteBaustelle_diesebaustelle.Params.RAKZ_B.Value = bstd.Params.RAKZ_B.Value;
                                                                letzteBaustelle_diesebaustelle.Params.RAKZ_VM.Value = bstd.Params.RAKZ_VM.Value;
                                                                //letzteBaustelle_diesebaustelle.Baustelle = GetBaustelleByBAUID(GetBauIDfromEBID(ebid));
                                                                letzteBaustelle_diesebaustelle.Params.RATYP.Value = bstd.Params.RATYP.Value;
                                                                reiseZeitRRplusHR = reiseZeit + naechsteReiseZeit;
                                                            }
                                                            else
                                                            {
                                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                                letzteBaustelle_diesebaustelle = null;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                            letzteBaustelle_diesebaustelle = null;
                                                        }
                                                    }
                                                    else
                                                    {//BAN 500059 WBNeu wenn kontierung auf seleber Baustelle ge�ndert wird
                                                        if (naechsteBauid == bauid &&
                                                            naechsteZuBearbeitendeArbeitsZeit.Arbeitstag.Tag == momentanBearbeiteteArbZeit.Arbeitstag.Tag &&
                                                            Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                                        {
                                                            //BAF 530042 - Beginn - R generieren wenn spanne zwischen Eins�tzen l�nger als R+H ist
                                                            if (spanne >= reiseZeit + naechsteReiseZeit && spanne != 0)
                                                            {
                                                                //dann muss R�ckreise her
                                                                letzteBaustelle_diesebaustelle = null;
                                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                            }//BAF 530042 Ende
                                                            else
                                                            {
                                                                try
                                                                {
                                                                    if (GetKontObjfromEBID(Convert.ToInt32((momentanBearbeiteteArbZeit.Params as dbAZ_ARBZEITParams).EBID.Value)) !=
                                                                        GetKontObjfromEBID(Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value)))
                                                                    {
                                                                        //hier sollte wechsel der bereitstellung wegen konto �nderung
                                                                        dbKG_ReiseZeile z = ZHin(new dbKG_ReiseZeile(r, null), naechsteZuBearbeitendeArbeitsZeit.Kommen, r.IntfID, null);
                                                                        z.Ab = z.An;
                                                                        z.Zeile.Params.VERKEHRSMITTEL.Value = "";
                                                                        z.Zeile.Params.RAKZTXT.Value = "";
                                                                        z.Zeile.Params.GEFKM.Value = "";
                                                                        z.Zeile.Params.EBID.Value = Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                        z = ZBWechselNeu(z, "88");
                                                                        r.Zeilen.Add(z);
                                                                    }
                                                                }
                                                                catch
                                                                {
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.woechentlich)
                                    {
                                        if (letzteBearbeiteteArbeitsZeit == null) //Hier fehlt noch der Fall, dass im letzten Monat eine Teilbrechnung gewesen sein k�nnte (was aber bl�d w�re)
                                        {
                                            r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                        }

                                        dbKG_ReiseZeile zeile = LetzteReiseZeile(Reisen, k);
                                        // defect 4944 beginn: merken der letzten reisezeile der vorg�ngerreise
                                        dbKG_ReiseZeile zeile_vorher = null;
                                        dbKG_Reise r_vorher = null;

                                        if (k - 1 >= 0)
                                        {
                                            r_vorher = (dbKG_Reise)Reisen[k - 1];
                                            zeile_vorher = LetzteReiseZeile(Reisen, k - 1);
                                            try
                                            {
                                                r_vorher.Aufenthaltsort =
                                                    GetBauIDfromEBID(Convert.ToInt32(zeile_vorher.Zeile.Params.EBID.Value));
                                            }
                                            catch
                                            {
                                            }
                                        }
                                        // defect 4944 ende
                                        // Defect #5991 Aufenthaltsort ermitteln falls nicht vorhanden
                                        try
                                        {
                                            if (r.Aufenthaltsort == 0)
                                                r.Aufenthaltsort = GetBauIDfromEBID(r.EBID);
                                            if (r_vorher.Aufenthaltsort == 0)
                                                r_vorher.Aufenthaltsort = GetBauIDfromEBID(r_vorher.EBID);
                                        }
                                        catch { /* do nothing */ }
                                        //Defect 5616
                                        if (zeile == null)
                                        {
                                            r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                        }
                                        else
                                            switch (zeile.Typ)
                                            {
                                                case dbKG_ReiseZeilenTyp.Rueckfahrt:
                                                    r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                                    break;
                                                case dbKG_ReiseZeilenTyp.Teilabrechnung:
                                                    if (monatsWechsel)
                                                    {
                                                        try
                                                        {
                                                            //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
                                                            //wir merken uns wo wir im Vormonat waren
                                                            dbBaustelle baustelle = GetBaustelleByBAUID(r_vorher.Aufenthaltsort);
                                                            Session["letztesAufenhaltsort"] = baustelle.Params.PLZ.Value.ToString() + " " + baustelle.Params.ORT.Value.ToString();
                                                        }
                                                        catch
                                                        {
                                                        }
                                                        // defect 4944 beginn auto-rr bei baustelenwechsel
                                                        if ((r_vorher != null) && (zeile_vorher != null) && (r.Aufenthaltsort != r_vorher.Aufenthaltsort))
                                                        {
                                                            //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), true, r_vorher.IntfID, ParamVal.Date0, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));
                                                            //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                            dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r_vorher, null), true, r_vorher.IntfID, ParamVal.Date0, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString());  //defect 5704
                                                            if (zt != null)
                                                                r.Zeilen.Add(zt);
                                                            //defect 5191 ende
                                                            r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r_vorher, null), Monat.MinDatum, r_vorher.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));  //defect 5704
                                                            r_vorher.ebidAusVormonat = false; //defect #5899
                                                            r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), r.ErsteAZ.Kommen, r.IntfID, null)); // defect 5702 neuer par konto

                                                        }
                                                        else
                                                        {
                                                            //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), true, r.IntfID, ParamVal.Date0, null));
                                                            //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                            dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), true, r.IntfID, ParamVal.Date0, null);
                                                            if (zt != null)
                                                                r.Zeilen.Add(zt);
                                                            //defect 5191 ende
                                                            r.ebidAusVormonat = false; //defect #5899
                                                            //TAPM-27 Beginn
                                                            //Pr�fe ob R�ckreise im Vormonat begonnen hat
                                                            if (r_vorher.LetzteAZ != null)
                                                            {
                                                                foreach (dbKG_ReiseZeile rzeile in r_vorher.Zeilen)
                                                                {
                                                                    if (rzeile.Ab == r_vorher.LetzteAZ.Gehen &&
                                                                        rzeile.Typ == dbKG_ReiseZeilenTyp.StandortWechsel &&
                                                                        rzeile.Zeile.Params.INTF_ID.Value.ToString() == "73" &&
                                                                        rzeile.An.ToShortTimeString() == ckorrZT_2359)
                                                                    {
                                                                        //nun ist R�ckreise im Vormonat begonen
                                                                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), r_vorher.LetzteAZ.Gehen, r.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));
                                                                        break;
                                                                    }
                                                                }
                                                            }//TAPM-27 Ende
                                                        }
                                                        // defect 4944 ende
                                                        monatsWechsel = false;
                                                    }
                                                    if (quartier != null)
                                                    {
                                                        r.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Kommen, quartier, r.IntfID));
                                                    }
                                                    break;
                                                case dbKG_ReiseZeilenTyp.StandortWechsel:
                                                    if (quartier != null)
                                                    {
                                                        r.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Kommen, quartier, r.IntfID));
                                                    }
                                                    break;
                                            }

                                        if (naechsteZuBearbeitendeArbeitsZeit == null)
                                        {
                                            //Hier sind wir augenscheinlich am Monatsende gelandet -> R�ckreise / [Quartier] - Teilabrechung
                                            //r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID));
                                            //Defect 4467 - Jetzt Heimreise am freitag, samstag sonntag
                                            if (momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek == DayOfWeek.Friday || momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek == DayOfWeek.Saturday || momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek == DayOfWeek.Sunday)
                                            {
                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                            }
                                            else
                                            {
                                                if (quartier != null)
                                                {
                                                    r.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Gehen, quartier, r.IntfID));
                                                }

                                                //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null));//defect 5242 pr�fung doppelt-t
                                                //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null);//defect 5242 pr�fung doppelt-t
                                                if (zt != null)
                                                    r.Zeilen.Add(zt);
                                                //defect 5191 ende
                                            }
                                        }
                                        else
                                        {
                                            //Defect #6045 - SW definiert ?
                                            if (letzteBaustelle_diesebaustelle != null)
                                            {
                                                long spanne = momentanBearbeiteteArbZeit.Kommen.Ticks - letzteBearbeiteteArbeitsZeit.Gehen.Ticks;
                                                spanne = spanne / (60 * 1000 * 1000 * 10); //->minuten
                                                if (spanne <= reiseZeitRRplusHR) // Convert.ToInt32(letzteBaustelle_diesebaustelle.Params.REISEZEIT.Value))
                                                {
                                                    //damit es zu keine �berschneidungen der AZ/RZ kommt
                                                    letzteBaustelle_diesebaustelle.Params.REISEZEIT.Value = spanne;
                                                    //nun generieren wir ein Standortwechsel zwischen 2 Baustellen
                                                    r.Zeilen.Add(WechselBaustelle(new dbKG_ReiseZeile(r, null), letzteBaustelle_diesebaustelle, "55", momentanBearbeiteteArbZeit));
                                                }
                                                //else
                                                //{
                                                //    r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null));
                                                //}
                                                letzteBaustelle_diesebaustelle = null;
                                                reiseZeitRRplusHR = 0;
                                            }

                                            bool wochenEnde = IstLetzteZeitDerWoche(Reisen, k, j, i, momentanBearbeiteteArbZeit);
                                            // Pr�fen ob Reisengenerierung f�r n�chste Arbziet notwendig ist
                                            bool keineReiseGenerierung = false;
                                            try
                                            {
                                                if (GetBaustelleStandort(Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value)).Params.RATYP.Value.ToString() == BAUSTELLE_OHNE_RA.ToString())
                                                    keineReiseGenerierung = true;
                                            }
                                            catch
                                            {
                                                //nothing
                                            }
                                            // Defect 3267
                                            if (naechsteZuBearbeitendeArbeitsZeit.Params is dbAZ_KALTAGParams || wochenEnde || keineReiseGenerierung)
                                            {
                                                // Defect 3267 - 
                                                //if (naechsteZuBearbeitendeArbeitsZeit.Params is dbAZ_KALTAGParams || keineReiseGenerierung)
                                                //    r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                //else
                                                    //if (quartier != null)
                                                    //{
                                                    //    r.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Gehen, quartier, r.IntfID));
                                                    //}
                                                    //else
                                                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                            }
                                            else
                                            {
                                                if (!naechsteZeitVonAndererReise)
                                                {
                                                    //Also von der selben Reise
                                                    //Wieder Quartierfahrt bzw. Rueckfahrt vor Wochenende / Absenz
                                                    //Defect 4449: GN 29.01.07 Abfrage auf Sonntag hinzugef�gt
                                                    //Defect 4467 - Jetzt Heimreise am freitag, samstag sonntag
                                                    if (IstLetzteZeitDerWoche(Reisen, k, j, i, momentanBearbeiteteArbZeit))// || 
                                                    //momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek == DayOfWeek.Friday || 
                                                    //momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek == DayOfWeek.Saturday ||
                                                    //momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek == DayOfWeek.Sunday) 
                                                    //k = Reisenindex, j = Tagindex, i = Zeitindex
                                                    {
                                                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                    }
                                                    else
                                                    {
                                                        //Quartierfahrt
                                                        if (quartier != null) //Nur ein Standortwechsel, wenn genug Zeit dazwischen ist
                                                        {
                                                            r.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Gehen, quartier, r.IntfID));
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    //Von einer anderen Reise
                                                    if (naechsteBauid == bauid)
                                                    {
                                                        if (quartier != null)
                                                        {
                                                            r.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Gehen, quartier, r.IntfID));
                                                        }
                                                        else
                                                        {//BAN 500059 WBNeu wenn kontierung auf seleber Baustelle ge�ndert wird
                                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                                            {
                                                                try
                                                                {
                                                                    if (GetKontObjfromEBID(Convert.ToInt32((momentanBearbeiteteArbZeit.Params as dbAZ_ARBZEITParams).EBID.Value)) !=
                                                                        GetKontObjfromEBID(Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value)))
                                                                    {
                                                                        //hier sollte wechsel der bereitstellung wegen konto �nderung
                                                                        dbKG_ReiseZeile z = ZHin(new dbKG_ReiseZeile(r, null), naechsteZuBearbeitendeArbeitsZeit.Kommen, r.IntfID, null);
                                                                        z.Ab = z.An;
                                                                        z.Zeile.Params.VERKEHRSMITTEL.Value = "";
                                                                        z.Zeile.Params.RAKZTXT.Value = "";
                                                                        z.Zeile.Params.GEFKM.Value = "";
                                                                        z.Zeile.Params.EBID.Value = Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                        z = ZBWechselNeu(z, "88");
                                                                        r.Zeilen.Add(z);
                                                                    }
                                                                }
                                                                catch
                                                                {
                                                                }
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        //Defect #6045 - sollen wir ein SW generiern ?
                                                        long spanne = naechsteZuBearbeitendeArbeitsZeit.Kommen.Ticks - momentanBearbeiteteArbZeit.Gehen.Ticks;
                                                        spanne = spanne / (60 * 1000 * 1000 * 10); //->minuten
                                                        if (diesebaustelle_naechsteBaustelle != null) //Es gibt keinen Standortwechsel zur n�chsten Baustelle
                                                        {
                                                            //ist spanne zwischen AZ kleiner als RZ RR + HR
                                                            if (spanne <= reiseZeit + naechsteReiseZeit)
                                                            {
                                                                // ein standortwechsel zwischen 2 Baustellen
                                                                letzteBaustelle_diesebaustelle = diesebaustelle_naechsteBaustelle;
                                                                reiseZeitRRplusHR = reiseZeit + naechsteReiseZeit;
                                                            }
                                                            else
                                                            {
                                                                //ansonst RR genrieren, sp�ter wird HR zur neue Basstelle 
                                                                letzteBaustelle_diesebaustelle = null;
                                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                            }
                                                            /*
                                                            if (momentanBearbeiteteArbZeit.Arbeitstag.Tag != naechsteZuBearbeitendeArbeitsZeit.Arbeitstag.Tag)
                                                            { //Wenn verschiedene Tage, auf jeden Fall Hinreise
                                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                            }*/
                                                            //Ansonsten nix, der Standortwechsel wird von der n�chsten Baustelle erzeugt. (Hoffentlich)
                                                        }
                                                        else
                                                        { //Es gibt keinen eingetragenen Standortwechsel
                                                            if (spanne <= reiseZeit + naechsteReiseZeit)
                                                            {
                                                                if (momentanBearbeiteteArbZeit.Params is dbAZ_ARBZEITParams)
                                                                {
                                                                    //wir generieren einen automatischen Standortwechsel
                                                                    letzteBaustelle_diesebaustelle = new dbBaustelleStandort(GetBaustelleByBAUID(bauid), null);
                                                                    // daten von der alte Baustelle
                                                                    int ebid = Convert.ToInt32((momentanBearbeiteteArbZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                    letzteBaustelle_diesebaustelle.Params.BAUID.Value = GetBauIDfromEBID(ebid);
                                                                    // daten von der neue Baustelle
                                                                    ebid = Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                    dbBaustelleStandort bstd = GetBaustelleStandort(ebid);
                                                                    letzteBaustelle_diesebaustelle.Params.BAUID_STDW.Value = bstd.Params.BAUID.Value;
                                                                    letzteBaustelle_diesebaustelle.Params.REISEZEIT.Value = spanne;
                                                                    letzteBaustelle_diesebaustelle.EinsatzTyp = (int)dbBaustelleStandort.Einsatz.BaustZuBaust;
                                                                    letzteBaustelle_diesebaustelle.RAKZ_BTEXT = bstd.RAKZ_BTEXT;
                                                                    letzteBaustelle_diesebaustelle.RAKZ_VMTEXT = bstd.RAKZ_VMTEXT;
                                                                    letzteBaustelle_diesebaustelle.Params.RAKZ_B.Value = bstd.Params.RAKZ_B.Value;
                                                                    letzteBaustelle_diesebaustelle.Params.RAKZ_VM.Value = bstd.Params.RAKZ_VM.Value;
                                                                    //letzteBaustelle_diesebaustelle.Baustelle = GetBaustelleByBAUID(GetBauIDfromEBID(ebid));
                                                                    letzteBaustelle_diesebaustelle.Params.RATYP.Value = bstd.Params.RATYP.Value;
                                                                    reiseZeitRRplusHR = reiseZeit + naechsteReiseZeit;
                                                                }
                                                                else
                                                                {
                                                                    r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                                    letzteBaustelle_diesebaustelle = null;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                                letzteBaustelle_diesebaustelle = null;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich)
                                    {


                                        if (letzteBearbeiteteArbeitsZeit == null) //Hier fehlt noch der Fall, dass im letzten Monat eine Teilbrechnung gewesen sein k�nnte (was aber bl�d w�re)
                                        {
                                            r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                        }

                                        dbKG_ReiseZeile zeile = LetzteReiseZeile(Reisen, k);
                                        // defect 4944 beginn: merken der letzten reisezeile der vorg�ngerreise
                                        dbKG_ReiseZeile zeile_vorher = null;
                                        dbKG_Reise r_vorher = null;

                                        if (k - 1 >= 0)
                                        {
                                            r_vorher = (dbKG_Reise)Reisen[k - 1];
                                            zeile_vorher = LetzteReiseZeile(Reisen, k - 1);
                                            try
                                            {
                                                r_vorher.Aufenthaltsort =
                                                    GetBauIDfromEBID(Convert.ToInt32(zeile_vorher.Zeile.Params.EBID.Value));
                                            }
                                            catch
                                            {
                                            }
                                        }
                                        // defect 4944 ende
                                        // Defect #5991 Aufenthaltsort ermitteln falls nicht vorhanden ist
                                        try
                                        {
                                            if (r_vorher.Aufenthaltsort == 0)
                                                r_vorher.Aufenthaltsort = GetBauIDfromEBID(r_vorher.EBID);
                                            if (r.Aufenthaltsort == 0)
                                                r.Aufenthaltsort = GetBauIDfromEBID(r.EBID);
                                        }
                                        catch { /* do nothing */ }
                                        if (zeile == null) //d.h. es gibt keine Reisezeilen im Vormonat, was legitim ist
                                        {
                                            r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                        }
                                        else switch (zeile.Typ)
                                            {
                                                case dbKG_ReiseZeilenTyp.Rueckfahrt:
                                                    r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Kommen, r.IntfID, null)); // defect 5702 neuer par konto
                                                    break;
                                                case dbKG_ReiseZeilenTyp.Teilabrechnung:
                                                    if (monatsWechsel)
                                                    {
                                                        //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
                                                        //wir merken uns wo wir im Vormonat waren
                                                        try
                                                        {
                                                            dbBaustelle baustelle = GetBaustelleByBAUID(r_vorher.Aufenthaltsort);
                                                            Session["letztesAufenhaltsort"] = baustelle.Params.PLZ.Value.ToString() + " " + baustelle.Params.ORT.Value.ToString();
                                                        }
                                                        catch
                                                        {
                                                        }
                                                        // defect 4944 beginn auto-rr bei baustelenwechsel
                                                        if ((r_vorher != null) && (zeile_vorher != null) && (r.Aufenthaltsort != r_vorher.Aufenthaltsort))
                                                        {
                                                            //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), true, r_vorher.IntfID, ParamVal.Date0, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));
                                                            //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                            dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r_vorher, null), true, r_vorher.IntfID, ParamVal.Date0, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString());  //defect 5704
                                                            if (zt != null)
                                                                r.Zeilen.Add(zt);
                                                            //defect 5191 ende
                                                            r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r_vorher, null), Monat.MinDatum, r_vorher.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));  //defect 5704
                                                            r_vorher.ebidAusVormonat = false; //defect #5899
                                                            r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), r.ErsteAZ.Kommen, r.IntfID, null)); // defect 5702 neuer par konto

                                                        }
                                                        else
                                                        {
                                                            //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), true, r.IntfID, ParamVal.Date0, null));//defect 5242 pr�fung doppelt-t
                                                            //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                            dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), true, r.IntfID, ParamVal.Date0, null);//defect 5242 pr�fung doppelt-t
                                                            if (zt != null)
                                                                r.Zeilen.Add(zt);
                                                            //defect 5191 ende
                                                            r.ebidAusVormonat = false; //defect #5899                                                            
                                                            //TAPM-27 Beginn
                                                            //Pr�fe ob R�ckreise im Vormonat begonnen hat
                                                            if (r_vorher.LetzteAZ != null)
                                                            {
                                                                foreach (dbKG_ReiseZeile rzeile in r_vorher.Zeilen)
                                                                {
                                                                    if (rzeile.Ab == r_vorher.LetzteAZ.Gehen &&
                                                                        rzeile.Typ == dbKG_ReiseZeilenTyp.StandortWechsel &&
                                                                        rzeile.Zeile.Params.INTF_ID.Value.ToString() == "73" &&
                                                                        rzeile.An.ToShortTimeString() == ckorrZT_2359)
                                                                    {
                                                                        //nun ist R�ckreise im Vormonat begonen
                                                                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), r_vorher.LetzteAZ.Gehen, r.IntfID, r_vorher.letzteHRoderT.Zeile.Params.BESCHREIB.Value.ToString()));
                                                                        break;
                                                                    }
                                                                }
                                                            }//TAPM-27 Ende
                                                        }

                                                        // defect 4944 ende
                                                        monatsWechsel = false;
                                                    }
                                                    else //Kein quartier bei monatswechsel, daher else
                                                        if (quartier != null)
                                                        {
                                                            r.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Kommen, quartier, r.IntfID));
                                                        }
                                                    break;
                                                case dbKG_ReiseZeilenTyp.StandortWechsel:
                                                    if (quartier != null)
                                                    {
                                                        try
                                                        {
                                                            if (momentanBearbeiteteArbZeit.Kommen.Date != letzteBearbeiteteArbeitsZeit.Gehen.Date)
                                                                r.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Kommen, quartier, r.IntfID));
                                                        }
                                                        catch
                                                        {
                                                            r.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Kommen, quartier, r.IntfID));
                                                        }
                                                    }
                                                    break;
                                                case dbKG_ReiseZeilenTyp.WechselBereitstellung:
                                                    if (quartier != null)
                                                    {
                                                        //man muss noch schauen was hier kommen sollte
                                                        /*try
                                                        {
                                                            if (momentanBearbeiteteArbZeit.Kommen.Date != letzteBearbeiteteArbeitsZeit.Gehen.Date)
                                                                r.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Kommen, quartier, r.IntfID));
                                                        }
                                                        catch
                                                        {
                                                            r.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Kommen, quartier, r.IntfID));
                                                        }*/
                                                    }
                                                    break;

                                            }


                                        if (naechsteZuBearbeitendeArbeitsZeit == null) // Augenscheinlich Monatsende
                                        {
                                            //if (momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek == DayOfWeek.Friday) //im zuge von 4944: das macht keinen sinn, anhand des zufaeliigen fallens auf einen freitag eine r�ckresie oder teilabrechnugn zu generieren....
                                            // im zuge von 4944: wir pr�fen, ob wir im vormonat auch auf der gleichen baustelle schon waren, dann generieren wir mal die r�ckreise
                                            // sonst ein T
                                            // BAN 500059 Beginn - Ist eine GT Absenz im Monat vorhanden, dann wird automatisch Reise beendet und eine neue angelegt. Dadurch ist
                                            // wird beendete Resie als r_vorher gesehen was automatich zur R�ckreise f�hrt. Wir brauchen zus�tzlich die Abfrage ob Hinreise im Vormonat begonnen ist
                                            // daf�r ist monatsWechsel2 implementiert + es m�sssen weitere checks gemacht werden, brauche aber mehr Zeit
                                            if ((r_vorher != null) && (zeile_vorher != null) && (r.Aufenthaltsort == r_vorher.Aufenthaltsort)) //&& monatsWechsel2)
                                            {
                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                            }
                                            else
                                            {
                                                if (quartier != null)
                                                {
                                                    r.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Gehen, quartier, r.IntfID));
                                                }

                                                //defect 5191 r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null));//defect 5242 pr�fung doppelt-t
                                                //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null);//defect 5242 pr�fung doppelt-t
                                                if (zt != null)
                                                    r.Zeilen.Add(zt);
                                                //defect 5191 ende

                                            }
                                        }
                                        else
                                        {
                                            if (letzteBaustelle_diesebaustelle != null)
                                            {
                                                //Defect #6045 - ein SW ist definiert
                                                long spanne = momentanBearbeiteteArbZeit.Kommen.Ticks - letzteBearbeiteteArbeitsZeit.Gehen.Ticks;
                                                spanne = spanne / (60 * 1000 * 1000 * 10); //->minuten

                                                //hier werden wir versuchen zu finden an welche AZ soll das SW angeh�ngt
                                                long testSpanne = 0;
                                                bool WBanletzteBearbeiteteArbeitsZeit = false; //bei default mit kommenden AZ
                                                try
                                                {
                                                    if (spanne > reiseZeitRRplusHR &&  //spanne gr�sser als RR + HR
                                                        r_vorher.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich) // vorhiger reise muss monatlich sein
                                                    {
                                                        testSpanne = spanne;
                                                        DateTime dtn = momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum;
                                                        DateTime dtm = letzteBearbeiteteArbeitsZeit.Arbeitstag.TagesDatum;
                                                        if (dtn != dtm) //wenn mindestens ein tag dazwischen liegt
                                                        {
                                                            dbAZTag azTag = (dbAZTag)Monat.Monteur.AZModell.AZTage[(int)letzteBearbeiteteArbeitsZeit.Arbeitstag.TagesDatum.DayOfWeek];
                                                            DateTime dt = Convert.ToDateTime(azTag.Params.AZ_Ende.Value); // wann ist AZ Ende
                                                            if (Convert.ToDateTime(dt.ToShortTimeString()) <= Convert.ToDateTime(letzteBearbeiteteArbeitsZeit.Gehen.ToShortTimeString()))
                                                            {
                                                                dt = letzteBearbeiteteArbeitsZeit.Gehen; // passt der MA arbeitet bis AZ_Ende
                                                            }
                                                            else
                                                                WBanletzteBearbeiteteArbeitsZeit = true; // Aha ... sein Arbeit endet vor AZ_Ende, hier k�nnte SW beginnen

                                                            testSpanne -= (24 * 60) - (dt.Hour * 60 - dt.Minute);
                                                            dtm = dtm.AddDays(1);
                                                            while (dtn > dtm)
                                                            {
                                                                //BAF 530042 - AZMKalenderTage ersetzen AZM aufrufe
                                                                if (!Monat.Monteur.AZMKalenderTage.ContainsKey(dtm))
                                                                {
                                                                    if( !Monat.Monteur.AZMKalenderTage[dtm].IstArbeitstag )
                                                                        testSpanne -= 24 * 60;
                                                                }//BAF 530042 Ende
                                                                else
                                                                if (!Monat.Monteur.IstArbeitstag(dtm)) //wochenende oder feiertag eliminieren
                                                                    testSpanne -= 24 * 60;
                                                                dtm = dtm.AddDays(1);
                                                            }
                                                            azTag = (dbAZTag)Monat.Monteur.AZModell.AZTage[(int)momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek];
                                                            dt = Convert.ToDateTime(azTag.Params.AZ_Begin.Value); // hier soll lt. AZM das Arbeit beginnen
                                                            if (Convert.ToDateTime(dt.ToShortTimeString()) >= Convert.ToDateTime(momentanBearbeiteteArbZeit.Kommen.ToShortTimeString()))
                                                            {
                                                                dt = momentanBearbeiteteArbZeit.Kommen; // der Arbeit beginnt rechtzeitig
                                                            }
                                                            else
                                                                WBanletzteBearbeiteteArbeitsZeit = false; // der Arbeit beginnt nach AZ_Begin - SW wird an diese AZ angeh�ngt

                                                            testSpanne -= dt.Hour * 60 + dt.Minute;

                                                        }
                                                        if (testSpanne > 0)
                                                            spanne = testSpanne; // neue spanne - ohne WE
                                                        else
                                                            testSpanne = 0; // ist was falsch gelaufen, wir setzten alle zur�ck
                                                    }
                                                }
                                                catch
                                                {
                                                    //do nothing
                                                }
                                                if (spanne <= reiseZeitRRplusHR)
                                                {
                                                    //damit es zu keine �berschneidungen der AZ/RZ kommt
                                                    if (testSpanne == 0)
                                                        letzteBaustelle_diesebaustelle.Params.REISEZEIT.Value = spanne;
                                                    //nun generieren wir ein Standortwechsel zwischen 2 Baustellen - von welchen AZ wird durch Intf_Id gesteuert
                                                    if (WBanletzteBearbeiteteArbeitsZeit)
                                                        r.Zeilen.Add(WechselBaustelle(new dbKG_ReiseZeile(r, null), letzteBaustelle_diesebaustelle, "54", letzteBearbeiteteArbeitsZeit));
                                                    else
                                                        r.Zeilen.Add(WechselBaustelle(new dbKG_ReiseZeile(r, null), letzteBaustelle_diesebaustelle, "55", momentanBearbeiteteArbZeit));
                                                }
                                                letzteBaustelle_diesebaustelle = null;
                                                reiseZeitRRplusHR = 0;
                                            }
                                            // Pr�fen ob Reisengenerierung f�r n�chste Arbziet notwendig ist
                                            bool keineReiseGenerierung = false;
                                            try
                                            {
                                                if (GetBaustelleStandort(Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value)).Params.RATYP.Value.ToString() == BAUSTELLE_OHNE_RA.ToString())
                                                    keineReiseGenerierung = true;
                                            }
                                            catch
                                            {
                                                //nothing
                                            }
                                            // Defect 3267 - 
                                            if (naechsteZuBearbeitendeArbeitsZeit.Params is dbAZ_KALTAGParams ||//) //Das hei�t ganzt�gige Absenz
                                                keineReiseGenerierung)
                                            {
                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                            }
                                            else
                                            {
                                                if (!naechsteZeitVonAndererReise)
                                                {
                                                    //Also von der selben Reise
                                                    //Wieder Quartierfahrt bzw. Rueckfahrt vor Wochenende / Absenz
                                                    if (IstLetzteZeitDesMonats(Reisen, k, j, i, momentanBearbeiteteArbZeit)) //k = Reisenindex, j = Tagindex, i = Zeitindex
                                                    {
                                                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                    }
                                                    else
                                                    {
                                                        //Quartierfahrt
                                                        if (quartier != null)
                                                        {
                                                            r.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Gehen, quartier, r.IntfID));
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    //Von einer anderen Reise
                                                    //if (quartier != null && naechsteZuBearbeitendeArbeitsZeit.Kommen.Date != momentanBearbeiteteArbZeit.Gehen.Date)
                                                    //{
                                                    //    r.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Gehen, quartier, r.IntfID));
                                                    //SW oder RR fehlt ????

                                                    //}
                                                    //else
                                                    //{
                                                    if (diesebaustelle_naechsteBaustelle != null) //Es gibt keinen Standortwechsel zur n�chsten Baustelle
                                                    {
                                                        long spanne = naechsteZuBearbeitendeArbeitsZeit.Kommen.Ticks - momentanBearbeiteteArbZeit.Gehen.Ticks;
                                                        spanne = spanne / (60 * 1000 * 1000 * 10); //->minuten
                                                        //nun versuchen wir wochenende zu eliminieren,
                                                        long testSpanne = 0;
                                                        try
                                                        {
                                                            //zu viele Abfragen ... muss try/ catch hier
                                                            dbBaustelleStandort neuStandOrt = GetBaustelleStandort(Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value));
                                                            if (spanne > reiseZeit + naechsteReiseZeit &&
                                                                 Convert.ToInt32(diesebaustelle_naechsteBaustelle.Params.REISEZEIT.Value) > 0 &&
                                                                 GetReiseArt(Convert.ToInt32(neuStandOrt.Params.RATYP.Value)) == dbKG_ReiseHeimfahrtTyp.monatlich) // n�chste reise muss auch monatlich sein
                                                            {
                                                                testSpanne = spanne;
                                                                DateTime dtn = naechsteZuBearbeitendeArbeitsZeit.Arbeitstag.TagesDatum;
                                                                DateTime dtm = momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum;
                                                                if (dtn != dtm)
                                                                {
                                                                    dbAZTag azTag = (dbAZTag)Monat.Monteur.AZModell.AZTage[(int)momentanBearbeiteteArbZeit.Arbeitstag.TagesDatum.DayOfWeek];
                                                                    DateTime dt = Convert.ToDateTime(azTag.Params.AZ_Ende.Value);
                                                                    if (Convert.ToDateTime(dt.ToShortTimeString()) < Convert.ToDateTime(momentanBearbeiteteArbZeit.Gehen.ToShortTimeString()))
                                                                        dt = momentanBearbeiteteArbZeit.Gehen;
                                                                    testSpanne -= (24 * 60) - (dt.Hour * 60 - dt.Minute);
                                                                    dtm = dtm.AddDays(1);
                                                                    while (dtn > dtm)
                                                                    {
                                                                        //BAF 530042 AZMKalenderTage ersetzen AZM Aufrufe
                                                                        if (!Monat.Monteur.AZMKalenderTage.ContainsKey(dtm))
                                                                        {
                                                                            if( !Monat.Monteur.AZMKalenderTage[dtm].IstArbeitstag )
                                                                                testSpanne -= 24 * 60;
                                                                        }//BAF 530042 Ende
                                                                        else
                                                                            if (!Monat.Monteur.IstArbeitstag(dtm))
                                                                                testSpanne -= 24 * 60;
                                                                        dtm = dtm.AddDays(1);
                                                                    }
                                                                    azTag = (dbAZTag)Monat.Monteur.AZModell.AZTage[(int)naechsteZuBearbeitendeArbeitsZeit.Arbeitstag.TagesDatum.DayOfWeek];
                                                                    dt = Convert.ToDateTime(azTag.Params.AZ_Begin.Value);
                                                                    if (Convert.ToDateTime(dt.ToShortTimeString()) > Convert.ToDateTime(naechsteZuBearbeitendeArbeitsZeit.Kommen.ToShortTimeString()))
                                                                        dt = naechsteZuBearbeitendeArbeitsZeit.Kommen;
                                                                    testSpanne -= dt.Hour * 60 + dt.Minute;

                                                                }
                                                                if (testSpanne > 0)
                                                                    spanne = testSpanne;

                                                            }
                                                        }
                                                        catch
                                                        {
                                                            //do nothing
                                                        }
                                                        if (spanne <= reiseZeit + naechsteReiseZeit)
                                                        {
                                                            //Defect #6045 - ein standortwechsel zwischen 2 Baustellen definieren
                                                            letzteBaustelle_diesebaustelle = diesebaustelle_naechsteBaustelle;
                                                            reiseZeitRRplusHR = reiseZeit + naechsteReiseZeit;
                                                        }
                                                        else
                                                        {
                                                            //die Spanne zwischen AZ ist gr�sser als RR und HR, daher werden wir kein SW generieren
                                                            letzteBaustelle_diesebaustelle = null;
                                                            r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                        }
                                                        //if (momentanBearbeiteteArbZeit.Arbeitstag.Tag != naechsteZuBearbeitendeArbeitsZeit.Arbeitstag.Tag)
                                                        //{ //Wenn verschiedene Tage, auf jeden Fall Hinreise
                                                        //    r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                        //}
                                                        //Ansonsten nix, der Standortwechsel wird von der n�chsten Baustelle erzeugt. (Hoffentlich)
                                                    }
                                                    else
                                                    {
                                                        //Es gibt keinen eingetragenen Standortwechsel
                                                        //Defect 4715, 4719, 4720
                                                        //GN 10.4.2007
                                                        //Hinreise zur Baustelle soll nur erfolgen, wenn der Arbeiter noch nicht dort ist - dadurch wird auch keine Hinreise erzeugt.
                                                        if (naechsteBauid != bauid)
                                                        {
                                                            long spanne = naechsteZuBearbeitendeArbeitsZeit.Kommen.Ticks - momentanBearbeiteteArbZeit.Gehen.Ticks;
                                                            spanne = spanne / (60 * 1000 * 1000 * 10); //->minuten
                                                            if (spanne <= reiseZeit + naechsteReiseZeit)
                                                            {
                                                                if (momentanBearbeiteteArbZeit.Params is dbAZ_ARBZEITParams &&
                                                                    naechsteZuBearbeitendeArbeitsZeit.Params is dbAZ_ARBZEITParams)
                                                                {
                                                                    //wir generieren einen automatischen Standortwechsel
                                                                    letzteBaustelle_diesebaustelle = new dbBaustelleStandort(GetBaustelleByBAUID(bauid), null);
                                                                    // daten von der alte Baustelle
                                                                    int ebid = Convert.ToInt32((momentanBearbeiteteArbZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                    letzteBaustelle_diesebaustelle.Params.BAUID.Value = GetBauIDfromEBID(ebid);
                                                                    // daten von der neue Baustelle
                                                                    ebid = Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                    dbBaustelleStandort bstd = GetBaustelleStandort(ebid);
                                                                    letzteBaustelle_diesebaustelle.Params.BAUID_STDW.Value = bstd.Params.BAUID.Value;
                                                                    letzteBaustelle_diesebaustelle.Params.REISEZEIT.Value = spanne;
                                                                    letzteBaustelle_diesebaustelle.EinsatzTyp = (int)dbBaustelleStandort.Einsatz.BaustZuBaust;
                                                                    letzteBaustelle_diesebaustelle.RAKZ_BTEXT = bstd.RAKZ_BTEXT;
                                                                    letzteBaustelle_diesebaustelle.RAKZ_VMTEXT = bstd.RAKZ_VMTEXT;
                                                                    letzteBaustelle_diesebaustelle.Params.RAKZ_B.Value = bstd.Params.RAKZ_B.Value;
                                                                    letzteBaustelle_diesebaustelle.Params.RAKZ_VM.Value = bstd.Params.RAKZ_VM.Value;
                                                                    //letzteBaustelle_diesebaustelle.Baustelle = GetBaustelleByBAUID(GetBauIDfromEBID(ebid));
                                                                    letzteBaustelle_diesebaustelle.Params.RATYP.Value = bstd.Params.RATYP.Value;
                                                                    reiseZeitRRplusHR = reiseZeit + naechsteReiseZeit;
                                                                }
                                                                else
                                                                {
                                                                    r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                                    letzteBaustelle_diesebaustelle = null;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                                letzteBaustelle_diesebaustelle = null;
                                                            }
                                                            //r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), momentanBearbeiteteArbZeit.Gehen, r.IntfID, null));
                                                        }
                                                        else
                                                        {
                                                            //neue Baustelle ist gleiche wie die alte baustelle, es gibt kein standortwechsel
                                                            if (quartier != null && naechsteZuBearbeitendeArbeitsZeit.Kommen.Date != momentanBearbeiteteArbZeit.Gehen.Date)
                                                            {
                                                                r.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r, null), bauid, (t.Zeiten[i] as dbArbZeit).Gehen, quartier, r.IntfID));
                                                            }
                                                            else
                                                            {
                                                                if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                                                {
                                                                    try
                                                                    {
                                                                        if (GetKontObjfromEBID(Convert.ToInt32((momentanBearbeiteteArbZeit.Params as dbAZ_ARBZEITParams).EBID.Value)) !=
                                                                            GetKontObjfromEBID(Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value)))
                                                                        {
                                                                            //hier sollte wechsel der bereitstellung wegen konto �nderung
                                                                            dbKG_ReiseZeile z = ZHin(new dbKG_ReiseZeile(r, null), naechsteZuBearbeitendeArbeitsZeit.Kommen, r.IntfID, null);
                                                                            z.Ab = z.An;
                                                                            z.Zeile.Params.VERKEHRSMITTEL.Value = "";
                                                                            z.Zeile.Params.RAKZTXT.Value = "";
                                                                            z.Zeile.Params.GEFKM.Value = "";
                                                                            z.Zeile.Params.EBID.Value = Convert.ToInt32((naechsteZuBearbeitendeArbeitsZeit.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                                            z = ZBWechselNeu(z, "88");
                                                                            r.Zeilen.Add(z);
                                                                        }
                                                                    }
                                                                    catch
                                                                    {
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    //}
                                                }
                                            }
                                        }
                                    }
                                }

                                letzteBearbeiteteArbeitsZeit = momentanBearbeiteteArbZeit;
                                letzteZeitVonAndererReise = naechsteZeitVonAndererReise;
                                letzteReiseZeit = reiseZeit;
                                letzteBauid = bauid;
                                /* 
                                if ((t.Zeiten.Count > 0) && ((t.Zeiten[0] as dbArbZeit).Params is dbAZ_ARBZEITParams))
                                {
                                    if (t.Tag != r.ErsteAZ.Arbeitstag.Tag)
                                        r.Zeilen.Add(ZHin(new dbKG_ReiseZeile(r, null), (t.Zeiten[0] as dbArbZeit).Kommen, r.IntfID));
                                    if (t.Tag != r.LetzteAZ.Arbeitstag.Tag)
                                        r.Zeilen.Add(ZRueck(new dbKG_ReiseZeile(r, null), (t.Zeiten[t.Zeiten.Count - 1] as dbArbZeit).Gehen, r.IntfID));
                                }*/
                            }
                        }
                    }
                }
                letzteZeitVonAndererReise = true;
                //letzteBaustelle_diesebaustelle = diesebaustelle_naechsteBaustelle;
            }
        }

        //Defect #6045 neu Art der ReiseZeilen WechselBaustelle
        //ist �hnlich den ZWechsel nur aufgerufen wird durch dbBaustelleStandort
        private dbKG_ReiseZeile WechselBaustelle(dbKG_ReiseZeile z, dbBaustelleStandort bs, string IntfId, dbArbZeit az)
        {
            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }

            z.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
            z.VonTyp = dbKG_ReiseZielTyp.Baustelle;
            //z.Von = alteBauID;
            z.Von = Convert.ToInt32(bs.Params.BAUID.Value);

            //defect 3929 versorgung z.ReiseTag korrigiert 
            //z.ReiseTag = z.Ab; //defect 3929
            if (IntfId != "HACK") //Siehe Genehmigung/KG_RA.aspx, sonst funktionierts dort nicht.4
            {
                //z.Ab = z.Reise.ErsteAZ.Kommen.AddMinutes(-int.Parse(bs.Params.REISEZEIT.Value.ToString())); //w�hle die k�rzere Timespan zw. AZ und Reisezeit
                //z.An = z.Reise.ErsteAZ.Kommen;
                z.Ab = az.Kommen.AddMinutes(-int.Parse(bs.Params.REISEZEIT.Value.ToString())); //w�hle die k�rzere Timespan zw. AZ und Reisezeit
                z.An = az.Kommen;
            }

            if (IntfId == "54")
            {
                z.Ab = az.Gehen;
                z.An = az.Gehen.AddMinutes(int.Parse(bs.Params.REISEZEIT.Value.ToString()));
            }

            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            z.ReiseTag = z.Ab; //defect 3929 versorgung z.ReiseTag korrigiert

            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            // comment the following code:
            // if (o != "" && kontObj != o) kontObj = o;
            //
            string kontObj = "";
            if (az.Params is dbAZ_ARBZEITParams)
                kontObj = GetKontObjfromEBID(Convert.ToInt32((az.Params as dbAZ_ARBZEITParams).EBID.Value));
            else
                kontObj = GetKontObjfromEBID(z.Reise.EBID);
            string o = this.AuftragNrAt(az.Kommen);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // ende
            //defect 5702 beginn konto von maske
            //if (konto != null)
            //   kontObj = konto;
            // defect 5702 ende
            z.AuftragNr = kontObj;


            z.NachTyp = dbKG_ReiseZielTyp.Baustelle;
            //z.Nach = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            //z.Nach = z.Reise.Aufenthaltsort;
            z.Nach = Convert.ToInt32(bs.Params.BAUID_STDW.Value);
            dbBaustelle dbb = GetBaustelleByBAUID(z.Nach);
            z.Zeile.Params.EBID.Value = Convert.ToInt32((az.Params as dbAZ_ARBZEITParams).EBID.Value);
            z.Zeile.Params.ABORT.Value = bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
            z.Zeile.Params.ANORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString();
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = bs.RAKZ_VMTEXT;
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu(Convert.ToInt32(bs.Params.RATYP.Value), km);
            z.Zeile.Params.BEREITST.Value = bs.Params.RAKZ_B.Value;
            z.Zeile.Params.BSTXT.Value = bs.RAKZ_BTEXT;
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";
            z.Zeile.Params.GEFKM.Value = bs.Params.KM.Value.ToString();

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            z.Zeile.Params.INTF_ID.Value = IntfId;// "55";// DBNull.Value;
            //z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            return z;
        }

        private dbKG_ReiseZeile NaechsteNichtBelegZeile(dbKG_Reise r, int i)
        {
            for (; i < r.Zeilen.Count; i++)
            {
                dbKG_ReiseZeile z1 = (dbKG_ReiseZeile)r.Zeilen[i];
                if (z1.Typ != dbKG_ReiseZeilenTyp.Belegzeile) return z1;
            }
            return null;
        }



        //Defect 3822
        //GN 4.1.2007 Kfz-Daten werden nicht korrekt in Standortwechsel umgem�nzt
        //Die folgende Methode f�gt die eingetragenen Standortwechsel der ersten
        //Reisen hinzu, wo es ein Hin-R�ckreisepaar gibt, zwischen denen der
        //Standortwechsel zu liegen kommt.
        public void ObiFahrten()
        {
            ArrayList benutzte = new ArrayList();

            foreach (dbKG_Reise r in Reisen)
            {

                //Den Monatsbericht zur Reise heraussuchen
                dbMontBer ber = null;

                foreach (dbMontBer b in Monat.Monteur.MBerichte)
                {
                    if (b.Params.EBID.Value.ToString() == r.EBID.ToString()) ber = b;
                }

                if (ber == null) continue;

                ArrayList adding = new ArrayList();

                for (int i = 0; i < r.Zeilen.Count - 1; i++)
                {
                    dbKG_ReiseZeile z1 = (dbKG_ReiseZeile)r.Zeilen[i];
                    if (z1.Typ == dbKG_ReiseZeilenTyp.Belegzeile) continue;

                    dbKG_ReiseZeile z2 = NaechsteNichtBelegZeile(r, i + 1);
                    if (z2 == null) continue;

                    foreach (dbRAKfzdaten ra in ber.KfzDatenlist)
                    {
                        DateTime rdatum = Convert.ToDateTime(ra.Params.RDATUM.Value);

                        if (z1.Ab.Ticks <= rdatum.Ticks && rdatum.Ticks < z2.An.Ticks)
                        {
                            adding.Add(KfzZeile(new dbKG_ReiseZeile(r, null), ra));
                            benutzte.Add(ra);
                            //Defect #6045
                            //wenn wir WechselBaustelle schon in RAzeilen definiert haben &&
                            //in der gleicehr Zeit KFZ Daten vorhanden sind, dann werden wird 
                            //WechselBaustellenZeile durch KfzZeile ersetzt.
                            if (z1.Typ == dbKG_ReiseZeilenTyp.StandortWechsel &&
                                (z1.Zeile.Params.INTF_ID.Value.ToString() == "55" || z1.Zeile.Params.INTF_ID.Value.ToString() == "54") &&
                                (z1.Ab == rdatum || z1.An == rdatum))
                            {
                                //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
                                ra.vonPLZ_ORT = z1.Zeile.Params.ABORT.Value.ToString();
                                ra.nachPLZ_ORT = z1.Zeile.Params.ANORT.Value.ToString();
                                ra.Ab = z1.Ab;
                                ra.An = z1.An;
                                ra.IntfID = Convert.ToInt32(z1.Zeile.Params.INTF_ID.Value);
                                r.Zeilen.Remove(z1);
                                i--;
                                break;
                            }
                        }

                    }
                }



                foreach (dbKG_ReiseZeile z in adding)
                {
                    r.Zeilen.Add(z);
                }


            }


            //Defect 5150
            //GN 22.6.2007
            //Falls es passieren sollte (was es gelegentlich tut), dass das Reisenarray inkonsistent erzeugt wird,
            //kann es vorkommen, dass obiger Algorithmus nicht alle Obifahrten zuordnet. In diesem Fall tritt untenstehender
            //Algorithmus in Kraft, der die Obifahrten anhand der Reisen-Von und Bisfeldern zuordnet
            foreach (dbMontBer b in Monat.Monteur.MBerichte)
            {

                foreach (dbRAKfzdaten ra in b.KfzDatenlist)
                {


                    foreach (dbKG_Reise r in Reisen)
                    {
                        if (benutzte.Contains(ra)) continue;

                        DateTime rdatum = Convert.ToDateTime(ra.Params.RDATUM.Value);
                        if (r.Von.Ticks <= rdatum.Ticks && r.Bis.Ticks >= rdatum.Ticks)
                        {
                            dbKG_ReiseZeile zToDelete = null;
                            foreach (dbKG_ReiseZeile z in r.Zeilen)
                            {
                                if (z.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung &&
                                    z.Ab == rdatum && z.An == rdatum && z.Zeile.Params.INTF_ID.Value.ToString() == "88")
                                {
                                    zToDelete = z;
                                    break;
                                }
                            }
                            if (zToDelete != null)
                                r.Zeilen.Remove(zToDelete);
                            r.Zeilen.Add(KfzZeile(new dbKG_ReiseZeile(r, null), ra));
                            benutzte.Add(ra);
                        }
                    }

                }
            }

        }


        public class AuftragAb
        {
            public string AuftragNr = "";
            public DateTime AbDatum = DateTime.Now;
            public AuftragAb(string nr, DateTime abDatum)
            {
                AuftragNr = nr;
                AbDatum = abDatum;
            }
        }
        public void AddAuftrag(string Auftrag, DateTime ab)
        {
            //bool dupl = false;
            //foreach (AuftragAb a in Auftraege)
            //    if (a.AuftragNr == Auftrag) dupl = true;
            //if (!dupl) 
            Auftraege.Add(new AuftragAb(Auftrag, ab));
        }
        public string AuftragNrAt(DateTime ab)
        {
            foreach (AuftragAb a in Auftraege)
                if (a.AbDatum.Ticks >= ab.Ticks) return a.AuftragNr;
            return "";
        }
        public string AuftragNrVor(DateTime ab)
        {
            AuftragAb au = null;
            if (Auftraege.Count > 0)
                au = (AuftragAb)Auftraege[0];
            foreach (AuftragAb a in Auftraege)
                if (a.AbDatum.Ticks <= ab.Ticks) au = a;
            if (au != null)
                return au.AuftragNr;
            return "";
        }


        /* Defect 5419 GN 15.10.2007
         * Algorithmus zum Erzeugen der Liste wurde neu implementiert
         * Funktionsweise: F�ge alle Auftragsnummern hinzu, f�ge alle Kostenstellen hinzu, w�hle das ausgew�hlte Element aus.
         */
        public DropDownList ddlAuftr�ge(DropDownList ddl, string SelectedVal)
        {
            foreach (AuftragAb a in Auftraege)
            {
                if (ddl.Items.FindByValue(a.AuftragNr) == null)
                {
                    ddl.Items.Add(new ListItem(a.AuftragNr, a.AuftragNr));
                }
            }

            foreach (dbKG_Reise reise in this.Reisen)
            {

                string kostenstelle = GetKontObjfromEBID(reise.EBID);

                if (ddl.Items.FindByValue(kostenstelle) == null)
                {
                    ddl.Items.Add(new ListItem(kostenstelle, kostenstelle));
                }
            }

            //Defect 5596
            //GN 23.11. 2007
            //Es werden s�mtliche GKAuftragsnummern, die noch nicht zugeordnet sind (kann passieren, wenn der Einsatzbericht auf eine GK-Auftragsnumemr l�uft), hinzugef�gt
            foreach (ValuePair vp in Monat.Monteur.Commons.GK_Auftrag)
            {
                if (ddl.Items.FindByValue(vp.Value) == null)
                {
                    ddl.Items.Add(new ListItem(vp.Value + " (" + vp.Text + ")", vp.Value));
                }
            }



            //Defect 3428
            //GN 23.11.2007
            //Falls der auzuw�hlende Auftrag sich noch nicht in der Liste befindetm wird er auch gleich hinzugef�gt
            //
            if (SelectedVal != null && SelectedVal != "")
            {
                if (ddl.Items.FindByValue(SelectedVal) == null) ddl.Items.Add(new ListItem(SelectedVal, SelectedVal));

                ddl.SelectedValue = SelectedVal;
            }

            return ddl;
        }

        private void SortZeiten()
        {
            foreach (dbKG_Reise r in Reisen) r.SortZeiten();
        }

        private dbBaustelleStandort GetQuartier(int EBID)
        {
            foreach (dbMontBer m in Monat.Monteur.MBerichte)
                if ((int)m.Params.EBID.Value == EBID)
                {
                    foreach (dbBaustelleStandort bs in m.Projekt.Baustelle.Standorte)
                        if (bs.Params.RAKZ_B.Value.ToString() == "") return bs; //HACK: Das ist schlecht. Woher wei� ich, wann das ein Quartiertyp ist?
                }

            return null;
        }

        private dbBaustelleStandort GetBaustelleZuBaustelle(int EBID1, int EBID2)
        {
            dbMontBer ber1 = null;
            dbMontBer ber2 = null;

            foreach (dbMontBer m in Monat.Monteur.MBerichte)
            {
                if ((int)m.Params.EBID.Value == EBID1)
                {
                    ber1 = m;
                }

                if ((int)m.Params.EBID.Value == EBID2)
                {
                    ber2 = m;
                }
            }

            if (ber1 == null || ber2 == null ||
                ber1.Projekt.Baustelle.Params.BAUID.Value == ber2.Projekt.Baustelle.Params.BAUID.Value) //Defect #6045, gleiche Baustelle
                return null;

            foreach (dbBaustelleStandort bs in ber1.Projekt.Baustelle.Standorte)
            {
                // altes Code - falsch
                // if ((int)bs.Params.STDID.Value == Convert.ToInt32(ber2.Projekt.Baustelle.Params.BAUID.Value.ToString()))
                //    return bs;
                //Defect #6045 ist ein BaustellenWechel von Bau1 zu Bau2 in der DB definiert ?
                if (bs.EinsatzTyp == (int)dbBaustelleStandort.Einsatz.BaustZuBaust &&
                    (int)bs.Params.BAUID_STDW.Value == Convert.ToInt32(ber2.Projekt.Baustelle.Params.BAUID.Value.ToString()))
                {
                    //Defect #5981 - bei SW RATYP von BaustellezuBaustelle �berschreiben mit dem RATYp neue Baustelle
                    dbBaustelleStandort neueBaustelle = GetBaustelleStandort(EBID2);
                    bs.Params.RATYP.Value = neueBaustelle.Params.RATYP.Value;
                    return bs;
                }
            }
            //falls nicht, wir �berpr�fen ob ein SW von der zweite Baustelle zur erste definiert ist
            foreach (dbBaustelleStandort bs in ber2.Projekt.Baustelle.Standorte)
            {
                if (bs.EinsatzTyp == (int)dbBaustelleStandort.Einsatz.BaustZuBaust &&
                    (int)bs.Params.BAUID_STDW.Value == Convert.ToInt32(ber1.Projekt.Baustelle.Params.BAUID.Value.ToString()))
                {
                    // wir nehmen die Daten von der bestehenden Standoerwechsel
                    dbBaustelleStandort neuBS = new dbBaustelleStandort(ber1.Projekt.Baustelle, null);
                    neuBS.Params.BAUID.Value = bs.Params.BAUID_STDW.Value;
                    neuBS.Params.BAUID_STDW.Value = bs.Params.BAUID.Value;
                    neuBS.Params.KM.Value = bs.Params.KM.Value;
                    neuBS.Params.RAKZ_B.Value = bs.Params.RAKZ_B.Value;
                    neuBS.Params.RAKZ_VM.Value = bs.Params.RAKZ_VM.Value;
                    //Defect #5981 - bei SW RATYP von BaustellezuBaustelle �berschreiben mit dem RATYp neue Baustelle
                    dbBaustelleStandort neueBaustelle = GetBaustelleStandort(EBID2);
                    //bs.Params.RATYP.Value = neueBaustelle.Params.RATYP.Value;
                    neuBS.Params.RATYP.Value = neueBaustelle.Params.RATYP.Value;
                    neuBS.Params.REISEZEIT.Value = bs.Params.REISEZEIT.Value;
                    neuBS.Params.STDID.Value = 0; // nicht relevant
                    neuBS.EinsatzTyp = (int)dbBaustelleStandort.Einsatz.BaustZuBaust;
                    neuBS.RAKZ_BTEXT = bs.RAKZ_BTEXT;
                    neuBS.RAKZ_VMTEXT = bs.RAKZ_VMTEXT;
                    //neuBS.Baustelle = GetBaustelleByBAUID(GetBauIDfromEBID(ebid));
                    return neuBS;
                }
            }
            // ansonst es ist kein Standortwechel zwischen Baustellen definiert
            return null;
        }


        private dbBaustelleStandort GetBaustelleStandort(int EBID)
        {
            foreach (dbMontBer m in Monat.Monteur.MBerichte)
                if ((int)m.Params.EBID.Value == EBID)
                {
                    foreach (dbBaustelleStandort bs in m.Projekt.Baustelle.Standorte)
                        if ((int)bs.Params.STDID.Value == Convert.ToInt32(Monat.Monteur.Params.STDSTDID.Value) /*|| EBID == 170005116 || EBID == 170005121 || EBID == 170005148 || EBID == 170005143*/) return bs;
                }
            if (VorMonat != null)   // defect 4936
            {
                foreach (dbMontBer m in VorMonat.Monteur.MBerichte)
                    if ((int)m.Params.EBID.Value == EBID)
                    {
                        foreach (dbBaustelleStandort bs in m.Projekt.Baustelle.Standorte)
                            if ((int)bs.Params.STDID.Value == Convert.ToInt32(Monat.Monteur.Params.STDSTDID.Value)) return bs;
                    }
            }  //defect 4936
            return new dbBaustelleStandort(null, null);
        }
        private dbBaustelle GetBaustelleByBAUID(int BAUID)
        {
            foreach (dbMontBer m in Monat.Monteur.MBerichte)
                foreach (dbBaustelleStandort bs in m.Projekt.Baustelle.Standorte)
                    if ((int)bs.Params.BAUID.Value == BAUID) 
                        return bs.Baustelle;
            if (VorMonat != null)   // defect 4936
            {
                foreach (dbMontBer m in VorMonat.Monteur.MBerichte)
                    foreach (dbBaustelleStandort bs in m.Projekt.Baustelle.Standorte)
                        if ((int)bs.Params.BAUID.Value == BAUID) 
                            return bs.Baustelle;
            }
            return new dbBaustelle(Monat.Monteur);
        }
        private int GetBauIDfromEBID(int EBID)
        {
            try
            {
                foreach (dbMontBer m in Monat.Monteur.MBerichte)
                    if ((int)m.Params.EBID.Value == EBID)
                        return (int)m.Projekt.Baustelle.Params.BAUID.Value;
                if (VorMonat != null)   // defect 4936
                {
                    foreach (dbMontBer m in VorMonat.Monteur.MBerichte)
                        if ((int)m.Params.EBID.Value == EBID)
                            return (int)m.Projekt.Baustelle.Params.BAUID.Value;
                }
            }
            catch { }
            return 0;
        }
        public string GetKontObjfromEBID(int EBID)
        {
            using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
            {
                cnx.Open();
                // Defect 5725, Config.Rowlock eingef�hrt
                // Defect 5771, Config.Nolock eingef�hrt
                using (SqlCommand cmd = new SqlCommand("SELECT r.Mandant, b.KST FROM EINSBER r " + Config.Nolock + " JOIN BEARBTECH as b " + Config.Nolock + " ON r.perskey = b.perskey WHERE EBID=@EBID AND (Mandant = 'MG' OR Mandant = 'ME' OR Mandant = 'MP') ", cnx)) // Defect 5436
                {
                    cmd.CommandType = CommandType.Text;

                    SqlParameter p = new SqlParameter("@EBID", EBID);

                    cmd.Parameters.Add(p);

                    SqlDataReader rd = cmd.ExecuteReader();

                    if (rd.Read())
                    {
                        string mandant = rd.GetString(0);
                        string kst = rd.GetString(1);

                        // Beginn Defect 3393
                        //F�r B&I Kostenstelle eintragen
                        if (mandant == "MG")
                        {
                            return "21" + kst;

                        }
                        // Ende Defect 3393

                        //F�r EEI Kostenstelle eintragen
                        else if (mandant == "ME")
                        {
                            return "22" + kst;
                        }
                        //Defect 4507
                        //Mandant MP eingef�hrt
                        else if (mandant == "MP")
                        {
                            return "10" + kst;
                        }
                        //Ende
                    }
                }
            }

            foreach (dbMontBer m in Monat.Monteur.MBerichte)
                if ((int)m.Params.EBID.Value == EBID) 
                    return m.Projekt.Params.KTOBJ.Value.ToString();
            if (VorMonat != null)   // defect 4936
            {
                foreach (dbMontBer m in VorMonat.Monteur.MBerichte)
                    if ((int)m.Params.EBID.Value == EBID)
                        return m.Projekt.Params.KTOBJ.Value.ToString();
            }
            return "";
        }

        /// <summary>
        /// GN -Defect 4507 Mandant MP hinzugef�gt (10)
        /// CG -Defect # 3393 - Nachkorrekur 
        /// gibt true z�ruck, wenn die KTOBJ f. den Mandant 'MG' od. 'ME' sein 
        /// muss. den diese beiden Mandanten verwenden die Kostellenstellenm statt 
        /// d. Auftragsnummer in der RA bzw. RAZEILE-TABELLE.BESCHREIB
        /// </summary>
        /// <param name="ktobj"> Auftragsnummer</param>
        /// <returns></returns>

        public bool useCostObj(string ktobj)
        {
            // 
            // muss. den diese beiden Mandanten verwenden die Kostellenstellenm statt 
            // d. Auftragsnummer in der RA bzw. RAZEILE-TABELLE.BESCHREIB
            try
            {
                return ktobj.Substring(0, 2) == "21" || ktobj.Substring(0, 2) == "22" || ktobj.Substring(0, 2) == "10";
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// Bestimmt, ob die aktuelle Arbeitszeit die Dauer des Aufenthalts eine Heimreise rechtfertigt
        /// Es muss im Vormonat eine Heimreise gegeben haben, oder er hat das Projekt gewechselt.
        /// </summary>
        /// <returns></returns>
        private bool MonatlicheHeimreiseAmWE(DateTime Start, DateTime Aktuell)
        {
            int[] nTage = new int[12] { 30, 27, 30, 29, 30, 29, 30, 30, 29, 30, 29, 30 };
            //Wir schauen, ob sich bis Samstag noch ein Anspruch auf Heimreise ausgeht..
            while (Aktuell.DayOfWeek != DayOfWeek.Saturday) Aktuell = Aktuell.AddDays(1);
            TimeSpan ts = new TimeSpan(Aktuell.Ticks - Start.Ticks);
            //GN 15.12.2006 -1 zum Index hinzugef�gt
            return (nTage[Start.Month - 1] <= ts.Days);
        }
        private bool IstLangGenugDa(dbKG_Reise r, int idx)
        {
            int[] nTage = new int[12] { 30, 27, 30, 29, 30, 29, 30, 30, 29, 30, 29, 30 };
            if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich)
            {
                DateTime start = r.ErsteAZ.Kommen;
                dbKG_Reise r2 = null;
                if (idx != 0) r2 = (dbKG_Reise)Reisen[idx];
                while ((r2 != null) &&
                    ((int)r2.LetzteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value ==
                     (int)r.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value))
                {
                    if (r2.letzteHeimreise.Ticks != DateTime.MinValue.Ticks)
                        start = r2.Von;
                    else break;
                    idx--;
                    if (idx != 0) r2 = (dbKG_Reise)Reisen[idx];
                    else r2 = null;
                }
                DateTime Ende = r.LetzteAZ.Gehen;
                //Wir schauen, ob sich bis Samstag noch ein Anspruch auf Heimreise ausgeht..
                while (Ende.DayOfWeek != DayOfWeek.Saturday) Ende = Ende.AddDays(1);
                TimeSpan ts = new TimeSpan(Ende.Ticks - start.Ticks);
                //return (nTage[start.Month] <= ts.Days);
                // CG: Defect# xxxx 11.01.2007 -1 zum Index hinzugef�gt. Beim Index 12 Fehler
                // CG 11.01.2007 -1 zum Index hinzugef�gt (ohne defect# 4259)
                // CG - �berpr�fung, ob nach dem ts.days gearbeitet wurde (ohne defect# 4259)
                // return (nTage[start.Month - 1] <= ts.Days);
                return (nTage[start.Month - 1] <= ts.Days || !ZtStempelVorhandenAb(ts.Days));
            }
            return false;
        }

        // Defect 3965, 3992
        // GN Art der Auswahl ob "A" oder "R" ge�ndert, jetzt abh�ngig von reisetyp
        private string ReiseartNeu(int ratyp, int km)
        {
            switch (ratyp)
            {
                case 0:              // < 10km
                    return ConfigurationManager.AppSettings["ReiseartORT"].ToString(); //A
                //Defect 4341: Reisekennzeichen SCHON WIEDER falsch. 15.01.2007
                case 5:              // 7-10km b&i
                    return ConfigurationManager.AppSettings["ReiseartNAHB_I"].ToString(); //0  defect 5128
                //case 1:             // < 70km defect 4970
                case 3:             // < 25km
                    //case 4:             // < 50km  //defect 4970 
                    return ConfigurationManager.AppSettings["ReiseartNAH"].ToString(); //R
                case 2:             // > 70km
                    //Defect 4011 GN Abfrage auf km < 120 herausgenommen
                    /*if (km < 120) */
                    //defect 4970 NK Abfrage auf km < 120 wieder aktiviert
                    //if (km > 120)
                    //{
                    //    return ConfigurationManager.AppSettings["ReiseartNAH"].ToString(); //R
                    //}
                    //else
                    //{
                    return ConfigurationManager.AppSettings["ReiseartFERN"].ToString(); //N
                //}
                case 6: //Defect 5981 - neue ReiseArt
                    return ConfigurationManager.AppSettings["ReiseartNAH"].ToString(); //R
                //defect 4970 wir tragen mal alle m�glichen reisearten fern ein, auch wenn wir noch nicht wissen ob es einen hotelbeleg gibt oder nicht (auswertung passiert sp�ter)
                case 1:
                case 4:
                    return ConfigurationManager.AppSettings["ReiseartFERN"].ToString(); //N
            }

            return "N";
        }

        /*
        private string Reiseart(dbKG_ReiseHeimfahrtTyp typ, int km)
        {
            switch (typ)
            {
                case dbKG_ReiseHeimfahrtTyp.taeglich:
                    return ConfigurationManager.AppSettings["ReiseartORT"].ToString();
                case dbKG_ReiseHeimfahrtTyp.woechentlich:
                    return ConfigurationManager.AppSettings["ReiseartNAH"].ToString();
                case dbKG_ReiseHeimfahrtTyp.monatlich:
                    if (km < 120) return ConfigurationManager.AppSettings["ReiseartFERN"].ToString();
                    else return "N";
                default:
                    return "N";
            }
        }*/

        /*
        public dbKG_ReiseZeile ZDefaults(dbKG_ReiseZeile z)
        {
            z.Zeile.Params.VERKEHRSMITTEL.Value = DBNull.Value;
            z.Zeile.Params.RAKZTXT.Value = "";
            z.Zeile.Params.AB.Value = DBNull.Value;
            z.Zeile.Params.AN.Value = DBNull.Value;
            z.Zeile.Params.ABORT.Value = "";
            z.Zeile.Params.ANORT.Value = "";
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = "N";
            z.Zeile.Params.BEREITST.Value = DBNull.Value;
            z.Zeile.Params.BSTXT.Value = "";
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = DBNull.Value;
            z.Zeile.Params.WAEHR.Value = "EUR";
            z.Zeile.Params.AUSLBEMERK.Value = "";
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = DBNull.Value;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABID.Value = DBNull.Value;
            z.Zeile.Params.ANID.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = DBNull.Value;
            z.Zeile.Params.GEFKM.Value = DBNull.Value;
            z.Zeile.Params.SCHWERGP.Value = "";
            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            return z;
        }
        */
        public dbKG_ReiseZeile ZHin(dbKG_ReiseZeile z, DateTime An, string IntfId, string konto)
        {

            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }


            z.ReiseTag = Convert.ToDateTime(An.ToShortDateString() + " " + ckorrZT_0000);
            z.Typ = dbKG_ReiseZeilenTyp.Hinfahrt;
            z.VonTyp = dbKG_ReiseZielTyp.Standort;
            z.Von = Convert.ToInt32((Int16)Monat.Monteur.Params.STDSTDID.Value);
            z.NachTyp = dbKG_ReiseZielTyp.Baustelle;
            //z.Nach = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            z.Nach = z.Reise.Aufenthaltsort;
            z.An = An;
            z.Ab = An.AddMinutes(-(int)bs.Params.REISEZEIT.Value);

            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }

            string o = this.AuftragNrAt(An);
            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)

            //
            // string o = this.AuftragNrAt(An);
            //if (!useCostObj(kontObj))
            //    if (o != "" && kontObj != o) kontObj = o;

            string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // ende

            //defect 5702 beginn konto von maske
            if (konto != null)
                kontObj = konto;
            // defect 5702 ende

            z.AuftragNr = kontObj;// AuftragNrAt(An);

            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.ANORT.Value = bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
            z.Zeile.Params.ABORT.Value = z.Reise.RAbrech.Monat.Monteur.Standort.Params.PLZZ.Value.ToString() + " " + z.Reise.RAbrech.Monat.Monteur.Standort.Params.ORT.Value.ToString();
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = bs.RAKZ_VMTEXT;
            z.Zeile.Params.BEREITST.Value = bs.Params.RAKZ_B.Value;
            z.Zeile.Params.BSTXT.Value = bs.RAKZ_BTEXT;
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";
            z.Zeile.Params.GEFKM.Value = bs.Params.KM.Value.ToString();

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.AENPERSKEY.Value = 0;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            //z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            return z;
        }
        public dbKG_ReiseZeile ZRueck(dbKG_ReiseZeile z, DateTime Ab, string IntfId, string kontierung)  //defect 4944 kontierung neu
        {

            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }

            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            //if (!useCostObj(kontObj))
            //    if (o != "" && kontObj != o) kontObj = o;

            string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            string o = this.AuftragNrVor(Ab);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // ende
            //defect 4944 beg
            if (kontierung != null)
                kontObj = kontierung;
            // defect 4944 ende

            // Beginn Defect# 4020: Arbeit �ber Mitternacht
            z.ReiseTag = Convert.ToDateTime(Ab.ToShortDateString() + " " + ckorrZT_0000);
            //Sonderbehandlung: RR am 1. Tag des Folgemonats, speziell f�r Nachtschichtler mit anschl. Heimreise
            while (z.ReiseTag.Ticks > Monat.MaxDatum.Ticks) z.ReiseTag = z.ReiseTag.AddDays(-1);
            // Ende Defect# 4020
            z.Typ = dbKG_ReiseZeilenTyp.Rueckfahrt;
            z.VonTyp = dbKG_ReiseZielTyp.Baustelle;
            z.Von = z.Reise.Aufenthaltsort;
            z.Nach = Convert.ToInt32((Int16)Monat.Monteur.Params.STDSTDID.Value);
            z.NachTyp = dbKG_ReiseZielTyp.Standort;
            z.Ab = Ab;
            z.An = Ab.AddMinutes((int)bs.Params.REISEZEIT.Value);

            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            z.AuftragNr = kontObj;

            //Defect #5899 - ersteArbzeit im Monat ermitteln
            //wenn das Monat mit einer TA beginnt, dann wird dieser Reise das EBID aus Vormonat zugewiesen
            //Um das zu vermeinden wird EBID durch das EBID von ersten Arbzeit im Monat ersetzt.
            if (z.Reise.ebidAusVormonat && Monat.ersteArbzeitImMonat != null)
            {
                try
                {
                    z.Zeile.Params.EBID.Value = (Monat.ersteArbzeitImMonat.Params as dbAZ_ARBZEITParams).EBID.Value;
                    z.Reise.ebidAusVormonat = false; // reise abgeschlossen
                    //kontObj = GetKontObjfromEBID((int)(z.Zeile.Params.EBID.Value)); //altes konto verwenden
                }
                catch
                {
                    z.Zeile.Params.EBID.Value = z.Reise.EBID;
                }

            }
            else
                z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.ABORT.Value = bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
            z.Zeile.Params.ANORT.Value = z.Reise.RAbrech.Monat.Monteur.Standort.Params.PLZZ.Value.ToString() + " " + z.Reise.RAbrech.Monat.Monteur.Standort.Params.ORT.Value.ToString();
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = bs.RAKZ_VMTEXT;
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            z.Zeile.Params.BEREITST.Value = bs.Params.RAKZ_B.Value.ToString();
            z.Zeile.Params.BSTXT.Value = bs.RAKZ_BTEXT;
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = "";
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";
            z.Zeile.Params.GEFKM.Value = bs.Params.KM.Value.ToString();

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            //z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);

            return z;
        }
        public dbKG_ReiseZeile ZFahrtADO(dbKG_ReiseZeile z, DateTime Ab, DateTime An, string IntfId)
        {
            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }

            z.ReiseTag = Convert.ToDateTime(An.ToShortDateString() + " " + ckorrZT_0000);
            if (z.ReiseTag.Month != Monat.MinDatum.Month)
                z.ReiseTag = Convert.ToDateTime(Ab.ToShortDateString() + " " + ckorrZT_0000);
            if (z.ReiseTag.Month != Monat.MinDatum.Month)
            {//nur bei Fahrt am Dienstort!
                Exception ex = new Exception("Fehler bei der Bestimmung des Reisedatums!"
                                            + "\nAbfahrt:" + Ab.ToString()
                                            + "\nAnkunft:" + An.ToString()
                                            + "\nliegt beides nicht im Monat " + Monat.MinDatum.Month.ToString());
                throw ex;
            }
            z.Typ = dbKG_ReiseZeilenTyp.FahrtAmDienstort;
            z.VonTyp = dbKG_ReiseZielTyp.Baustelle;
            //z.Von = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            z.Von = z.Reise.Aufenthaltsort;
            z.NachTyp = dbKG_ReiseZielTyp.Baustelle;
            //z.Nach = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            z.Nach = z.Reise.Aufenthaltsort;
            z.An = An;
            z.Ab = Ab;
            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            z.AuftragNr = AuftragNrAt(An);
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.ANORT.Value = bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
            z.Zeile.Params.ABORT.Value = z.Zeile.Params.ANORT.Value;
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = GetKontObjfromEBID(z.Reise.EBID);
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.AENPERSKEY.Value = 0;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            //z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            return z;
        }
        public dbKG_ReiseZeile ZTeilab(dbKG_ReiseZeile z, bool erste, string IntfId, DateTime reisetag, string kontierung)  //defect 4944 kontierung neu
        {
            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);
            //defect 5155 beginn
            string bereitst = "";
            string bereitst_txt = "";

            bool bret = get_bereitstellung_von_reise(z.Reise, ref bereitst, ref bereitst_txt);
            //defect 5155 ende
            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }
            //defect 5242 bginn eintrage reisetag wenn versorgt
            z.ReiseTag = Monat.MaxDatum;
            if (erste)
            {
                z.ReiseTag = Monat.MinDatum;
            }
            if (reisetag != ParamVal.Date0)
            {
                z.ReiseTag = reisetag;
            }
            //pr�fen ob wir schon eine t-zeile an diesem tag haben 
            /* defect 5191  sp�ter pr�fen
            foreach (dbKG_ReiseZeile zx in z.Reise.Zeilen)
            {
                if ( (zx.ReiseTag == z.ReiseTag) 
                     && (zx.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) 
                     && (zx.Ab.Hour == z.Ab.Hour)
                   )
                {
                    //da gibts an dem tag zur gleichen zeit schon ein T.... was tun ?
                    //retrun den....
                    return null; // defect 5191 
                    //return zx;  // defect 5191
                }
            } 
             * defect 5191  sp�ter pr�fen*/
            //defect 5242 ende
            z.Typ = dbKG_ReiseZeilenTyp.Teilabrechnung;
            z.VonTyp = dbKG_ReiseZielTyp.Baustelle;

            // defect 5033 beginn null werte abfedern
            if (z.Reise.ErsteAZ != null)
            {
                z.Von = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;

            }
            else
            {
                z.Von = GetBauIDfromEBID(z.Reise.EBID);
            }
            // defect 5033 ende

            string o;
            if (erste)
            {
                //Defect 3299: Teilbrechnung am falschen Datum
                //Datum wird jetzt immer auf die letzte Zeit des vorigen Monats gesetzt
                //Start
                z.Ab = new DateTime(Monat.MinDatum.Year, Monat.MinDatum.Month, 1).AddMinutes(-1);
                //z.Ab = Monat.MinDatum.AddMinutes(-1); //am Vormonat anschlie�en
                //Ende
                try
                {
                    //Defect #5974 Exception abfangen
                    o = AuftragNrAt(z.Reise.ErsteAZ.Kommen);
                }
                catch
                {
                    o = "";
                }
            }
            else
            {
                z.Ab = Monat.MaxDatum;
                try
                {
                    //Defect #5974 Exception abfangen
                    o = AuftragNrVor(z.Reise.LetzteAZ.Gehen);
                }
                catch
                {
                    o = "";
                }
                if (kontierung == ckorrZT_0000)
                {
                    z.Ab = Convert.ToDateTime(reisetag.ToShortDateString() + " " + ckorrZT_0000 + ":00");
                    z.An = z.Ab;
                    o = AuftragNrAt(z.An); //Defect #6045 - TA mit richtigen Konto versorgen
                }
                if (kontierung == ckorrZT_2359)
                {
                    z.Ab = Convert.ToDateTime(reisetag.ToShortDateString() + " " + ckorrZT_2359 + ":59");
                    z.An = z.Ab;
                    o = AuftragNrVor(z.An);//Defect #6045 - TA mit richtigen Konto versorgen
                }

            }
            // defect 5191: pr�fen ob wir schon eine t-zeile an diesem tag haben
            foreach (dbKG_ReiseZeile zx in z.Reise.Zeilen)
            {
                if ((zx.ReiseTag == z.ReiseTag)
                     && ((zx.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) ||
                     (zx.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung && zx.Zeile.Params.INTF_ID.Value.ToString() == "85"))
                    //&& (zx.Ab.Hour == z.Ab.Hour)
                    //Defect #6042 - Zeit.Hour ist nicht ausreichend, mann soll tats�chliche Zeit vergleichen
                     && (zx.Ab == z.Ab)
                   )
                {
                    //da gibts an dem tag zur gleichen zeit schon ein T.... was tun ?
                    //retrun den....
                    return null; // defect 5191  
                    //return zx; // defect 5191
                }
            }
            //defect 5191 ende            
            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //            if (o != "" && kontObj != o) kontObj = o;

            string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // ende
            //defect 4944 beg
            if ((kontierung != null) && !(kontierung.Equals(ckorrZT_0000)) && !(kontierung.Equals(ckorrZT_2359)))
                kontObj = kontierung;
            //defect 4944 end
            z.AuftragNr = kontObj;


            z.An = z.Ab;
            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            //Defect #5899 - ersteArbzeit im Monat ermitteln
            //wenn das Monat mit einer TA beginnt, dann wird dieser Reise das EBID aus Vormonat zugewiesen
            //Um das zu vermeinden wird EBID durch das EBID von ersten Arbzeit im Monat ersetzt.
            if (erste && Monat.ersteArbzeitImMonat != null)
            {
                try
                {
                    z.Zeile.Params.EBID.Value = (Monat.ersteArbzeitImMonat.Params as dbAZ_ARBZEITParams).EBID.Value;
                    z.Reise.ebidAusVormonat = true;
                }
                catch
                {
                    z.Zeile.Params.EBID.Value = z.Reise.EBID;
                }
            }
            else
                z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.NachTyp = dbKG_ReiseZielTyp.Baustelle;
            //defect 5033 beginn null werte abfedern
            if (z.Reise.ErsteAZ != null)
            {
                z.Nach = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            }
            else
            {
                z.Nach = GetBauIDfromEBID(z.Reise.EBID);
            }
            //defect 5033 ende
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = "";
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            // falls eine reduzierung in der reise eingetragen ist, soll sie wirken in allen t-zeilen / defect 4971
            if (z.Reise.redBeg != ParamVal.Date0)
            {
                if (z.Reise.Bis.DayOfYear > z.Reise.redBeg.DayOfYear)
                {
                    if ((z.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                    {
                        z.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                    }
                    if (z.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                    {
                        z.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                    }
                    //z.Zeile.Params.REISEART.Value = 'D';
                }
            }
            //defect 5155 beginn
            if (bereitst == "")
            {
                z.Zeile.Params.BEREITST.Value = bs.Params.RAKZ_B.Value; //   '0';// Vormals null, am 31.01.07 ge�ndert. GN
                z.Zeile.Params.BSTXT.Value = bs.RAKZ_BTEXT; //  "";
            }
            else
            {
                z.Zeile.Params.BEREITST.Value = bereitst;
                z.Zeile.Params.BSTXT.Value = bereitst_txt; // defect 5155 text dazu "";

            }
            // defect 5155 ende 
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABID.Value = DBNull.Value;
            z.Zeile.Params.ANID.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = DBNull.Value;
            // Meldung von Fr. Eichlberger (11.07.2008) - Kein Defect notwendig
            // Eine T Zeile wird zu RR ge�ndert - wenn GEFKM.Value == DBNull.Value kommt es zur exception
            z.Zeile.Params.GEFKM.Value = "";
            //z.Zeile.Params.GEFKM.Value = DBNull.Value;

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            //z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            if (erste)
            {
                try
                {
                    bs = GetBaustelleStandort(Convert.ToInt32(z.Zeile.Params.EBID.Value));
                    z.Zeile.Params.ABORT.Value = z.Zeile.Params.ANORT.Value =
                        bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
                    z.Zeile.Params.ABID.Value = z.Zeile.Params.ANID.Value = bs.Baustelle.Params.BAUID.Value;
                }
                catch
                {
                }

            }
            return z;
        }



        public dbKG_ReiseZeile ZZuQuartier(dbKG_ReiseZeile z, int alteBauID, DateTime start, dbBaustelleStandort quartier, string IntfId)
        {
            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }

            z.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
            z.VonTyp = dbKG_ReiseZielTyp.Baustelle;
            z.Von = alteBauID;
            z.Ab = new DateTime(start.Ticks); //w�hle die k�rzere Timespan zw. AZ und Reisezeit
            z.An = new DateTime(start.Ticks).AddMinutes((int)quartier.Params.REISEZEIT.Value);
            z.ReiseTag = z.Ab;

            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }

            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            // Comment the following code
            // if (o != "" && kontObj != o) kontObj = o;

            string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            string o = this.AuftragNrAt(start);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // Ende  
            z.AuftragNr = kontObj;

            z.NachTyp = dbKG_ReiseZielTyp.Standort; //TODO: Da geh�rt eigentlich Quartier kacke.

            // Beginn Defect #4588: 'Nach' wird ebenfalls auf 'alteBauID'
            // gesetzt (wie 'Von')
            //z.Nach = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            z.Nach = 0;// wohin?? z.Reise.Aufenthaltsort;
            // z.Nach = alteBauID;
            // Ende Defect #4588

            dbBaustelle dbb = GetBaustelleByBAUID(alteBauID);
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.ABORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString();
            z.Zeile.Params.ANORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString(); // MC 49359"";//kann man nicht wissen. bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
            z.Zeile.Params.VERKEHRSMITTEL.Value = quartier.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = quartier.RAKZ_VMTEXT;
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            z.Zeile.Params.BEREITST.Value = "";//Darf man nicht angeben bs.Params.RAKZ_B.Value;
            z.Zeile.Params.BSTXT.Value = "";
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";
            z.Zeile.Params.GEFKM.Value = quartier.Params.KM.Value.ToString();

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";
            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            //z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            z.Zeile.Params.INTF_ID.Value = 72; //Convert.ToInt16(IntfId);
            return z;
        }

        public dbKG_ReiseZeile ZVonQuartier(dbKG_ReiseZeile z, int zuBauID, DateTime start, dbBaustelleStandort quartier, string IntfId)
        {
            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }

            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            // comment the following code:
            // if (o != "" && kontObj != o) kontObj = o;
            //
            string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            string o = this.AuftragNrVor(start);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // ende

            z.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
            z.VonTyp = dbKG_ReiseZielTyp.Standort; //TODO: Das ist falsch. -> Exception

            // Beginn Defect #4588: 'Von' wird ebenfalls auf z.Reise.Aufenthaltsort
            // gesetzt (wie 'Nach')
            z.Von = 0;// woher?? z.Reise.Aufenthaltsort;
            // z.Von = z.Reise.Aufenthaltsort;
            // Ende Defect #4588

            z.Ab = new DateTime(start.Ticks).AddMinutes(-(int)quartier.Params.REISEZEIT.Value); //w�hle die k�rzere Timespan zw. AZ und Reisezeit
            z.An = new DateTime(start.Ticks);
            z.ReiseTag = z.Ab;
            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            z.AuftragNr = kontObj;

            z.NachTyp = dbKG_ReiseZielTyp.Baustelle;
            //z.Nach = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            z.Nach = z.Reise.Aufenthaltsort;
            dbBaustelle dbb = GetBaustelleByBAUID(zuBauID);
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.ABORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString(); //- MC49359 "";
            z.Zeile.Params.ANORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString();//kann man nicht wissen. bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
            z.Zeile.Params.VERKEHRSMITTEL.Value = quartier.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = quartier.RAKZ_VMTEXT;
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            z.Zeile.Params.BEREITST.Value = "";//Darf man nicht angeben bs.Params.RAKZ_B.Value;
            z.Zeile.Params.BSTXT.Value = "";
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";

            z.Zeile.Params.GEFKM.Value = quartier.Params.KM.Value.ToString();

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            //z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            z.Zeile.Params.INTF_ID.Value = 72; // Convert.ToInt16(IntfId);
            return z;
        }


        public dbKG_ReiseZeile WReise(dbKG_ReiseZeile z, dbKG_ReiseZeile rz)
        {
            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);
            dbBaustelleStandort quartier = GetQuartier(Int32.Parse(rz.Zeile.Params.EBID.Value.ToString()));
            int ZuBauid = GetBauIDfromEBID(Int32.Parse(rz.Zeile.Params.EBID.Value.ToString()));

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
                if (km == 0) km = Int32.Parse(rz.Zeile.Params.GEFKM.Value.ToString());
            }
            catch { }

            z.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
            z.VonTyp = dbKG_ReiseZielTyp.Standort;

            if (quartier != null)
            {
                z.Ab = new DateTime(rz.An.Ticks).AddMinutes(-(int)quartier.Params.REISEZEIT.Value); //w�hle die k�rzere Timespan zw. AZ und Reisezeit
                z.An = new DateTime(rz.An.Ticks);
                z.Zeile.Params.VERKEHRSMITTEL.Value = quartier.Params.RAKZ_VM.Value;
                z.Zeile.Params.RAKZTXT.Value = quartier.RAKZ_VMTEXT;
                z.Zeile.Params.GEFKM.Value = quartier.Params.KM.Value.ToString();
            }
            else
            {
                z.Zeile.Params.RAKZTXT.Value = rz.Zeile.Params.RAKZTXT.Value;
                z.Zeile.Params.VERKEHRSMITTEL.Value = rz.Zeile.Params.VERKEHRSMITTEL.Value;
                z.Zeile.Params.GEFKM.Value = km;
                z.Ab = rz.Ab;
                z.An = rz.An;
            }
            z.ReiseTag = z.An;
            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            // Defect 3649 GN Bei Reisen �ber mitternacht ben�tigen wir einen Standortwechsel
            //Defect 3794
            //29.11.2006 GN Der Reisetag wurde beim Teilen einer Reise �ber Mitternacht nicht korrekt gesetzt.
            z.ReiseTag = rz.Ab;

            z.AuftragNr = rz.AuftragNr;
            z.NachTyp = rz.NachTyp;
            z.Nach = rz.Nach;
            dbBaustelle dbb = GetBaustelleByBAUID(ZuBauid);
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.ABORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString(); // MC49359 rz.Zeile.Params.ABORT.Value;
            z.Zeile.Params.ANORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString();
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = rz.Zeile.Params.REISEART.Value;
            z.Zeile.Params.BSTXT.Value = "";
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = GetKontObjfromEBID(z.Reise.EBID);
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            z.Zeile.Params.INTF_ID.Value = 73; // MC499359 DBNull.Value;
            return z;
        }

        //Hack mittels unbenutzter IntfId.
        public dbKG_ReiseZeile ZWechsel(dbKG_ReiseZeile z, int alteBauID, string IntfId, string konto)
        {
            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }

            z.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
            z.VonTyp = dbKG_ReiseZielTyp.Baustelle;
            z.Von = alteBauID;

            //defect 3929 versorgung z.ReiseTag korrigiert 
            //z.ReiseTag = z.Ab; //defect 3929
            if (IntfId != "HACK") //Siehe Genehmigung/KG_RA.aspx, sonst funktionierts dort nicht.4
            {
                z.Ab = z.Reise.ErsteAZ.Kommen.AddMinutes(-int.Parse(bs.Params.REISEZEIT.Value.ToString())); //w�hle die k�rzere Timespan zw. AZ und Reisezeit
                z.An = z.Reise.ErsteAZ.Kommen;
            }

            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            z.ReiseTag = z.Ab; //defect 3929 versorgung z.ReiseTag korrigiert

            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            // comment the following code:
            // if (o != "" && kontObj != o) kontObj = o;
            //
            string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            string o = this.AuftragNrAt(z.Reise.ErsteAZ.Kommen);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // ende
            //defect 5702 beginn konto von maske
            if (konto != null)
                kontObj = konto;
            // defect 5702 ende
            z.AuftragNr = kontObj;


            z.NachTyp = dbKG_ReiseZielTyp.Baustelle;
            //z.Nach = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            z.Nach = z.Reise.Aufenthaltsort;
            dbBaustelle dbb = GetBaustelleByBAUID(alteBauID);
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.ABORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString();
            z.Zeile.Params.ANORT.Value = bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = bs.RAKZ_VMTEXT;
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            z.Zeile.Params.BEREITST.Value = bs.Params.RAKZ_B.Value;
            z.Zeile.Params.BSTXT.Value = bs.RAKZ_BTEXT;
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";
            z.Zeile.Params.GEFKM.Value = bs.Params.KM.Value.ToString();

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            //z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            return z;
        }

        public dbKG_ReiseZeile TWechsel(dbKG_ReiseZeile z, string IntfId)
        {
            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }

            z.Typ = dbKG_ReiseZeilenTyp.Teilabrechnung;
            z.VonTyp = dbKG_ReiseZielTyp.Baustelle;
            z.Von = Convert.ToInt32((Int16)Monat.Monteur.Params.STDSTDID.Value);

            if (IntfId != "HACK") //Siehe Genehmigung/KG_RA.aspx, sonst funktionierts dort nicht.4
            {
                //Defect 4299 17.01.2006
                //Start
                z.Ab = new DateTime(Monat.MinDatum.Year, Monat.MinDatum.Month, 1).AddMinutes(-1);
                z.An = z.Ab;
                //Ende
                //z.Ab = z.Reise.ErsteAZ.Kommen; //w�hle die k�rzere Timespan zw. AZ und Reisezeit
                //z.An = z.Reise.ErsteAZ.Kommen;
            }

            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            z.ReiseTag = z.Ab;


            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            // comment the following code:
            // if (o != "" && kontObj != o) kontObj = o;
            //
            string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            string o = this.AuftragNrAt(z.Reise.ErsteAZ.Kommen);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // ende

            z.AuftragNr = kontObj;

            z.NachTyp = dbKG_ReiseZielTyp.Baustelle;
            //z.Nach = (int)z.Reise.ErsteAZ.Arbeitstag.MBericht.Projekt.Baustelle.Params.BAUID.Value;
            z.Nach = z.Reise.Aufenthaltsort;
            dbBaustelle dbb = GetBaustelleByBAUID(z.Von);
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.ABORT.Value = dbb.Params.PLZ.Value.ToString() + " " + dbb.Params.ORT.Value.ToString();
            z.Zeile.Params.ANORT.Value = bs.Baustelle.Params.PLZ.Value.ToString() + " " + bs.Baustelle.Params.ORT.Value.ToString();
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = bs.RAKZ_VMTEXT;
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            z.Zeile.Params.BEREITST.Value = bs.Params.RAKZ_B.Value;
            z.Zeile.Params.BSTXT.Value = bs.RAKZ_BTEXT;
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";
            z.Zeile.Params.GEFKM.Value = bs.Params.KM.Value.ToString();

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            //z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            return z;
        }
        //BAN 500059
        //Wechsel bereitstellung neu
        public dbKG_ReiseZeile ZBWechselNeu(dbKG_ReiseZeile z, string IntfId)
        {
            z.Typ = dbKG_ReiseZeilenTyp.WechselBereitstellung;
            z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            try
            {
                z.Zeile.Params.BEREITST.Value =
                    GetBaustelleStandort(Convert.ToInt32(z.Zeile.Params.EBID.Value)).Params.RAKZ_B.Value;
            }
            catch
            {
            }
            return z;
        }
        //BAN 500059 Ende
        public dbKG_ReiseZeile ZBWechsel(dbKG_ReiseZeile z, string IntfId) //Wechsel bereitstellung
        {
            dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);

            int km = 0;
            try
            {
                km = int.Parse(bs.Params.KM.Value.ToString());
            }
            catch { }


            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            // comment the following code:
            // if (o != "" && kontObj != o) kontObj = o;
            //
            string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            string o = this.AuftragNrAt(z.Reise.ErsteAZ.Kommen);
            if (!useCostObj(kontObj))
                if (o != "" && kontObj != o) kontObj = o;
            // ende

            z.ReiseTag = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0000);
            z.Typ = dbKG_ReiseZeilenTyp.WechselBereitstellung;
            z.Zeile.Params.AB.Value = z.Ab;
            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(z.Reise.EBID).Params.RATYP.Value, km);
            z.Zeile.Params.AUSLART.Value = DBNull.Value;
            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = DBNull.Value;
            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = "0";
            z.Zeile.Params.GEFKM.Value = bs.Params.KM.Value.ToString();

            //CR 4932 Feld wird im GUI schon richtig gesetzt, auskommentiert
            //GN 15.5.2007
            //z.Zeile.Params.SCHWERGP.Value = "";

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            //z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfID);
            z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            return z;
        }

        public dbKG_ReiseZeile KfzZeile(dbKG_ReiseZeile z, dbRAKfzdaten ra)
        {
            DateTime rdatum = Convert.ToDateTime(Convert.ToDateTime(ra.Params.RDATUM.Value));

            //Defect #5996 - verwende das EB aus der DB bzw. ra und nicht von der Reise
            //string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            string kontObj = "";
            if ((int)ra.Params.EBID.Value != 0)
                kontObj = GetKontObjfromEBID((int)ra.Params.EBID.Value);
            else
                kontObj = GetKontObjfromEBID(z.Reise.EBID);
            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            // comment the following code:
            // if (o != "" && kontObj != o) kontObj = o;
            //
            if (Monat.Genehmiger.Mandant.MANDANT != "M3")
            {
                string o = this.AuftragNrAt(rdatum);
                if (!useCostObj(kontObj))
                    if (o != "" && kontObj != o)
                        kontObj = o;
            }
            // ende

            z.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
            z.Ab = Convert.ToDateTime(ra.Params.RDATUM.Value);
            z.An = Convert.ToDateTime(ra.Params.RDATUM.Value);

            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }

            //Defect 4479, 4618
            //GN 16.5.2007
            //Die folgenden Zeilen zerst�rten wertvolle Information �ber die Reisen
            //z.Reise.Von = Convert.ToDateTime(ra.Params.RDATUM.Value);
            //z.Reise.Bis = Convert.ToDateTime(ra.Params.RDATUM.Value);


            z.ReiseTag = Convert.ToDateTime(ra.Params.RDATUM.Value);
            z.Zeile.Params.EBID.Value = ra.Params.EBID.Value;
            z.AuftragNr = kontObj;
            /* Defect 4378: auslesen d. OBI-Verkehrmittel aus d. Config-datei bzw. Datenbank
               // Defect 3496
               // Die Fahrzeugart (Verkehrsmittel) und Text bei Standortwechsel versorgen
               z.Zeile.Params.VERKEHRSMITTEL.Value = "E";      // Defect #3987: eigener PKW
            */
            z.Zeile.Params.VERKEHRSMITTEL.Value = ConfigurationManager.AppSettings["OBIVERKSMITTEL"].ToString();

            /* Defect 4378: auslesen d. OBI-Verkehrmittel aus d. Config-datei bzw. Datenbank
               // Defect 3593
               // z.Zeile.Params.RAKZTXT.Value = DBNull.Value; 
               z.Zeile.Params.RAKZTXT.Value = "Eigener PKW mit km-Geld Einzelabkommen";
               //
            */
            z.Zeile.Params.RAKZTXT.Value = Monat.Monteur.Commons.vpGetText(Monat.Monteur.Commons.Verkehrsmittel, z.Zeile.Params.VERKEHRSMITTEL.Value.ToString());
            z.Zeile.Params.AB.Value = ra.Params.RDATUM.Value;
            z.Zeile.Params.AN.Value = ra.Params.RDATUM.Value;
            z.Zeile.Params.LKZ.Value = "AT";
            z.Zeile.Params.REISEART.Value = ReiseartNeu((int)GetBaustelleStandort(Convert.ToInt32(ra.Params.EBID.Value)).Params.RATYP.Value, 0);
            //z.Zeile.Params.REISEART.Value ="C";
            z.Zeile.Params.BEREITST.Value = "";
            z.Zeile.Params.BSTXT.Value = "";
            z.Zeile.Params.AUSLART.Value = "";
            z.Zeile.Params.ANZNAECHTE.Value = "";
            z.Zeile.Params.BETRAG.Value = "";
            z.Zeile.Params.WAEHR.Value = "";
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABID.Value = DBNull.Value;
            z.Zeile.Params.ANID.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = ra.Params.ABKM.Value;
            z.Zeile.Params.GEFKM.Value = ra.Params.GEFKM.Value;

            //CR 4932 Schwergep�ck wird �bernommen
            //GN 14.5.2007
            z.Zeile.Params.SCHWERGP.Value = ra.Params.SCHWERGP.Value;

            //CR 4931 Anzahl Mitfahrer wird �bernommen
            //GN 16.5.2007
            z.Zeile.Params.MITFAHRER.Value = ra.Params.MITFAHRER.Value.ToString();

            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            z.Zeile.Params.INTF_ID.Value = "0";

            //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
            if (ra.Ab != ParamVal.Date0 && ra.An != ParamVal.Date0)
            {
                z.Ab = ra.Ab;
                z.An = ra.An;
                z.Zeile.Params.INTF_ID.Value = ra.IntfID;

            }
            z.Zeile.Params.ANORT.Value = ra.nachPLZ_ORT;
            z.Zeile.Params.ABORT.Value = ra.vonPLZ_ORT;
            return z;
        }
        public dbKG_ReiseZeile ZBeleg(dbKG_ReiseZeile z, dbRAAuslage ra, string IntfId)
        {
            // string kontObj = GetKontObjfromEBID(z.Reise.EBID);
            z.Typ = dbKG_ReiseZeilenTyp.Belegzeile;
            z.Ab = Convert.ToDateTime(Convert.ToDateTime(ra.Params.DATUM.Value).ToShortDateString());
            z.An = z.Ab;
            z.ReiseTag = z.Ab;

            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            //z.Zeile.Params.EBID.Value = z.Reise.EBID;
            //Defect #5996 - verwende das EB aus der DB bzw. ra und nicht von der Reise
            string kontObj = "";
            dbBaustelleStandort bs = null;
            if ((int)ra.Params.EBID.Value != 0)
            {
                kontObj = GetKontObjfromEBID((int)ra.Params.EBID.Value);
                z.Zeile.Params.EBID.Value = ra.Params.EBID.Value;
                bs = GetBaustelleStandort((int)ra.Params.EBID.Value);
            }
            else
            {
                kontObj = GetKontObjfromEBID(z.Reise.EBID);
                z.Zeile.Params.EBID.Value = z.Reise.EBID;
                bs = GetBaustelleStandort(z.Reise.EBID);
            }

            // CG: Defect# 3393 - Nachkorrektur: wenn 
            // F�r Mandant = 'ME' od. 'MG'muss die Kostenstelle statt die Auftragsnummer
            // verwendet werden: useCostObj(kontObj)
            //
            // comment the following code:
            if (Monat.Genehmiger.Mandant.MANDANT != "M3")
            {
                string o = this.AuftragNrAt(z.Ab);
                if (!useCostObj(kontObj))
                    if (o != "" && kontObj != o)
                        kontObj = o;
            }
            // ende

            z.AuftragNr = kontObj;
            // dbBaustelleStandort bs = GetBaustelleStandort(z.Reise.EBID);
            z.Zeile.Params.VERKEHRSMITTEL.Value = bs.Params.RAKZ_VM.Value;
            z.Zeile.Params.RAKZTXT.Value = "";
            z.Zeile.Params.AB.Value = DBNull.Value;
            z.Zeile.Params.AN.Value = DBNull.Value;
            z.Zeile.Params.LKZ.Value = DBNull.Value;
            z.Zeile.Params.REISEART.Value = DBNull.Value;
            z.Zeile.Params.BEREITST.Value = bs.Params.RAKZ_B.Value;
            z.Zeile.Params.BSTXT.Value = "";
            z.Zeile.Params.AUSLART.Value = ra.Params.RAKZ.Value;
            z.Zeile.Params.ANZNAECHTE.Value = ra.Params.ANZAHL.Value.ToString();
            z.Zeile.Params.BETRAG.Value = Convert.ToDouble(ra.Params.BETRAG.Value).ToString("N");
            z.Zeile.Params.WAEHR.Value = "EUR";
            z.Zeile.Params.AUSLBEMERK.Value = "";
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = kontObj;
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABID.Value = DBNull.Value;
            z.Zeile.Params.ANID.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = DBNull.Value;
            z.Zeile.Params.GEFKM.Value = DBNull.Value;
            z.Zeile.Params.SCHWERGP.Value = "";
            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            //z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            return z;
        }

        /*
        public dbKG_ReiseZeile ZBarauslage(dbKG_ReiseZeile z, dbBarauslagen ra, DateTime tag)
        {
            z.Typ = dbKG_ReiseZeilenTyp.Barauslage;
            z.Ab = tag;
            z.An = tag;
            if (z.Ab.ToString("t").Equals(z.An.ToString("t")) && z.An.ToString("t").Equals(cNullrefZT))
            {
                z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0001);
                z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0001);
            }
            z.ReiseTag = tag;
            z.Zeile.Params.EBID.Value = z.Reise.EBID;
            z.AuftragNr = z.Reise.ErsteAZ.AuftragNr;
            z.Zeile.Params.VERKEHRSMITTEL.Value = "Barauslage"; //Da k�nnte man evt. den String zum Reisekennzeichen reinschreiben
            z.Zeile.Params.RAKZTXT.Value = "";
            z.Zeile.Params.AB.Value = tag;
            z.Zeile.Params.AN.Value = DBNull.Value;
            z.Zeile.Params.LKZ.Value = DBNull.Value;
            z.Zeile.Params.REISEART.Value = DBNull.Value;
            //z.Zeile.Params.BEREITST.Value = DBNull.Value;
            z.Zeile.Params.BEREITST.Value = DBNull.Value;//bs.Params.RAKZ_B.Value;
            z.Zeile.Params.BSTXT.Value = "";
            z.Zeile.Params.AUSLART.Value = ra.Params.TYP.Value.ToString();
            z.Zeile.Params.ANZNAECHTE.Value = ra.Params.ANZ.Value.ToString();//.Params.ANZAHL.Value.ToString();
            z.Zeile.Params.BETRAG.Value = ra.calcSumme().ToString("N");
            z.Zeile.Params.WAEHR.Value = "EUR";
            z.Zeile.Params.AUSLBEMERK.Value = "HIEEAAAR";
            z.Zeile.Params.PROZ.Value = DBNull.Value;
            z.Zeile.Params.BESCHREIB.Value = GetKontObjfromEBID(z.Reise.EBID);
            z.Zeile.Params.ZWECK.Value = DBNull.Value;
            z.Zeile.Params.ABID.Value = DBNull.Value;
            z.Zeile.Params.ANID.Value = DBNull.Value;
            z.Zeile.Params.ABKM.Value = DBNull.Value;
            z.Zeile.Params.GEFKM.Value = DBNull.Value;
            z.Zeile.Params.SCHWERGP.Value = "";
            z.Zeile.Params.MWST.Value = DBNull.Value;
            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
            z.Zeile.Params.DATLA.Value = DateTime.Now;
            z.Zeile.Params.DATNEU.Value = DateTime.Now;
            //z.Zeile.Params.INTF_ID.Value = DBNull.Value;
            //z.Zeile.Params.INTF_ID.Value = Convert.ToInt16(IntfId);
            return z;
        }*/

        private bool IstErsteArbeitstag(DateTime dt)
        {
            dbKG_Reise rr = null;
            foreach (dbKG_Reise r in Reisen)
            {
                if ((rr == null) & (Convert.ToDateTime(r.Von.ToShortDateString()).Ticks == dt.Ticks)) rr = r;
                if (rr != null) break;
            }
            return (rr != null);
        }
        public dbKG_ReiseZeile getZeileByAb(DateTime ab)
        {
            foreach (dbKG_Reise r in Reisen)
                foreach (dbKG_ReiseZeile z in r.Zeilen)
                    if (z.Ab.Ticks == ab.Ticks) return z;
            return null;
        }

        /// <summary>
        /// liefert die entsprechende Reise aus Rabrech.Reisen
        /// </summary>
        /// <param name="dt">Datum/Uhrzeit</param>
        /// <param name="ReiseBeginn">true: Reise beginnt mit dt, false: Reise endet mit dt</param>
        /// <param name="before">true: Reise Beginn/Ende davor, false: Reise Beginn/Ende danach</param>
        /// <returns></returns>
        public dbKG_Reise FindeReise(DateTime dt, bool ReiseBeginn, bool before, ArrayList Reisen)
        {
            if (before)
            {
                if (ReiseBeginn) //suche die letzte Reise die vor dt beginnt
                {
                    dbKG_Reise rr = null;
                    foreach (dbKG_Reise r in Reisen)
                        if ((rr == null) & (r.Von.Ticks <= dt.Ticks)) rr = r;
                        else
                            if ((rr != null) && ((r.Von.Ticks <= dt.Ticks) & (rr.Von.Ticks < r.Von.Ticks))) rr = r;
                    return rr;
                }
                else //suche die letzte Reise die vor dt endet
                {
                    dbKG_Reise rr = null;
                    foreach (dbKG_Reise r in Reisen)
                        if ((rr == null) & (r.Bis.Ticks <= dt.Ticks)) rr = r;
                        else
                            if ((rr != null) && ((r.Bis.Ticks <= dt.Ticks) & (rr.Bis.Ticks < r.Bis.Ticks))) rr = r;
                    return rr;
                }
            }
            else
            {
                if (ReiseBeginn) //suche die erste Reise die nach dt beginnt
                {
                    dbKG_Reise rr = null;
                    foreach (dbKG_Reise r in Reisen)
                        if ((rr == null) & (r.Von.Ticks >= dt.Ticks)) rr = r;
                        else
                            if ((rr != null) && ((r.Von.Ticks >= dt.Ticks) & (rr.Von.Ticks > r.Von.Ticks))) rr = r;
                    return rr;
                }
                else //suche die erste reise die nach dt endet
                {
                    dbKG_Reise rr = null;
                    foreach (dbKG_Reise r in Reisen)
                        if ((rr == null) & (r.Bis.Ticks >= dt.Ticks)) rr = r;
                        else
                            if ((rr != null) && ((r.Bis.Ticks >= dt.Ticks) & (rr.Bis.Ticks > r.Bis.Ticks))) rr = r;
                    return rr;
                }
            }
        }
        //defect 4972 finde hinreise zu r�ckreis
        public dbKG_Reise FindeHinRzuRueckR(dbKG_ReiseZeile z, bool findeInReise)
        {
            dbKG_Reise rgef = null;
            dbKG_Reise rtmp = null;
            foreach (dbKG_Reise r in Reisen)
            {
                int anzRs = 0;
                dbKG_ReiseZeile ztmp = null;
                bool bmerk = false;
                bool flg_ertseT = true;  //defect 5243
                foreach (dbKG_ReiseZeile zs in r.Zeilen)
                {
                    if ((zs.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                        || (zs.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                        || (zs.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                        )
                    {
                        anzRs++;
                        if ((anzRs > 1) && (findeInReise == false))
                        {
                            //das ist kein kanditat dem eine reise fehlt
                            rtmp = null;
                            ztmp = null;
                            break;
                        }
                    }
                    bmerk = false;
                    //defect 5243 abfrage erweiter zum finden der richtigen reisen beim eintarge von zeilen
                    if ((zs.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) && (zs.An.Ticks <= z.Ab.Ticks)
                        || (zs.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (zs.An.Ticks <= z.Ab.Ticks) && (flg_ertseT == true)
                        )
                    {
                        flg_ertseT = false;  //defect 5243
                        if (ztmp != null)
                        {
                            if (ztmp.An.Ticks > zs.An.Ticks)
                            {
                                bmerk = true;
                            }
                        }
                        else
                        {
                            bmerk = true;
                        }
                        if (bmerk == true)
                        {
                            ztmp = zs;
                            rtmp = r;
                        }
                    }
                }
                if (rtmp != null)
                {
                    rgef = rtmp;
                    //break;  //defect 5243 nicht die erste gefunden ist die richtige....
                }
            }
            return (rgef);
        }
        //defect 4972 finde hinreise zu r�ckreis

        public dbKG_Reise FindeRueckRzuHinR(dbKG_ReiseZeile z, bool findeInReise)
        {
            dbKG_Reise rgef = null;
            dbKG_Reise rtmp = null;
            foreach (dbKG_Reise r in Reisen)
            {
                int anzRs = 0;
                dbKG_ReiseZeile ztmp = null;
                bool bmerk = false;
                foreach (dbKG_ReiseZeile zs in r.Zeilen)
                {
                    if ((zs.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                        || (zs.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                        || (zs.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                        )
                    {
                        anzRs++;
                        if ((anzRs > 1) && (findeInReise == false))
                        {
                            //das ist kein kanditat dem eine reise fehlt
                            rtmp = null;
                            ztmp = null;
                            break;
                        }
                    }
                    bmerk = false;
                    if (((zs.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) || ((zs.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (zs.Ab.Day == zs.Reise.Kopf.MaxDatum.Day))) && (zs.Ab.Ticks >= z.An.Ticks))   // defect 5764 auch eine teilabrechnung als r�ckreise erkennen
                    {
                        if (ztmp != null)
                        {
                            if (ztmp.An.Ticks < zs.An.Ticks)
                            {
                                bmerk = true;
                            }
                        }
                        else
                        {
                            bmerk = true;
                        }
                        if (bmerk == true)
                        {
                            ztmp = zs;
                            rtmp = r;
                        }
                    }
                }
                if (rtmp != null)
                {
                    rgef = rtmp;
                    break;
                }
            }
            return (rgef);
        }
        /// <summary>
        /// Diese Funktion check ob, nach dem "letzerArbeitstag"
        /// einen Arbeitszeitstempel gibt
        /// </summary>
        /// <param name="letzerArbeitstag"></param>
        /// <returns></returns>
        public bool ZtStempelVorhandenAb(int letzerArbeitstag)
        {

            if ((Monat.Monteur.MBerichte[0] as dbMontBer).Tage.Count < letzerArbeitstag)
                return false;
            foreach (dbArbTag t in (Monat.Monteur.MBerichte[0] as dbMontBer).Tage)
            {
                foreach (dbArbZeit z in t.Zeiten)
                    if ((z.Kommen.Ticks != ParamVal.Date0.Ticks) & (z.Arbeitstag.Tag > letzerArbeitstag))
                        return true;
            }
            return false;
        }


        /// <summary>
        /// Ermittelt aus den Reisen und deren Zeilen Reisen im Sinne SAP:
        /// eine Reise beginnt mit einer H- und endet mit der n�chsten T- oder R-Zeile, inklusive BelegZeilen...
        /// je Reise: eine Rakopf und viele Zeilen
        /// </summary>
        /// <returns><b>""</b>alles OK
        /// <b>!=""</b>Fehler in der Reihenfolge</returns>
        /// 
        public string ComputeSAP(bool RNGAusCB, bool no_rng, bool bereitAusVorg)  //defect 4972  //defect 5155 neuer par: bereitAusVorg 
        {
            Debug.WriteLine("dbKGRabrech:ComputeSAP Beginn at " + DateTime.Now.ToLongTimeString());
            bool sortNotwendig = false; //TAPM-27, neue Variable, sortNotwendig wird true wenn RR im Vormoat begonnen ist
            DelAllTZeileRNG(Reisen);  // defect 4972 mal alle diese generierten zeilen l�schen, da wir die ja neu berechnen oder setzen
            int ABkm = 0;
            string ret_err_txt = ""; // defect 5593

            foreach (dbMontBer mb in Monat.Monteur.MBerichte)
                if (mb.Params.KM.Value.ToString().Length > 0)
                    if ((int)mb.Params.KM.Value != 0)
                        if (ABkm > (int)mb.Params.KM.Value) ABkm = (int)mb.Params.KM.Value; //suche den kleinsten Kilometerstand 
            ArrayList rks = new ArrayList();
            ArrayList rzs = new ArrayList();
            dbKG_Reise lvReise = null;
            dbKG_Reise letzteReise = null;
            foreach (dbKG_Reise re in Reisen)
            {
                if (re.Kopf.AllowUpdate & VormonatVer�ndert)
                    lvReise = re; //die letzte die hier landet ist jene, die ver�ndert wurde ... und �berschrieben werden muss
                if ((!re.Kopf.AllowUpdate)) //Never change a winning team! Die sind aus der DB, d.h. die sollten schon passen, falls nicht: v.V.!
                    foreach (dbKG_ReiseZeile z in re.Zeilen)
                        if (z.Ab.Ticks > ParamVal.Date0.AddYears(1).Ticks) rzs.Add(z);
                foreach (dbKG_ReiseZeile z in re.Zeilen)
                    if (z.Typ == dbKG_ReiseZeilenTyp.Belegzeile) rzs.Add(z);
                letzteReise = re;
            }

            //Defect 4698_4722_4764_4766_4778
            //GN 9.3. Hinreise folgt auf Hinreise, Standortwechsel unzul�ssig
            //Folgende Zeilen nehmen alle Zeilen, die dem Vormonat zugeordnet wurden, aber
            //eigentlich im momentanen Monat liegen, auch noch mit in die �berpr�fung.

            if (lvReise != null)
            {
                foreach (dbKG_ReiseZeile z in lvReise.Zeilen)
                {
                    if (z.ReiseTag >= Monat.MinDatum) rzs.Add(z);
                }
            }

            //Defect 4525
            dbKG_ReiseZeileSort Sorter = new dbKG_ReiseZeileSort(dbKG_ReiseZeileSort.SortByEnum.Ab);
            rzs.Sort(Sorter);

            /*#region Beginnende Teilabrechnung und Abschlie�ende Teilabrechnung auf den Monatsletzten legen
            dbKG_ReiseZeileSort Sorter = new dbKG_ReiseZeileSort(dbKG_ReiseZeileSort.SortByEnum.Ab);
            rzs.Sort(Sorter);
            dbKG_ReiseZeile trz = null;
            int inichtBelege = 0;
            foreach (dbKG_ReiseZeile xz in rzs) //Teilabrechnung am Anfang?
            {
                if (xz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                {
                    trz = xz;
                    break;
                }
                if (xz.Typ != dbKG_ReiseZeilenTyp.Belegzeile) inichtBelege++; //steht doch nicht am Anfang
            }
            /*
            if ((trz != null) && (inichtBelege == 0) && (trz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung))
            {
                // CG: Defect # 3975 pr�fen, ob es sich um den ersten tag der Reise handelt
                if (IstErsteArbeitstag(trz.ReiseTag) == false)
                {
                    // CG: Defect # 3975 nur der letzte Tag der Reise darf angepasst werden.
                    trz.Ab = Monat.MinDatum.AddMinutes(-1);
                    trz.An = Monat.MinDatum.AddMinutes(-1);
                }
            }
             */
            /*
            trz = null;
            foreach (dbKG_ReiseZeile xz in rzs) //suche die letzte Teilabrechnung
                if (xz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) trz = xz;
            if ((trz != null) && (trz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung))
            {
                    trz.Ab = Monat.MaxDatum;
                    trz.An = Monat.MaxDatum;
            }
            #endregion*/
            #region Reisen Teilen wenn Reise �ber Mitternacht
            //BAN 500059 bei verwendung neue Schnittstelle Reisen Teilen wenn Reise �ber Mitternacht ist es nicht mehr notwendig
            bool useNewHRInterface = false;
            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
            {
                useNewHRInterface = true;
            }
            //if (true) //aus-false-n falls nicht gew�nscht!
            if (!useNewHRInterface)
            {
                ArrayList rzs2 = new ArrayList();
                bool doCheck;

                foreach (dbKG_ReiseZeile rz in rzs)
                {
                    doCheck = true;
                    if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) | (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) | (rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel))
                    {
                        dbKG_ReiseZeilenTyp rTyp = rz.Typ;
                        if (rz.Ab.Day != rz.An.Day) //Reise �ber Mitternacht: splitten!
                        {
                            dbKG_ReiseZeile rz2 = null;
                            if (rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                            {
                                rz2 = ZHin(new dbKG_ReiseZeile(rz.Reise, null), rz.An, rz.Reise.IntfID, null); // defect 5702 neuer par konto
                                rz2.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
                                rz2.Zeile.Params.INTF_ID.Value = 73;
                                rz2.Zeile.Params.VERKEHRSMITTEL.Value = rz.Zeile.Params.VERKEHRSMITTEL.Value;
                                rz2.Zeile.Params.RAKZTXT.Value = rz.Zeile.Params.RAKZTXT.Value;
                                rz2.Zeile.Params.ABORT.Value = rz2.Zeile.Params.ANORT.Value;
                                rz2.Zeile.Params.ABID.Value = rz2.Zeile.Params.ANID.Value;
                                doCheck = false;
                                rTyp = rz.Typ;
                            }

                            if (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                            {
                                if (doCheck)
                                {
                                    rz2 = ZRueck(new dbKG_ReiseZeile(rz.Reise, null), rz.An, rz.Reise.IntfID, null);
                                    rz2.Typ = dbKG_ReiseZeilenTyp.Rueckfahrt;
                                    rz.Typ = dbKG_ReiseZeilenTyp.StandortWechsel;
                                    rz.Zeile.Params.ANORT.Value = rz.Zeile.Params.ABORT.Value;
                                    rz.Zeile.Params.ANID.Value = rz.Zeile.Params.ABID.Value;
                                    rz.Zeile.Params.INTF_ID.Value = 73;
                                    rz2.Zeile.Params.RAKZTXT.Value = rz.Zeile.Params.RAKZTXT.Value;
                                    rz2.Zeile.Params.VERKEHRSMITTEL.Value = rz.Zeile.Params.VERKEHRSMITTEL.Value;
                                    rTyp = rz.Typ;
                                }
                                doCheck = false;

                            }
                            if (rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)
                            {
                                if (doCheck)
                                {
                                    rz2 = WReise(new dbKG_ReiseZeile(rz.Reise, null), rz);
                                }
                            }
                            rz2.An = rz.An;
                            rz.An = Convert.ToDateTime(rz.Ab.ToShortDateString() + " " + ckorrZT_2359);
                            rz.ReiseTag = rz.Ab;
                            rz2.Ab = Convert.ToDateTime(rz2.An.ToShortDateString() + " " + ckorrZT_0000);
                            rz2.Zeile.Params.GEFKM.Value = 0;
                            if (rz2.An.ToString("t").Equals(cNullrefZT) && rz.Ab.ToShortDateString() != rz2.An.ToShortDateString())
                            {
                                rz.Typ = rTyp;
                            }
                            //TAPM-27, geht die Reise �ber Monatsgr�nze
                            if (rz.Ab.Month == rz2.An.Month || rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                            {
                                //TAPM-27 hier geht die Reise nicht �ber Monatsgr�nze oder es ist eine Hinreise welche im Vortag begonnen ist
                                // Code bleibt gleich wie bisher
                                rzs2.Add(rz);
                                if (rz2.An.ToString("t").Equals(cNullrefZT) && rz.Ab.ToShortDateString() != rz2.An.ToShortDateString())
                                {
                                    // Splitt nicht m�glich:
                                    // dieser ergibt sich, wenn die Ankunftszeit (von dem 2. "Splitt"-Satz) am n�chsten Tag um 00:00 anf�llt
                                    // z.Bsp. 01.11 07:00 - 02.11 00:00
                                    //  Nach dem Splitting: 
                                    //  rz.Ab - An :           01.11 07:00 - 01.11 23:59
                                    //  rz2.Ab - An:           02.11 00:00 - 02.11 00:00
                                    //
                                }
                                else
                                {
                                    // nur eine Reisezeile generieren, die nicht am Mitternacht beginnt und endet,
                                    // z.B. 01.11.2006 00:00 - 02.11.2006 00:00 (aus bspw. 01.11.2006 23:00 - 02.11.2006 00:00)
                                    //       ausschliessen
                                    rz2.ReiseTag = rz2.Ab;
                                    rzs2.Add(rz2);
                                }
                            }
                            else
                            {
                                //TAPM-27, hier ist R�ckreise welche �ber Monatsgr�nze
                                if (rz2.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                                {
                                    //R�ckreise endet in n�chsten Monat
                                    //nur ein SW bis 23:59 wird geschrieben
                                    if (Monat.MaxDatum.ToShortDateString() == rz.An.ToShortDateString() &&
                                        rz.Ab.ToShortTimeString() != rz.An.ToShortTimeString())
                                        rzs2.Add(rz);
                                    //eine TA um 23:59:59 soll automatisch genereiert werden

                                    //R�ckreise im Vormonat begonnen
                                    //Die Fahrt (SW) bis Mitternacht ist schon abgerechnet, wir schreiben nur Rest der 
                                    //R�ckreise in diesen Monat.
                                    if (Monat.MinDatum.ToShortDateString() == rz2.An.ToShortDateString())
                                    {
                                        //eine Minute dazu weil diese im Vormonat weggeonomen w�rde
                                        rz2.An = rz2.An.AddMinutes(1);
                                        rzs2.Add(rz2);
                                        //N�chste Zeile ist TA, soll aber vor rz2 geschrieben, dacher sortieren wir 
                                        //Reisezeilen nach diese prozedure
                                        sortNotwendig = true;
                                    }
                                }
                            }
                        }
                        else
                            rzs2.Add(rz);
                    }
                    else
                        rzs2.Add(rz);
                }
                rzs = new ArrayList();
                foreach (dbKG_ReiseZeile rz in rzs2) rzs.Add(rz);
            }
            #endregion
            #region Km richtigstellen und Fortrechnen
            foreach (dbKG_ReiseZeile rz in rzs)
            {
                if (WirFahrenMitdemAuto(rz.Zeile.Params.VERKEHRSMITTEL.ToString()))
                {
                    switch (rz.Typ)
                    {
                        case dbKG_ReiseZeilenTyp.FahrtAmDienstort:
                        case dbKG_ReiseZeilenTyp.Hinfahrt:
                        case dbKG_ReiseZeilenTyp.Rueckfahrt:
                        case dbKG_ReiseZeilenTyp.StandortWechsel:
                            rz.Zeile.Params.ABKM.Value = ABkm.ToString();
                            ABkm += Convert.ToInt32(rz.Zeile.Params.GEFKM.Value);
                            break;
                    }
                }
            }
            #endregion
            #region neue Reisen aus Reisen erstellen
            dbKG_Reise r = new dbKG_Reise(this, null);
            dbKG_ReiseZeile letzteZeile = null;

            //TAPM-27 Sortierung wird durchgef�hrt falls RR im Vormonat begonnen ist, damit die TA auf erste stelle stehen sollte
            if (sortNotwendig)
                rzs.Sort(new dbKG_ReiseZeileSort(dbKG_ReiseZeileSort.SortByEnum.Ab));

            foreach (dbKG_ReiseZeile z in rzs)
            {
                dbKG_ReiseZeile z1 = null;
                foreach (dbKG_ReiseZeile z2 in r.Zeilen) //merken wir uns die letzte nicht-Belegzeile der aktuellen Reise
                    if (z2.Typ != dbKG_ReiseZeilenTyp.Belegzeile) z1 = z2;

                if ((z1 != null) && (!dbKG_ReiseZeilenKZ.ZeilenFolgeValid(z1, z)))
                {
                    if (bereitAusVorg == false)  // defect 5338 bei erstmaligen aufruf von comute-sap diesen nicht unterbrechen wg inkonsistenzen
                    {
                        return "Nicht Zul�ssig: " + dbKG_ReiseZeilenKZ.GetKZText(z.Typ) + "(Ab:" + z.Ab.ToShortDateString() + " " + z.Ab.ToShortTimeString() + ") folgt auf " + dbKG_ReiseZeilenKZ.GetKZText(z1.Typ) + "!";
                    }
                    else  // defect 5593 beg
                    {
                        ret_err_txt = ret_err_txt + "<br />" + "Nicht Zul�ssig: " + dbKG_ReiseZeilenKZ.GetKZText(z.Typ) + "(Ab:" + z.Ab.ToShortDateString() + " " + z.Ab.ToShortTimeString() + ") folgt auf " + dbKG_ReiseZeilenKZ.GetKZText(z1.Typ) + "!";
                    }  // // defect 5593 end
                }

                switch (z.Typ)
                {
                    case dbKG_ReiseZeilenTyp.FahrtAmDienstort:
                    case dbKG_ReiseZeilenTyp.Hinfahrt:
                    case dbKG_ReiseZeilenTyp.StandortWechsel:
                    case dbKG_ReiseZeilenTyp.WechselBereitstellung:
                        //Defect 4299, 4393 17.01.2006 GN
                        //Eine Reise darf nicht mit einem Standortwechsel anfangen
                        //START
                        //if (z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel && r.Zeilen.Count == 0)
                        if ((z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel || z.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung) && r.Zeilen.Count == 0) //BAN 500059
                        {
                            if (bereitAusVorg == false)  // defect 5338 bei erstmaligen aufruf von comute-sap diesen nicht unterbrechen wg inkonsistenzen
                            {
                                return "Nicht Zul�ssig: Reise beginnt mit " + dbKG_ReiseZeilenKZ.GetKZText(dbKG_ReiseZeilenTyp.StandortWechsel) + "!";
                            }
                            else  // defect 5593 beg
                            {
                                ret_err_txt = ret_err_txt + "<br />" + "Nicht Zul�ssig: Reise beginnt mit " + dbKG_ReiseZeilenKZ.GetKZText(dbKG_ReiseZeilenTyp.StandortWechsel) + "!";
                            }  // defect 5593 end
                        }
                        //ENDE      
                        r.EBID = (int)z.Zeile.Params.EBID.Value;
                        r.Zeilen.Add(z);
                        break;
                    case dbKG_ReiseZeilenTyp.Rueckfahrt:
                        if (r.Zeilen.Count == 0) //suppi
                        {
                            if (bereitAusVorg == false)  // defect 5338 bei erstmaligen aufruf von comute-sap diesen nicht unterbrechen wg inkonsistenzen
                            {
                                return "Nicht Zul�ssig: Reise beginnt mit " + dbKG_ReiseZeilenKZ.GetKZText(dbKG_ReiseZeilenTyp.Rueckfahrt) + "!";
                            }
                            else  // defect 5593 beg
                            {
                                ret_err_txt = ret_err_txt + "<br />" + "Nicht Zul�ssig: Reise beginnt mit " + dbKG_ReiseZeilenKZ.GetKZText(dbKG_ReiseZeilenTyp.Rueckfahrt) + "!";
                            }  // defect 5593 end
                        }
                        //else  defect 5593 wir bauen den bl�dsinn  zusammen
                        {//das Ende einer Reise
                            r.EBID = (int)z.Zeile.Params.EBID.Value;
                            r.Zeilen.Add(z);
                            rks.Add(r);
                            r = new dbKG_Reise(this, null);
                        }
                        break;
                    case dbKG_ReiseZeilenTyp.Teilabrechnung:
                        if (r.Zeilen.Count == 0)
                        {
                            r.EBID = (int)z.Zeile.Params.EBID.Value;
                            r.Zeilen.Add(z);
                        }
                        //Defect 4299, 4393
                        //StART
                        else if (letzteZeile != null && letzteZeile.Typ != dbKG_ReiseZeilenTyp.Rueckfahrt)
                        {                        //das Ende einer Reise, wenn die letzte keine R�ckfahrt war
                            //ENDE
                            r.EBID = (int)z.Zeile.Params.EBID.Value;
                            r.Zeilen.Add(z);
                            rks.Add(r);
                            r = new dbKG_Reise(this, null);
                        }

                        break;
                    default:
                        break;
                }
                letzteZeile = z;
            }

            //Defect 4299 GN 17.1.2006
            //Wenn die letzte R�ckfahrt gel�scht wird, dann f�llt die ganze zugeh�rige Reise aus -> siehe switch-block
            //Dort steht, bei R oder abschlie�endem T speichere Reise und erzeuge neue Reise
            //Deswegen funktioniert folgende Abfrage auf r.Zeilen.Count != 0
            //�nderung Anfang 
            if (r.Zeilen.Count != 0)
            {
                //Die Reise wird hinzugef�gt
                rks.Add(r);
                //Bei Reisetyp Hinfahrt, StandortWechsel, WechselBereitstellung sollte man noch eine Teilabrechnung dranh�ngen.

                dbKG_ReiseZeilenTyp typ = ((dbKG_ReiseZeile)r.Zeilen[r.Zeilen.Count - 1]).Typ;

                //Defect 4918
                //GN 11.04.2007
                //Teilabrechnung wurde zu folgender Abfrage hinzugef�gt, da auch dieser Fall auftreten kann.

                if (typ == dbKG_ReiseZeilenTyp.StandortWechsel || typ == dbKG_ReiseZeilenTyp.WechselBereitstellung || typ == dbKG_ReiseZeilenTyp.Hinfahrt || typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                {
                    //defect 5191  r.Zeilen.Add(ZTeilab(new dbKG_ReiseZeile(letzteReise, null), false, letzteReise.IntfID, ParamVal.Date0, null));//defect 5242 pr�fung doppelt-t
                    //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                    dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(letzteReise, null), false, letzteReise.IntfID, ParamVal.Date0, null);//defect 5242 pr�fung doppelt-t
                    if (zt != null)
                        r.Zeilen.Add(zt);
                    //defect 5191 ende

                }

            }
            //�nderung Ende

            #endregion
            #region Belegzeilen richtig zuordnen

            ArrayList bereitsVerwendeteBaraulagen = new ArrayList();

            Hashtable reisenAdd = new Hashtable();

            foreach (dbKG_Reise rb1 in rks)
            {
                reisenAdd.Add(rb1, new ArrayList());
            }

            foreach (dbKG_ReiseZeile z in rzs)
            {
                bool flg_zug = false;  //defect 5764 
                if (z.Typ == dbKG_ReiseZeilenTyp.Belegzeile)
                {
                    flg_zug = false;  //defect 5764 
                    foreach (dbKG_Reise rb1 in rks)
                    {
                        //Defect 4626 - Barauslagen werden der falschen Reise zugeordnet
                        //GN 22.02.2007
                        //Start

                        if (((dbKG_ReiseZeile)rb1.Zeilen[0]).ReiseTag <= z.ReiseTag && (DateTime)z.ReiseTag <= ((dbKG_ReiseZeile)rb1.Zeilen[rb1.Zeilen.Count - 1]).ReiseTag.AddDays(1).AddMinutes(-1) && !bereitsVerwendeteBaraulagen.Contains(z))
                        {

                            ((ArrayList)reisenAdd[rb1]).Add(z);
                            flg_zug = true; //defect 5764 
                            bereitsVerwendeteBaraulagen.Add(z);
                        }
                        //Ende
                    }
                    // defect 5764 beg: nicht zugeordnete belegzeilen trotdem irgendwo zuordnen, sonst sind die futsch
                    if (flg_zug == false)
                    {
                        foreach (dbKG_Reise rb1 in rks)
                        {
                            if (((dbKG_ReiseZeile)rb1.Zeilen[0]).ReiseTag <= z.ReiseTag && !bereitsVerwendeteBaraulagen.Contains(z))
                            {
                                ((ArrayList)reisenAdd[rb1]).Add(z);
                                bereitsVerwendeteBaraulagen.Add(z);
                                break;
                            }
                        }
                    }

                    //defect 5764 ende

                }



            }

            foreach (dbKG_Reise rb1 in reisenAdd.Keys)
            {
                ArrayList toAdd = (ArrayList)reisenAdd[rb1];
                rb1.Zeilen.AddRange(toAdd);

            }


            #endregion
            #region Reisen auf Vollst�ndigkeit pr�fen
            foreach (dbKG_Reise re in rks)
            {
                dbKG_ReiseZeile z1 = null;
                foreach (dbKG_ReiseZeile z2 in re.Zeilen)
                    if (z2.Typ != dbKG_ReiseZeilenTyp.Belegzeile)
                    {
                        z1 = z2;
                        break;
                    }
                dbKG_ReiseZeile z8 = null;
                foreach (dbKG_ReiseZeile z2 in re.Zeilen)
                    if (z2.Typ != dbKG_ReiseZeilenTyp.Belegzeile) z8 = z2;
                // CG: Standortwechsel angefuehrt
                if ((z1 == null) || ((z1.Typ != dbKG_ReiseZeilenTyp.Hinfahrt) &
                                     (z1.Typ != dbKG_ReiseZeilenTyp.Teilabrechnung) & (z1.Typ != dbKG_ReiseZeilenTyp.StandortWechsel)))
                    //dann is was faul
                    if (bereitAusVorg == false)  // defect 5338 bei erstmaligen aufruf von comute-sap diesen nicht unterbrechen wg inkonsistenzen
                    {
                        return "Unzul�ssiger Typ f�r Reisebeginn: " + dbKG_ReiseZeilenKZ.GetKZText(z1.Typ) + " Ab: " + z1.Ab.ToShortDateString() + " " + z1.Ab.ToShortTimeString();
                    }
                    else  // defect 5593 beg
                    {
                        ret_err_txt = ret_err_txt + "<br />" + "Unzul�ssiger Typ f�r Reisebeginn: " + dbKG_ReiseZeilenKZ.GetKZText(z1.Typ) + " Ab: " + z1.Ab.ToShortDateString() + " " + z1.Ab.ToShortTimeString();
                    }  // defect 5593 end

                if ((z8 == null) || ((z8.Typ != dbKG_ReiseZeilenTyp.Rueckfahrt) & (z8.Typ != dbKG_ReiseZeilenTyp.Teilabrechnung)))
                    if (bereitAusVorg == false)  // defect 5338 bei erstmaligen aufruf von comute-sap diesen nicht unterbrechen wg inkonsistenzen
                    {
                        return "Unzul�ssiger Typ f�r Reiseende: " + dbKG_ReiseZeilenKZ.GetKZText(z8.Typ) + " Ab: " + z8.Ab.ToShortDateString() + " " + z8.Ab.ToShortTimeString();
                    }
                    else  // defect 5593 beg
                    {
                        ret_err_txt = ret_err_txt + "<br />" + "Unzul�ssiger Typ f�r Reiseende: " + dbKG_ReiseZeilenKZ.GetKZText(z8.Typ) + " Ab: " + z8.Ab.ToShortDateString() + " " + z8.Ab.ToShortTimeString();
                    }  // defect 5593 end

                re.Von = z1.Ab;
                re.Bis = z8.An;
                foreach (dbArbTag arbt in (Monat.Monteur.MBerichte[0] as dbMontBer).Tage)
                    foreach (dbArbZeit arbz in arbt.Zeiten)
                        if ((arbz.Params is dbAZ_ARBZEITParams) && ((int)(arbz.Params as dbAZ_ARBZEITParams).EBID.Value == re.EBID))
                        {
                            if (re.ErsteAZ == null) re.ErsteAZ = arbz;
                            re.LetzteAZ = arbz;
                        }
            }
            #endregion
            #region Daten vervollst�ndigen, verlinken und ArbZeiten f�r die Reisezeiten
            ArrayList aZeiten = new ArrayList();
            dbBearbeiter Bearb = (dbBearbeiter)Session["Bearbeiter"];
            foreach (dbKG_Reise re in rks)
            {
                re.Kopf.Params.ABRNR.Value = (int)(re.Zeilen[0] as dbKG_ReiseZeile).Zeile.Params.EBID.Value;
                re.Kopf.Params.AENPERSKEY.Value = Bearb.Params.PERSKEY.Value; // Monat.Monteur.Params.PERSKEY.Value;
                re.Kopf.Params.ART.Value = "I";
                re.Kopf.Params.BEARBDAT.Value = DateTime.Now;
                re.Kopf.Params.BEARBEITER.Value = "M";
                re.Kopf.Params.DATLA.Value = DateTime.Now;
                re.Kopf.Params.DATLASRV.Value = DateTime.Now;
                re.Kopf.Params.DATNEU.Value = DateTime.Now;
                re.Kopf.Params.DSTBER.Value = DBNull.Value;
                re.Kopf.Params.FIRMA.Value = Monat.Monteur.Firmenkennung;
                re.Kopf.Params.HAUPTREISE.Value = "Montage";
                re.Kopf.Params.HUBRAUM.Value = "";
                re.Kopf.Params.KURSEIGENW.Value = "0.0";
                re.Kopf.Params.KURSFREMDW.Value = "0.0";
                re.Kopf.Params.MANDANT.Value = Monat.Monteur.Params.MANDANT.Value;
                re.Kopf.Params.NAME.Value = Monat.Monteur.Params.NACHNAME.Value;
                re.Kopf.Params.PERSKEY.Value = Monat.Monteur.Params.PERSKEY.Value;
                re.Kopf.Params.PERSNR.Value = Monat.Monteur.Params.PERSNR.Value.ToString().Substring(2);
                re.Kopf.Params.POLKZ.Value = Monat.Monteur.TechParams.KFZKZ.Value;
                re.Kopf.Params.RAHIST.Value = DBNull.Value;
                re.Kopf.Params.RASTAT.Value = 40;
                re.Kopf.Params.REGION.Value = DBNull.Value;
                re.Kopf.Params.STANDORT.Value = DBNull.Value;
                re.Kopf.Params.STATUS.Value = DBNull.Value;
                re.Kopf.Params.TEXT.Value = "";
                re.Kopf.Params.VGPERSKEY.Value = Monat.Monteur.Vorgesetzter.Params.PERSKEY.Value;
                re.Kopf.Params.VORGESKEY.Value = Monat.Monteur.Vorgesetzter.Params.PERSKEY.Value;
                re.Kopf.Params.VORNAME.Value = Monat.Monteur.Params.VORNAME.Value;
                re.Kopf.Params.WAGENTYPE.Value = Monat.Monteur.TechParams.KFZ.Value;
                foreach (dbKG_ReiseZeile ze in re.Zeilen)
                {
                    ze.Zeile.RaKopf = re.Kopf;
                    re.Kopf.Zeilen.Add(ze);
                }
            }
            //Vorhandene Reisezeiten l�schen
            Debug.WriteLine("dbKGRabrech:ComputeSAP:Vorhandene Reisezeiten l�schen Beginn at " + DateTime.Now.ToLongTimeString());
            foreach (dbMontBer mb in Monat.Monteur.MBerichte)
                if (mb.ReiseTageErfasst) //BAF 530042 - nur Wenn ReiseTage erfasst sind
                {
                    foreach (dbArbTag rt in mb.ReiseTage)
                        foreach (dbArbZeit az in rt.Zeiten)
                            if (!az.AllowUpdate) az.Deleted = true; //nurnix was aus der DB kommt l�schen, das sollte vom vormonat �brig sein!!
                }
            Debug.WriteLine("dbKGRabrech:ComputeSAP:Vorhandene Reisezeiten l�schen End at " + DateTime.Now.ToLongTimeString());
            //neue Reisezeiten generieren
            //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
            string aufenthaltsOrt = "";
            if (rks != null && rks.Count > 0)
            {
                dbKG_Reise ersteReise = (dbKG_Reise)rks[0];
                dbKG_ReiseZeile ersteReiseZeile = ersteReise.ersteHSoderT;
                if (ersteReiseZeile != null && ersteReiseZeile.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                {
                    try
                    {
                        aufenthaltsOrt = (string)Session["letztesAufenhaltsort"];
                    }
                    catch
                    {
                    }
                }
            }
            foreach (dbKG_Reise re in rks)
            {
                foreach (dbKG_ReiseZeile z in re.Zeilen)
                {

                    /* defect 6044
                     *  in case of "hinreise" - EbID from next (productive)work time - ArbeitZeit
                     *  in case of "rueckreise" - EbID from previous (productive)work time - ArbeitZeit
                     *  in case of "standortwechsel - EbID from next (productive)work time - ArbeitZeit
                     */
                    if (Monat.Rabrech.ArbzeitenALL != null)
                        switch (z.Typ)
                        {
                            case dbKG_ReiseZeilenTyp.Hinfahrt:
                                //foreach (dbArbZeit az in aZeiten)
                                //{
                                //    if (z.Ab == az.Kommen && az.IstArbeitsZeit) 

                                //       z.Zeile.Params.EBID.Value = az.Params.EBID.Value;

                                //}

                                // EbID von naechste AZ wird zugeordnet
                                foreach (dbArbTag at in Monat.Rabrech.ArbzeitenALL)
                                {
                                    if (at.TagesDatum == z.An.Date)
                                    {
                                        foreach (dbArbZeit az in at.Zeiten)
                                        {
                                            if (az.Kommen == z.An)
                                            {
                                                try
                                                {
                                                    if (z.Zeile.Params.EBID.Value.ToString() != ((dbAZ_ARBZEITParams)az.Params).EBID.Value.ToString())
                                                    {
                                                        // Debug.WriteLine("z -" + z.Zeile.Params.EBID.Value + " ... az -" + ((dbAZ_ARBZEITParams)az.Params).EBID.Value);
                                                        z.Zeile.Params.EBID.Value = ((dbAZ_ARBZEITParams)az.Params).EBID.Value;
                                                    }
                                                    //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
                                                    dbBaustelleStandort bs = GetBaustelleStandort(Convert.ToInt32(((dbAZ_ARBZEITParams)az.Params).EBID.Value));
                                                    z.Zeile.Params.ABORT.Value = Monat.Monteur.Standort.Params.PLZZ.Value.ToString() + " " + Monat.Monteur.Standort.Params.ORT.Value.ToString();
                                                    z.Zeile.Params.ANORT.Value = bs.Baustelle.Params.PLZ.Value + " " + bs.Baustelle.Params.ORT.Value.ToString();
                                                    aufenthaltsOrt = z.Zeile.Params.ANORT.Value.ToString(); ;
                                                }
                                                catch
                                                {
                                                    //wir lassen so wie es ist
                                                }
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                }
                                break;
                            case dbKG_ReiseZeilenTyp.FahrtAmDienstort:
                                // EbID von naechste AZ wird zugeordnet
                                foreach (dbArbTag at in Monat.Rabrech.ArbzeitenALL)
                                {
                                    if (at.TagesDatum == z.An.Date)
                                    {
                                        foreach (dbArbZeit az in at.Zeiten)
                                        {
                                            if (az.Kommen == z.An)//&& az.AuftragNr == z.AuftragNr)
                                            {
                                                try
                                                {
                                                    if (z.Zeile.Params.EBID.Value.ToString() != ((dbAZ_ARBZEITParams)az.Params).EBID.Value.ToString())
                                                    {
                                                        // Debug.WriteLine("z -" + z.Zeile.Params.EBID.Value + " ... az -" + ((dbAZ_ARBZEITParams)az.Params).EBID.Value);
                                                        z.Zeile.Params.EBID.Value = ((dbAZ_ARBZEITParams)az.Params).EBID.Value;
                                                    }
                                                    //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
                                                    dbBaustelleStandort bs = GetBaustelleStandort(Convert.ToInt32(((dbAZ_ARBZEITParams)az.Params).EBID.Value));
                                                    z.Zeile.Params.ANORT.Value = z.Zeile.Params.ABORT.Value = bs.Baustelle.Params.PLZ.Value + " " + bs.Baustelle.Params.ORT.Value.ToString();
                                                    aufenthaltsOrt = z.Zeile.Params.ANORT.Value.ToString();
                                                }
                                                catch
                                                {
                                                    //wir lassen so wie es ist
                                                }
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                }
                                break;
                            case dbKG_ReiseZeilenTyp.Rueckfahrt:
                                // EbID von vorige AZ wird zugeordnet
                                foreach (dbArbTag at in Monat.Rabrech.ArbzeitenALL)
                                {
                                    if (at.TagesDatum == z.Ab.Date)
                                    {
                                        foreach (dbArbZeit az in at.Zeiten)
                                        {
                                            if (az.Gehen == z.Ab)
                                            {
                                                try
                                                {
                                                    if (z.Zeile.Params.EBID.Value.ToString() != ((dbAZ_ARBZEITParams)az.Params).EBID.Value.ToString())
                                                    {
                                                        //Debug.WriteLine("z -" + z.Zeile.Params.EBID.Value + " ... az -" + ((dbAZ_ARBZEITParams)az.Params).EBID.Value);
                                                        z.Zeile.Params.EBID.Value = ((dbAZ_ARBZEITParams)az.Params).EBID.Value;
                                                    }
                                                    //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
                                                    dbBaustelleStandort bs = GetBaustelleStandort(Convert.ToInt32(((dbAZ_ARBZEITParams)az.Params).EBID.Value));
                                                    z.Zeile.Params.ABORT.Value = bs.Baustelle.Params.PLZ.Value + " " + bs.Baustelle.Params.ORT.Value.ToString();
                                                    z.Zeile.Params.ANORT.Value = Monat.Monteur.Standort.Params.PLZZ.Value.ToString() + " " + Monat.Monteur.Standort.Params.ORT.Value.ToString();
                                                    aufenthaltsOrt = z.Zeile.Params.ANORT.Value.ToString();
                                                }
                                                catch
                                                {
                                                    //wir lassen so wie es ist
                                                }
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                }
                                break;

                            case dbKG_ReiseZeilenTyp.WechselBereitstellung: //BAN 500059 - Wie StandortWechsel betrachten ???? 
                            //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
                            case dbKG_ReiseZeilenTyp.StandortWechsel:
                                // Quartierfahrt
                                if (z.Zeile.Params.INTF_ID.Value.ToString() == "72" || z.Zeile.Params.INTF_ID.Value.ToString() == "73") //ToString() == "" || z.Zeile.Params.ABORT.Value.ToString() == "") //quartierfahrt
                                    break;
                                bool anOrtfound = false;
                                bool abOrtfound = false;
                                z.Zeile.Params.ANORT.Value = aufenthaltsOrt;
                                foreach (dbArbTag at in Monat.Rabrech.ArbzeitenALL)
                                {
                                    foreach (dbArbZeit az in at.Zeiten)
                                    {
                                        try //machen wir try/catch ... wer wei� was alles passieren kann
                                        {
                                            if (az.Kommen == ParamVal.Date0 || az.Gehen == ParamVal.Date0 || az.Params is dbAZ_KALTAGParams)
                                                continue;
                                            dbBaustelleStandort bs = GetBaustelleStandort(Convert.ToInt32(((dbAZ_ARBZEITParams)az.Params).EBID.Value));
                                            if (abOrtfound == false)
                                            {
                                                if (az.Gehen <= z.Ab)
                                                {
                                                    z.Zeile.Params.ABORT.Value = bs.Baustelle.Params.PLZ.Value + " " + bs.Baustelle.Params.ORT.Value.ToString();
                                                }
                                                else
                                                {
                                                    if (az.Kommen == z.Ab && z.Ab == z.An)
                                                    {
                                                        z.Zeile.Params.ABORT.Value = aufenthaltsOrt; // + " " + bs.Baustelle.Params.ORT.Value.ToString();
                                                    }
                                                    // Defect xxxx Ein SW innerhalb eine AZ
                                                    if (az.Gehen > z.Ab && az.Kommen < z.An && z.Ab == z.An)
                                                    {
                                                        z.Zeile.Params.ABORT.Value = bs.Baustelle.Params.PLZ.Value + " " + bs.Baustelle.Params.ORT.Value.ToString();
                                                        z.Zeile.Params.ANORT.Value = bs.Baustelle.Params.PLZ.Value + " " + bs.Baustelle.Params.ORT.Value.ToString();
                                                        anOrtfound = true;
                                                    }
                                                    abOrtfound = true;
                                                }
                                            }
                                            if (anOrtfound == false && abOrtfound == true)
                                            {
                                                if (az.Kommen >= z.An)
                                                {
                                                    z.Zeile.Params.ANORT.Value = bs.Baustelle.Params.PLZ.Value + " " + bs.Baustelle.Params.ORT.Value.ToString();
                                                    anOrtfound = true;
                                                }
                                            }

                                            if (abOrtfound && anOrtfound)
                                            {
                                                aufenthaltsOrt = z.Zeile.Params.ANORT.Value.ToString();
                                                break;
                                            }
                                        }
                                        catch
                                        {
                                            // do nothing
                                        }
                                    }
                                    if (abOrtfound && anOrtfound)
                                    {
                                        break;
                                    }
                                }
                                break;
                        }
                    // ende 6044
                    dbMontBer mb = null;
                    int mbi = -1;
                    foreach (dbMontBer mm in Monat.Monteur.MBerichte)
                    {
                        mbi++;
                        if ((int)mm.Params.EBID.Value == (int)z.Zeile.Params.EBID.Value)
                        {
                            mb = mm;
                            break;
                        }
                    }
                    if (mb != null) //zaboing bei rollung
                    {
                        if ((Monat.Monteur.MBerichte[mbi] as dbMontBer).RAbrech == null)
                            (Monat.Monteur.MBerichte[mbi] as dbMontBer).RAbrech = this;
                        DateTime zAB = ParamVal.Date0;
                        switch (z.Typ)
                        {
                            case dbKG_ReiseZeilenTyp.FahrtAmDienstort:
                            case dbKG_ReiseZeilenTyp.Hinfahrt:
                            case dbKG_ReiseZeilenTyp.Rueckfahrt:
                            case dbKG_ReiseZeilenTyp.StandortWechsel:
                                //BAF 530042 Beginn - AZMKalenderTage ersetzen AZM Aufrufe 
                                if (Monat.Monteur.AZMKalenderTage.ContainsKey(z.Ab.Date) && Monat.Monteur.AZMKalenderTage.ContainsKey(z.An.Date))
                                {
                                    DateTime nBeg = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + Monat.Monteur.AZMKalenderTage[z.Ab.Date].AZ_Begin.ToShortTimeString());
                                    //DateTime nEnd = Convert.ToDateTime(z.An.ToShortDateString() + " " + Monat.Monteur.AZMKalenderTage[z.An.Date].AZ_Ende.ToShortTimeString());
                                    DateTime nEnd = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + Monat.Monteur.AZMKalenderTage[z.Ab.Date].AZ_Ende.ToShortTimeString());
                                    // defect 5696 beginn  1.versuch der korrektur...
                                    bool bupd = false;
                                    if (Monat.Monteur.AZMKalenderTage[z.Ab.Date].AZ_SollarbeitStd == 0)
                                    {
                                        // wir reisen an einem nichtarbeitstag dh nbeg und nend seten wir k�nslich....
                                        nBeg = z.An.AddMinutes(1);
                                        nEnd = z.An.AddMinutes(2);
                                        bupd = true;
                                    }
                                    // defect 5696 ende
                                    TimeSpan vorher = new TimeSpan(nBeg.Ticks - z.Ab.Ticks);
                                    TimeSpan dazwischen = new TimeSpan(Math.Min(z.An.Ticks, nEnd.Ticks) - Math.Max(z.Ab.Ticks, nBeg.Ticks));
                                    TimeSpan nachher = new TimeSpan(z.An.Ticks - nEnd.Ticks);
                                    int iDay = z.Ab.Day - 1;
                                    if (z.Ab.Month != Monat.MinDatum.Month)
                                    {
                                        //wir springen nicht mehr ins n�chste Monat also es kann nur Reise welche im Vormonat begonnen ist
                                        iDay = 0;
                                        //iDay = Monat.MaxDatum.Day - 1;
                                    }

                                    //Defect #5171
                                    //19.6.2007 GN
                                    //Standortwechsel am Wochenende f�hren zu Fehlermeldung
                                    bool useTime = true; //5171 Wird auf false gesetzt, wenn es sich bei der momentan bearbeiteten Zeit um einen Standortwechsel mit 0 Minuten handelt

                                    if (z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel && z.Ab.Ticks - z.An.Ticks == 0) useTime = false;

                                    if (vorher.TotalMinutes > 0 && useTime) //5171 && useTime hinzugef�gt
                                    {//eine Arbzeit vor der Dienstzeit
                                        (Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTageErfasst = true;
                                        dbArbZeit zv = new dbArbZeit((dbArbTag)(Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay], dbArbZeit.ArbZeitType.ReiseVorherNachher);
                                        zv.Kommen = z.Ab;
                                        if (dazwischen.TotalMinutes > 0) zv.Gehen = nBeg;
                                        else zv.Gehen = z.An;
                                        (zv.Params as dbAZ_ARBZEITParams).AUFTRNR.Value = z.AuftragNr;
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay] as dbArbTag).Zeiten.Add(zv);
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).Tage[iDay] as dbArbTag).Relevanz = true;  //defect 5696 zum speichern der zeitz sollte das gesetzt sein
                                        aZeiten.Add(zv);
                                        zv.AllowUpdate = false;
                                        // defect 5696 beg: wir wollen das zeug auch schreiben in die db
                                        //zv.AllowUpdate = bupd; 
                                        //zv.Deleted = bupd;
                                        if (bupd == true)
                                        {
                                            zv.AllowUpdate = false;
                                            zv.Deleted = false;
                                        }
                                        zv.istReisezeit = true;
                                        // defect 5696 ende

                                    }
                                    if (dazwischen.TotalMinutes > 0 && useTime)  //5171 && useTime hinzugef�gt
                                    {//eine Arbeitszeit in der Dienstzeit
                                        (Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTageErfasst = true;
                                        dbArbZeit zd = new dbArbZeit((dbArbTag)(Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay], dbArbZeit.ArbZeitType.ReiseInDienstzeit);
                                        if (vorher.TotalMinutes > 0) zd.Kommen = nBeg;
                                        else zd.Kommen = z.Ab;
                                        if (nachher.TotalMinutes > 0) zd.Gehen = nEnd;
                                        else zd.Gehen = z.An;
                                        (zd.Params as dbAZ_ARBZEITParams).AUFTRNR.Value = z.AuftragNr;
                                        zd.NormStunden = dazwischen.TotalMinutes / 60;
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay] as dbArbTag).Zeiten.Add(zd);
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).Tage[iDay] as dbArbTag).Relevanz = true;  //defect 5696 zum speichern der zeitz sollte das gesetzt sein
                                        aZeiten.Add(zd);
                                        zd.AllowUpdate = false;

                                    }
                                    if (nachher.TotalMinutes > 0 && useTime) //5171 && useTime hinzugef�gt
                                    {//eine Arbeitszeit nach der Dienstze�t
                                        (Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTageErfasst = true;
                                        dbArbZeit zn = new dbArbZeit((dbArbTag)(Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay], dbArbZeit.ArbZeitType.ReiseVorherNachher);
                                        if (dazwischen.TotalMinutes > 0) zn.Kommen = nEnd;
                                        else zn.Kommen = z.Ab;
                                        zn.Gehen = z.An;
                                        (zn.Params as dbAZ_ARBZEITParams).AUFTRNR.Value = z.AuftragNr;
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay] as dbArbTag).Zeiten.Add(zn);
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).Tage[iDay] as dbArbTag).Relevanz = true;  //defect 5696 zum speichern der zeitz sollte das gesetzt sein
                                        aZeiten.Add(zn);
                                        //Hinfahrt aus vortag ?
                                        zn.istReisezeit = true;
                                        zn.AllowUpdate = false;
                                    }
                                }//BAF 530042 Ende - AZMKalenderTage ersetzen AZM Aufrufe
                                else
                                {
                                    dbAZTag azt = (Monat.Monteur.AZModell.AZTage[(int)z.Ab.DayOfWeek] as dbAZTag);
                                    DateTime nBeg = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.AZ_Begin.Value).ToShortTimeString());
                                    if (z.Ab < Monat.MinDatum)
                                    {
                                        //Reise beginnt in vormonat
                                        azt = (Monat.Monteur.AZModell.AZTage[(int)z.An.DayOfWeek] as dbAZTag);
                                        zAB = z.Ab;
                                        z.Ab = nBeg = Monat.MinDatum; // Convert.ToDateTime(z.Ab.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.AZ_Begin.Value).ToShortTimeString());
                                    }
                                    DateTime nEnd = Convert.ToDateTime(z.An.ToShortDateString() + " " + Convert.ToDateTime(azt.Params.AZ_Ende.Value).ToShortTimeString());
                                    //TAPM-35 Beginn
                                    try
                                    {
                                        if (ConfigurationManager.AppSettings["TAPM35"] == "true")
                                        {
                                            //TAPM-35 - nBeg und nEnd aktualisieren, an dem Tag wo die Reise statgefunden hat war ein anderes AZM als der aktuelle
                                            dbAZTag aztTAPM35 = new dbAZModell(Monat.Monteur, z.Ab).AZTage[(int)z.Ab.DayOfWeek] as dbAZTag;
                                            nBeg = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + Convert.ToDateTime(aztTAPM35.Params.AZ_Begin.Value).ToShortTimeString());
                                            nEnd = Convert.ToDateTime(z.An.ToShortDateString() + " " + Convert.ToDateTime(aztTAPM35.Params.AZ_Ende.Value).ToShortTimeString());
                                        }
                                    }
                                    catch
                                    {
                                        // do nothing
                                    }// TAPM-35Ende
                                    // defect 5696 beginn  1.versuch der korrektur...
                                    bool bupd = false;
                                    if (Convert.ToDecimal(azt.Params.AZ_SollarbeitStd.Value.ToString()) == 0)
                                    {
                                        // wir reisen an einem nichtarbeitstag dh nbeg und nend seten wir k�nslich....
                                        nBeg = z.An.AddMinutes(1);
                                        nEnd = z.An.AddMinutes(2);
                                        bupd = true;

                                    }
                                    // defect 5696 ende

                                    TimeSpan vorher = new TimeSpan(nBeg.Ticks - z.Ab.Ticks);
                                    TimeSpan dazwischen = new TimeSpan(Math.Min(z.An.Ticks, nEnd.Ticks) - Math.Max(z.Ab.Ticks, nBeg.Ticks));
                                    TimeSpan nachher = new TimeSpan(z.An.Ticks - nEnd.Ticks);
                                    int iDay = z.Ab.Day - 1;
                                    if (z.Ab.Month != Monat.MinDatum.Month)
                                    {
                                        //wir springen nicht mehr ins n�chste Monat also es kann nur Reise welche im Vormonat begonnen ist
                                        iDay = 0;
                                        //iDay = Monat.MaxDatum.Day - 1;
                                    }

                                    //Defect #5171
                                    //19.6.2007 GN
                                    //Standortwechsel am Wochenende f�hren zu Fehlermeldung
                                    bool useTime = true; //5171 Wird auf false gesetzt, wenn es sich bei der momentan bearbeiteten Zeit um einen Standortwechsel mit 0 Minuten handelt

                                    if (z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel && z.Ab.Ticks - z.An.Ticks == 0) useTime = false;

                                    if (vorher.TotalMinutes > 0 && useTime) //5171 && useTime hinzugef�gt
                                    {//eine Arbzeit vor der Dienstzeit
                                        (Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTageErfasst = true;
                                        dbArbZeit zv = new dbArbZeit((dbArbTag)(Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay], dbArbZeit.ArbZeitType.ReiseVorherNachher);
                                        zv.Kommen = z.Ab;
                                        if (dazwischen.TotalMinutes > 0) zv.Gehen = nBeg;
                                        else zv.Gehen = z.An;
                                        (zv.Params as dbAZ_ARBZEITParams).AUFTRNR.Value = z.AuftragNr;
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay] as dbArbTag).Zeiten.Add(zv);
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).Tage[iDay] as dbArbTag).Relevanz = true;  //defect 5696 zum speichern der zeitz sollte das gesetzt sein
                                        aZeiten.Add(zv);
                                        zv.AllowUpdate = false;
                                        // defect 5696 beg: wir wollen das zeug auch schreiben in die db
                                        //zv.AllowUpdate = bupd; 
                                        //zv.Deleted = bupd;
                                        if (bupd == true)
                                        {
                                            zv.AllowUpdate = false;
                                            zv.Deleted = false;
                                        }
                                        zv.istReisezeit = true;
                                        // defect 5696 ende

                                    }
                                    if (dazwischen.TotalMinutes > 0 && useTime)  //5171 && useTime hinzugef�gt
                                    {//eine Arbeitszeit in der Dienstzeit
                                        (Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTageErfasst = true;
                                        dbArbZeit zd = new dbArbZeit((dbArbTag)(Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay], dbArbZeit.ArbZeitType.ReiseInDienstzeit);
                                        if (vorher.TotalMinutes > 0) zd.Kommen = nBeg;
                                        else zd.Kommen = z.Ab;
                                        if (nachher.TotalMinutes > 0) zd.Gehen = nEnd;
                                        else zd.Gehen = z.An;
                                        (zd.Params as dbAZ_ARBZEITParams).AUFTRNR.Value = z.AuftragNr;
                                        zd.NormStunden = dazwischen.TotalMinutes / 60;
                                        //Pausenberechnung bei ReiseImDienstzeit
                                        //hier fehlt noch �ber�pr�fung ob pause schon bei eine andere Reise abgezo9gen ist
                                        //ein defect must her ....
                                        /*
                                        try
                                        {
                                            if (Monat.Rabrech.ArbzeitenALL != null)
                                            {
                                                double aStd = dazwischen.TotalMinutes;
                                                double pause = 0;
                                                bool pauseBerechnen = false;
                                                foreach (dbArbTag at in Monat.Rabrech.ArbzeitenALL)
                                                {
                                                    if (at.TagesDatum == z.An.Date)
                                                    {
                                                        foreach (dbArbZeit az in at.Zeiten)
                                                        {
                                                            if (az.STDAbsenzID.Equals(STDAbsenzIDs.Zeitausgleich))
                                                                continue;
                                                            aStd += (az.NormStunden + az.UEStunden100 + az.UEStunden50) * 60;
                                                            pause += az.Pause * 60;
                                                            if (az.Kommen == zd.Gehen || az.Gehen == zd.Kommen)
                                                                pauseBerechnen = true;
                                                        }
                                                        break;
                                                    }
                                                }
                                                if (aStd > 300 && pause < 30 && pauseBerechnen)
                                                {
                                                    double ns = zd.NormStunden;
                                                    double ps = zd.Pause;
                                                    if (aStd - pause > 300)
                                                    {
                                                        zd.NormStunden -= (30 - pause) / 60;
                                                        zd.Pause = (30 - pause) / 60;
                                                    }
                                                    if (zd.NormStunden < 0 || zd.Pause < 0)
                                                    {
                                                        zd.NormStunden = ns;
                                                        zd.Pause = ps;
                                                    }
                                                }
                                            }
                                        }
                                        catch
                                        {
                                            //do nothing
                                        }*/
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay] as dbArbTag).Zeiten.Add(zd);
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).Tage[iDay] as dbArbTag).Relevanz = true;  //defect 5696 zum speichern der zeitz sollte das gesetzt sein
                                        aZeiten.Add(zd);
                                        zd.AllowUpdate = false;

                                    }
                                    if (nachher.TotalMinutes > 0 && useTime) //5171 && useTime hinzugef�gt
                                    {//eine Arbeitszeit nach der Dienstze�t
                                        (Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTageErfasst = true;
                                        dbArbZeit zn = new dbArbZeit((dbArbTag)(Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay], dbArbZeit.ArbZeitType.ReiseVorherNachher);
                                        if (dazwischen.TotalMinutes > 0) zn.Kommen = nEnd;
                                        else zn.Kommen = z.Ab;
                                        zn.Gehen = z.An;
                                        (zn.Params as dbAZ_ARBZEITParams).AUFTRNR.Value = z.AuftragNr;
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).ReiseTage[iDay] as dbArbTag).Zeiten.Add(zn);
                                        ((Monat.Monteur.MBerichte[mbi] as dbMontBer).Tage[iDay] as dbArbTag).Relevanz = true;  //defect 5696 zum speichern der zeitz sollte das gesetzt sein
                                        aZeiten.Add(zn);
                                        //Hinfahrt aus vortag ?
                                        zn.istReisezeit = true;
                                        zn.AllowUpdate = false;
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                        if (zAB != ParamVal.Date0)
                        {
                            z.Ab = zAB;
                        }
                    }
                    else
                    {
                        //keine ArbZeit bei Rollung des Vormonats
                    }
                }
            }
            #endregion
            #region Pr�fung der erstellten Arbzeiten auf �berschneidungen

            Debug.WriteLine("dbKGRabrech:ComputeSAP:Pr�fung der AZ auf �berschneidung Beginn at " + DateTime.Now.ToLongTimeString());
            /*foreach (dbMontBer mb in Monat.Monteur.MBerichte)
                foreach (dbArbTag at in mb.Tage)
                    foreach (dbArbZeit az in at.Zeiten)
                        if ((az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz) &&
                            (az.Kommen.Ticks != ParamVal.Date0.Ticks) &&
                            ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)mb.Params.EBID.Value))
                            aZeiten.Add(az);*/
            //BAF 530042 aZeiten nicht durch MBerichte sondern �ber ArbeitszeitenAll laden
            if (Monat.Rabrech.ArbzeitenALL != null)
            {
                foreach (dbArbTag at in Monat.Rabrech.ArbzeitenALL)
                {
                    if (at.TagesDatum.Month == Monat.MinDatum.Month)
                    {
                        foreach (dbArbZeit az in at.Zeiten)
                        {
                            if ((az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz) &&
                                (az.Kommen.Ticks != ParamVal.Date0.Ticks))
                                aZeiten.Add(az);
                        }
                    }
                }
            }//BAF 530042 Ende
            /*foreach (dbMontBer mb in Monat.Monteur.MBerichte) 
                foreach (dbArbTag at in mb.ReiseTage)
                    foreach (dbArbZeit az in at.Zeiten)
                        if ((az.ZeitTyp != dbArbZeit.ArbZeitType.gtAbsenz) &&
                            (az.Kommen.Ticks != ParamVal.Date0.Ticks) &&
                            ((int)(az.Params as dbAZ_ARBZEITParams).EBID.Value == (int)mb.Params.EBID.Value) &&
                            (az.AllowUpdate)) //die neu hinzugef�gten sind schon dabei!
                            aZeiten.Add(az);*/
            //TODO: GN Wof�r wurde das ben�tigt? Jetzt keine falschen Zeit�berschneidungen mehr
            dbArbZeitSort azSort = new dbArbZeitSort(dbArbZeitSort.SortByEnum.Kommen);
            aZeiten.Sort(azSort);
            DateTime de = ParamVal.Date0;
            foreach (dbArbZeit az in aZeiten)
            {
                if (de.Ticks == ParamVal.Date0.Ticks) de = az.Gehen;
                else
                {
                    if (de.Ticks > az.Kommen.Ticks)
                        if (bereitAusVorg == false)  // defect 5338 bei erstmaligen aufruf von comute-sap diesen nicht unterbrechen wg inkonsistenzen
                        {
                            return "Fehler: Zeit�berschneidung Reisezeit/Arbeitszeit am " +
                                az.Kommen.ToShortDateString() + " um " + az.Kommen.ToShortTimeString();
                        }
                        else  // defect 5593 beg
                        {
                            ret_err_txt = ret_err_txt + "<br />" + "Fehler: Zeit�berschneidung Reisezeit/Arbeitszeit am " +
                                az.Kommen.ToShortDateString() + " um " + az.Kommen.ToShortTimeString();
                        }  // defect 5593 end
                    de = az.Gehen;
                }
            }
            #endregion
            Debug.WriteLine("dbKGRabrech:ComputeSAP:Pr�fung der AZ auf �berschneidung Ende at " + DateTime.Now.ToLongTimeString());
            // beg Defect 4972 aufruf stemplegen red_ng
            if (no_rng == false)
            {
                Debug.WriteLine("dbKGRabrech:ComputeSAP:red_ng_stempel_generierung Beginn at " + DateTime.Now.ToLongTimeString());
                red_ng_stempel_generierung(rks, RNGAusCB, bereitAusVorg);  // defect 5155 par bereitAusVorg weitergeben
                Debug.WriteLine("dbKGRabrech:ComputeSAP:red_ng_stempel_generierung Ende at " + DateTime.Now.ToLongTimeString());
                rks = Reisen;
            }
            // ende Defect 4972 aufruf stemplegen red_ng


            #region this.Reisen reinitialisieren und SAP-konforme Reisen speichern, Monat.Tage reinitialisieren
            Reisen = new ArrayList();
            if (lvReise != null)
            {
                lvReise.Kopf.Params.RASTAT.Value = (int)RaStat.Genehmigt;
                //Defect 5991 - Aufenthaltsort ermitteln falls nicht vorhanden ist
                if (lvReise.Aufenthaltsort == 0 && lvReise.EBID != 0)
                    lvReise.Aufenthaltsort = GetBauIDfromEBID(lvReise.EBID);
                Reisen.Add(lvReise);
            }
            foreach (dbKG_Reise rrr in rks)
            {
                //Defect 5991 - Aufenthaltsort ermitteln falls nicht vorhanden ist
                if (rrr.Aufenthaltsort == 0 && rrr.EBID != 0)
                    rrr.Aufenthaltsort = GetBauIDfromEBID(rrr.EBID);
                Reisen.Add(rrr);
                rrr.Kopf.Zeilen = new ArrayList();
                foreach (dbKG_ReiseZeile ze in rrr.Zeilen)
                {
                    rrr.Kopf.Zeilen.Add(ze);
                }
            }
            //TAPM-27 - Falls letzte Reise nur eine TA ist ... l�sche diese Reise
            if (Reisen.Count > 1)
            {
                dbKG_Reise lastTrip = (dbKG_Reise)Reisen[Reisen.Count - 1];
                if (lastTrip.Zeilen.Count == 0) //keine Zeilen
                    Reisen.Remove(lastTrip);
                else
                    if (lastTrip.Zeilen.Count == 1)
                    {
                        if ((lastTrip.Zeilen[0] as dbKG_ReiseZeile).Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            Reisen.Remove(lastTrip);
                    }
            }
            Monat.Tage = null;
            #endregion
            Initialized = true;
            Debug.WriteLine("dbKGRabrech:ComputeSAP: End at " + DateTime.Now.ToLongTimeString());
            return ret_err_txt;  // defect 5593
        }

        private SqlParameter finde_naechste_AZ(DateTime dt_reise)
        {
            //foreach (Object az in Monat.Rabrech.ArbzeitenALL)
            //{
            //    if 
            //}

            return null;
        }


        private bool WirFahrenMitdemAuto(string Vm)
        {
            if ((Vm == "7") | (Vm == "8") | (Vm == "9") | (Vm == "D") | (Vm == "E") | (Vm == "F")) return true;
            return false;
        }
        // defect 4972 beginn
        private bool DelAllTZeileRNG(ArrayList ri)
        {
            //dbKG_Reise aktReise = null;
            bool bRet = false;
            foreach (dbKG_Reise r in ri)
            {
                bool bDel = false;
                do
                {
                    bDel = false;
                    foreach (dbKG_ReiseZeile z in r.Zeilen)
                    {
                        if (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                        {
                            if (
                                //Defect #6042 - Zus�tliche Abfrage ist TA im RA Monat ist
                                ((z.ReiseTag.Day == 1) && (z.Ab.Hour == 23) && (z.Ab.Minute == 59) && (z.Ab.Month != r.RAbrech.Monat.MinDatum.Month))
                                ||
                                (
                                (z.ReiseTag.Day == r.RAbrech.Monat.MaxDatum.Day) && (z.Ab.Hour == 23) && (z.Ab.Minute == 59))
                                ||
                                (z.flg_teilabr_del == false)  // t-zeilen f�r Urlaub/ZA nicht l�schen defect 5242
                                )
                            {
                            }
                            else
                            {
                                r.Zeilen.Remove(z);
                                bDel = true;
                                break;
                            }
                        }
                        //zus�tzlich W Zeile die TA ersetzt haben //BAN 500059
                        if (z.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung && z.Zeile.Params.INTF_ID.Value.ToString() == "85")
                        {
                            r.Zeilen.Remove(z);
                            bDel = true;
                            break;
                        }
                    }

                } while (bDel == true);
                //
                foreach (dbKG_ReiseZeile z in r.Zeilen)
                {
                    if ((z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                    {
                        if (z.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN_RED_NG)
                        {
                            z.Zeile.Params.REISEART.Value = cReiseartFERN;
                        }
                        if (z.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH_RED_NG)
                        {
                            z.Zeile.Params.REISEART.Value = cReiseartNAH;
                        }
                    }
                }
            }
            return bRet;
        }

        public bool InsertReiseZeile(dbKG_ReiseZeile z, ref dbKG_Reise r_gef, bool add)  //defect 5243 erweiterung um r_gef und add
        {
            bool bret = false;
            dbKG_Reise r = null;
            if ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                        || (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
            {
                r = FindeHinRzuRueckR(z, true);
            }
            else if ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                        || (z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt))
            {
                r = FindeRueckRzuHinR(z, true);

            }
            else if (z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)
            {
                r = FindeRueckRzuHinR(z, true); //defect 5243 suchfunktion f�r standortwechse 
                if (r == null)
                {
                    r = FindeHinRzuRueckR(z, true);
                }
            }
            //zeile hinzuf�gen
            if (r != null)
            {
                if (add == true)  //defect 5243 nicht immer dazuf�gen
                {
                    r.Zeilen.Add(z);
                    PruefeReiseZeilen(r, false);  //defect 5155 2.par: bereitstellung nicht aus vorg�ngerreise
                }
                bret = true;
            }
            r_gef = r; //defect 5243 return f�r gefunden reise 
            return bret;

        }

        // defect 5243 beginn: loeschen einer t1-zeile am monatsende wenn eine rr da ist
        public bool DelTZeileMonatsende(ref dbKG_Reise rr)
        {
            bool b_ret = false;
            foreach (dbKG_ReiseZeile z in rr.Zeilen)
            {
                if (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                {
                    foreach (dbKG_ReiseZeile z1 in rr.Zeilen)
                    {
                        if ((z1.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            && (z1.Ab.DayOfYear == Monat.MaxDatum.DayOfYear)
                            && (z1.Ab.Hour == 23)
                           )
                        {
                            // wir haben eine fl�ssige t-zeile am ende....l�schen
                            rr.Zeilen.Remove(z1);
                            b_ret = true;
                            break;
                        }
                    }
                    break;
                }
            }
            return b_ret;
        }
        // defect 5243 ende

        // loeschen von einer reisezeile in den reiseobjekten nach zeitstempel (defect 4972)
        public string DelReiseZeile(ArrayList reisen, DateTime dt, bool no_compute_sap, dbKG_ReiseZeile rz) //defect 5430, 5432 auch mit an und hascode pr�fen  // defect 5390 statt bool eine fm-string retournieren
        {
            // suchen der reise
            dbKG_Reise aktReise = null;
            bool bRet = false;
            string errRet = "";

            foreach (dbKG_Reise r in reisen)
            {
                foreach (dbKG_ReiseZeile z in r.Zeilen)
                {
                    if ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                        || (z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                        || (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                        || (z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)           //defect 5308 Standortwechsel etc. beachten
                        || (z.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung)     //defect 5308
                        || (z.Typ == dbKG_ReiseZeilenTyp.FahrtAmDienstort)          //defect 5308
                        )
                    {
                        if (dt != ParamVal.Date0) //defect 5430_5432
                        {
                            if ((z.Ab == dt) || (z.An == dt))
                            {
                                aktReise = r;
                                break;
                            }
                        }
                        else
                        {
                            //defect 5430_5432 bei suchen aus der maske wird nur das objekt inhaltlich verglichen
                            if (z == rz)
                            {
                                aktReise = r;
                                break;
                            }
                            //defect 5430_5432 ende
                        }
                    }
                }
                if (aktReise != null) // wenn gefunden defect 5430, 5432
                {
                    break;  // erste gefunden nehnem  defect 5430, 5432
                }
            }
            // loeschen der zeile in der reise
            dbKG_Reise rgef = null;
            dbKG_ReiseZeile rzgepr = null;
            if (aktReise != null)
            {
                foreach (dbKG_ReiseZeile z in aktReise.Zeilen)
                {
                    if (dt != ParamVal.Date0)
                    {
                        if (z.Ab == dt)
                        {
                            aktReise.Zeilen.Remove(z);
                            bRet = true;
                            break;
                        }
                        if (z.An == dt)
                        {
                            aktReise.Zeilen.Remove(z);
                            bRet = true;
                            break;
                        }
                    }
                    else
                    {
                        if (z == rz)
                        {
                            aktReise.Zeilen.Remove(z);
                            bRet = true;
                            break;
                        }
                    }
                }
                // pr�fen ob die reise leer ist (kein hin oder r�ckreise)
                int anz_stempel = 0;
                foreach (dbKG_ReiseZeile z in aktReise.Zeilen)
                {
                    if ((z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                        || (z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)  //defect 5243
                        || (z.Typ == dbKG_ReiseZeilenTyp.FahrtAmDienstort) //defect 5243
                        || (z.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung) //defect 5243
                        || (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                        || ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (z.flg_teilabr_del == false))  //defect 5243:das sind die genrierten t-zeilen f�r die u/k
                        || ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (z.ReiseTag.Day == 1))  //defect 5243:das ist eine t-zeile am monatsanfang
                        || ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (z.ReiseTag.Day == Monat.MaxDatum.Day))  //defect 5243:das ist eine t-zeile am monatsende
                        )
                    {
                        anz_stempel++;
                    }
                }
                if (anz_stempel == 0)
                {
                    //leere reise - l�schen
                    // defect 5590: umh�ngen von belegen auf eine andere reise
                    foreach (dbKG_ReiseZeile z in aktReise.Zeilen)
                    {
                        if ((z.Typ == dbKG_ReiseZeilenTyp.Belegzeile) || (z.Typ == dbKG_ReiseZeilenTyp.Barauslage))
                        {
                            //suchen einer anderen reise
                            dbKG_Reise rgefl = null;
                            foreach (dbKG_Reise r in reisen)
                            {
                                if ((rgefl == null) && (!r.Equals(aktReise)))
                                {
                                    rgefl = r;
                                }
                                if ((z.ReiseTag <= r.Bis) && (z.ReiseTag >= r.Von)
                                    && (!r.Equals(aktReise)))
                                {
                                    rgefl = r;
                                }
                            }
                            if (rgefl != null)
                            {
                                rgefl.Zeilen.Add(z);
                            }
                        }
                    }
                    //ende defect 5590
                    reisen.Remove(aktReise);
                }
                if (anz_stempel == 1)
                {
                    //dbKG_Reise neueReise = null;
                    //unvollst�ndige reise
                    foreach (dbKG_ReiseZeile z in aktReise.Zeilen)
                    {
                        if ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            || (z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                            //|| (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                            //|| (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            )
                        {
                            rgef = FindeRueckRzuHinR(z, false);
                            if ((rgef == null) && (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung))
                                rgef = FindeHinRzuRueckR(z, false);

                            rzgepr = z;
                            break;
                        }
                        if ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            //|| (z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                            || (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                            //|| (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                            )
                        {
                            rgef = FindeHinRzuRueckR(z, false);
                            if ((rgef == null) && (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung))
                                rgef = FindeRueckRzuHinR(z, false);

                            rzgepr = z;
                            break;
                        }
                    }
                    // wir haben nun eine passenden reise gefunden f�r die letzte zeile
                    // die h�ngen wir dieser um und loeschen die leere reise
                    if ((rgef != null) && (!rgef.Equals(aktReise)))  // defect 5329 problem gleiche reise wie gefunden reise ist nicht gut wenn man loescht !!!
                    {
                        rgef.Zeilen.Add(rzgepr);
                        PruefeReiseZeilen(rgef, false); //defect 5155 2.par: bereitstellung nicht aus vorg�ngerreise
                        // defect 5590: umh�ngen von belegen auf eine andere reise
                        foreach (dbKG_ReiseZeile z in aktReise.Zeilen)
                        {
                            if ((z.Typ == dbKG_ReiseZeilenTyp.Belegzeile) || (z.Typ == dbKG_ReiseZeilenTyp.Barauslage))
                            {
                                //suchen einer anderen reise
                                dbKG_Reise rgefl = null;
                                foreach (dbKG_Reise r in reisen)
                                {
                                    if ((rgefl == null) && (!r.Equals(aktReise)))
                                    {
                                        rgefl = r;
                                    }
                                    if ((z.ReiseTag <= r.Bis) && (z.ReiseTag >= r.Von)
                                        && (!r.Equals(aktReise)))
                                    {
                                        rgefl = r;
                                    }
                                }
                                if (rgefl != null)
                                {
                                    rgefl.Zeilen.Add(z);
                                }
                            }
                        }
                        //ende defect 5590
                        reisen.Remove(aktReise);
                    }


                }
            }
            if ((bRet == true) && (no_compute_sap == false))
            {
                errRet = ComputeSAP(false, false, false);  //defect 5155 3. parameter  // defect 5390 err string retournieren
            }
            if (bRet == false)          // defect 5390
                errRet = "L�schen nicht m�glich";  // defect 5390

            return errRet;  // string statt bool
        }
        // defect 5155  prufen aller reisen wg bereitstellungen
        public bool PruefeReisen(ArrayList reise_prf)
        {
            foreach (dbKG_Reise r in reise_prf)
            {
                bool ret = PruefeReiseZeilen(r, true); //defect 5155 2.par: bereitstellung  aus vorg�ngerreise  ermitteln
            }
            return true;
        }
        //ermitteln der vorgaendgerreise von r
        dbKG_Reise erm_vorg_reise(dbKG_Reise r, ref bool flg_beginn_T)
        {
            dbKG_Reise last_r = null;
            // ist die reise eine mit einem T am anfang ?
            bool flg_t_beg = false;
            foreach (dbKG_ReiseZeile z in r.Zeilen)
            {
                if (z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                {
                    break;

                }
                if (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                {
                    flg_t_beg = true;
                }
            }
            flg_beginn_T = flg_t_beg;
            if (ReisenALL != null)
            {
                foreach (dbKG_Reise ra in ReisenALL)
                {
                    //wenn wir die reise haben geben wir den vorg�nger zur�ck
                    if (r.Von == ra.Von)
                    {
                        break;
                    }
                    last_r = ra;
                }
            }
            return last_r;
        }
        public void set_bereitstellung_von_reise(dbKG_Reise r, string bereitst, string bereitst_txt, dbRaZeile rz)
        {
            if ((bool)Session["ber_ignore"] == false)
            {
                foreach (dbKG_ReiseZeile z in r.Zeilen)
                {

                    if ((z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) ||
                        (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) ||
                        (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) ||
                        (z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)  //defect 5243 auch bei standortwechsel
                        )
                    {

                        z.Zeile.Params.BEREITST.Value = bereitst; //defect 5155
                        z.Zeile.Params.BSTXT.Value = bereitst_txt;  //defect 5155
                    }
                }
            }
            else
            {
                foreach (dbKG_ReiseZeile z in r.Zeilen)
                {
                    if (z.Zeile == rz)
                    {
                        z.Zeile.Params.BEREITST.Value = bereitst;
                        z.Zeile.Params.BSTXT.Value = bereitst_txt;
                    }
                }

            }
        }

        bool get_bereitstellung_von_reise(dbKG_Reise r, ref string bereitst, ref string bereitst_txt)
        {
            string tmp_bereitst = "";
            string tmp_bereitst_txt = "";
            try
            {

                foreach (dbKG_ReiseZeile z in r.Zeilen)
                {
                    if (z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                    {
                        // das ist es 
                        tmp_bereitst = z.Zeile.Params.BEREITST.Value.ToString();
                        tmp_bereitst_txt = z.Zeile.Params.BSTXT.Value.ToString();
                        break;
                    }
                    if (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                    {
                        //das kanns sein
                        tmp_bereitst = z.Zeile.Params.BEREITST.Value.ToString();
                        tmp_bereitst_txt = z.Zeile.Params.BSTXT.Value.ToString();
                    }
                    if (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                    {
                        // das auch
                        tmp_bereitst = z.Zeile.Params.BEREITST.Value.ToString();
                        tmp_bereitst_txt = z.Zeile.Params.BSTXT.Value.ToString();
                    }

                }
            }
            catch
            {
                tmp_bereitst = bereitst;
                tmp_bereitst_txt = bereitst_txt;
            }
            bereitst = tmp_bereitst;
            bereitst_txt = tmp_bereitst_txt;
            return true;
        }
        //defect 5155 ende

        // prufen der gemergden reisezeieln und korrgieren der werte f�r reiseart etc.
        public bool PruefeReiseZeilen(dbKG_Reise rprf, bool korr_bereitst_vorm) //defect 5155 2.par: schalter fuer bereitstellungsermittlung aus vorg�ngerreise 
        {
            int aktReistag = 0;
            dbKG_ReiseZeile zhin = null;
            dbKG_ReiseZeile zrck = null;
            DateTime von = ParamVal.Date0;
            DateTime bis = ParamVal.Date0;
            //bool bAndreReiseAZvorher = false;
            if (rprf.Zeilen.Count == 0)
            {
                return false;
            }
            rprf.redBeg = ParamVal.Date0; // defect 4972 initn da neu bestimmt wird
            foreach (dbKG_ReiseZeile z in rprf.Zeilen)
            {
                if ((z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                    || ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && aktReistag != 0)
                    )
                {
                    zrck = z;
                    // pruefen das ende der reise aus den zeilen
                    if (bis == ParamVal.Date0)
                    {
                        bis = z.An;
                    }
                    if (bis < z.An)
                    {
                        bis = z.An;
                    }
                }
                if ((z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                    || ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && aktReistag == 0) // nur teilabrechnung ohne hinresie pruefen == reisebeginn
                    )
                {
                    zhin = z;
                    aktReistag = z.ReiseTag.DayOfYear;
                    if (von == ParamVal.Date0)
                    {
                        von = z.Ab;
                    }
                    if (von > z.Ab)
                    {
                        von = z.Ab;
                    }
                    /*
                     * if ((z.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH) // R, N, D, E
                        || (z.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  
                        || (z.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN_RED_NG)
                        || (z.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH_RED_NG)
                        )
                    {
                        //bReiseIstKandidat = true;
                    }
                     */
                    /* m�gliche bereitstellungen bei 4,5,6, 8,9 wird quartier bereitgestell -> kein anspruch auf Naechtigungsgeld
                    RAKZID     RAKZ  RAKZTXT                                           
                    ---------- ----- --------------------------------------------------
                    B          0     Keine Bereitstellungen                            
                    B          1     EINE Hauptmahlzeit (75% TG)                       
                    B          2     BEIDE Hauptmahlzeiten (50% TG)                    
                    B          3     Volle Verpflegung u. Getr�nke (25% TG)            
                    B          4     Quartier beigestellt                              
                    B          5     Quart.,Verpfl.,Getr. bei Firmenveranstalt.(10% TG)
                    B          6     Quartier u. volle Verpflegung (50% TG)            
                    B          7     Keine Verg�tung (zB Urlaub auf Dienstreise)       
                    B          8     Quartier,Verpflegung,Getr�nke (25% TG)            
                    B          9     Quartier und eine Hauptmahlzeit (75% TG)          
                    */
                    /*
                    if (
                            (z.Zeile.Params.BEREITST.Value.ToString() == "4")
                        || (z.Zeile.Params.BEREITST.Value.ToString() == "5")
                        || (z.Zeile.Params.BEREITST.Value.ToString() == "6")
                        || (z.Zeile.Params.BEREITST.Value.ToString() == "8")
                        || (z.Zeile.Params.BEREITST.Value.ToString() == "9")
                       )
                    {
                        //bBereitstellung = true;
                    }
                    */

                }

                if (z.Typ == dbKG_ReiseZeilenTyp.Belegzeile)
                {
                    if ((z.Zeile.Params.AUSLART.Value.ToString() == "HOTI") || (z.Zeile.Params.AUSLART.Value.ToString() == "HTIF"))
                    {
                        //bHotelBeleg = true;
                    }
                }


            }
            // von-bis auf zeilenzeiten korrigieren
            if (von != ParamVal.Date0)
            {
                rprf.Von = von;
            }
            if (bis != ParamVal.Date0)
            {
                rprf.Bis = bis;
            }
            //bereitstellung gleichziehen 
            string bereitst_hin = "0";
            string bereitst_hin_txt = "";  //defect 5155
            string bereitst_rck_txt = "";  //defect 5155
            try
            {
                bereitst_hin = zhin.Zeile.Params.BEREITST.Value.ToString();
                bereitst_hin_txt = zhin.Zeile.Params.BSTXT.Value.ToString();   // defect 5155 merken auch des textes
            }
            catch
            {

            }
            string bereitst_rck = "0";
            try
            {
                bereitst_rck = zrck.Zeile.Params.BEREITST.Value.ToString();
                bereitst_rck_txt = zrck.Zeile.Params.BSTXT.Value.ToString();   // defect 5155 merken auch des textes
            }
            catch
            {
            }
            bool ber_done = false;
            // # 6012 beginn
            bool ber_ignore = false;
            try
            {
                ber_ignore = (bool)Session["ber_ignore"];
            }
            catch
            {
            }
            if (bereitst_hin != bereitst_rck && ber_ignore == false)
            //if (bereitst_hin != bereitst_rck)
            {
                if (bereitst_hin != "0")
                {
                    try  //defect 5241 
                    {
                        zrck.Zeile.Params.BEREITST.Value = bereitst_hin;
                        zrck.Zeile.Params.BSTXT.Value = bereitst_hin_txt; //defect 5155
                    }
                    catch //defect 5241 
                    {
                    }

                    bereitst_rck = bereitst_hin;  //defect 5155  merken der bereitstellung aus der hinreise
                    bereitst_rck_txt = bereitst_hin_txt; //defect 5155 auch den text
                    ber_done = true;
                }
                if ((bereitst_rck != "0") && (ber_done == false))
                {
                    try  //defect 5241 
                    {
                        zhin.Zeile.Params.BEREITST.Value = bereitst_rck;
                        zhin.Zeile.Params.BSTXT.Value = bereitst_rck_txt; //defect 5155
                    }
                    catch //defect 5241 
                    {
                    }
                    bereitst_hin = bereitst_rck;  //defect 5155 merken der bereitstellung aus der r�ckreise
                    bereitst_hin_txt = bereitst_rck_txt; //defect 5155 auch den text
                }
            }
            // defect 5155 beginn: suchen vorg�ngerreise, wenn der beginn der reise eine Teilabrechnung ist
            bool flg_hinr_T = false;
            dbKG_Reise r_vorg = erm_vorg_reise(rprf, ref flg_hinr_T);
            string bereitst_hin_vorg = bereitst_hin;
            string bereitst_hin_vorg_txt = bereitst_hin_txt;
            if ((r_vorg == null) || (flg_hinr_T == false))
            {
                //nix da
            }
            else
            {
                //gib bereitstellung
                bool ret = get_bereitstellung_von_reise(r_vorg, ref bereitst_hin_vorg, ref bereitst_hin_vorg_txt);
                if (korr_bereitst_vorm == true)
                {
                    bereitst_hin = bereitst_hin_vorg;
                    bereitst_hin_txt = bereitst_hin_vorg_txt;
                }
            }
            // defect 5155 ende

            //defect# 5198 Reiseart wird nicht korrigiert weil die nicht mehr von reisedauer und km abh�ngig ist
            // #6012 remove session variable
            if (Session["ber_ignore"] != null)
                Session.Remove("ber_ignore");
            // #6012 ende
            return true;

        }
        // reduziertes NG (defect 4972)
        //ermittekln aller abrbeitszeiten die wir betrachten
        public ArrayList get_ArbzeitenALL(ArrayList ArbzeitenALL)  // defect 5701 public, um die initialiesierung aufzurufen
        {
            {
                // loop �ber alle arbeitszeiten 
                ArrayList ArbzeitenALLus = null; //alle arbeitszeiten der monate unsortiert
                ArbzeitenALLus = new ArrayList();

                foreach (dbKG_Monat VM in VorMonate)
                {
                    int first_1 = 1;
                    foreach (dbMontBer MB in VM.Monteur.MBerichte)
                    {
                        if (first_1 == VM.Monteur.MBerichte.Count)
                        {
                            foreach (dbArbTag AT in MB.Tage)
                            {
                                //if ((AT.GTAbsenz == true) || (AT.SummeProduktiveStunden > 0))  defect 4972
                                {
                                    ArbzeitenALLus.Add(AT);
                                }
                            }
                        }
                        first_1++;
                    }
                }
                int first_2 = 1;
                foreach (dbMontBer MB in Monat.Monteur.MBerichte)
                {
                    if (first_2 == Monat.Monteur.MBerichte.Count)
                    {
                        foreach (dbArbTag AT in MB.Tage)
                        {
                            //if ((AT.GTAbsenz == true) || (AT.SummeProduktiveStunden > 0))  defect 4972
                            {
                                ArbzeitenALLus.Add(AT);
                            }
                        }
                    }
                    first_2++;
                }
                ArbzeitenALL = new ArrayList();
                int beganz = ArbzeitenALLus.Count;
                for (int i = 0; i < beganz; i++)
                {
                    dbArbTag ATmin = null;
                    foreach (dbArbTag AT in ArbzeitenALLus)
                    {
                        if (ATmin == null)
                            ATmin = AT;
                        if (ATmin.TagesDatum > AT.TagesDatum)
                            ATmin = AT;
                    }
                    ArbzeitenALL.Add(ATmin);
                    ArbzeitenALLus.Remove(ATmin);
                }
            }
            return (ArbzeitenALL);

        }
        /*
                            GTABSENZID AZMNR  GTABSENZTXT                                        DATLA                                              AENPERSKEY  TSTAMP             DATNEU                                             STATUS 
                            ---------- ------ -------------------------------------------------- -------------------------------------------------- ----------- ------------------ -------------------------------------------------- ------ 
                            10         19     Ersatzruhe                                         1999-06-10 12:33:34.000                            0           0x00000000061604FE 1999-06-10 12:33:34.000                            20
                            20         28     Gesch�ftlich Abwesend                              1999-06-10 12:33:39.000                            0           0x0000000006160503 1999-06-10 12:33:39.000                            20
                            30         25     Karenzurlaub                                       1999-06-10 12:33:59.000                            0           0x00000000061604FF 1999-06-10 12:33:59.000                            20
                            40         17     Pflegefreistellung                                 1999-06-10 12:34:14.000                            0           0x00000000432B38E9 1999-06-10 12:34:14.000                            20
                            50         26     Pr�senzdienst                                      1999-06-10 12:34:25.000                            0           0x0000000006160501 1999-06-10 12:34:25.000                            20
                            60         29     Sonderurlaub (Ausland)                             1999-06-10 12:34:43.000                            0           0x0000000006160504 1999-06-10 12:34:43.000                            20
                            70         18     sonstige Abwesenheit                               1999-06-10 12:34:53.000                            0           0x00000000061604FD 1999-06-10 12:34:53.000                            20
                            80         15     Truppen�bung                                       1999-06-10 12:35:10.000                            0           0x00000000061604FA 1999-06-10 12:35:10.000                            20
                            90         12     Urlaub                                             1999-06-10 12:35:25.000                            0           0x00000000061604F7 1999-06-10 12:35:25.000                            20
                            100        13     Urlaub eigene Kosten                               1999-06-10 12:35:40.000                            0           0x00000000061604F8 1999-06-10 12:35:40.000                            20
                            110        27     Wochenhilfe                                        1999-06-10 12:35:46.000                            0           0x0000000006160502 1999-06-10 12:35:46.000                            20
                            120        16     ZA ganzt�gig                                       1999-06-10 12:35:59.000                            0           0x00000000061604FB 1999-06-10 12:35:59.000                            20
                            130        14     Paragraph 8                                        2001-05-02 18:25:39.000                            0           0x00000000061604F9 2001-05-02 18:25:39.000                            20
                            140        30     Arbeitsausfall betrieblich                         2001-05-02 18:26:20.000                            0           0x0000000006160505 2001-05-02 18:26:20.000                            20
                            150        31     Arbeitsausfall au�erbetr.                          2001-05-02 18:27:22.000                            0           0x0000000006160506 2001-05-02 18:27:22.000                            20
                            160        32     Betriebsrat                                        2001-05-02 18:27:47.000                            0           0x0000000006160507 2001-05-02 18:27:47.000                            20
                            170        33     Gestzl. Freizeit KV                                2001-05-02 18:28:06.000                            0           0x0000000006160508 2001-05-02 18:28:06.000                            20
                            180        34     Studienurlaub                                      2001-05-02 18:28:26.000                            0           0x0000000006160509 2001-05-02 18:28:26.000                            20
                            190        37     Jubil�umstag                                       2001-05-02 18:28:58.000                            0           0x000000000616050A 2001-05-02 18:28:58.000                            20
                            200        41     Sabbatical                                         2001-05-09 15:13:16.000                            0           0x000000000616050B 2001-05-09 15:13:16.000                            20
                            210        11     Krankheit                                          2003-04-10 14:32:56.873                            849         0x000000001724B630 2003-04-10 14:32:56.873                            20
                            212        20     Krankheit Beginn                                   2003-04-16 09:00:00.000                            849         0x00000000172DA837 2003-04-16 09:00:00.000                            20
                            214        21     Krankheit Ende                                     2003-04-16 09:00:00.000                            849         0x00000000172DA847 2003-04-16 09:00:00.000                            20
                            220        24     Unfall                                             2003-04-10 14:33:16.733                            849         0x000000001724B632 2003-04-10 14:33:16.733                            20
                            222        22     Unfall Beginn                                      2003-04-16 09:00:00.000                            849         0x00000000172DA852 2003-04-16 09:00:00.000                            20
                            224        23     Unfall Ende                                        2003-04-16 09:00:00.000                            849         0x00000000172DA869 2003-04-16 09:00:00.000                            20
                            226        42     Firmensonderurlaub/BVI                             2007-03-28 11:24:45.260                            0           0x000000004534FC3A 2007-03-28 11:24:45.260                            20
                            228        44     Feiertag im Ausland                                2007-03-28 11:24:45.260                            0           0x000000004534FC3B 2007-03-28 11:24:45.260                            20
                            230        58     Bildungsfreistellung                               2007-03-28 11:24:45.260                            0           0x000000004534FC3C 2007-03-28 11:24:45.260                            20
         * */
        // ermiitle einer krankeheit-urlaubszeitspanne
        private bool get_KU_ab_dat(ArrayList az_all, DateTime abDat, DateTime beg, DateTime end)
        {
            dbArbTag at_erster = null;
            dbArbTag at_letzer = null;
            int anz_uk = 0;
            foreach (dbArbTag AT in az_all)
            {

                if (AT.TagesDatum.DayOfYear >= abDat.DayOfYear)
                {
                    //tag innerhalb der reise
                    if ((AT.GTAbsenzID == 212)
                        || (AT.GTAbsenzID == 210)
                        || (AT.GTAbsenzID == 214)
                        || (AT.GTAbsenzID == 222)
                        || (AT.GTAbsenzID == 220)
                        || (AT.GTAbsenzID == 224)
                       )
                    {
                        //das ist jetzt Unfall / Krankheit
                        if (at_erster == null)
                        {
                            // erster tag
                            at_erster = AT;
                        }
                        else
                        {
                            at_letzer = AT;
                        }
                        anz_uk++;
                    }
                }
            }
            return true;
        }
        // defect 5242 beginn:suchen nach unfall/krankeit-absenzblock
        private bool finde_UKR_block(ArrayList az_all, ref DateTime finde_von, ref int anz_uk, ref dbArbTag at_erster, ref dbArbTag at_letzer, ref bool weitereAbsenzen)
        {
            foreach (dbArbTag AT in az_all)
            {
                if ((AT.TagesDatum.Year == Monat.MinDatum.Year)
                     &&
                     (AT.TagesDatum.Month == Monat.MinDatum.Month)
                    &&
                     (AT.TagMin > finde_von)
                   )
                {
                    //tag innerhalb der reise 
                    if ((AT.GTAbsenzID == 212)
                        || (AT.GTAbsenzID == 210)
                        || (AT.GTAbsenzID == 214)
                        || (AT.GTAbsenzID == 222)
                        || (AT.GTAbsenzID == 220)
                        || (AT.GTAbsenzID == 224)
                       )
                    {
                        //das ist jetzt Unfall / Krankheit
                        if (at_erster == null)
                        {
                            // erster tag
                            at_erster = AT;
                            at_letzer = AT;
                        }
                        else
                        {
                            at_letzer = AT;
                        }
                        anz_uk++;
                    }
                    else
                    {
                        //hier springen wir �ber feiertag, fenstertag & wochenende
                        //BAF 530042 Beginn - AZMKalenderTage ersetzen AZM Aufrufe
                        if (AT.MBericht.Bearbeiter.BerichtsMonat == 0)
                            AT.MBericht.Bearbeiter.BerichtsMonat = AT.MBericht.BerichtsMonat;
                        if (AT.MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(AT.TagesDatum))
                        {
                            if (!AT.MBericht.Bearbeiter.AZMKalenderTage[AT.TagesDatum].IstArbeitstag
                                && AT.SummeProduktiveStundenAlleMBs == 0
                                && AT.GTAbsenzID == 0)
                                continue;
                        }//BAF 530042 Ende
                        else
                            if (!AT.MBericht.Bearbeiter.IstArbeitstag(AT.TagesDatum)
                                && AT.SummeProduktiveStundenAlleMBs == 0
                                && AT.GTAbsenzID == 0)
                            {
                                continue;
                            }
                        //Defect #6108 - Absenz vor dem Unfall/Krankheit
                        if (anz_uk == 0)
                        {
                            if (AT.GTAbsenzID != 0)
                                weitereAbsenzen = true;
                            else
                                weitereAbsenzen = false;
                        }
                        else
                        {
                            //Defect #6108 - Eine Absenz nach Unfall/Krankheit
                            if (AT.GTAbsenzID != 0)
                            {
                                weitereAbsenzen = true;
                                at_letzer = AT;
                                continue; //nicht abbrechen
                            }
                        }
                        if (at_erster != null)
                            break;
                    }
                }
            }
            if (at_erster == null)
            {
                finde_von = Monat.MaxDatum;
                return false;
            }
            else
            {
                finde_von = at_letzer.TagMax;
                return true;
            }
        }
        // defect 5242 ende

        //L�schen einer generierten hin/r�ckresien bei urlaub/unfall etc.
        // im gobackhome wird f�r jede t�gliche absenz automatisch eine r�ck/hinreise generiert
        private ArrayList DelAutoRR(ArrayList r_all, ArrayList az_all)
        {
            int anz_uk = 0;
            dbArbTag at_erster = null;
            dbArbTag at_letzer = null;
            // defect 5242 beginn
            DateTime finde_von = Monat.MinDatum;
            bool b_ret1 = true;
            while (b_ret1 == true)
            {
                // defect 5242 ende
                anz_uk = 0;
                at_erster = null;
                at_letzer = null;
                bool weitereAbsenzen = false;

                b_ret1 = finde_UKR_block(az_all, ref  finde_von, ref  anz_uk, ref  at_erster, ref  at_letzer, ref weitereAbsenzen); //defect 5242

                // weniger als 8 tage auf u/k
                if ((anz_uk < 8) && (anz_uk > 0)
                    && (at_erster != null)
                    && (at_letzer != null)
                    && weitereAbsenzen == false)
                {
                    DateTime erster = at_erster.TagesDatum;
                    DateTime letzer = at_letzer.TagesDatum;
                    erster = erster.AddDays(-1);
                    letzer = letzer.AddDays(+1);

                    //at_erster.TagesDatum = at_erster.TagesDatum.AddDays(-1);
                    //at_letzer.TagesDatum = at_letzer.TagesDatum.AddDays(1);
                    // an diesen tagen suche wir nun die r�ck und die hinreise
                    // und l�schen diese wenn es beide gibt
                    DateTime rr = ParamVal.Date0;
                    DateTime hr = ParamVal.Date0;
                    dbKG_Reise r_rr = null;  //defect 5479, 5703
                    dbKG_Reise r_hr = null;  //defect 5479, 5703 
                    DateTime ersterT = erster; // defect 5479, 5703 tag merken
                    DateTime letzerT = letzer; // defect 5479, 5703 tag merken
                    bool bSucheRR = true; // defect 5479, 5703  flag f�r suche
                    bool bSucheHR = true; // defect 5479, 5703 flag f�r suche
                    int anz_dl_HR = 0; // defect 5479, 5703 zaehler f�r suche
                    int anz_dl_RR = 0; // defect 5479, 5703 zaehler f�r suche
                    bool bSucheWeiter = true; // defect 5479, 5703 flag f�r suche abbrechne ja / nein
                    bool rrTag = false;
                    bool hrTag = false;
                    for (; ; )  // defect 5479, 5703 enlosloop
                    {
                        // Beginn Defect 5762
                        // Initialisierung erg�nzt
                        rr = ParamVal.Date0;
                        hr = ParamVal.Date0;
                        r_rr = null;
                        r_hr = null;
                        // Beginn Defect 5762
                        foreach (dbKG_Reise r in r_all)
                        {
                            //int raTyp = (int)GetBaustelleStandort(r.EBID).Params.RATYP.Value;
                            //r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                            bool bret = PruefeReiseZeilen(r, false);  //defect 5155 2.par: bereitstellung nicht aus vorg�ngerreise

                            if (r.Bis.DayOfYear == erster.DayOfYear)
                            {
                                if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich)
                                {
                                    if (rr == ParamVal.Date0)
                                    {
                                        rr = r.Bis;
                                        r_rr = r;
                                    }
                                    else
                                        if (rr < r.Bis)
                                        {
                                            rr = r.Bis;
                                            r_rr = r;
                                        }
                                }
                                else
                                {
                                    if (rr == ParamVal.Date0)
                                        rrTag = true;
                                    else
                                        if (rr < r.Bis)
                                        {
                                            rr = ParamVal.Date0;
                                            rrTag = true;
                                        }
                                }
                            }
                            /*if ((r.Bis.DayOfYear == erster.DayOfYear)
                                &&
                                (r.Heimfahrt != dbKG_ReiseHeimfahrtTyp.taeglich)  //defect 5333: dass sollte nicht bei t�glichen heimfahrten gel�scht werden
                                )
                            {
                                if (rr == ParamVal.Date0)
                                {
                                    rr = r.Bis;
                                    r_rr = r;
                                }
                                else if (rr < r.Bis)
                                {
                                    rr = r.Bis;
                                    r_rr = r;
                                }
                            }
                            if ((r.Von.DayOfYear == letzer.DayOfYear)
                                 &&
                                (r.Heimfahrt != dbKG_ReiseHeimfahrtTyp.taeglich)  //defect 5333: dass sollte nicht bei t�glichen heimfahrten gel�scht werden
                                )
                            {
                                if (hr == ParamVal.Date0)
                                {
                                    hr = r.Von;
                                    r_hr = r;
                                }
                                else if (hr < r.Bis)
                                {
                                    hr = r.Von;
                                    r_hr = r;
                                }
                            }*/
                            if (r.Von.DayOfYear == letzer.DayOfYear)
                            {
                                if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich && hrTag == false)
                                {
                                    if (hr == ParamVal.Date0)
                                    {
                                        hr = r.Von;
                                        r_hr = r;
                                    }
                                    else
                                        if (hr < r.Von)
                                        {
                                            hr = r.Von;
                                            r_hr = r;
                                        }
                                }
                                else
                                {
                                    if (hr == ParamVal.Date0)
                                        hrTag = true;
                                    else
                                        if (hr < r.Von)
                                        {
                                            hr = ParamVal.Date0;
                                            hrTag = false;
                                        }
                                }
                            }
                        }
                        // defect 5479, 5703 beg: auswertung der flags und weiterschaltung der suchtage
                        if (hr != ParamVal.Date0)
                        {
                            bSucheHR = false;
                            if (r_hr.Heimfahrt != dbKG_ReiseHeimfahrtTyp.monatlich)
                            {
                                bSucheWeiter = false;
                            }
                        }
                        /*else
                        {
                            letzer = letzer.AddDays(+1);
                            anz_dl_HR++;
                        }*/
                        else
                        {
                            if (hrTag == false)
                            {
                                letzer = letzer.AddDays(+1);
                                anz_dl_HR++;
                            }
                        }


                        if (rr != ParamVal.Date0)
                        {
                            bSucheRR = false;
                            if (r_rr.Heimfahrt != dbKG_ReiseHeimfahrtTyp.monatlich)
                            {
                                bSucheWeiter = false;
                            }
                        }
                        else
                        {
                            if (rrTag == false)
                            {
                                erster = erster.AddDays(-1);
                                anz_dl_RR++;
                            }
                            //erster = erster.AddDays(-1);
                            //anz_dl_RR++;
                        }
                        if (((bSucheHR == false || hrTag == true) && (bSucheRR == false || rrTag == true))
                            || (anz_dl_RR > 30)
                            || (anz_dl_HR > 30)
                            || (bSucheWeiter == false))
                        {
                            break;
                        }

                    } // defect 5479, 5703 ende
                    //Defect #6108 -zus�tlich �berprufen ob nach Krankheit die Baustelle gewechselt ist
                    int bauID_RR = 0;
                    int bauID_HR = 0;

                    try
                    {
                        bauID_RR = GetBauIDfromEBID(r_rr.EBID);
                        bauID_RR = GetBauIDfromEBID(Convert.ToInt32((r_rr.LetzteAZ.Params as dbAZ_ARBZEITParams).EBID.Value));
                    }
                    catch
                    {
                    }
                    try
                    {
                        bauID_HR = GetBauIDfromEBID(r_hr.EBID);
                        bauID_HR = GetBauIDfromEBID(Convert.ToInt32((r_hr.ErsteAZ.Params as dbAZ_ARBZEITParams).EBID.Value));
                    }
                    catch
                    {
                    }
                    if ((hr != ParamVal.Date0) && (rr != ParamVal.Date0) && bauID_RR == bauID_HR)
                    {
                        string b_del = DelReiseZeile(r_all, rr, true, null);
                        if (b_del == "")
                        {
                            b_del = DelReiseZeile(r_all, hr, true, null);
                        }
                    }

                }
            }
            return (r_all);
        }
        // defect 5242 beginn: suchen nach einem absenzblock
        private bool finde_UZA_block(ArrayList az_all, ref DateTime finde_von, ref int anz_uk, ref int anz_za, ref dbArbTag at_erster, ref dbArbTag at_letzer)
        {
            //Defect #6108 tempVorher = die erste Absenz im Block
            dbArbTag tempVorher = null;
            int anzGT = 0;

            foreach (dbArbTag AT in az_all)
            {
                if ((AT.TagesDatum.Year == Monat.MinDatum.Year)
                     &&
                     (AT.TagesDatum.Month == Monat.MinDatum.Month)
                     &&
                     (AT.TagMin > finde_von)
                   )
                {
                    //BAF 530042 Beginn AZMKalenderTage ersetzen AZM Aufrufe
                    if (AT.MBericht.Bearbeiter.BerichtsMonat == 0)
                        AT.MBericht.Bearbeiter.BerichtsMonat = AT.MBericht.BerichtsMonat;
                    if (AT.MBericht.Bearbeiter.AZMKalenderTage.ContainsKey(AT.TagesDatum))
                    {
                        if (at_erster != null)
                        {
                            if (AT.SummeProduktiveStundenAlleMBs > 0)
                            {
                                //Defect #6108 falls eine andere GTAbsenz vom Urlaub/ZA aufgetretten ist dann ist die unter tempVorher gespeichert
                                if (anzGT > 0)
                                {
                                    if (tempVorher != null)
                                        at_erster = tempVorher;
                                    break;
                                }
                                else
                                {
                                    //es waren nur WO & Feiertage, also alles r�cksetzen
                                    anz_uk = 0;
                                    at_erster = null;
                                    tempVorher = null;
                                    at_letzer = null;
                                    continue;
                                }
                            }
                            // Geht die GT-Absenz || Feiertag weiter ?
                            if (AT.GTAbsenzID != 0 ||
                                AT.MBericht.Bearbeiter.AZMKalenderTage[AT.TagesDatum].IstFeiertag ||
                                AT.MBericht.Bearbeiter.AZMKalenderTage[AT.TagesDatum].IstFenstertag)
                            {
                                if (AT.GTAbsenzID != 0)
                                    anzGT++;
                                anz_uk++;
                                at_letzer = AT;
                                if (AT.GTAbsenzID == 120)
                                    anz_za++;
                                continue;
                            }
                            // wir arbeitne normalerweise hier nicht
                            if (AT.MBericht.Bearbeiter.AZMKalenderTage[AT.TagesDatum].IstArbeitstag != true)
                            {
                                at_letzer = AT;
                                continue;
                            }
                            //defect 5479, 5703 wenn der block durch einer andere abzenz unterbrochen wird suche beenden
                            if ((AT.GTAbsenzID != 90)
                                && (AT.GTAbsenzID != 100)
                                && (AT.GTAbsenzID != 120)
                               )
                            {
                                //Defect #6108 falls eine andere GTAbsenz vom Urlaub/ZA aufgetretten ist dann ist die unter tempVorher gespeichert
                                if (tempVorher != null)
                                    at_erster = tempVorher;
                                break;
                            }
                        }
                        //tag innerhalb der reise ur/ZA 
                        if (/*(AT.GTAbsenzID == 90)
                        || (AT.GTAbsenzID == 100)
                        || (AT.GTAbsenzID == 120)*/
                            AT.GTAbsenzID != 0 //Defect #6108 - Alle GT Absenzen gleich behandeln
                            //Ein Feiertag hat GTAbsenzID = 0, dieser soll auch ber�cksichtig so weit an dem Tag keine produktivstunden vorhanden sind
                            || (AT.MBericht.Bearbeiter.AZMKalenderTage[AT.TagesDatum].IstFeiertag && AT.SummeProduktiveStundenAlleMBs == 0)
                           )
                        {
                            if (AT.GTAbsenzID != 0)
                                anzGT++;
                            //das ist jetzt Urlaub / ZA
                            if (at_erster == null)
                            {
                                // erster tag
                                at_erster = AT;
                                at_letzer = AT;
                            }
                            else
                            {
                                at_letzer = AT;
                            }
                            anz_uk++;
                        }
                        else
                        {
                            if (!AT.MBericht.Bearbeiter.AZMKalenderTage[AT.TagesDatum].IstArbeitstag &&
                                  AT.SummeProduktiveStundenAlleMBs == 0)
                            {
                                //Wochenende
                                if (tempVorher == null)
                                    tempVorher = AT;
                            }
                            else
                            {
                                tempVorher = null;
                            }
                            //  if ( AT.GTAbsenzID != 0 /*|| 
                            //        (AT.MBericht.Bearbeiter.IstFeiertag(AT.TagesDatum) && AT.SummeProduktiveStundenAlleMBs == 0))*/
                            //        && tempVorher == null)
                            //  {
                            //      //es ist eine andere GT Absenz, wir merken uns den Tag, falls der n�chste Tag ZA/Urlaub ist
                            //      //dann wird der Block ab hier berechnet.
                            //      tempVorher = AT;
                            //  }
                            //  if (AT.SummeProduktiveStundenAlleMBs > 0)
                            //  {
                            //      tempVorher = null;
                            //      anz_uk = 0;
                            //  }
                        }
                        if (AT.GTAbsenzID == 120)
                        {
                            anz_za++;
                        }

                    }//BAF 530042 Ende
                    else //altes code
                    {
                        // wenn wir nicht urlauben sondern arbeiten, beenden wir die suche
                        if (at_erster != null)
                        {
                            if (AT.SummeProduktiveStundenAlleMBs > 0)
                            {
                                //Defect #6108 falls eine andere GTAbsenz vom Urlaub/ZA aufgetretten ist dann ist die unter tempVorher gespeichert
                                if (anzGT > 0)
                                {
                                    if (tempVorher != null)
                                        at_erster = tempVorher;
                                    break;
                                }
                                else
                                {
                                    //es waren nur WO & Feiertage, also alles r�cksetzen
                                    anz_uk = 0;
                                    at_erster = null;
                                    tempVorher = null;
                                    at_letzer = null;
                                    continue;
                                }
                            }
                            // Geht die GT-Absenz || Feiertag weiter ?
                            if (AT.GTAbsenzID != 0 ||
                                AT.MBericht.Bearbeiter.IstFeiertag(AT.TagesDatum) || 
                                AT.MBericht.Bearbeiter.IstFenstertag(AT.TagesDatum)) 
                            {
                                if (AT.GTAbsenzID != 0)
                                    anzGT++;
                                anz_uk++;
                                at_letzer = AT;
                                if (AT.GTAbsenzID == 120)
                                    anz_za++;
                                continue;
                            }
                            // wir arbeitne normalerweise hier nicht
                            if (AT.MBericht.Bearbeiter.IstArbeitstag(AT.TagesDatum) != true)
                            {
                                at_letzer = AT;
                                continue;
                            }
                            //defect 5479, 5703 wenn der block durch einer andere abzenz unterbrochen wird suche beenden
                            if ((AT.GTAbsenzID != 90)
                                && (AT.GTAbsenzID != 100)
                                && (AT.GTAbsenzID != 120)
                               )
                            {
                                //Defect #6108 falls eine andere GTAbsenz vom Urlaub/ZA aufgetretten ist dann ist die unter tempVorher gespeichert
                                if (tempVorher != null)
                                    at_erster = tempVorher;
                                break;
                            }
                        }
                        //tag innerhalb der reise ur/ZA 
                        if (/*(AT.GTAbsenzID == 90)
                        || (AT.GTAbsenzID == 100)
                        || (AT.GTAbsenzID == 120)*/
                            AT.GTAbsenzID != 0 //Defect #6108 - Alle GT Absenzen gleich behandeln
                            //Ein Feiertag hat GTAbsenzID = 0, dieser soll auch ber�cksichtig so weit an dem Tag keine produktivstunden vorhanden sind
                            || (AT.MBericht.Bearbeiter.IstFeiertag(AT.TagesDatum) && AT.SummeProduktiveStundenAlleMBs == 0)
                           )
                        {
                            if (AT.GTAbsenzID != 0)
                                anzGT++;
                            //das ist jetzt Urlaub / ZA
                            if (at_erster == null)
                            {
                                // erster tag
                                at_erster = AT;
                                at_letzer = AT;
                            }
                            else
                            {
                                at_letzer = AT;
                            }
                            anz_uk++;
                        }
                        else
                        {
                            if (!AT.MBericht.Bearbeiter.IstArbeitstag(AT.TagesDatum) &&
                                  AT.SummeProduktiveStundenAlleMBs == 0)
                            {
                                //Wochenende
                                if (tempVorher == null)
                                    tempVorher = AT;
                            }
                            else
                            {
                                tempVorher = null;
                            }
                            //  if ( AT.GTAbsenzID != 0 /*|| 
                            //        (AT.MBericht.Bearbeiter.IstFeiertag(AT.TagesDatum) && AT.SummeProduktiveStundenAlleMBs == 0))*/
                            //        && tempVorher == null)
                            //  {
                            //      //es ist eine andere GT Absenz, wir merken uns den Tag, falls der n�chste Tag ZA/Urlaub ist
                            //      //dann wird der Block ab hier berechnet.
                            //      tempVorher = AT;
                            //  }
                            //  if (AT.SummeProduktiveStundenAlleMBs > 0)
                            //  {
                            //      tempVorher = null;
                            //      anz_uk = 0;
                            //  }
                        }
                        if (AT.GTAbsenzID == 120)
                        {
                            anz_za++;
                        }
                    }
                }
            }
            //return
            if (at_erster == null)
            {
                finde_von = Monat.MaxDatum;
                return false;
            }
            else
            {
                finde_von = at_letzer.TagMax;
                return true;
            }
        }
        // defect 5242 ende

        // umwandeln von hin/rr bei urlaub/za < 5 AT und reise > 7 AT
        private ArrayList UmwAutoRR(ArrayList r_all, ArrayList az_all)
        {
            int anz_uk = 0;
            int anz_za = 0;
            dbArbTag at_erster = null;
            dbArbTag at_letzer = null;
            // defect 5242 beginn
            DateTime finde_von = Monat.MinDatum.AddDays(-1);

            foreach (dbKG_Reise r in r_all)
            {
                try
                {
                    int ebid = (int)(r.ersteHSoderT.Zeile.Params.EBID.Value);
                    int raTyp = (int)GetBaustelleStandort(ebid).Params.RATYP.Value;
                    r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                }
                catch
                {
                }
            }

            bool b_ret1 = true;
            while (b_ret1 == true)
            {
                // defect 5242 ende
                anz_uk = 0;
                anz_za = 0;
                at_erster = null;
                at_letzer = null;
                b_ret1 = finde_UZA_block(az_all, ref finde_von, ref anz_uk, ref anz_za, ref at_erster, ref at_letzer);  //defect 5242


                // weniger als 5 tage auf u/k
                if ((anz_za == 1)
                     && (anz_uk == 1) && (Monat.Monteur.Params.PERSNR.Value.ToString().Substring(0, 2) != "93")
                    //.ABTEILUNG.Value.ToString().Substring(0, 3) != "B&I")
                   )
                {
                    // weniger als 8 tage auf u/k
                    if ((at_erster != null)
                        && (at_letzer != null)
                        )
                    {
                        DateTime erster = at_erster.TagesDatum;
                        DateTime letzer = at_letzer.TagesDatum;
                        erster = erster.AddDays(-1);
                        letzer = letzer.AddDays(+1);

                        //at_erster.TagesDatum = at_erster.TagesDatum.AddDays(-1);
                        //at_letzer.TagesDatum = at_letzer.TagesDatum.AddDays(1);
                        // an diesen tagen suche wir nun die r�ck und die hinreise
                        // und l�schen diese wenn es beide gibt
                        DateTime rr = ParamVal.Date0;
                        DateTime hr = ParamVal.Date0;
                        dbKG_Reise r_rr = null;  //defect 5479, 5703
                        dbKG_Reise r_hr = null;  //defect 5479 , 5703
                        DateTime ersterT = erster; // defect 5479, 5703 tag merken
                        DateTime letzerT = letzer; // defect 5479, 5703 tag merken
                        bool bSucheRR = true; // defect 5479, 5703  flag f�r suche
                        bool bSucheHR = true; // defect 5479, 5703 flag f�r suche
                        int anz_dl_HR = 0; // defect 5479, 5703 zaehler f�r suche
                        int anz_dl_RR = 0; // defect 5479, 5703 zaehler f�r suche
                        bool bSucheWeiter = true; // defect 5479, 5703 flag f�r suche abbrechne ja / nein
                        bool rrTag = false;
                        bool hrTag = false;
                        dbKG_ReiseZeile rr_z = null;
                        dbKG_ReiseZeile hr_z = null;

                        for (; ; )  // defect 5479, 5703 enlosloop
                        {
                            foreach (dbKG_Reise r in r_all)
                            {
                                //int raTyp = (int)GetBaustelleStandort(r.EBID).Params.RATYP.Value;
                                //r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                                bool b_ret = PruefeReiseZeilen(r, false); //defect 5155 2.par: bereitstellung nicht aus vorg�ngerreise


                                if (r.Bis.DayOfYear == erster.DayOfYear)
                                {
                                    try
                                    {
                                        int ebid = (int)(r.letzteHRoderT.Zeile.Params.EBID.Value);
                                        int raTyp = (int)GetBaustelleStandort(ebid).Params.RATYP.Value;
                                        r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                                    }
                                    catch
                                    {
                                    }
                                    if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich)  //defect 5333: dass sollte nicht bei t�glichen heimfahrten gel�scht werden
                                    {
                                        if (rr == ParamVal.Date0)
                                        {
                                            rr = r.Bis;
                                            r_rr = r;
                                        }
                                        else
                                            if (rr < r.Bis)
                                            {
                                                rr = r.Bis;
                                                r_rr = r;
                                            }
                                        try
                                        {
                                            rr_z = r.letzteHRoderT;
                                        }
                                        catch
                                        {
                                        }
                                    }
                                    else
                                    {
                                        if (rr == ParamVal.Date0)
                                            rrTag = true;
                                        else
                                            if (rr < r.Bis)
                                            {
                                                rr = ParamVal.Date0;
                                                rrTag = true;
                                            }
                                    }
                                }
                                if (r.Von.DayOfYear == letzer.DayOfYear)
                                {
                                    try
                                    {
                                        int ebid = (int)(r.ersteHSoderT.Zeile.Params.EBID.Value);
                                        int raTyp = (int)GetBaustelleStandort(ebid).Params.RATYP.Value;
                                        r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                                    }
                                    catch
                                    {
                                    }
                                    if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich && hrTag == false)  //defect 5333: dass sollte nicht bei t�glichen heimfahrten gel�scht werden
                                    {
                                        if (hr == ParamVal.Date0)
                                        {
                                            hr = r.Von;
                                            r_hr = r;
                                        }
                                        else
                                            if (hr < r.Von)
                                            {
                                                hr = r.Von;
                                                r_hr = r;
                                            }
                                        try
                                        {
                                            hr_z = r.ersteHSoderT;
                                        }
                                        catch
                                        {
                                        }
                                    }
                                    else
                                    {
                                        if (hr == ParamVal.Date0)
                                            hrTag = true;
                                        else
                                            if (hr < r.Von)
                                            {
                                                hr = ParamVal.Date0;
                                                hrTag = false;
                                            }
                                    }
                                }
                            }
                            // defect 5479, 5703 beg: auswertung der flags und weiterschaltung der suchtage
                            if (hr != ParamVal.Date0)
                            {
                                bSucheHR = false;
                                if (r_hr.Heimfahrt != dbKG_ReiseHeimfahrtTyp.monatlich)
                                {
                                    bSucheWeiter = false;
                                }
                            }
                            else
                            {
                                if (hrTag == false)
                                {
                                    letzer = letzer.AddDays(+1);
                                    anz_dl_HR++;
                                }
                            }

                            if (rr != ParamVal.Date0)
                            {
                                bSucheRR = false;
                                if (r_rr.Heimfahrt != dbKG_ReiseHeimfahrtTyp.monatlich)
                                {
                                    bSucheWeiter = false;
                                }
                            }
                            else
                            {
                                if (rrTag == false)
                                {
                                    erster = erster.AddDays(-1);
                                    anz_dl_RR++;
                                }
                            }
                            if (((bSucheHR == false || hrTag == true) && (bSucheRR == false || rrTag == true))
                                 || (anz_dl_RR > 30)
                                 || (anz_dl_HR > 30)
                                 || (bSucheWeiter == false))
                            {
                                break;
                            }
                        } // defect 5479, 5703 ende
                        // l�schen der gefundenen reisezeilen
                        int bauID_RR = 0;
                        int bauID_HR = 0;

                        try
                        {
                            bauID_RR = GetBauIDfromEBID(r_rr.EBID);
                            bauID_RR = GetBauIDfromEBID(Convert.ToInt32((r_rr.LetzteAZ.Params as dbAZ_ARBZEITParams).EBID.Value));
                        }
                        catch
                        {
                        }
                        try
                        {
                            bauID_HR = GetBauIDfromEBID(r_hr.EBID);
                            bauID_HR = GetBauIDfromEBID(Convert.ToInt32((r_hr.ErsteAZ.Params as dbAZ_ARBZEITParams).EBID.Value));
                        }
                        catch
                        {
                        }
                        if ((hr != ParamVal.Date0) && (rr != ParamVal.Date0)
                            && bauID_HR == bauID_RR
                            && r_rr.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich
                            && r_hr.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich)
                        {
                            string b_del = DelReiseZeile(r_all, rr, true, null);
                            if (b_del == "")
                            {
                                //BAN 500059 falls quartier vorhande ist, dann sollten RR und HR auf quartierfahrt ge�ndertt werden
                                dbBaustelleStandort quartier = null;
                                try
                                {
                                    quartier = GetQuartier(Convert.ToInt32(rr_z.Zeile.Params.EBID.Value));
                                    if (quartier != null && bauID_RR != 0)
                                    {
                                        r_rr.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r_rr, null), bauID_RR, rr_z.Ab, quartier, "0"));
                                    }
                                }
                                catch
                                {
                                }

                                b_del = DelReiseZeile(r_all, hr, true, null);
                                if (b_del == "")
                                {
                                    try
                                    {
                                        if (quartier != null && bauID_HR != 0)
                                        {
                                            r_hr.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r_hr, null), bauID_HR, hr_z.An, quartier, "0"));
                                        }
                                    }
                                    catch
                                    {
                                    }
                                }
                                //hier fehlt TA anstat die 2 Reisezeilen was gel�scht sind
                                /*if (b_del == "" && r1 != -1 && r2 != -1) //Zeilen sind gel�scht
                                {
                                    dbKG_Reise r = (dbKG_Reise)r_all[r1];
                                    dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, "66", rr, ckorrZT_2359);
                                    if (zt != null)
                                    {
                                        zt.flg_teilabr_del = false;
                                        r.Zeilen.Add(zt);
                                        r = (dbKG_Reise)r_all[r2];
                                        zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, "66", hr, ckorrZT_0000);
                                        if (zt != null)
                                        {
                                            zt.flg_teilabr_del = false;
                                            r.Zeilen.Add(zt);
                                        }
                                    }
                                }*/
                            }
                        }

                    }

                }
                else
                {
                    if ((anz_uk < 5) && (anz_uk > 0)
                        && (at_erster != null)
                        && (at_letzer != null)
                        )
                    {
                        DateTime erster = at_erster.TagesDatum;
                        DateTime letzer = at_letzer.TagesDatum;
                        erster = erster.AddDays(-1);
                        letzer = letzer.AddDays(+1);
                        DateTime ersterT = erster; // defect 5479, 5703 tag merken
                        DateTime letzerT = letzer; // defect 5479, 5703 tag merken
                        // an diesen tagen suche wir nun die r�ck und die hinreise
                        // und wandel in t-zeilen um
                        DateTime rr = ParamVal.Date0;
                        DateTime hr = ParamVal.Date0;
                        dbKG_Reise r_rr = null;
                        dbKG_Reise r_hr = null;
                        bool bSucheRR = true; // defect 5479, 5703  flag f�r suche
                        bool bSucheHR = true; // defect 5479, 5703 flag f�r suche
                        int anz_dl_HR = 0; // defect 5479, 5703 zaehler f�r suche
                        int anz_dl_RR = 0; // defect 5479, 5703 zaehler f�r suche
                        bool bSucheWeiter = true; // defect 5479, 5703 flag f�r suche abbrechne ja / nein
                        bool bGenT_HR = false; // flag f�r gen einer neuen t-zeile
                        bool bGenT_RR = false; // flag f�r gen einer neuen t-zeile
                        //dbKG_ReiseZeile rr_z = null;
                        //dbKG_ReiseZeile hr_z = null;

                        for (; ; )  // defect 5479, 5703 enlosloop
                        {
                            // Beginn Defect 5762
                            // Initialisierung erg�nzt
                            rr = ParamVal.Date0;
                            hr = ParamVal.Date0;
                            r_rr = null;
                            r_hr = null;
                            bSucheHR = true;
                            bSucheRR = true;
                            // Ende Defect 5762
                            bool rrTag = false;
                            bool hrTag = false;
                            foreach (dbKG_Reise r in r_all)
                            {
                                //int raTyp = (int)GetBaustelleStandort(r.EBID).Params.RATYP.Value;
                                //r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                                bool bret = PruefeReiseZeilen(r, false); //defect 5155 2.par: bereitstellung nicht aus vorg�ngerreise
                                //if (((r.Bis.DayOfYear - r.Von.DayOfYear) > 6)||(r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich)||(r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.woechentlich) )  
                                //mal was anderes
                                if (r.Bis.DayOfYear == erster.DayOfYear)
                                {
                                    //RR Tag/Reise gefunden
                                    try
                                    {
                                        int ebid = (int)(r.letzteHRoderT.Zeile.Params.EBID.Value);
                                        int raTyp = (int)GetBaustelleStandort(ebid).Params.RATYP.Value;
                                        r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                                    }
                                    catch
                                    {
                                    }
                                    if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich)  //defect 5440 nachbesserung: dass sollte nicht bei t�glichen heimfahrten gel�scht werden
                                    {
                                        if ((rr == ParamVal.Date0) && (bSucheRR == true))// defect 5479, 5703 suchen weitere reisen
                                        {
                                            rr = r.Bis;
                                            r_rr = r;
                                        }
                                        else if ((rr < r.Bis) && (bSucheRR == true)) // defect 5479, 5703 suchen weitere reisen
                                        {
                                            rr = r.Bis;
                                            r_rr = r;
                                        }
                                        /*try
                                        {
                                            rr_z = r.letzteHRoderT;
                                        }
                                        catch
                                        {
                                        }*/
                                    }
                                    else
                                    {
                                        //die reise ist keine monatliche entsendung
                                        if (rr == ParamVal.Date0)
                                            rrTag = true;
                                        else
                                            if (rr < r.Bis)
                                            {
                                                rr = ParamVal.Date0;
                                                rrTag = true;
                                            }
                                    }
                                }

                                if (r.Von.DayOfYear == letzer.DayOfYear)
                                {
                                    //RR Tag/Reise gefunden
                                    try
                                    {
                                        int ebid = (int)(r.ersteHSoderT.Zeile.Params.EBID.Value);
                                        int raTyp = (int)GetBaustelleStandort(ebid).Params.RATYP.Value;
                                        r.Heimfahrt = (dbKG_ReiseHeimfahrtTyp)GetReiseArt(raTyp);
                                    }
                                    catch
                                    {
                                    }
                                    if (r.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich && hrTag == false)  //defect 5440 nachbesserung: dass sollte nicht bei t�glichen heimfahrten gel�scht werden
                                    {
                                        if ((hr == ParamVal.Date0) && (bSucheHR == true))  // defect 5479, 5703 suchen weitere reisen
                                        {
                                            hr = r.Von;
                                            r_hr = r;
                                        }
                                        else if ((hr < r.Von) && (bSucheHR == true)) // defect 5479, 5703 suchen weitere reisen
                                        {
                                            hr = r.Von;
                                            r_hr = r;
                                        }
                                        /*try
                                        {
                                            rr_z = r.ersteHSoderT;
                                        }
                                        catch
                                        {
                                        }*/
                                    }
                                    else
                                    {
                                        //die reise ist keine monatliche entsendung
                                        if (hr == ParamVal.Date0)
                                            hrTag = true;
                                        else
                                            if (hr < r.Von)
                                            {
                                                hr = ParamVal.Date0;
                                                hrTag = false;
                                            }
                                    }
                                }
                            }
                            // defect 5479, 5703 beg: auswertung der flags und weiterschaltung der suchtage
                            if (hr != ParamVal.Date0)
                            {
                                bSucheHR = false;
                                if (r_hr.Heimfahrt != dbKG_ReiseHeimfahrtTyp.monatlich)
                                {
                                    bSucheWeiter = false;
                                }
                            }
                            else
                            {
                                if (anz_dl_HR == 0)
                                {
                                    foreach (dbArbTag AT in az_all)
                                    {
                                        if (AT.TagesDatum.DayOfYear == letzer.DayOfYear)
                                        {
                                            if (
                                                (AT.GTAbsenzID != 90)
                                                && (AT.GTAbsenzID != 100)
                                                && (AT.GTAbsenzID != 120)
                                                  && (AT.GTAbsenzID != 0)//&& !(AT.MBericht.Bearbeiter.IstFeiertag(AT.TagesDatum) && AT.SummeProduktiveStundenAlleMBs == 0))
                                                //&& (AT.SummeProduktiveStundenAlleMBs == 0)
                                                )
                                            {
                                                // der tag ist nun eine andere absenz, dh hier muss eine t-zeile rein....
                                                bGenT_HR = true;
                                                hr = letzer; // wir suchen eine hinreise nach dem hr
                                                r_hr = FindeReise(hr
                                                    , true //bool ReiseBeginn
                                                    , false //bool before
                                                    , r_all
                                                    );

                                                bSucheHR = false;
                                                break;
                                            }
                                        }
                                    }
                                }
                                if (bGenT_HR == false && hrTag == false)
                                {
                                    letzer = letzer.AddDays(+1);
                                    anz_dl_HR++;
                                }
                                else
                                {

                                }
                            }

                            if (rr != ParamVal.Date0)
                            {
                                bSucheRR = false;
                                if (r_rr.Heimfahrt != dbKG_ReiseHeimfahrtTyp.monatlich)
                                {
                                    bSucheWeiter = false;
                                }
                            }
                            else
                            {
                                if (anz_dl_RR == 0)
                                {
                                    foreach (dbArbTag AT in az_all)
                                    {
                                        if (AT.TagesDatum.DayOfYear == erster.DayOfYear)
                                        {
                                            if (
                                                (AT.GTAbsenzID != 90)
                                                && (AT.GTAbsenzID != 100)
                                                && (AT.GTAbsenzID != 120)
                                                  && (AT.GTAbsenzID != 0)//!(AT.MBericht.Bearbeiter.IstFeiertag(AT.TagesDatum) && AT.SummeProduktiveStundenAlleMBs == 0))
                                                //&& (AT.SummeProduktiveStundenAlleMBs == 0)
                                                )
                                            {
                                                // der tag ist nun eine andere absenz, dh hier muss eine t-zeile rein....
                                                bGenT_RR = true;
                                                rr = erster; // wir suchen eine r�ckreise nach dem hr
                                                r_rr = FindeReise(Convert.ToDateTime(rr.ToShortDateString() + " " + ckorrZT_2359)
                                                    , false //bool ReiseBeginn
                                                    , true //bool before
                                                    , r_all
                                                    );

                                                bSucheRR = false;
                                                break;
                                            }
                                        }
                                    }
                                }
                                if (bGenT_RR == false && rrTag == false)
                                {
                                    erster = erster.AddDays(-1);
                                    anz_dl_RR++;
                                }
                            }
                            if (((bSucheHR == false || hrTag == true) && (bSucheRR == false || rrTag == true))
                                  || (anz_dl_RR > 30)
                                  || (anz_dl_HR > 30)
                                  || (bSucheWeiter == false)
                                )
                            {
                                break;
                            }
                        } // defect 5479, 5703 ende
                        // Defect #5822 zus�tlich �berpr�fen ob r_hr != null wegen foreach schleife
                        int bauID_RR = 0;
                        int bauID_HR = 0;

                        try
                        {
                            bauID_RR = GetBauIDfromEBID(r_rr.EBID);
                            bauID_RR = GetBauIDfromEBID(Convert.ToInt32((r_rr.LetzteAZ.Params as dbAZ_ARBZEITParams).EBID.Value));
                        }
                        catch
                        {
                        }
                        try
                        {
                            bauID_HR = GetBauIDfromEBID(r_hr.EBID);
                            bauID_HR = GetBauIDfromEBID(Convert.ToInt32((r_hr.ErsteAZ.Params as dbAZ_ARBZEITParams).EBID.Value));
                        }
                        catch
                        {
                        }
                        // Abfrage erweitert mit r_rr != null und ob baustellenwechsel vor/nach Absenzen stattgefunden hat 
                        if ((hr != ParamVal.Date0) && (rr != ParamVal.Date0) && r_hr != null
                            && r_rr != null && bauID_HR == bauID_RR
                            && r_rr.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich
                            && r_hr.Heimfahrt == dbKG_ReiseHeimfahrtTyp.monatlich)
                        {
                            // 
                            //dbKG_ReiseZeileSort Sorter = new dbKG_ReiseZeileSort(dbKG_ReiseZeileSort.SortByEnum.Ab);
                            foreach (dbKG_ReiseZeile z in r_hr.Zeilen)
                            {
                                if (((z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung))
                                   &&
                                   ((z.Ab.DayOfYear == hr.DayOfYear) || (bGenT_HR == true))
                                    )
                                {
                                    // t eintragen
                                    if (bGenT_HR == true)
                                    {
                                        dbKG_Reise rins = new dbKG_Reise(this, null);  //public dbKG_Reise(dbKG_Rabrech rAbrech, dbRaKopf RaKopf)
                                        rins.LetzteAZ = r_hr.LetzteAZ;
                                        rins.EBID = r_hr.EBID;
                                        rins.Aufenthaltsort = r_hr.Aufenthaltsort;
                                        rins.barAuslagen = r_hr.barAuslagen;
                                        rins.IntfID = r_hr.IntfID;
                                        rins.RAbrech = r_hr.RAbrech;
                                        rins.NachLetzteAZ = r_hr.NachLetzteAZ;

                                        r_all.Add(rins);
                                        //t-zeile addieren
                                        dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r_hr, null), false, r_hr.IntfID, hr, ckorrZT_0000);
                                        if (zt != null)
                                        {
                                            zt.flg_teilabr_del = false;
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                zt.Typ = dbKG_ReiseZeilenTyp.WechselBereitstellung;
                                                zt.Zeile.Params.INTF_ID.Value = 88;
                                            }
                                            rins.Zeilen.Add(zt);
                                            dbKG_ReiseZeile zt1 = ZRueck(new dbKG_ReiseZeile(r_hr, null) //dbKG_ReiseZeile z
                                                                        , Convert.ToDateTime(hr.ToShortDateString() + " " + r_hr.Bis.ToShortTimeString())//r_hr.LetzteAZ.Gehen //DateTime Ab
                                                                        , r_hr.IntfID //string IntfId
                                                                        , null //string kontierung
                                                                        );
                                            if (zt1 != null)
                                            {
                                                if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                                {
                                                    zt1 = ZBWechselNeu(zt1, "88");//
                                                    zt1.Zeile.Params.REISEART.Value = "U"; //Urlaub auf dienst reise
                                                }
                                                rins.Zeilen.Add(zt1);
                                                rins.SortZeiten();
                                                bool bret = PruefeReiseZeilen(rins, false);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        dbBaustelleStandort quartier = null;
                                        try
                                        {
                                            quartier = GetQuartier(Convert.ToInt32(z.Zeile.Params.EBID.Value));
                                            if (quartier != null && bauID_RR != 0)
                                            {
                                                r_hr.Zeilen.Add(ZVonQuartier(new dbKG_ReiseZeile(r_hr, null), bauID_HR, z.An, quartier, "0"));
                                            }
                                        }
                                        catch
                                        {
                                        }
                                        //was ist das f�r eine TA ????? m�glicherweise eine TA am Ende des Monats wenn letzter Tag 
                                        //GTAbsenz ist 
                                        z.Typ = dbKG_ReiseZeilenTyp.Teilabrechnung;

                                        //z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_0000 + ":00");
                                        //z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_0000 + ":00");
                                        z.Ab = Convert.ToDateTime(letzerT.ToShortDateString() + " " + ckorrZT_0000 + ":00");
                                        z.An = Convert.ToDateTime(letzerT.ToShortDateString() + " " + ckorrZT_0000 + ":00");
                                        z.ReiseTag = letzerT;
                                        r_hr.Von = z.Ab;

                                        z.flg_teilabr_del = false;
                                        z.Zeile.Params.BSTXT.Value = "";
                                        z.Zeile.Params.AUSLART.Value = DBNull.Value;
                                        z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
                                        z.Zeile.Params.BETRAG.Value = "";
                                        z.Zeile.Params.WAEHR.Value = DBNull.Value;
                                        z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
                                        z.Zeile.Params.PROZ.Value = DBNull.Value;
                                        z.Zeile.Params.ANORT.Value = "";
                                        z.Zeile.Params.ABORT.Value = "";
                                        z.Zeile.Params.ZWECK.Value = DBNull.Value;
                                        z.Zeile.Params.ABID.Value = DBNull.Value;
                                        z.Zeile.Params.ANID.Value = DBNull.Value;
                                        z.Zeile.Params.ABKM.Value = DBNull.Value;
                                        // Meldung von Fr. Eichlberger (11.07.2008) - Kein Defect notwendig
                                        // Eine T Zeile wird zu RR ge�ndert - wenn GEFKM.Value == DBNull.Value kommt es zur exception
                                        z.Zeile.Params.GEFKM.Value = "";
                                        //z.Zeile.Params.GEFKM.Value = DBNull.Value;
                                        z.Zeile.Params.SCHWERGP.Value = "";
                                        z.Zeile.Params.MWST.Value = DBNull.Value;
                                        z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
                                        z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
                                        z.Zeile.Params.VERMSONST.Value = DBNull.Value;
                                        z.Zeile.Params.DATLA.Value = DateTime.Now;
                                        z.Zeile.Params.DATNEU.Value = DateTime.Now;
                                        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                        {
                                            z.Typ = dbKG_ReiseZeilenTyp.WechselBereitstellung;
                                            z.Zeile.Params.INTF_ID.Value = 88;
                                            try
                                            {
                                                z.Zeile.Params.BEREITST.Value =
                                                    GetBaustelleStandort(Convert.ToInt32(z.Zeile.Params.EBID.Value)).Params.RAKZ_B.Value;
                                                z.Zeile.Params.VERKEHRSMITTEL.Value = "";
                                            }
                                            catch
                                            {
                                            }

                                        }

                                    }
                                    bool bret1 = PruefeReiseZeilen(r_hr, false);
                                    r_all.Sort(new ReisenComparer());
                                    break;
                                }
                            }
                            //foreach (dbKG_ReiseZeile z in r_rr.Zeilen)
                            //                            for(int i = 0; i < r.Zeilen.Count-1;i++) {
                            //                              dbKG_ReiseZeile z1 = (dbKG_ReiseZeile)r.Zeilen[i];
                            if (r_rr != null) // 5762
                            {
                                for (int idx = r_rr.Zeilen.Count - 1; idx >= 0; idx--)
                                {
                                    dbKG_ReiseZeile z = (dbKG_ReiseZeile)r_rr.Zeilen[idx];

                                    if (((z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) || (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung))
                                       &&
                                       ((z.Ab.DayOfYear == rr.DayOfYear) || (bGenT_RR == true))
                                        )
                                    {
                                        if (bGenT_RR == true)
                                        {
                                            dbKG_Reise rins = new dbKG_Reise(this, null);  //public dbKG_Reise(dbKG_Rabrech rAbrech, dbRaKopf RaKopf)

                                            rins.LetzteAZ = r_rr.LetzteAZ;
                                            rins.EBID = r_rr.EBID;
                                            rins.Aufenthaltsort = r_rr.Aufenthaltsort;
                                            rins.barAuslagen = r_rr.barAuslagen;
                                            rins.IntfID = r_rr.IntfID;
                                            rins.RAbrech = r_rr.RAbrech;
                                            rins.NachLetzteAZ = r_rr.NachLetzteAZ;

                                            r_all.Add(rins);
                                            //t-zeile addieren
                                            dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r_rr, null), false, r_rr.IntfID, rr, ckorrZT_0000);
                                            if (zt != null)
                                            {
                                                if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                                {
                                                    zt = ZBWechselNeu(zt, "88");//
                                                    zt.Zeile.Params.REISEART.Value = "U"; //urlaub auf dienstreise
                                                    try
                                                    {
                                                        zt.Zeile.Params.BEREITST.Value = GetBaustelleStandort(Convert.ToInt32(zt.Zeile.Params.EBID.Value)).Params.RAKZ_B.Value;
                                                        zt.Zeile.Params.VERKEHRSMITTEL.Value = "";
                                                        zt.Zeile.Params.RAKZTXT.Value = "";
                                                    }
                                                    catch
                                                    {
                                                    }
                                                }
                                                zt.flg_teilabr_del = false;
                                                rins.Zeilen.Add(zt);
                                                dbKG_ReiseZeile zt1 = ZHin(new dbKG_ReiseZeile(r_rr, null) //dbKG_ReiseZeile z
                                                                          , Convert.ToDateTime(rr.ToShortDateString() + " " + r_rr.Von.ToShortTimeString())
                                                                          , r_rr.IntfID //string IntfId
                                                                          , null  // defect 5702 neuer par konto 
                                                                          );
                                                if (zt1 != null)
                                                {
                                                    if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                                    {
                                                        zt1 = ZBWechselNeu(zt1, "88");//
                                                        //zt1.Zeile.Params.REISEART.Value = "U"; // Urlaub
                                                    }

                                                    zt1.flg_teilabr_del = false;
                                                    rins.Zeilen.Add(zt1);
                                                    rins.SortZeiten();
                                                    bool bret = PruefeReiseZeilen(rins, false);
                                                }
                                            }
                                        }
                                        else
                                        {
                                            dbBaustelleStandort quartier = null;
                                            try
                                            {
                                                quartier = GetQuartier(Convert.ToInt32(z.Zeile.Params.EBID.Value));
                                                if (quartier != null && bauID_RR != 0)
                                                {
                                                    r_rr.Zeilen.Add(ZZuQuartier(new dbKG_ReiseZeile(r_rr, null), bauID_RR, z.Ab, quartier, "0"));
                                                }
                                            }
                                            catch
                                            {
                                            }
                                            //was ist das f�r eine TA ????? m�glicherweise eine TA am Anfang des Monats wenn erste Tag 
                                            //im Monat GTAbsenz ist und vormonat mit TA abgeschlossen ist.

                                            // t eintragen
                                            z.Typ = dbKG_ReiseZeilenTyp.Teilabrechnung;

                                            //z.Ab = Convert.ToDateTime(z.Ab.ToShortDateString() + " " + ckorrZT_2359 + ":59");
                                            //z.An = Convert.ToDateTime(z.An.ToShortDateString() + " " + ckorrZT_2359 + ":59");
                                            z.Ab = Convert.ToDateTime(ersterT.ToShortDateString() + " " + ckorrZT_2359 + ":59");
                                            z.An = Convert.ToDateTime(ersterT.ToShortDateString() + " " + ckorrZT_2359 + ":59");
                                            z.ReiseTag = ersterT;
                                            r_rr.Bis = z.An;

                                            z.flg_teilabr_del = false;
                                            z.Zeile.Params.BSTXT.Value = "";
                                            z.Zeile.Params.AUSLART.Value = DBNull.Value;
                                            z.Zeile.Params.ANZNAECHTE.Value = DBNull.Value;
                                            z.Zeile.Params.BETRAG.Value = "";
                                            z.Zeile.Params.WAEHR.Value = DBNull.Value;
                                            z.Zeile.Params.AUSLBEMERK.Value = DBNull.Value;
                                            z.Zeile.Params.PROZ.Value = DBNull.Value;
                                            z.Zeile.Params.ANORT.Value = "";
                                            z.Zeile.Params.ABORT.Value = "";
                                            z.Zeile.Params.ZWECK.Value = DBNull.Value;
                                            z.Zeile.Params.ABID.Value = DBNull.Value;
                                            z.Zeile.Params.ANID.Value = DBNull.Value;
                                            z.Zeile.Params.ABKM.Value = DBNull.Value;
                                            // Meldung von Fr. Eichlberger (11.07.2008) - Kein Defect notwendig
                                            // Eine T Zeile wird zu RR ge�ndert - wenn GEFKM.Value == DBNull.Value kommt es zur exception
                                            z.Zeile.Params.GEFKM.Value = "";
                                            //z.Zeile.Params.GEFKM.Value = DBNull.Value;
                                            z.Zeile.Params.SCHWERGP.Value = "";
                                            z.Zeile.Params.MWST.Value = DBNull.Value;
                                            z.Zeile.Params.VERMBETRAG.Value = DBNull.Value;
                                            z.Zeile.Params.VERMWAEHR.Value = DBNull.Value;
                                            z.Zeile.Params.VERMSONST.Value = DBNull.Value;
                                            z.Zeile.Params.DATLA.Value = DateTime.Now;
                                            z.Zeile.Params.DATNEU.Value = DateTime.Now;
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                r_rr.Bis = r_rr.Bis.AddSeconds(1);
                                                z.ReiseTag = z.Ab = z.An = r_rr.Bis;
                                                z.Typ = dbKG_ReiseZeilenTyp.WechselBereitstellung;
                                                z.Zeile.Params.INTF_ID.Value = 88;
                                                z.Zeile.Params.REISEART.Value = "U"; //Urlaub auf dienst reise
                                                z.Zeile.Params.VERKEHRSMITTEL.Value = "";
                                                z.Zeile.Params.RAKZTXT.Value = "";
                                            }
                                        }
                                        bool bret1 = PruefeReiseZeilen(r_rr, false);
                                        r_all.Sort(new ReisenComparer());
                                        break;
                                    }

                                }
                            }
                        }
                    }
                }
            }


            return (r_all);
        }

        //red-ng
        private void red_ng_stempel_generierung(ArrayList rks, bool RNGAusCB, bool bereitAusVorg)  // defect 5155 3.parameter
        {
            #region reduziertes naechtigungsgeld zeitpunktsermittlung (defect 4971)
            /*  f�r defect 4971 kommen folgende regeln  dazu zur anwendung:
                �	Eine Reise beginnt wenn vorher 2 Tage Arbeit ohne Reise waren oder eine Reise an einen anderen Dienstort stattgefunden hat.
                �	Bei den Reisen werden nur Reisen des aktuellen Berichtsmonats und des Vormonats betrachtet und zur Berechnung der Reduzierung herangezogen.
                �	Ein Dienstort wird durch eine Baustellen-ID definiert.
                �	Reduziertes N�chtigungsgeld wird nur dann bezahlt, wenn keine Quartierbereitstellung existiert und der (gesamten) Reise kein Hotelbeleg zugeordnet ist.
                �	Die Reduzierung wird ab dem 8 (cAnzKalTageBisReduzierung) Kalendertag ab Reisebeginn automatisch in der Tabelle RAZEILEN generiert (T-Zeile an SAP).
            */
            // beginn defect 4972 mal alle rr entfernen die nicht notwenduig sind

            // generieren von hin und r�ckresien bei urlaub/krankenstand, mal die arbitszeiten zusammenw�rfeln
            //ArrayList ArbzeitenALL = null; //alle arbeitszeiten der monate //defect 5390 public
            ArbzeitenALL = get_ArbzeitenALL(ArbzeitenALL);
            // defect 5479, 5703 nur einmalig durchlaufen....
            if (bereitAusVorg == true)
            {
                //Reisen = DelAutoRR(rks, ArbzeitenALL); // defect 5479, 5703 reihenfolge angepasst
                //Defect #6097 - rks ist schon modifizierte Reise, deswegen sollten wie das objekt Reisen mit rks
                //�berschreiben noch vom Aufruf von UmwAutoRR (in diese wird das objekt Reisen verwendet und die
                //Ergebnis kann falsch sein.
                Reisen = rks;
                Reisen = UmwAutoRR(rks, ArbzeitenALL);
                Reisen = DelAutoRR(Reisen, ArbzeitenALL);

            }

            //loeschen von den reduzierungszeilen, falls vorhanden (sicher ist sicher)
            //DelAllTZeileRNG(ReisenALL);  passier in copute sap
            // und dann die reisen nochmals zusammenbasteln wg der gel�schten stempel....
            ComputeSAP(false, true, false); // aber die rng nicht aufrufen !!!  3.parameter f�r defect 5155
            // ende defect 4972

            // init
            ReisenALL = new ArrayList();    //alle reisen die gerpueft werden
            ArrayList ReisenKandRNG = null; //alle reisen, die kandidaten f�r reduziertes naechtigugsgeld sind
            ReisenKandRNG = new ArrayList();
            // loop �ber alle reisen mal alle in ein objekt zusammenw�rfeln
            foreach (dbKG_Monat vm in VorMonate)
            {
                foreach (dbKG_Reise rvm in vm.Rabrech.Reisen)
                {
                    ReisenALL.Add(rvm);
                }
            }
            foreach (dbKG_Reise ram in Reisen)
            {
                ReisenALL.Add(ram);
            }
            // beginn defect 5155 prufen aller reisen nur wenn verlang
            if (bereitAusVorg == true)
            {
                bool bret = PruefeReisen(ReisenALL);
            }
            // ende defect 5155
            // loop uber alle reisen und suchen einer hinfahrt einer reise die keine belege zugeordnte hat 
            //   oder bei der das quartier nicht bereitgestellt wurde und keine r�ckreise am gleichen tag

            foreach (dbKG_Reise rkan in ReisenALL)
            {
                bool bReiseIstKandidat = false;
                bool bHotelBeleg = false;
                bool bBereitstellung = false;
                int aktReistag = 0;
                DateTime von = ParamVal.Date0;  //defect 5033 merker f�r neue von-zeit
                DateTime bis = ParamVal.Date0;  //defect 5033 merker f�r neue bis-zeit
                //bool bAndreReiseAZvorher = false;
                rkan.redBeg = ParamVal.Date0; // defect 4972 initn da neu bestimmt wird
                int anz_naechte = 0;  // neu f. defect 4972
                foreach (dbKG_ReiseZeile z in rkan.Zeilen)
                {
                    if ((z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                        || ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && aktReistag != 0)   //defect 5033 beginn: auch bei t-ende dieses erkennen
                        // || ((z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel) && aktReistag != 0)   //defect ????
                        // || ((z.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung && z.Zeile.Params.REISEART.Value.ToString() == "U") && aktReistag != 0)   //BAN 500059
                        )
                    {
                        // pruefen das ende der reise aus den zeilen
                        if (bis == ParamVal.Date0)
                        {
                            bis = z.An;
                        }
                        if (bis < z.An)
                        {
                            bis = z.An;
                        }
                        //defect 5033 ende
                        if (aktReistag == z.ReiseTag.DayOfYear)
                        {
                            bReiseIstKandidat = false;
                        }
                    }
                    if ((z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || ((z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && aktReistag == 0) // nur teilabrechnung ohne hinresie pruefen == reisebeginn
                        // || (z.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung && z.Zeile.Params.INTF_ID.Value.ToString() == "88" && aktReistag == 0 ))
                        )
                    {
                        aktReistag = z.ReiseTag.DayOfYear;
                        // defect 5033 beginn: pruefen das ende der reise aus den zeilen
                        if (von == ParamVal.Date0)
                        {
                            von = z.Ab;
                        }
                        if (von > z.Ab)
                        {
                            von = z.Ab;
                        }
                        // defect 5033 ende
                        if ((z.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH)
                            || (z.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //R,N, defect 4972 D, E dazu
                            || (z.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN_RED_NG)
                            || (z.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH_RED_NG)
                            )
                        {
                            bReiseIstKandidat = true;
                        }
                        /* m�gliche bereitstellungen bei 4,5,6, 8,9 wird quartier bereitgestell -> kein anspruch auf Naechtigungsgeld
                        RAKZID     RAKZ  RAKZTXT                                           
                        ---------- ----- --------------------------------------------------
                        B          0     Keine Bereitstellungen                            
                        B          1     EINE Hauptmahlzeit (75% TG)                       
                        B          2     BEIDE Hauptmahlzeiten (50% TG)                    
                        B          3     Volle Verpflegung u. Getr�nke (25% TG)            
                        B          4     Quartier beigestellt                              
                        B          5     Quart.,Verpfl.,Getr. bei Firmenveranstalt.(10% TG)
                        B          6     Quartier u. volle Verpflegung (50% TG)            
                        B          7     Keine Verg�tung (zB Urlaub auf Dienstreise)       
                        B          8     Quartier,Verpflegung,Getr�nke (25% TG)            
                        B          9     Quartier und eine Hauptmahlzeit (75% TG)          
                        */
                        if (
                                (z.Zeile.Params.BEREITST.Value.ToString() == "4")
                            || (z.Zeile.Params.BEREITST.Value.ToString() == "5")
                            || (z.Zeile.Params.BEREITST.Value.ToString() == "6")
                            || (z.Zeile.Params.BEREITST.Value.ToString() == "8")
                            || (z.Zeile.Params.BEREITST.Value.ToString() == "9")
                           )
                        {
                            bBereitstellung = true;
                        }
                    }

                    /*if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                    {

                    }
                    else
                    {*/
                    if (z.Typ == dbKG_ReiseZeilenTyp.Belegzeile)
                    {
                        if ((z.Zeile.Params.AUSLART.Value.ToString() == "HOTI") || (z.Zeile.Params.AUSLART.Value.ToString() == "HTIF"))
                        {
                            bHotelBeleg = true;
                            try
                            {
                                anz_naechte = anz_naechte + Convert.ToInt32(z.Zeile.Params.ANZNAECHTE.Value.ToString());
                            }
                            catch
                            {
                            }

                        }
                    }
                    //}
                }
                //defect 5033: eintragen der ermittelten von-bis zeiten f�r die nachfolgende bewertungen der reisen.
                if (von != ParamVal.Date0)
                {
                    rkan.Von = von;
                }
                if (bis != ParamVal.Date0)
                {
                    rkan.Bis = bis;
                }
                //defect 5033 ende

                //defect 4972 beginn auswertung hotelbeleg
                if (bHotelBeleg == true)
                {
                    if ((rkan.Bis.DayOfYear - rkan.Von.DayOfYear) > anz_naechte)
                    {
                        bReiseIstKandidat = true;
                        rkan.anz_naechte = anz_naechte;
                    }
                    else
                    {
                        bReiseIstKandidat = false;
                        rkan.anz_naechte = -1;
                    }
                }
                //defect 4972 ende
                // auswertung:
                if (
                    //(bHotelBeleg == true) ||   defect 4972 weg hier
                    (bBereitstellung == true))
                {
                    bReiseIstKandidat = false;
                }
                // aufnehmen in kandidatenliste
                if (bReiseIstKandidat == true)
                {
                    ReisenKandRNG.Add(rkan);
                }
                //defect 4970 beginn - korrigieren der eintr�ge f�r die reisearten
                foreach (dbKG_ReiseZeile z in rkan.Zeilen)
                {
                    // prufen der bisherigen N-eintr�ge:
                    if (z.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN) //N
                    {
                        // bei eint�gigen reisen setzten wir immer R
                        if ((bis.DayOfYear - von.DayOfYear == 0) && ((bis.Hour - von.Hour) < 9))
                        {
                            z.Zeile.Params.REISEART.Value = cReiseartNAH;  //R
                        }
                        else
                        {
                            // gibts dazu einen hotelbeleg, dann setzen wir auf R
                            if (bHotelBeleg == true)
                            {
                                z.Zeile.Params.REISEART.Value = cReiseartNAH;  //R
                            }
                        }
                    }
                }
                //defect 4970 ende
            }
            // jetzt werden die kandidaten gepr�ft, wann der beginn der reise ist....
            // zuerst mal prufen ob 2 arbeitstage ohne reise waren
            // neu abgleich mit arbeitszeiten des monats
            ArrayList ReisenBegKandRNG = null; //alle reisen, die ein beginn einer neuen reise sind f�r die reduzierung
            ReisenBegKandRNG = new ArrayList();
            //int iCounter = 0;
            //dbKG_Reise rakn_vorher = null;
            //defect 5390 beginn: wir ermitteln die reisetage und trage diese in den Arbtag ein
            if (RNGAusCB == false)  // das ermitteln wir nur dann wenn es nicht in der maske gesetzt wurde...
            {
                int last_bauid = -1;
                //int anzAZTagOhneReise = 0;
                dbArbTag ATvorher = null;  // defect 5698
                int ATIndex = -1; //BAN 500059
                bool vortagIstGTAbsenz = false;
                foreach (dbArbTag AT in ArbzeitenALL)
                {
                    AT.RNGReisetag = false;
                    AT.RNGBaust = -1;
                    AT.RNGkand = false;
                    AT.RNGBaustWechsel = false;
                    ATIndex++;

                    foreach (dbKG_Reise r in ReisenALL)
                    {
                        if ((((r.Von.ToShortDateString() == AT.TagesDatum.ToShortDateString()) ||
                            (r.Von <= AT.TagesDatum))
                            )
                            && ((r.Bis.ToShortDateString() == AT.TagesDatum.ToShortDateString()) ||
                                (r.Bis >= AT.TagesDatum)
                                )
                        )
                        {

                            //tag mit reise, wir tragen die werte ein...
                            AT.RNGReisetag = true;
                            //anzAZTagOhneReise = 0;
                            int ebid = -1;

                            if (AT.GTAbsenz == true)
                            {
                                AT.RNGBaust = last_bauid;
                                vortagIstGTAbsenz = true;
                                //BAN 500059 falls es Montag ist dann sollte �berpr�ft werden ob man Sontag ... auch wegnehmen soll
                                int atIndex = ATIndex - 1;
                                while (atIndex >= 0)
                                {
                                    dbArbTag at = ArbzeitenALL[atIndex] as dbArbTag;
                                    if (at.SummeProduktiveStundenAlleMBs == 0)
                                    {
                                        at.RNGkand = false;
                                    }
                                    else
                                        break; //aussteigen aus der while schleife
                                    atIndex--;
                                }
                            }
                            else
                            {
                                if (vortagIstGTAbsenz)
                                {
                                    if (AT.SummeProduktiveStundenAlleMBs == 0)
                                    {
                                        AT.RNGBaust = last_bauid;
                                        continue; //mit n�chsten TAG
                                    }
                                    else
                                        vortagIstGTAbsenz = false;
                                }
                                foreach (dbArbZeit az in AT.Zeiten)
                                {
                                    // az.Params.To
                                    string x = az.Params.ToString();
                                    dbAZ_ARBZEITParams p = (dbAZ_ARBZEITParams)az.Params;
                                    ebid = (int)p.EBID.Value;
                                    // defect 5698 beg: ebid auch aus reise holen, wenn am at nix is
                                    if ((ebid == 0) && (AT.TagesDatum.Ticks < r.Von.Ticks))
                                        ebid = r.EBID;
                                    // defect 5698 ende
                                    int bauid = GetBauIDfromEBID(ebid); // (dbArbZeit)AT.Zeiten[0].Params.EBID.Value;
                                    if (bauid > 0)
                                    {
                                        // flag f�r wechsel der baustelle tags�ber setzen
                                        if ((AT.RNGBaust != -1)
                                            && (AT.RNGBaust != bauid))
                                        {
                                            AT.RNGBaustWechsel = true;
                                            last_bauid = bauid;
                                        }
                                        if ((last_bauid != bauid) && (last_bauid != -2))  // defect 5698 auch bei ausnahme vormonat nicht gespeichert
                                        {
                                            //if(last_bauid != -1)
                                            AT.RNGBaustWechsel = true;
                                            last_bauid = bauid;

                                        }
                                        if (last_bauid == -2)  // defect beginn 5698: ausnahme vormonat nicht gesp.
                                        {
                                            last_bauid = bauid;
                                            if ((ATvorher.RNGReisetag == false))
                                            {
                                                AT.RNGBaustWechsel = true;
                                            }

                                        }

                                        //defect 5698 ende
                                        AT.RNGBaust = bauid;
                                    }
                                    else
                                    {
                                        AT.RNGBaust = last_bauid;
                                        if (last_bauid == -2)  // defect beginn 5698: ausnahme vormonat nicht gesp.
                                        {
                                            if ((ATvorher.RNGReisetag == false))
                                            {
                                                AT.RNGBaustWechsel = true;
                                            }
                                        }
                                        //defect 5698 ende
                                    }
                                }
                                //} BAN 500059 GT Absenz ist kein RNGkand Beginn
                                foreach (dbKG_Reise rk in ReisenKandRNG)
                                {
                                    if (r.Equals(rk))
                                    {
                                        AT.RNGkand = true;
                                        break;
                                    }
                                }
                            }//BAN 500059 GT Absenz ist kein RNGkand Ende
                        }
                    }
                    //Defect #6108 - Alle GT Absenzen gleich behandeln 
                    // prufung, ob wir 2 tage 'daheim' sind, wenn ja dann beginen wir eine neue entsendung (deshalb last_bauid resetten
                    //if ((AT.RNGReisetag == false) && ((AT.GTAbsenz == true) || (AT.SummeProduktiveStunden > 0))) //defect 4972 nur dann hochz�hlen wenn gearbeitet wurde
                    //{
                    //    if (/*(AT.GTAbsenzID == 90)      //URLAUB
                    //        || (AT.GTAbsenzID == 100)  //Urlaub eigene Kosten
                    //        || (AT.GTAbsenzID == 120)  //ZA ganzt�gig
                    //        || (AT.GTAbsenzID == 210)  //Krankheit 
                    //        || (AT.GTAbsenzID == 212)  //Krankheit Beginn
                    //        || (AT.GTAbsenzID == 214)  //Krankheit Ende 
                    //        || (AT.GTAbsenzID == 220)  //Unfall
                    //        || (AT.GTAbsenzID == 222)  //Unfall beginn
                    //        || (AT.GTAbsenzID == 224)  //Unfall ende
                    //        )*/
                    //        AT.GTAbsenzID == 0 ) 
                    //    {
                    //        // absenztag, der gilt nicht als unterbrechung der entsendung
                    //    }
                    //    else
                    //    {
                    //        anzAZTagOhneReise++;
                    //        //Defect #6108 - 
                    //        if (anzAZTagOhneReise == 5)//2) Nach 5 GTA wird so wie so automatch HR&RR generiert
                    //        {
                    //            //beginn einer neune reise
                    //            //last_bauid = -1;
                    //        }
                    //    }
                    //}
                    // defect 5698 beg: wenn das vormonat fehlt am 1. dann beginnen wir alles neu zu initalisieren
                    if (ATvorher != null)
                    {
                        if ((AT.TagesDatum.Day == 1))
                        {
                            if (last_bauid == -1)
                            {
                                last_bauid = -2;
                                AT.RNGBaust = last_bauid;
                            }
                            //if ((AT.TagesDatum.Month - ATvorher.TagesDatum.Month != 1))
                            if ((AT.TagesDatum.Year * 12 + AT.TagesDatum.Month - ATvorher.TagesDatum.Year * 12 - ATvorher.TagesDatum.Month != 1))
                            {
                                AT.RNGBaustWechsel = true;
                                last_bauid = -2;
                                AT.RNGBaust = last_bauid;
                            }
                        }
                    }
                    ATvorher = AT;
                    // defect 5698 ende
                }

                //defect 5390 ende
                //defect 5390 neue ermittlung aus arbeitszeiten
                DateTime redBeg = ParamVal.Date0;
                DateTime reiseBeginn = ParamVal.Date0;
                //bool bIstRbeginn = false;
                //int anzRT = 0;

                //bool RNGkandVorher = null;
                //bool RNGReisetagVorher = null;
                //int anzATvorher = -1;
                //int BauidVorher = -1;
                //bool last_bstw = false;
                DateTime rng_start = ParamVal.Date0;
                int rng_tage = 0;
                foreach (dbArbTag AT in ArbzeitenALL)
                {
                    // wenn die baustelle wechselt und der tag ein reisetag ist, dan beginnt die erh�hungsrechnung
                    if (((AT.RNGBaustWechsel == true) && (AT.RNGReisetag == true)))
                    {
                        rng_start = AT.TagesDatum;
                        rng_tage = 0;
                    }
                    //wenn es ein reisetag ist z�hlen wir hoch
                    if (AT.RNGReisetag == true)
                    {
                        //if (AT.GTAbsenzID != 120 && AT.GTAbsenzID != 90 && AT.GTAbsenzID != 100)
                        rng_tage++;
                        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                            if (AT.GTAbsenzID == 120 || AT.GTAbsenzID == 90 || AT.GTAbsenzID == 100)
                                rng_tage--; //wieder wegnehmen
                    }
                    if ((AT.RNGReisetag == true) && (rng_tage > cAnzKalTageBisReduzierung + 1) && (AT.RNGkand == true))
                    {
                        AT.RNG = true;
                    }
                    else
                    {
                        AT.RNG = false;
                    }
                    /*

                    // merken eines baustellenwechsels, wenn er auf true schaltet
                    if ((last_bstw == false)  && (AT.RNGBaustWechsel == true) )
                    {
                        last_bstw = true;
                    }
                    // wenn AT.RNGkand = true dann ist der tag ein reduzierungskandidat
                    if (AT.RNGkand == true)
                    {
                        // wenn nun last_bstw = true dann habe wir einen rng-beginn
                        if (last_bstw == true)
                        {
                            rng_start = AT.TagesDatum;
                        }

                        rng_tage++;
                    }

                    // beginn einer reise, wenn flag RNGkand wechselt
                    if (RNGkandVorher == null)
                    {
                        if (AT.RNGkand == true)
                        {
                            // erster rng-kandidat, der ist sicher ein beginn
                            anzRT = 0;
                        }
                    }
                    else if (RNGkandVorher == true)
                    {

                    }
                     * */
                }
            }
            RNGAusCB = true;  // das setzen wir mal gleich mit der maske, da jetzt auch hier dieses kennzeichen gesetzt wird....

            /* defect 5390 beginn: wir bauen alles um........
            foreach (dbKG_Reise rkan in ReisenKandRNG) 
            {
                // wir pr�fen hier nur die aktuelle reise und ihre vorg�ngerreise, ob in den tagen dazwischen arbeitszeiten waren
                int anzAZTagOhneReise = 0;                    //anzahl der arbeitstage ohne einer reise
                bool bIstBeginnReise = false;        // Diese reise ist der beginn einer neuen reise
                if (iCounter > 0)
                {
                    foreach (dbArbTag AT in ArbzeitenALL)
                    {
                        // 
                        if ((AT.TagesDatum.DayOfYear > rakn_vorher.Bis.DayOfYear) && (AT.TagesDatum.DayOfYear < rkan.Von.DayOfYear))
                        {
                            //counter hochz�hlen da tag zwischen reisen   
                            //  defect 4972: absenzbetrachtung bei urlaub/za und unfall krankeit keine unterberechung des red-ng !
                            GTABSENZID AZMNR  GTABSENZTXT                                        DATLA                                              AENPERSKEY  TSTAMP             DATNEU                                             STATUS 
                            ---------- ------ -------------------------------------------------- -------------------------------------------------- ----------- ------------------ -------------------------------------------------- ------ 
                            10         19     Ersatzruhe                                         1999-06-10 12:33:34.000                            0           0x00000000061604FE 1999-06-10 12:33:34.000                            20
                            20         28     Gesch�ftlich Abwesend                              1999-06-10 12:33:39.000                            0           0x0000000006160503 1999-06-10 12:33:39.000                            20
                            30         25     Karenzurlaub                                       1999-06-10 12:33:59.000                            0           0x00000000061604FF 1999-06-10 12:33:59.000                            20
                            40         17     Pflegefreistellung                                 1999-06-10 12:34:14.000                            0           0x00000000432B38E9 1999-06-10 12:34:14.000                            20
                            50         26     Pr�senzdienst                                      1999-06-10 12:34:25.000                            0           0x0000000006160501 1999-06-10 12:34:25.000                            20
                            60         29     Sonderurlaub (Ausland)                             1999-06-10 12:34:43.000                            0           0x0000000006160504 1999-06-10 12:34:43.000                            20
                            70         18     sonstige Abwesenheit                               1999-06-10 12:34:53.000                            0           0x00000000061604FD 1999-06-10 12:34:53.000                            20
                            80         15     Truppen�bung                                       1999-06-10 12:35:10.000                            0           0x00000000061604FA 1999-06-10 12:35:10.000                            20
                            90         12     Urlaub                                             1999-06-10 12:35:25.000                            0           0x00000000061604F7 1999-06-10 12:35:25.000                            20
                            100        13     Urlaub eigene Kosten                               1999-06-10 12:35:40.000                            0           0x00000000061604F8 1999-06-10 12:35:40.000                            20
                            110        27     Wochenhilfe                                        1999-06-10 12:35:46.000                            0           0x0000000006160502 1999-06-10 12:35:46.000                            20
                            120        16     ZA ganzt�gig                                       1999-06-10 12:35:59.000                            0           0x00000000061604FB 1999-06-10 12:35:59.000                            20
                            130        14     Paragraph 8                                        2001-05-02 18:25:39.000                            0           0x00000000061604F9 2001-05-02 18:25:39.000                            20
                            140        30     Arbeitsausfall betrieblich                         2001-05-02 18:26:20.000                            0           0x0000000006160505 2001-05-02 18:26:20.000                            20
                            150        31     Arbeitsausfall au�erbetr.                          2001-05-02 18:27:22.000                            0           0x0000000006160506 2001-05-02 18:27:22.000                            20
                            160        32     Betriebsrat                                        2001-05-02 18:27:47.000                            0           0x0000000006160507 2001-05-02 18:27:47.000                            20
                            170        33     Gestzl. Freizeit KV                                2001-05-02 18:28:06.000                            0           0x0000000006160508 2001-05-02 18:28:06.000                            20
                            180        34     Studienurlaub                                      2001-05-02 18:28:26.000                            0           0x0000000006160509 2001-05-02 18:28:26.000                            20
                            190        37     Jubil�umstag                                       2001-05-02 18:28:58.000                            0           0x000000000616050A 2001-05-02 18:28:58.000                            20
                            200        41     Sabbatical                                         2001-05-09 15:13:16.000                            0           0x000000000616050B 2001-05-09 15:13:16.000                            20
                            210        11     Krankheit                                          2003-04-10 14:32:56.873                            849         0x000000001724B630 2003-04-10 14:32:56.873                            20
                            212        20     Krankheit Beginn                                   2003-04-16 09:00:00.000                            849         0x00000000172DA837 2003-04-16 09:00:00.000                            20
                            214        21     Krankheit Ende                                     2003-04-16 09:00:00.000                            849         0x00000000172DA847 2003-04-16 09:00:00.000                            20
                            220        24     Unfall                                             2003-04-10 14:33:16.733                            849         0x000000001724B632 2003-04-10 14:33:16.733                            20
                            222        22     Unfall Beginn                                      2003-04-16 09:00:00.000                            849         0x00000000172DA852 2003-04-16 09:00:00.000                            20
                            224        23     Unfall Ende                                        2003-04-16 09:00:00.000                            849         0x00000000172DA869 2003-04-16 09:00:00.000                            20
                            226        42     Firmensonderurlaub/BVI                             2007-03-28 11:24:45.260                            0           0x000000004534FC3A 2007-03-28 11:24:45.260                            20
                            228        44     Feiertag im Ausland                                2007-03-28 11:24:45.260                            0           0x000000004534FC3B 2007-03-28 11:24:45.260                            20
                            230        58     Bildungsfreistellung                               2007-03-28 11:24:45.260                            0           0x000000004534FC3C 2007-03-28 11:24:45.260                            20

                            \hier war mal stern/
                            if ((AT.GTAbsenz == true) || (AT.SummeProduktiveStunden > 0)) //defect 4972 nur dann hochz�hlen wenn gearbeitet wurde
                            {
                                if ((AT.GTAbsenzID == 90)
                                    || (AT.GTAbsenzID == 100)
                                    || (AT.GTAbsenzID == 120)
                                    || (AT.GTAbsenzID == 210)
                                    || (AT.GTAbsenzID == 212)
                                    || (AT.GTAbsenzID == 214)
                                    || (AT.GTAbsenzID == 220)
                                    || (AT.GTAbsenzID == 222)
                                    || (AT.GTAbsenzID == 224)
                                    )
                                {
                                }
                                else
                                {
                                    anzAZTagOhneReise++;
                                    if (anzAZTagOhneReise == 2)
                                    {
                                        //beginn einer neune reise
                                        bIstBeginnReise = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    // erste reise merken - ist automatsch beginnkandidat
                    ReisenBegKandRNG.Add(rkan);
                }

                if (bIstBeginnReise == true)
                {
                    ReisenBegKandRNG.Add(rkan);
                }
                iCounter++;
                rakn_vorher = rkan;
            }
            // jetzt pr�fen wir die beginne ob und wann die reduzierung eintritt
            // dh. zuerst mal beginn und wirkliches ende zu einer reise finden, um den kalendertag f�r den beginn der k�rzug zu errechnen
            DateTime redBeg = ParamVal.Date0;
            DateTime reiseBeginn = ParamVal.Date0;
            int lastBauid = -1;
            bool bIstRbeginn = false;
            int anzRT = 0; // defect 5033
            foreach (dbKG_Reise rtkan in ReisenKandRNG)
            {
                bIstRbeginn = false;
                foreach (dbKG_Reise rbkan in ReisenBegKandRNG)
                {
                    if (rbkan.Equals(rtkan))
                    {
                        // reisebeginnkandidat gefunden 
                        reiseBeginn = rbkan.Von;
                        redBeg = ParamVal.Date0;
                        lastBauid = -1;
                        bIstRbeginn = true;
                        break;
                    }
                }
                if (bIstRbeginn == true)
                {
                    //ende > 8(cAnzKalTageBisReduzierung) kaltage -> das ist dann einfach...
                    DateTime tmpBeginn = reiseBeginn;
                    //tmpBeginn = tmpBeginn.AddDays(cAnzKalTageBisReduzierung);
                    //wir z�hlen mal die reisetage dieser reise ( defect 5033)
                    anzRT = rtkan.Bis.DayOfYear - rtkan.Von.DayOfYear + 1;
                    // ist das reisenende innerhalb des reduzierungzeitraumes (dauer > offenen reisetage)
                    if (anzRT > cAnzKalTageBisReduzierung + 1)  //defect 5242 reduzierungsbeginn am r�ckresietag 
                    {
                        redBeg = rtkan.Von;
                        redBeg = redBeg.AddDays(cAnzKalTageBisReduzierung);
                        redBeg = Convert.ToDateTime(redBeg.ToShortDateString() + " " + ckorrZT_0000);
                        rtkan.redBeg = redBeg;
                        // defect 4972 nur wenn wir einen hotelbeleg habe und die anzahl der n�chte gr�sser als der
                        // red-beginn ist modifizieren wir diesen nicht !
                        /*
                        if  ((rtkan.anz_naechte > 0) && ( (rtkan.Von.DayOfYear + rtkan.anz_naechte)  > redBeg.DayOfYear ) )
                        {
                            rtkan.redBeg = rtkan.redBeg.AddDays((rtkan.Von.DayOfYear + rtkan.anz_naechte - redBeg.DayOfYear));
                        }
                         \hier war mal stern/
                    }
                    else
                    {
                        // wir m�ssen uns nur die reistage bisher merken, sonst nix eintragen
                    }
                }
                if (lastBauid == -1)
                {
                    lastBauid = GetBauIDfromEBID(rtkan.EBID);
                }
                else
                {
                    //wir pr�fen die bauid ob sie gleich ist, wenn ja dann z�hlt die reise dazu
                    if (lastBauid != GetBauIDfromEBID(rtkan.EBID))
                    {
                        // bei einer neunen bauid ist diese reise wieder ein neubeginn
                        lastBauid = GetBauIDfromEBID(rtkan.EBID);
                        reiseBeginn = rtkan.Von;
                        anzRT = rtkan.Bis.DayOfYear - rtkan.Von.DayOfYear + 1;
                        // ist das reisenende innerhalb des reduzierungzeitraumes (dauer > offenen reisetage)
                        if (anzRT > cAnzKalTageBisReduzierung)
                        {
                            redBeg = rtkan.Von;
                            redBeg = redBeg.AddDays(cAnzKalTageBisReduzierung);
                            redBeg = Convert.ToDateTime(redBeg.ToShortDateString() + " " + ckorrZT_0000);
                            rtkan.redBeg = redBeg;
                            // defect 4972 nur wenn wir einen hotelbeleg habe und die anzahl der n�chte gr�sser als der
                            // red-beginn ist modifizieren wir diesen
                            if ((rtkan.anz_naechte > 0) && ((rtkan.Von.DayOfYear + rtkan.anz_naechte) > redBeg.DayOfYear))
                            {
                                rtkan.redBeg = rtkan.redBeg.AddDays((rtkan.Von.DayOfYear + rtkan.anz_naechte - redBeg.DayOfYear));
                            }

                        }
                    }
                    else
                    {
                        //gleiche  bauid (reise z�hlt dazu)
                        DateTime tmpBeginn = reiseBeginn;
                        tmpBeginn = tmpBeginn.AddDays(cAnzKalTageBisReduzierung);
                        // wenn die anzahl der reisetage schon groesser ist, dann ist der reduzierungsbeginn der reisebeginn
                        if (anzRT > cAnzKalTageBisReduzierung)
                        {
                            redBeg = rtkan.Von;
                            redBeg = Convert.ToDateTime(redBeg.ToShortDateString() + " " + ckorrZT_0000);
                            //eintragen
                            rtkan.redBeg = redBeg;
                            // defect 4972 nur wenn wir einen hotelbeleg habe und die anzahl der n�chte gr�sser als der
                            // red-beginn ist modifizieren wir diesen hier nicht !
/*                            if ((rtkan.anz_naechte > 0) && ((rtkan.Von.DayOfYear + rtkan.anz_naechte) > redBeg.DayOfYear))
                            {
                                rtkan.redBeg = rtkan.redBeg.AddDays((rtkan.Von.DayOfYear + rtkan.anz_naechte - redBeg.DayOfYear));
                            }
                            \hier war mal stern/
                        }
                        else
                        {
                            // ist das reisenende innerhalb des reduzierungzeitraumes (dauer > offenen reisetage)
                            if ((rtkan.Bis.DayOfYear - rtkan.Von.DayOfYear) > (cAnzKalTageBisReduzierung - anzRT))
                            {
                                tmpBeginn = rtkan.Von;
                                tmpBeginn = tmpBeginn.AddDays((cAnzKalTageBisReduzierung - anzRT));
                                redBeg = tmpBeginn;
                                redBeg = Convert.ToDateTime(redBeg.ToShortDateString() + " " + ckorrZT_0000);
                                //eintragen
                                rtkan.redBeg = redBeg;
                                // defect 4972 nur wenn wir einen hotelbeleg habe und die anzahl der n�chte gr�sser als der
                                // red-beginn ist modifizieren wir diesen
                                if ((rtkan.anz_naechte > 0) && ((rtkan.Von.DayOfYear + rtkan.anz_naechte) > redBeg.DayOfYear))
                                {
                                    rtkan.redBeg = rtkan.redBeg.AddDays((rtkan.Von.DayOfYear + rtkan.anz_naechte - redBeg.DayOfYear));
                                }
                                anzRT = cAnzKalTageBisReduzierung + 1; //defect 5033 anzah reisetage muss �ber reduzierungsbeginn gesetzt werden
                            }
                            else
                            {
                                // das kommt wohl selten vor, dass wir zwei reisen haben
                                anzRT = anzRT + (rtkan.Bis.DayOfYear - rtkan.Von.DayOfYear + 1);
                            }
                        }
                    }
                }
                //
            }
             * ende defect 5390 */
            // so jetzt ist in dem objekt deiniert wann der reduzierungsbeginn f�r die einzelene reise ist -> umsetztn in t-zeilen
            // je nach versorgung aus den checkboxen oder aus den errechneten beginnen defect 4972
            if (RNGAusCB == false)
            {
                // ermitteln aus den generiertern eintr�gen
                //dazu werden in den objekten der reisen zusaetzliche objekte von dbkg_reiseZeile eingef�gt...

                foreach (dbKG_Reise rtkan in ReisenKandRNG)
                {
                    if (rtkan.redBeg != ParamVal.Date0)
                    {
                        //hier ist die reduzierung zu ermitteln
                        // am beginn der reise:
                        if (rtkan.redBeg.DayOfYear == rtkan.Von.DayOfYear)
                        {
                            //suchen der hinreise-zeile oder Teilabrechnung-hinreise  oder r�ckreise und modify dieser
                            foreach (dbKG_ReiseZeile rz in rtkan.Zeilen)
                            {
                                //if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) || (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                                if (rz.Typ != dbKG_ReiseZeilenTyp.Barauslage && rz.Typ != dbKG_ReiseZeilenTyp.Belegzeile) //Alle bis auf Belegzeilen
                                {
                                    // was wollen wir anders haben ist das D in der razeile
                                    if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                                    {
                                        rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                    }
                                    if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                                    {
                                        rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                    }
                                }
                            }
                        }
                        else
                        {
                            //wir nm�ssen eine t-zeile einf�gen....nach der hinreise und vor der r�ckreise
                            //suchen der hinreise-zeile oder Teilabrechnung-hinreise und modify dieser
                            bool bR�ckreiseSuchen = false;
                            string tmpReiseart = "";
                            foreach (dbKG_ReiseZeile rz in rtkan.Zeilen)
                            {
                                if (bR�ckreiseSuchen == false)
                                {
                                    if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung))
                                    {
                                        //hinreise gefunden , suchen der r�ckreise
                                        bR�ckreiseSuchen = true;
                                        tmpReiseart = rz.Zeile.Params.REISEART.Value.ToString();
                                        //pruefen ob die zeilen nach dem reduzierungsbeginn liegen um das D zu setzten 
                                        if (rz.ReiseTag.DayOfYear > rtkan.redBeg.DayOfYear)
                                        {
                                            if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                                            {
                                                rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                            }
                                            if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                                            {
                                                rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                            }
                                        }
                                    }
                                    // fuer den rest der reise d eintragen
                                    //if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) || (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                                    if (rz.Typ != dbKG_ReiseZeilenTyp.Barauslage && rz.Typ != dbKG_ReiseZeilenTyp.Belegzeile) //Alle bis auf Belegzeilen
                                    {
                                        if (rz.ReiseTag.DayOfYear > rtkan.redBeg.DayOfYear)
                                        {
                                            if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                                            {
                                                rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                            }
                                            if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                                            {
                                                rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if ((rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) ||
                                         ((rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel) && (rz.ReiseTag.DayOfYear > rtkan.redBeg.DayOfYear)
                                         )
                                       )
                                    {
                                        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"] && rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                                        {
                                            //BAN 500059 - TA ist nicht mehr notwendig, 
                                            int index = rtkan.Zeilen.IndexOf(rz); //-1
                                            DateTime redBegTmp = rtkan.redBeg;
                                            redBegTmp = redBegTmp.AddDays(1);

                                            //1.t-zeile
                                            //defect 5191 rtkan.Zeilen.Insert((index), ZTeilab(new dbKG_ReiseZeile(rtkan, null), false, rtkan.IntfID, redBegTmp, null));//defect 5242 pr�fung doppelt-t
                                            //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                            dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(rtkan, null), false, rtkan.IntfID, redBegTmp, null);//defect 5242 pr�fung doppelt-t
                                            if (zt != null)
                                            {
                                                zt = ZBWechselNeu(zt, "85");
                                                rtkan.Zeilen.Insert((index), zt);


                                            }
                                            break;
                                        }
                                        else
                                        {
                                            int index = rtkan.Zeilen.IndexOf(rz); //-1
                                            DateTime redBegTmp = rtkan.redBeg;
                                            redBegTmp = redBegTmp.AddDays(1);

                                            //1.t-zeile
                                            //defect 5191 rtkan.Zeilen.Insert((index), ZTeilab(new dbKG_ReiseZeile(rtkan, null), false, rtkan.IntfID, redBegTmp, null));//defect 5242 pr�fung doppelt-t
                                            //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                            dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(rtkan, null), false, rtkan.IntfID, redBegTmp, null);//defect 5242 pr�fung doppelt-t
                                            if (zt != null)
                                                rtkan.Zeilen.Insert((index), zt);
                                            //defect 5191 ende
                                            dbKG_ReiseZeile rzt = (dbKG_ReiseZeile)rtkan.Zeilen[(index)];

                                            //rzt.Zeile.Params.REISEART.Value = "D";  // defect 4970
                                            if ((tmpReiseart == cReiseartNAH))  //R defect4970
                                            {
                                                rzt.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                            }
                                            if (tmpReiseart == cReiseartFERN)  //defect4970
                                            {
                                                rzt.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                            }
                                            rzt.ReiseTag = redBegTmp;
                                            rzt.Ab = redBegTmp;
                                            rzt.An = redBegTmp;
                                            // 2.t-zeile

                                            //defect 5191 rtkan.Zeilen.Insert((index), ZTeilab(new dbKG_ReiseZeile(rtkan, null), false, rtkan.IntfID, rtkan.redBeg, null));//defect 5242 pr�fung doppelt-t
                                            //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                            dbKG_ReiseZeile ztx = ZTeilab(new dbKG_ReiseZeile(rtkan, null), false, rtkan.IntfID, rtkan.redBeg, null);//defect 5242 pr�fung doppelt-t
                                            if (ztx != null)
                                                rtkan.Zeilen.Insert((index), ztx);
                                            //defect 5191 ende
                                            rzt = (dbKG_ReiseZeile)rtkan.Zeilen[(index)];

                                            rzt.Zeile.Params.REISEART.Value = tmpReiseart;
                                            rzt.ReiseTag = rtkan.redBeg;

                                            rzt.Ab = Convert.ToDateTime(rtkan.redBeg.ToShortDateString() + " " + ckorrZT_2359 + ":59");  //defect 5242: zeitstempel erg�nzt 
                                            rzt.An = Convert.ToDateTime(rtkan.redBeg.ToShortDateString() + " " + ckorrZT_2359 + ":59"); //defect 5242: zeitstempel erg�nzt

                                            break;  // nach dem break muss man noch den rest der reise nach reduzierungseintr�gen f�r die REISEART durchsuchen !
                                        }
                                    }
                                    else
                                    {
                                        //pruefen ob die zeilen nach dem reduzierungsbeginn liegen um das D zu setzten 
                                        if ((rz.ReiseTag.DayOfYear > rtkan.redBeg.DayOfYear) && ((rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung))
                                            )
                                        {
                                            if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                                            {
                                                rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                            }
                                            if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                                            {
                                                rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                            }

                                        }
                                    }
                                }
                            }
                            // alle zeilen nochmals pr�fen wegen: nach dem break muss man noch den rest der reise nach reduzierungseintr�gen f�r die REISEART durchsuchen !
                            foreach (dbKG_ReiseZeile rz in rtkan.Zeilen)
                            {
                                if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) || (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                                {
                                    if (rz.ReiseTag.DayOfYear > rtkan.redBeg.DayOfYear)
                                    {
                                        if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                                        {
                                            rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                        }
                                        if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                                        {
                                            rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                //erzeugen der t-zeilen aus den gesetzten kreuzen in der maske
                foreach (dbKG_Reise r in ReisenALL)
                {
                    //                  //  r.Von 
                    //bool rng = false;
                    bool RNG_vt = false;
                    foreach (dbArbTag AT in ArbzeitenALL)
                    {
                        //bool istRT = false;
                        /* defect 5390 beginn: auch die reisetage mit pr�fen ohne day of year range
                        if ((r.Von.DayOfYear <= AT.TagesDatum.DayOfYear)
                           && (r.Bis.DayOfYear >= AT.TagesDatum.DayOfYear)
                            )  */
                        if ((((r.Von.ToShortDateString() == AT.TagesDatum.ToShortDateString()) ||
                            (r.Von <= AT.TagesDatum))
                            )
                            && ((r.Bis.ToShortDateString() == AT.TagesDatum.ToShortDateString()) ||
                                (r.Bis >= AT.TagesDatum)
                                )
                            && AT.RNGkand == true
                        )
                        // defect 5390 ende
                        {
                            //  istRT = true;
                            if (AT.RNG == true)
                            {
                                if (RNG_vt == false)
                                {
                                    //hier ein wechsel von nicht RNG zu RNG
                                    #region inserten einer t-zeile
                                    //aenderung auf true f�r dieses datum -> t zeile
                                    dbKG_ReiseZeile last_rz = null;
                                    dbKG_ReiseZeile hinf_rz = null;  // defect 5390
                                    ArrayList tZeilenVonStandortwechsel = new ArrayList();
                                    string tmpReiseart = "";
                                    DateTime redBegTmp = AT.TagesDatum;
                                    int index = -2;
                                    // suchen der hinreise 
                                    foreach (dbKG_ReiseZeile rz in r.Zeilen)
                                    {
                                        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                        {
                                            if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || ((rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (rz.Ab.ToShortDateString() == r.Von.ToShortDateString()))  // hinreise  // defect 5390 string statt day of year
                                                   || (rz.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung)) //BAN 500059
                                            {
                                                // hinfahrt gefunden, merken wir uns diese mal
                                                hinf_rz = rz;  // defect 5390 merken der hinfahrt
                                                if (redBegTmp.ToShortDateString() == rz.ReiseTag.ToShortDateString())  // defect 5390 vergleich nun mit dem string und nicht day of year
                                                {
                                                    //reisetag am gleichen tag wie hinreise
                                                    index = -1;
                                                    last_rz = rz;
                                                    break;
                                                }
                                                else if (redBegTmp > rz.ReiseTag) // defect 5390 vergleich nun ohne day of year
                                                {
                                                    //reduzierung nach hinreise
                                                    last_rz = rz;
                                                    index = r.Zeilen.IndexOf(rz);
                                                    //break; //defect #5981 - kein break, es kann sein das wir ein SW noch vor reduzierung haben
                                                }

                                            }
                                            else if (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                                            {
                                                // da tun wir mal nix
                                            }
                                        }
                                        else
                                        {
                                            if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || ((rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (rz.Ab.ToShortDateString() == r.Von.ToShortDateString())))  // hinreise  // defect 5390 string statt day of year
                                            {
                                                // hinfahrt gefunden, merken wir uns diese mal
                                                hinf_rz = rz;  // defect 5390 merken der hinfahrt
                                                if (redBegTmp.ToShortDateString() == rz.ReiseTag.ToShortDateString())  // defect 5390 vergleich nun mit dem string und nicht day of year
                                                {
                                                    //reisetag am gleichen tag wie hinreise
                                                    index = -1;
                                                    last_rz = rz;
                                                    break;
                                                }
                                                else if (redBegTmp > rz.ReiseTag) // defect 5390 vergleich nun ohne day of year
                                                {
                                                    //reduzierung nach hinreise
                                                    last_rz = rz;
                                                    index = r.Zeilen.IndexOf(rz);
                                                    //break; //defect #5981 - kein break, es kann sein das wir ein SW noch vor reduzierung haben
                                                }

                                            }
                                            else if (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                                            {
                                                // da tun wir mal nix
                                            }
                                            else
                                                if (rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel
                                                    && rz.Zeile.Params.ABORT.Value.ToString() != "" // kein Quartierfahrt
                                                    && rz.Zeile.Params.ANORT.Value.ToString() != "" // kein Quartierfahrt
                                                    && rz.Zeile.Params.ABORT.Value.ToString() != rz.Zeile.Params.ANORT.Value.ToString()) //bleibt am selben ort - KFZ Zeile
                                                {
                                                    if (redBegTmp.DayOfYear > rz.ReiseTag.DayOfYear)
                                                    {
                                                        //defect #5981
                                                        if (hinf_rz != null)
                                                        {
                                                            if (rz.Zeile.Params.REISEART.Value.ToString() != hinf_rz.Zeile.Params.REISEART.Value.ToString())
                                                            {
                                                                //durch SW �ndert sich die Reiseart, hier muss T Zeilen
                                                                DateTime dt = rz.ReiseTag;
                                                                dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, dt, ckorrZT_0000);
                                                                if (zt != null)
                                                                {
                                                                    zt.Zeile.Params.REISEART.Value = rz.Zeile.Params.REISEART.Value;
                                                                    tZeilenVonStandortwechsel.Add(zt);
                                                                    //index = r.Zeilen.IndexOf(rz);
                                                                    //r.Zeilen.Insert((index), zt);
                                                                    dt = dt.AddDays(-1);
                                                                    dbKG_ReiseZeile ztx = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, dt, ckorrZT_2359);
                                                                    if (ztx != null)
                                                                    {
                                                                        ztx.Zeile.Params.REISEART.Value = hinf_rz.Zeile.Params.REISEART.Value;
                                                                        //r.Zeilen.Insert((index), ztx);
                                                                        tZeilenVonStandortwechsel.Add(ztx);
                                                                    }
                                                                    else
                                                                        tZeilenVonStandortwechsel.RemoveAt(tZeilenVonStandortwechsel.Count - 1);
                                                                }
                                                            }
                                                        }
                                                        //einf�geindex nach standortwechsel
                                                        //Defect #6036 index vergeben ohne hinf_rz oder last_rz bringt Exception
                                                        //soll rz als hinf_rz && last_rz gesehen werden ????
                                                        //defect #5981 - wir sind noch nicht bei reduzierung und Reiseart kann sich bei SW �ndern
                                                        //deswegen �berschreiben wir hinf_rz mit standortwechsel
                                                        hinf_rz = rz;
                                                        last_rz = rz;//defect #5981 - SW ber�cksichtigen
                                                        index = r.Zeilen.IndexOf(rz);
                                                    }
                                                }
                                        }
                                    }
                                    // wir inserten  die t-zeilen, wenn der tag nicht der hin oder rr-tag ist
                                    if (index >= 0)
                                    {
                                        //1.t-zeile
                                        //defect 5191 r.Zeilen.Insert((index), ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null));//defect 5242 pr�fung doppelt-t
                                        //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                        dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, redBegTmp, ckorrZT_0000);//defect 5242 pr�fung doppelt-t //5191 statt null-date den reisetag mitgeben
                                        if (zt != null)
                                        {
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                zt = ZBWechselNeu(zt, "85");
                                                r.Zeilen.Insert((index), zt);
                                            }
                                            else
                                            {
                                                r.Zeilen.Insert((index), zt);
                                            }
                                            //defect 5191 ende
                                            if (hinf_rz == null)
                                                tmpReiseart = last_rz.Zeile.Params.REISEART.Value.ToString();
                                            else
                                                tmpReiseart = hinf_rz.Zeile.Params.REISEART.Value.ToString();
                                            //defect #5981 - SW ber�cksichtigen
                                            if (last_rz != null && last_rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)
                                            {
                                                tmpReiseart = last_rz.Zeile.Params.REISEART.Value.ToString();
                                            }
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                if (last_rz != null && last_rz.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung)
                                                {
                                                    tmpReiseart = last_rz.Zeile.Params.REISEART.Value.ToString();
                                                }
                                            }
                                            // defect 5390 beginn: reiseart normalisieren
                                            if (tmpReiseart == cReiseartNAH_RED_NG)
                                                tmpReiseart = cReiseartNAH;
                                            if (tmpReiseart == cReiseartFERN_RED_NG)
                                                tmpReiseart = cReiseartFERN;
                                            // defect 5390 ende
                                            dbKG_ReiseZeile rzt = (dbKG_ReiseZeile)r.Zeilen[(index)];
                                            if ((tmpReiseart == cReiseartNAH))
                                            {
                                                rzt.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                            }
                                            if (tmpReiseart == cReiseartFERN)
                                            {
                                                rzt.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                            }
                                            rzt.ReiseTag = redBegTmp;
                                            rzt.Ab = redBegTmp;
                                            rzt.An = redBegTmp;
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                //keine zweite T Zeile
                                            }
                                            else
                                            {
                                                // 2.t-zeile
                                                redBegTmp = redBegTmp.AddDays(-1);  //defect  5390 
                                                redBegTmp = Convert.ToDateTime(redBegTmp.ToShortDateString() + " " + ckorrZT_2359 + ":59");
                                                //defect 5191 r.Zeilen.Insert((index), ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null));//defect 5242 pr�fung doppelt-t
                                                //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                dbKG_ReiseZeile ztx = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, redBegTmp, ckorrZT_2359);//defect 5242 pr�fung doppelt-t //5191 statt null-date den reisetag mitgeben
                                                if (ztx != null)
                                                {
                                                    r.Zeilen.Insert((index), ztx);
                                                    //defect 5191 ende
                                                    rzt = (dbKG_ReiseZeile)r.Zeilen[(index)];

                                                    if (hinf_rz != null) //defect #5981
                                                        tmpReiseart = hinf_rz.Zeile.Params.REISEART.Value.ToString();
                                                    rzt.Zeile.Params.REISEART.Value = tmpReiseart; //von hinf_rz
                                                    rzt.ReiseTag = redBegTmp; //r.redBeg;  defect 5390 

                                                    rzt.Ab = Convert.ToDateTime(redBegTmp.ToShortDateString() + " " + ckorrZT_2359 + ":59");  //defect 5242: zeitstempel erg�nzt 
                                                    rzt.An = Convert.ToDateTime(redBegTmp.ToShortDateString() + " " + ckorrZT_2359 + ":59");   //defect 5242: zeitstempel erg�nzt 
                                                }
                                            }
                                        }
                                    }
                                    else if (index == -1)
                                    {
                                        //modify der hinreise
                                        tmpReiseart = last_rz.Zeile.Params.REISEART.Value.ToString();
                                        // defect 5390 beginn: reiseart normalisieren
                                        if (tmpReiseart == cReiseartNAH_RED_NG)
                                            tmpReiseart = cReiseartNAH;
                                        if (tmpReiseart == cReiseartFERN_RED_NG)
                                            tmpReiseart = cReiseartFERN;
                                        // defect 5390 ende

                                        if ((tmpReiseart == cReiseartNAH))
                                        {
                                            last_rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                        }
                                        if (tmpReiseart == cReiseartFERN)
                                        {
                                            last_rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                        }
                                    }
                                    //jetzt f�gen wir tZeilenVonStandortwechsel
                                    foreach (dbKG_ReiseZeile tZeile in tZeilenVonStandortwechsel)
                                    {
                                        bool tZeileExist = false;
                                        foreach (dbKG_ReiseZeile zx in r.Zeilen)
                                        {
                                            if ((zx.ReiseTag == tZeile.ReiseTag)
                                                 && (zx.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                                                 && (zx.Ab == tZeile.Ab))
                                            {
                                                // T Zeile gib es schon
                                                tZeileExist = true;
                                                break;
                                            }
                                        }
                                        if (!tZeileExist)
                                        {
                                            r.Zeilen.Add(tZeile);
                                        }
                                    }
                                    // alle zeilen nochmals pr�fen wegen: nach dem break muss man noch den rest der reise nach reduzierungseintr�gen f�r die REISEART durchsuchen !
                                    r.SortZeiten();  // defect 5390
                                    dbKG_ReiseZeile ersteRZ = null;
                                    foreach (dbKG_ReiseZeile rz in r.Zeilen)
                                    {
                                        //if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) || (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                                        if (rz.Typ != dbKG_ReiseZeilenTyp.Barauslage && rz.Typ != dbKG_ReiseZeilenTyp.Belegzeile)
                                        {
                                            if (rz.ReiseTag > redBegTmp)//r.redBeg.DayOfYear)  defect 5390 nur zeilen nach der reduzierung aendern
                                            {
                                                if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                                                {
                                                    rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                                }
                                                if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                                                {
                                                    rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                                }
                                            }
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                if (rz.ReiseTag == redBegTmp)//r.redBeg.DayOfYear)  defect 5390 nur zeilen nach der reduzierung aendern
                                                {
                                                    if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                                                    {
                                                        rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                                    }
                                                    if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                                                    {
                                                        rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (ersteRZ == null)
                                                {
                                                    ersteRZ = rz;
                                                }
                                                else
                                                {
                                                    rz.Zeile.Params.REISEART.Value = ersteRZ.Zeile.Params.REISEART.Value;
                                                    ersteRZ = null;
                                                }
                                            }

                                        }
                                    }
                                    #endregion
                                }
                                else
                                {
                                    if (AT.RNGBaustWechsel && AT.RNGkand == true)
                                    {
                                        //durch SW �ndert sich die Reiseart, hier muss T Zeilen
                                        try
                                        {
                                            if (ConfigurationManager.AppSettings["TAPM-34plus"] == "true")
                                            {
                                                DateTime dt = AT.TagesDatum;
                                                dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, dt, ckorrZT_0000);
                                                if (zt != null)
                                                {
                                                    dbArbZeit az = (dbArbZeit)AT.Zeiten[AT.Zeiten.Count - 1];
                                                    int ebid = Convert.ToInt32((az.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                    int ratyp = Convert.ToInt32(GetBaustelleStandort(ebid).Params.RATYP.Value);
                                                    if (ReiseartNeu(ratyp, 0) == cReiseartNAH)
                                                        zt.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;
                                                    else
                                                        if (ReiseartNeu(ratyp, 0) == cReiseartFERN)
                                                            zt.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;

                                                    //index = r.Zeilen.IndexOf(rz);
                                                    //r.Zeilen.Insert((index), zt);
                                                    dt = dt.AddDays(-1);
                                                    dbKG_ReiseZeile ztx = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, dt, ckorrZT_2359);
                                                    if (ztx != null && ratyp != 0 && ratyp != 3 && ratyp != 5) //nicht bei t�glichen reisetagen
                                                    {
                                                        r.Zeilen.Add(zt);
                                                        r.Zeilen.Add(ztx);
                                                        r.SortZeiten();  // defect 5390
                                                        dbKG_ReiseZeile ersteRZ = null;
                                                        foreach (dbKG_ReiseZeile rz in r.Zeilen)
                                                        {
                                                            if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) || (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                                                            {
                                                                if (rz.ReiseTag > dt)//r.redBeg.DayOfYear)  defect 5390 nur zeilen nach der reduzierung aendern
                                                                {
                                                                    if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH))  //R defect4970
                                                                    {
                                                                        rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                                                    }
                                                                    if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN)  //defect4970
                                                                    {
                                                                        rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                                                    }
                                                                }
                                                                if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                                                {
                                                                    //Da kommen wir sowieso nicht weil TAPM-34 Plus nicht aktiv ist
                                                                    //was ist das ???
                                                                }
                                                                else
                                                                {
                                                                    if (ersteRZ == null)
                                                                    {
                                                                        ersteRZ = rz;
                                                                    }
                                                                    else
                                                                    {
                                                                        rz.Zeile.Params.REISEART.Value = ersteRZ.Zeile.Params.REISEART.Value;
                                                                        ersteRZ = null;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        catch
                                        {
                                        }
                                    }
                                }
                                RNG_vt = true;

                            }
                            else
                            {
                                if (RNG_vt == true)
                                {
                                    //hier ein wechsel von RNG zu nicht RNG
                                    // defect 5390 beginn: auch das r�ckschalten mit t-zeile betonieren
                                    #region inserten einer t-zeile
                                    //aenderung auf true f�r dieses datum -> t zeile
                                    dbKG_ReiseZeile last_rz = null;
                                    dbKG_ReiseZeile hinf_rz = null;  // defect 5390

                                    string tmpReiseart = "";
                                    DateTime redBegTmp = AT.TagesDatum;
                                    int index = -2;
                                    // suchen der hinreise 
                                    foreach (dbKG_ReiseZeile rz in r.Zeilen)
                                    {
                                        if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                        {
                                            if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || ((rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (rz.Ab.ToShortDateString() == r.Von.ToShortDateString()))  // hinreise  // defect 5390 string statt day of year
                                             || (rz.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung)) //BAN 500059
                                            {
                                                hinf_rz = rz;  // defect 5390 merken der hinfahrt
                                                if (redBegTmp.ToShortDateString() == rz.ReiseTag.ToShortDateString())  // defect 5390 vergleich nun mit dem string und nicht day of year
                                                {
                                                    //reisetag am gleichen tag wie hinreise
                                                    index = -1;
                                                    last_rz = rz;
                                                    break;
                                                }
                                                else if (redBegTmp > rz.ReiseTag) // defect 5390 vergleich nun ohne day of year
                                                {
                                                    //reduzierung nach hinreise
                                                    last_rz = rz;
                                                    index = r.Zeilen.IndexOf(rz);
                                                    //break; nicht unterbrechen wegen SW
                                                }

                                            }
                                            else if (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                                            {
                                                // da tun wir mal nix
                                            }
                                        }
                                        else
                                        {
                                            if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || ((rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) && (rz.Ab.ToShortDateString() == r.Von.ToShortDateString())))  // hinreise  // defect 5390 string satt day of year
                                            {
                                                // hinfahrt gefunden, merken wir uns diese mal
                                                hinf_rz = rz;  // defect 5390 merken der hinfahrt
                                                if (redBegTmp.ToShortDateString() == rz.ReiseTag.ToShortDateString())  // defect 5390 vergleich nun mit dem string und nicht day of year
                                                {
                                                    //reisetag am gleichen tag wie hinreise
                                                    index = -1;
                                                    last_rz = rz;
                                                    break;
                                                }
                                                else if (redBegTmp > rz.ReiseTag) // defect 5390 vergleich nun ohne day of year
                                                {
                                                    //reduzierung nach hinreise
                                                    last_rz = rz;
                                                    index = r.Zeilen.IndexOf(rz);
                                                    //break; nicht unterbrechen wegen SW
                                                }

                                            }
                                            else if (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                                            {
                                                // da tun wir mal nix
                                            }
                                            else
                                                if (rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel
                                                    && rz.Zeile.Params.ABORT.Value.ToString() != "" //kein quartierfahrt
                                                    && rz.Zeile.Params.ANORT.Value.ToString() != "" //kein quartierfahrt
                                                    && rz.Zeile.Params.ABORT.Value.ToString() != rz.Zeile.Params.ANORT.Value.ToString() //bleibt am seleben ort - KFZ Daten
                                                    )
                                                {
                                                    if (redBegTmp.DayOfYear >= rz.ReiseTag.DayOfYear)
                                                    {
                                                        //einf�geindex nach standortwechsel
                                                        //Defect #6036 index vergeben ohne hinf_rz oder last_rz bringt Exception
                                                        //soll rz als hinf_rz && last_rz gesehen werden ????
                                                        if (hinf_rz != null)
                                                        {
                                                            if (last_rz != null && last_rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)
                                                            {
                                                                //defect #5981 - wir wechseln die Baustelle zum zwiten mal.
                                                                hinf_rz = last_rz;
                                                            }
                                                            last_rz = rz;
                                                            index = r.Zeilen.IndexOf(rz); // - 3 setzten falls wir kein TA brauchen
                                                        }
                                                    }
                                                }
                                        }
                                    }
                                    // wir inserten  die t-zeilen, wenn der tag nicht der hin oder rr-tag ist
                                    if (index >= 0)
                                    {
                                        //1.t-zeile
                                        //defect 5191 r.Zeilen.Insert((index), ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null));//defect 5242 pr�fung doppelt-t
                                        //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                        //dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, redBegTmp, null);//defect 5242 pr�fung doppelt-t
                                        //Defect #6045 - TA mit ckorrZT_0000 hinzuf�gen
                                        dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, redBegTmp, ckorrZT_0000);
                                        if (zt != null)
                                        {
                                            //Defect #6045 - falls TA hinzuf�gt werden sollte, dann nachkommende Reisezeilen anpassen
                                            //defect #5981 - SW ber�cksichtigen
                                            if (last_rz != null && last_rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)
                                            {
                                                //TA vom SW
                                                zt.Zeile.Params.REISEART.Value = last_rz.Zeile.Params.REISEART.Value.ToString();
                                            }
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                zt = ZBWechselNeu(zt, "85");
                                                r.Zeilen.Insert((index), zt);
                                            }
                                            else
                                            {
                                                r.Zeilen.Insert((index), zt);
                                            }
                                            //defect 5191 ende
                                            if (hinf_rz == null)
                                                tmpReiseart = last_rz.Zeile.Params.REISEART.Value.ToString();
                                            else
                                                tmpReiseart = hinf_rz.Zeile.Params.REISEART.Value.ToString();
                                            if (last_rz != null && last_rz.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)
                                            {
                                                tmpReiseart = last_rz.Zeile.Params.REISEART.Value.ToString();
                                            }
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                if (last_rz != null && last_rz.Typ == dbKG_ReiseZeilenTyp.WechselBereitstellung)
                                                {
                                                    tmpReiseart = last_rz.Zeile.Params.REISEART.Value.ToString();
                                                }
                                            }
                                            // defect 5390 beginn: reiseart normalisieren
                                            if (tmpReiseart == cReiseartNAH_RED_NG)
                                                tmpReiseart = cReiseartNAH;
                                            if (tmpReiseart == cReiseartFERN_RED_NG)
                                                tmpReiseart = cReiseartFERN;
                                            // defect 5390 ende

                                            dbKG_ReiseZeile rzt = (dbKG_ReiseZeile)r.Zeilen[(index)];
                                            rzt.Zeile.Params.REISEART.Value = tmpReiseart;

                                            rzt.ReiseTag = redBegTmp;
                                            rzt.Ab = redBegTmp;
                                            rzt.An = redBegTmp;

                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                // 2.t-zeile nicht notwendig
                                            }
                                            else
                                            {
                                                // 2.t-zeile
                                                redBegTmp = redBegTmp.AddDays(-1);  //defect  5390 
                                                //defect 5191 r.Zeilen.Insert((index), ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, ParamVal.Date0, null));//defect 5242 pr�fung doppelt-t
                                                //defect 5191 umbau der zuweisung um die doppelte nicht doch wieder anzuh�ngen
                                                //dbKG_ReiseZeile ztx = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, redBegTmp, null);//defect 5242 pr�fung doppelt-t
                                                //Defect #6045 - TA mit ckorrZT_2359 hinzuf�gen
                                                dbKG_ReiseZeile ztx = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, redBegTmp, ckorrZT_2359);
                                                if (ztx != null)
                                                {
                                                    r.Zeilen.Insert((index), ztx);
                                                    //defect 5191 ende
                                                    rzt = (dbKG_ReiseZeile)r.Zeilen[(index)];

                                                    if (hinf_rz != null)
                                                    {
                                                        tmpReiseart = hinf_rz.Zeile.Params.REISEART.Value.ToString();
                                                    }
                                                    if ((tmpReiseart == cReiseartNAH))
                                                    {
                                                        rzt.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                                    }
                                                    if (tmpReiseart == cReiseartFERN)
                                                    {
                                                        rzt.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                                    }
                                                    rzt.ReiseTag = redBegTmp; //r.redBeg;  defect 5390 

                                                    rzt.Ab = Convert.ToDateTime(redBegTmp.ToShortDateString() + " " + ckorrZT_2359 + ":59");  //defect 5242: zeitstempel erg�nzt 
                                                    rzt.An = Convert.ToDateTime(redBegTmp.ToShortDateString() + " " + ckorrZT_2359 + ":59");   //defect 5242: zeitstempel erg�nzt 
                                                }
                                            }
                                        }
                                    }
                                    else if (index == -1)
                                    {
                                        //modify der hinreise
                                        tmpReiseart = last_rz.Zeile.Params.REISEART.Value.ToString();
                                        // defect 5390 beginn: reiseart normalisieren
                                        if (tmpReiseart == cReiseartNAH_RED_NG)
                                            tmpReiseart = cReiseartNAH;
                                        if (tmpReiseart == cReiseartFERN_RED_NG)
                                            tmpReiseart = cReiseartFERN;
                                        // defect 5390 ende

                                        if ((tmpReiseart == cReiseartNAH))
                                        {
                                            last_rz.Zeile.Params.REISEART.Value = cReiseartNAH_RED_NG;//'D';
                                        }
                                        if (tmpReiseart == cReiseartFERN)
                                        {
                                            last_rz.Zeile.Params.REISEART.Value = cReiseartFERN_RED_NG;//'E';
                                        }
                                    }
                                    // alle zeilen nochmals pr�fen wegen: nach dem break muss man noch den rest der reise nach reduzierungseintr�gen f�r die REISEART durchsuchen !
                                    r.SortZeiten();
                                    dbKG_ReiseZeile ersteRZ = null;
                                    foreach (dbKG_ReiseZeile rz in r.Zeilen)
                                    {
                                        //if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) || (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                                        if (rz.Typ != dbKG_ReiseZeilenTyp.Belegzeile && rz.Typ != dbKG_ReiseZeilenTyp.Barauslage)
                                        {
                                            if (rz.ReiseTag > redBegTmp)//r.redBeg.DayOfYear)  defect 5390 nur zeilen nach der reduzierung aendern
                                            {
                                                if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH_RED_NG))
                                                {
                                                    rz.Zeile.Params.REISEART.Value = cReiseartNAH;
                                                }
                                                if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN_RED_NG)
                                                {
                                                    rz.Zeile.Params.REISEART.Value = cReiseartFERN;
                                                }
                                            }
                                            if (Session["UseNewHRInterface"] != null && (bool)Session["UseNewHRInterface"])
                                            {
                                                if (rz.ReiseTag == redBegTmp)//r.redBeg.DayOfYear)  defect 5390 nur zeilen nach der reduzierung aendern
                                                {
                                                    if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH_RED_NG))
                                                    {
                                                        rz.Zeile.Params.REISEART.Value = cReiseartNAH;
                                                    }
                                                    if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN_RED_NG)
                                                    {
                                                        rz.Zeile.Params.REISEART.Value = cReiseartFERN;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (ersteRZ == null)
                                                {
                                                    ersteRZ = rz;
                                                }
                                                else
                                                {
                                                    rz.Zeile.Params.REISEART.Value = ersteRZ.Zeile.Params.REISEART.Value;
                                                    ersteRZ = null;
                                                }
                                            }
                                        }
                                    }
                                    #endregion
                                    // defect 5390 ende

                                    //aenderung auf false -> zul�ssig ?
                                    RNG_vt = false;

                                }
                                else
                                {
                                    if (AT.RNGBaustWechsel && AT.RNGkand == true)
                                    {
                                        try
                                        {
                                            //durch SW �ndert sich die Reiseart, hier muss T Zeilen
                                            if (ConfigurationManager.AppSettings["TAPM-34plus"] == "true")
                                            {
                                                DateTime dt = AT.TagesDatum;
                                                dbKG_ReiseZeile zt = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, dt, ckorrZT_0000);
                                                if (zt != null)
                                                {
                                                    dbArbZeit az = (dbArbZeit)AT.Zeiten[AT.Zeiten.Count - 1];
                                                    int ebid = Convert.ToInt32((az.Params as dbAZ_ARBZEITParams).EBID.Value);
                                                    int ratyp = Convert.ToInt32(GetBaustelleStandort(ebid).Params.RATYP.Value);
                                                    if (ReiseartNeu(ratyp, 0) == cReiseartNAH)
                                                        zt.Zeile.Params.REISEART.Value = cReiseartNAH;
                                                    else
                                                        if (ReiseartNeu(ratyp, 0) == cReiseartFERN)
                                                            zt.Zeile.Params.REISEART.Value = cReiseartFERN;

                                                    dt = dt.AddDays(-1);
                                                    dbKG_ReiseZeile ztx = ZTeilab(new dbKG_ReiseZeile(r, null), false, r.IntfID, dt, ckorrZT_2359);
                                                    if (ztx != null && ratyp != 0 && ratyp != 3 && ratyp != 5) //nicht bei t�glichen Reisen
                                                    {
                                                        r.Zeilen.Add(zt);
                                                        r.Zeilen.Add(ztx);
                                                        r.SortZeiten();  // defect 5390
                                                        dbKG_ReiseZeile ersteRZ = null;
                                                        foreach (dbKG_ReiseZeile rz in r.Zeilen)
                                                        {
                                                            if ((rz.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) || (rz.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung) || (rz.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt))
                                                            {
                                                                if (rz.ReiseTag > dt)//r.redBeg.DayOfYear)  defect 5390 nur zeilen nach der reduzierung aendern
                                                                {
                                                                    if ((rz.Zeile.Params.REISEART.Value.ToString() == cReiseartNAH_RED_NG))  //R defect4970
                                                                    {
                                                                        rz.Zeile.Params.REISEART.Value = cReiseartNAH;//'D';
                                                                    }
                                                                    if (rz.Zeile.Params.REISEART.Value.ToString() == cReiseartFERN_RED_NG)  //defect4970
                                                                    {
                                                                        rz.Zeile.Params.REISEART.Value = cReiseartFERN;//'E';
                                                                    }
                                                                }
                                                                //hier kommen wir auch nicht TAPM-34 Plus inaktiv
                                                                if (ersteRZ == null)
                                                                {
                                                                    ersteRZ = rz;
                                                                }
                                                                else
                                                                {
                                                                    rz.Zeile.Params.REISEART.Value = ersteRZ.Zeile.Params.REISEART.Value;
                                                                    ersteRZ = null;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        catch
                                        {
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            #endregion
            // ende defect 4971
        }
        // ende defect 4972
    }




    public class dbKG_Reise
    {
        public bool ebidAusVormonat = false;
        public ArrayList barAuslagen = new ArrayList();
        public bool hatRueckReise = false;
        public ArrayList Zeilen = new ArrayList();
        private dbRaKopf lKopf = null;
        public DateTime redBeg = ParamVal.Date0; //kalendertag des jahres an dem bei dieser reise ein reduziertes Naechtigungsgeld beginnt / defect 4971
        public int anz_naechte = -1;  // defect 4972 f�r den hotelbeleg
        public dbRaKopf Kopf
        {
            get //creates new RaKopf if null
            {
                if (lKopf == null) //leere Rakopf
                    lKopf = new dbRaKopf(RAbrech.Monat.Monteur, RAbrech.Monat.MinDatum.Year * 100 + RAbrech.Monat.MinDatum.Month, this);
                return lKopf;
            }
            set //creates new RaKopf if null 
            {
                lKopf = value;
                Zeilen = new ArrayList();
                if (lKopf != null)
                    foreach (dbRaZeile z in lKopf.Zeilen)
                        Zeilen.Add(new dbKG_ReiseZeile(this, z));
                else
                    lKopf = new dbRaKopf(RAbrech.Monat.Monteur, RAbrech.Monat.MinDatum.Year * 100 + RAbrech.Monat.MinDatum.Month, this);
            }
        }
        public dbKG_Rabrech RAbrech; //Parent-Object
        public dbKG_Reise(dbKG_Rabrech rAbrech, dbRaKopf RaKopf)
        {
            RAbrech = rAbrech;
            Kopf = RaKopf;
        }
        public DateTime letzteHeimreise
        {
            get
            {
                DateTime d = DateTime.MinValue;
                foreach (dbKG_ReiseZeile z in Zeilen)
                    if (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                        d = z.Ab;
                return d;
            }
        }

        //BAN 500059 - auch mit S oder W kann Einsatz auf eine Baustelle beendet werden
        public dbKG_ReiseZeile letzteHRSWoderT
        {
            get
            {
                dbKG_ReiseZeile l = null;
                foreach (dbKG_ReiseZeile z in Zeilen)
                {
                    if (z.Typ < dbKG_ReiseZeilenTyp.Belegzeile)
                    {
                        if (l != null)
                        {
                            if ((z.Ab.Ticks >= l.Ab.Ticks) && (z.ReiseTag >= l.ReiseTag))
                            {
                                l = z;
                            }
                        }
                        else
                        {
                            l = z;
                        }
                    }
                }
                return l;
            }
        }

        public dbKG_ReiseZeile letzteHRoderT
        {
            get
            {
                dbKG_ReiseZeile l = null;
                foreach (dbKG_ReiseZeile z in Zeilen)
                {
                    if ((z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt) | (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt) | (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung || z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel))
                    //defect 5329 begin: pruefen der reihenfolge der zeilen, wir wollen ja die letzte dieser zeilen....
                    //l = z;
                    {
                        if (l != null)
                        {
                            // >= anstatt > weil wir suchen das letzte HRoderT
                            if ((z.Ab.Ticks >= l.Ab.Ticks) && (z.ReiseTag >= l.ReiseTag))
                            {
                                l = z;
                            }
                        }
                        else
                        {
                            l = z;
                        }

                    }
                    //defect 5329 ende
                }
                return l;
            }
        }
        public dbKG_ReiseZeile ersteHSoderT //ersteHoderS -> ersteHSoderT
        {
            get
            {
                dbKG_ReiseZeile l = null;
                foreach (dbKG_ReiseZeile z in Zeilen)
                {
                    //Defect #5974 Die Reise kann auch mit der TA beginnen
                    if (z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt || z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel || z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                        return z;
                }
                return l;
            }
        }

        public void SortZeiten()
        {
            dbKG_ReiseZeileSort Sorter = new dbKG_ReiseZeileSort(dbKG_ReiseZeileSort.SortByEnum.Ab);
            Zeilen.Sort(Sorter);
        }
        public bool ZeitenValid()
        {
            int i = 0;
            foreach (dbKG_ReiseZeile z in Zeilen)
            {
                if (i > 0)
                {
                    if (!dbKG_ReiseZeilenKZ.ZeilenFolgeValid((Zeilen[i] as dbKG_ReiseZeile), z))
                        return false;
                }
                i++;
            }
            return true;
        }
        #region Helper Properties for Creation and Computing

        public dbArbZeit ErsteAZ = null;
        public dbArbZeit LetzteAZ = null;
        public dbArbZeit NachLetzteAZ = null;
        public dbKG_ReiseHeimfahrtTyp Heimfahrt;
        public DateTime Von; ///Ankunft am Aufenthaltsort 
        public DateTime Bis; ///R�ckfahrt vom Aufenthaltsort zum Ziel
        public int Aufenthaltsort; //BAUID
        public string IntfID = "0";

        #endregion
        #region public properties

        public int EBID
        {
            get
            {
                return (int)Kopf.Params.ABRNR.Value;
            }
            set
            {
                Kopf.Params.ABRNR.Value = value;
            }
        }

        #endregion

    }

    public class dbKG_ReiseZeile
    {
        public bool flg_teilabr_del = true;  //defect 4972: default kann man t-zeilen nicht l�schen / nur l�schbar bei t-zeilen um den urlaub/za
        public dbKG_Reise Reise;
        public DateTime ReiseTag
        {
            get
            {
                return Convert.ToDateTime(Zeile.Params.DAT.Value);
            }
            set
            {
                Zeile.Params.DAT.Value = Convert.ToDateTime(value.ToShortDateString());
            }
        }
        private dbRaZeile lZeile = null;
        public string AuftragNr = "";
        public dbRaZeile Zeile
        {
            get //creates new one if null
            {
                if (lZeile == null)
                    lZeile = new dbRaZeile(Reise.Kopf, this);
                return lZeile;
            }
            set //creates new one if null
            {
                lZeile = value;
                if (lZeile == null)
                    lZeile = new dbRaZeile(Reise.Kopf, this);
            }
        }
        public dbKG_ReiseZeile(dbKG_Reise reise, dbRaZeile zeile)
        {
            Reise = reise;
            Zeile = zeile;
        }
        public DateTime Ab
        {
            get
            {
                //DateTime dn = Convert.ToDateTime("00:00:00");
                //if (Zeile.Params.AB.Value != DBNull.Value) dn = Convert.ToDateTime(Zeile.Params.AB.Value);
                //DateTime d = Convert.ToDateTime(Convert.ToDateTime(Zeile.Params.DAT.Value).ToShortDateString() + " " + Convert.ToDateTime(dn).ToShortTimeString());
                if (Zeile.Params.AB.Value != DBNull.Value)
                    return Convert.ToDateTime(Zeile.Params.AB.Value);
                else
                    return ParamVal.Date0;
            }
            set
            {
                Zeile.Params.AB.Value = value;
            }
        }
        public DateTime An
        {
            get
            {
                //DateTime dn = Convert.ToDateTime("00:00:00");
                //if (Zeile.Params.AN.Value != DBNull.Value) dn = Convert.ToDateTime(Zeile.Params.AN.Value);
                //DateTime d = Convert.ToDateTime(Convert.ToDateTime(Zeile.Params.DAT.Value).ToShortDateString() + " " + Convert.ToDateTime(dn).ToShortTimeString());
                if (Zeile.Params.AN.Value != DBNull.Value)
                    return Convert.ToDateTime(Zeile.Params.AN.Value);
                else
                    return ParamVal.Date0;
            }
            set
            {
                Zeile.Params.AN.Value = value;
            }
        }
        public dbKG_ReiseZeilenTyp Typ
        {
            get
            {
                return dbKG_ReiseZeilenKZ.GetTyp(Zeile.Params.ZEILENKZ.Value.ToString());
            }
            set
            {
                Zeile.Params.ZEILENKZ.Value = dbKG_ReiseZeilenKZ.GetKZ(value);
            }
        }
        private string[] BSKZ = new string[] { "B", "S" };
        public int Von
        {
            get
            {
                if (Zeile.Params.ABID.Value.ToString().Length < 2) Zeile.Params.ABID.Value = "S0";
                return Convert.ToInt32(Zeile.Params.ABID.Value.ToString().Substring(1));
            }
            set
            {
                if (Zeile.Params.ABID.Value.ToString().Length < 2) Zeile.Params.ABID.Value = "S0";
                Zeile.Params.ABID.Value = BSKZ[(int)VonTyp] + value.ToString();
            }
        }
        public dbKG_ReiseZielTyp VonTyp
        {
            get
            {
                if (Zeile.Params.ABID.Value.ToString().Length < 2) Zeile.Params.ABID.Value = "S0";
                if (Zeile.Params.ABID.Value.ToString().IndexOf("B") >= 0) return dbKG_ReiseZielTyp.Baustelle;
                return dbKG_ReiseZielTyp.Standort;
            }
            set
            {
                if (Zeile.Params.ABID.Value.ToString().Length < 2) Zeile.Params.ABID.Value = "S0";
                Zeile.Params.ABID.Value = BSKZ[(int)value] + Von.ToString();
            }
        }
        public int Nach
        {
            get
            {

                if (Zeile.Params.ANID.Value.ToString().Length < 2) Zeile.Params.ANID.Value = "S0";
                return Convert.ToInt32(Zeile.Params.ANID.Value.ToString().Substring(1));
            }
            set
            {
                if (Zeile.Params.ANID.Value.ToString().Length < 2) Zeile.Params.ANID.Value = "S0";
                Zeile.Params.ANID.Value = BSKZ[(int)NachTyp] + value.ToString();
            }
        }
        public dbKG_ReiseZielTyp NachTyp
        {
            get
            {
                if (Zeile.Params.ANID.Value.ToString().Length < 2) Zeile.Params.ANID.Value = "S0";
                if (Zeile.Params.ANID.Value.ToString().IndexOf("B") >= 0) return dbKG_ReiseZielTyp.Baustelle;
                return dbKG_ReiseZielTyp.Standort;
            }
            set
            {
                if (Zeile.Params.ANID.Value.ToString().Length < 2) Zeile.Params.ANID.Value = "S0";
                Zeile.Params.ANID.Value = BSKZ[(int)value] + Nach.ToString();
            }
        }
    }

    public class dbKG_ReiseZeileSort : IComparer
    {
        public enum SortByEnum { Ab, An };
        private SortByEnum SortBy = SortByEnum.Ab;
        public dbKG_ReiseZeileSort(SortByEnum SortByWhat)
        {
            SortBy = SortByWhat;
        }
        int IComparer.Compare(object o1, object o2)
        {
            dbKG_ReiseZeile a1 = (dbKG_ReiseZeile)o1;
            dbKG_ReiseZeile a2 = (dbKG_ReiseZeile)o2;

            if (SortBy == SortByEnum.Ab)
            {
                // Beginn #5376 - Sortierung der Reisen und Standortwechsel falsch
                if (a1.Ab != a2.Ab)
                    return a1.Ab.CompareTo(a2.Ab);

                if (a1.An != a2.An)
                    return a1.An.CompareTo(a2.An);
                // Ende #5376

                // Begin #5376 - Sortierung erweitern
                try
                {
                    // compare AuftragNr
                    if (a1.AuftragNr != a2.AuftragNr)
                        return a1.AuftragNr.CompareTo(a2.AuftragNr);

                    // compare Typ
                    if (a1.Typ != a2.Typ)
                        return a1.Typ.CompareTo(a2.Typ);

                    // compare VERKEHRSMITTEL
                    if (a1.Zeile.Params.VERKEHRSMITTEL.Value.ToString() !=
                        a2.Zeile.Params.VERKEHRSMITTEL.Value.ToString())
                        return a1.Zeile.Params.VERKEHRSMITTEL.Value.ToString().CompareTo(
                            a2.Zeile.Params.VERKEHRSMITTEL.Value.ToString());

                    // compare BEREITST
                    if (a1.Zeile.Params.BEREITST.Value.ToString() !=
                        a2.Zeile.Params.BEREITST.Value.ToString())
                        return a1.Zeile.Params.BEREITST.Value.ToString().CompareTo(
                            a2.Zeile.Params.BEREITST.Value.ToString());

                    // compare GEFKM
                    if (a1.Zeile.Params.GEFKM.Value.ToString() !=
                        a2.Zeile.Params.GEFKM.Value.ToString())
                        return a1.Zeile.Params.GEFKM.Value.ToString().CompareTo(
                            a2.Zeile.Params.GEFKM.Value.ToString());

                    // compare MITFAHRER
                    if (a1.Zeile.Params.MITFAHRER.Value.ToString() !=
                        a2.Zeile.Params.MITFAHRER.Value.ToString())
                        return a1.Zeile.Params.MITFAHRER.Value.ToString().CompareTo(
                            a2.Zeile.Params.MITFAHRER.Value.ToString());

                    // compare SCHWERGP
                    if (a1.Zeile.Params.SCHWERGP.Value.ToString() !=
                        a2.Zeile.Params.SCHWERGP.Value.ToString())
                        return a1.Zeile.Params.SCHWERGP.Value.ToString().CompareTo(
                            a2.Zeile.Params.SCHWERGP.Value.ToString());
                }
                catch
                {
                    // do nothing
                }
                // default 0 -> inhalt der Zeilen ist gleich
                return 0;
                // Ende #5376
            }
            else
                return a1.An.CompareTo(a2.An);
        }
    }
}
