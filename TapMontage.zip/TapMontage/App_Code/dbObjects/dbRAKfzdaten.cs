//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbRAKfzdaten.cs
//
// Description  : DB-Zugriffe f�r Standortwechsel
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0027 ---------------------------------------------------
//
// Date         : 14. Mai 2007
// Author       : GN
// Defect#      : 4931
//                Neues Feld 'Mitfahrt'
//
//
// Defect#      : 4932
//                Neues Feld 'Schwergep�ck'
//
// ----------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
/// <summary>
/// Summary description for dbRAKfzdaten
/// </summary>
namespace TapMontage.dbObjects
{
    public class dbRAKfzdatenParams
    {
        public SqlParameter RAKID = new SqlParameter("@RAKID", Int32.MinValue);
        public SqlParameter EBID = new SqlParameter("@EBID", Int32.MinValue);
        public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
        public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", Int32.MinValue);
        public SqlParameter RDATUM = new SqlParameter("@RDATUM", ParamVal.Date0);
        public SqlParameter RRICHT = new SqlParameter("@RRICHT", (string)"");
        public SqlParameter KFZ = new SqlParameter("@KFZ", (string)"");
        public SqlParameter KFZKZ = new SqlParameter("@KFZKZ", (string)"");
        public SqlParameter ABKM = new SqlParameter("@ABKM", int.MinValue);
        public SqlParameter GEFKM = new SqlParameter("@GEFKM", int.MinValue);
        public SqlParameter MITFAHRER = new SqlParameter("@MITFAHRER", int.MinValue); //CR 4931 14.5.2007 GN Neuer Parameter Mitfahrer
        public SqlParameter SCHWERGP = new SqlParameter("@SCHWERGP", (string)""); //CR 4932 14.5.2007 GN Neuer Parameter Schwergep�ck
        public ArrayList List = new ArrayList();

        public dbRAKfzdatenParams()
        {
            List.Add(RAKID);
            List.Add(EBID);
            List.Add(MANDANT);
            List.Add(PERSKEY);
            List.Add(RDATUM);
            List.Add(RRICHT);
            List.Add(KFZ);
            List.Add(KFZKZ);
            List.Add(ABKM);
            List.Add(GEFKM);
            List.Add(MITFAHRER); //CR 4931 14.5.2007 GN Neuer Parameter
            List.Add(SCHWERGP); //CR 4932 14.5.2007 GN Neuer Parameter
            List = ParamVal.SetDefaultValues(List);
        }
      
    }
    public class dbPersKfzParams
    {
        public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", Int32.MinValue);
        public SqlParameter KFZ = new SqlParameter("@KFZ", (string)"");
        public SqlParameter KFZKZ = new SqlParameter("@KFZKZ", (string)"");
        public ArrayList PersKfzL = new ArrayList();

        public dbPersKfzParams()
        {
            PersKfzL.Add(PERSKEY);
            PersKfzL.Add(KFZ);
            PersKfzL.Add(KFZKZ);
            PersKfzL = ParamVal.SetDefaultValues(PersKfzL);
        }

    }
    public class dbRAKfzdaten
    {
        //Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
        public string vonPLZ_ORT = "";
        public string nachPLZ_ORT = "";
        public DateTime Ab = ParamVal.Date0;
        public DateTime An = ParamVal.Date0;
        public int IntfID = 0;
        public string EingesetzterKfzTyp = "";
        public string EingesetzterKfzPolKennz = "";
        public dbRAKfzdatenParams Params = new dbRAKfzdatenParams();
        public dbPersKfzParams KfzParams = new dbPersKfzParams();

        public dbMontBer MontBer;

        public dbRAKfzdaten(dbMontBer mber)
        {
            MontBer = mber;
            if (MontBer == null) MontBer = new dbMontBer(null, null);
        
        }

        /// <summary>
        /// Private Properties
        /// </summary>
        public bool AllowUpdate = false;
        public bool Deleted = false;

        public bool Insert()
        {
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    Params.RAKID.Value = SelectMaxId();
                    Params.EBID.Value = MontBer.Params.EBID.Value;
                    Params.MANDANT.Value = MontBer.Params.MANDANT.Value;
                    Params.PERSKEY.Value = MontBer.Params.PERSKEY.Value;
                    ParamVal.InsertValid(Params.List);
                    using (SqlCommand cmd = new SqlCommand("sp_TM_RAKfzInsert", cnx)) // Defect 5436, using eingef�hrt
                    {
                      cmd.CommandType = CommandType.StoredProcedure;
                      foreach (SqlParameter s in Params.List)
                        cmd.Parameters.Add(s);
                      int nRecs = cmd.ExecuteNonQuery();
                      foreach (SqlParameter s in Params.List)
                        cmd.Parameters.Remove(s);
                      AllowUpdate = (nRecs > 0);
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return AllowUpdate;
        }

        public int SelectMaxId()
        {
            int iRes = 0;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("select MAX(RAKID) as NXTRAKID from TPM_RAKfzdaten " + Config.Rowlock, cnx)) // Defect 5436
                    {
                      using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
                      {
                        while (rd.Read())
                        {
                          if (!rd.IsDBNull(0))
                            iRes = (int)rd.GetValue(0);
                          else
                            iRes = 0;
                        }
                      }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            ++iRes;
            return iRes;
        }

      public ArrayList SelectMyPersKfz()
      { 
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    string sqltxt = "SELECT KFZ, KFZKZ FROM BEARBTECH " + Config.Nolock + " WHERE PERSKEY = @PERSKEY";
                    using (SqlCommand cmd = new SqlCommand(sqltxt.ToString(), cnx)) // Defect 5436
                    {
                      KfzParams.PERSKEY.Value = MontBer.Params.PERSKEY.Value;
                      ParamVal.InsertValid(KfzParams.PersKfzL);
                      cmd.Parameters.Add(KfzParams.PERSKEY);
                      using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
                      {
                        cmd.Parameters.Remove(KfzParams.PERSKEY);
                        while (rd.Read())
                        {
                          dbRAKfzdaten ra = new dbRAKfzdaten(MontBer);
                          ParamVal.SetDefaultValues(ra.Params.List);
                          ra.KfzParams.KFZ.Value = rd.GetValue(0);
                          ra.KfzParams.KFZKZ.Value = rd.GetValue(1);
                          al.Add(ra);
                        }
                      }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return al;
      }
        public ArrayList SelectAllMyKfzDaten()
        {
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    //CR 4931,4932 SQLSkript angepasst
                    //GN 14.5.2007
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    string sqltxt = "Select RAKID, EBID, MANDANT, PERSKEY, RDATUM, RRICHT, KFZ, KFZKZ, ABKM, GEFKM, SCHWERGP, MITFAHRER " +
                                    "FROM TPM_RAKfzdaten " + Config.Nolock + " where EBID = @EBID and PERSKEY = @PERSKEY and MANDANT = @MANDANT";
                    using (SqlCommand cmd = new SqlCommand(sqltxt.ToString(), cnx)) // Defect 5436
                    {
                      cmd.Parameters.Add(MontBer.Params.EBID);
                      cmd.Parameters.Add(MontBer.Params.PERSKEY);
                      cmd.Parameters.Add(MontBer.Params.MANDANT);
                      ParamVal.InsertValid(Params.List);

                      using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
                      {
                        cmd.Parameters.Remove(MontBer.Params.EBID);
                        cmd.Parameters.Remove(MontBer.Params.PERSKEY);
                        cmd.Parameters.Remove(MontBer.Params.MANDANT);
                        while (rd.Read())
                        {
                          dbRAKfzdaten ra = new dbRAKfzdaten(MontBer);
                          ParamVal.SetDefaultValues(ra.Params.List);
                          ra.Params.RAKID.Value = rd.GetValue(0);
                          ra.Params.EBID.Value = MontBer.Params.EBID.Value;
                          ra.Params.MANDANT.Value = rd.GetValue(2);
                          ra.Params.PERSKEY.Value = rd.GetValue(3);
                          ra.Params.RDATUM.Value = rd.GetValue(4);
                          ra.Params.RRICHT.Value = rd.GetValue(5);
                          ra.Params.KFZ.Value = rd.GetValue(6);
                          ra.Params.KFZKZ.Value = rd.GetValue(7);
                          ra.Params.ABKM.Value = rd.GetValue(8);
                          ra.Params.GEFKM.Value = rd.GetValue(9);

                          //CR 4931,4932 Parameter werden ausgelesen
                          //GN 14.5.2007
                          ra.Params.SCHWERGP.Value = rd.GetValue(10);
                          ra.Params.MITFAHRER.Value = rd.GetValue(11);
                          // Ortsangabe Pflichtfeld in SAP TM - Zwischenziele
                          ra.nachPLZ_ORT = ra.vonPLZ_ORT = MontBer.Projekt.Baustelle.Params.PLZ.Value.ToString() + " " + MontBer.Projekt.Baustelle.Params.ORT.Value.ToString();
                          ra.AllowUpdate = true;
                          ra.Deleted = false;
                          al.Add(ra);
                        }
                      }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return al;
        }

        public bool SelectEinsKfz(string ebid, string perskey, string mandant, string datum)
        {
            bool found = false;
            SqlParameter EBID = new SqlParameter("@EBID", Int32.MinValue);
            SqlParameter PERSKEY = new SqlParameter("@PERSKEY", Int32.MinValue);
            SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
            SqlParameter RDATUM  = new SqlParameter("@RDATUM", ParamVal.Date0);

            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {

                    EBID.Value = Int32.Parse(ebid);
                    PERSKEY.Value = Int32.Parse(perskey);
                    MANDANT.Value = mandant;
                    RDATUM.Value = Convert.ToDateTime(datum);
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    string sqltxt = "SELECT KFZ, KFZKZ FROM TPM_RAKfzdaten " + Config.Nolock +
                                    "WHERE EBID = @EBID AND PERSKEY = @PERSKEY AND " +
                                    "MANDANT = @MANDANT AND datepart(month, RDATUM) = datepart(month, @RDATUM) AND " +
                                    "datepart(year, RDATUM) = datepart(year, @RDATUM) "+
                                    "ORDER BY RAKID DESC";
                    using (SqlCommand cmd = new SqlCommand(sqltxt.ToString(), cnx)) // Defect 5436
                    {
                      cmd.Parameters.Add(EBID);
                      cmd.Parameters.Add(PERSKEY);
                      cmd.Parameters.Add(MANDANT);
                      cmd.Parameters.Add(RDATUM);

                      using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
                      {
                        cmd.Parameters.Remove(EBID);
                        cmd.Parameters.Remove(PERSKEY);
                        cmd.Parameters.Remove(MANDANT);
                        cmd.Parameters.Remove(RDATUM);
                        while ((found == false) && rd.Read())
                        {
                          EingesetzterKfzTyp = rd.GetValue(0).ToString().Trim();
                          EingesetzterKfzPolKennz = rd.GetValue(1).ToString().Trim();
                          found = ((EingesetzterKfzTyp != "") || (EingesetzterKfzTyp != null) &&
                                   (EingesetzterKfzPolKennz != "") || (EingesetzterKfzPolKennz != null));
                          if (found == true) rd.Close();
                        }
                      }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return found;
        }

        public bool Update()
        {
            if (!AllowUpdate) return Insert();
            else
            {
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        using (SqlCommand cmd = new SqlCommand("sp_TM_RAKfzUpdate", cnx)) // Defect 5436
                        {
                          cmd.CommandType = CommandType.StoredProcedure;
                          foreach (SqlParameter s in Params.List)
                            cmd.Parameters.Add(s);
                          int nRecs = cmd.ExecuteNonQuery();
                          foreach (SqlParameter s in Params.List)
                            cmd.Parameters.Remove(s);
                          AllowUpdate = (nRecs > 0);
                          if (!AllowUpdate)
                          {
                            Exception ex = new Exception("dbRAKfzdaten::Update: Update failed!");
                            throw ex;
                          }
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            }
            return AllowUpdate;
        }

        public bool Delete()
        {
            ParamVal.InsertValid(Params.List);
            if (AllowUpdate)
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        // Defect 5725, Config.Rowlock eingef�hrt
                        using (SqlCommand cmd = new SqlCommand("Delete from TPM_RAKfzdaten " + Config.Rowlock + " where RAKID = @RAKID", cnx)) // Defect 5436
                        {
                          cmd.Parameters.Add(Params.RAKID);
                          int nRecs = cmd.ExecuteNonQuery();
                          cmd.Parameters.Remove(Params.RAKID);
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            return AllowUpdate;
        }

        public void Save()
        {
            if (AllowUpdate)
            {
                if (!Deleted) Update();
                else Delete();
            }
            else
            {
                if (!Deleted) Insert();
                //else do_nothing();
            }
        }

        public ArrayList SelectAll()
        {
            ArrayList al = new ArrayList();
            return al;
        }

    }
}
