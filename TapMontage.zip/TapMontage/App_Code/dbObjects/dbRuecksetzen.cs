﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbRuecksetzen.cs
//
// Description  : Einsatzbericht Zurücksetzen
//
//=============== V1.0.0049 ===============================================
//
// Date         : 10.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500062
//                Umstellung TAP Montage auf 8-stellige Personalnummer
//
// Date         : 08.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAF 530023 
//                BERMON hinzugefügt
//
//=============== V1.0.0047 ===============================================
//
// Date         : 11.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-42
//                Rücksetzen EB durch Genehmiger von 40 auf 30
//
//=============== V1.0.0044 ===============================================
//
// Date         : 30.Juli 2008
// Author       : Joldic Dzevad
// Defect#      : 6178/TAPM-19
//                Rücksetzen EB durch Erfasser/Genehmiger von 30 auf 10
//
// ===============================================================================
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections;
using TapMontage.dbObjects;
using System.Net;
using System.IO;

/// <summary>
/// Zusammenfassungsbeschreibung für dbRuecksetzen
/// </summary>
public class dbRuecksetzen
{
    //TAPM-42 mögliche Rückgabewerten
    public enum dbRuecksetzStatus
    {
        ok,
        AZinSAP,
        AZkeine,
        RAinSAP,
        AZMaktiv,
        ErrorByCheck
    }
    private int ebId = 0;
    private ArrayList barAuslagen = new ArrayList(); 
	public dbRuecksetzen(int ebid, ArrayList barauslagen)
	{
        ebId = ebid;
        barAuslagen = barauslagen;
	}
    public dbRuecksetzen() //TAPM-42 default Konstruktor
    {

    }
    //TAPM-42 - hiermit können alle 3 Prüfungen durchgefürt - wird aber nicht verwendet
    public int pruefeStatus(string persnr, int perskey, DateTime bermon, Int16 sozstellung)
    {
        string fm = "";
        if (pruefeAZ(perskey, bermon) != dbRuecksetzStatus.ok) return 2;
        if (pruefeReisen(perskey, bermon) != dbRuecksetzStatus.ok) return 3;
        if (sozstellung != 6 && sozstellung != 7)
        {
            if (!pruefeAZM(persnr, bermon, ref fm)) return 1;
        }
        return 0;
    }
    //TAPM-42 - prüfen ob Reise nach SAP übertragen ist
    private dbRuecksetzStatus pruefeReisen(int perskey, DateTime bermon)
    {
        int anzahlRA = 0;
        int anzahlRastat80 = 0;
        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT dbo.RAKOPF.RAID, dbo.RAKOPF.RASTAT FROM dbo.RAKOPF " + Config.Nolock +
                                                       //" INNER JOIN dbo.EINSBER " + Config.Nolock + " ON dbo.RAKOPF.ABRNR = dbo.EINSBER.EBID " +
                                                       " WHERE dbo.RAKOPF.PERSKEY = @PERSKEY AND dbo.RAKOPF.BERMON = @BERMON", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", perskey));
                    cmd.Parameters.Add(new SqlParameter("@BERMON", bermon));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            anzahlRA++;
                            if (rd.GetInt16(1) == 80)
                                anzahlRastat80++;
                        }
                    }
                }
            }
            catch
            {
                anzahlRA = -1;
            }
            finally { cnx.Close(); }
        }
        if (anzahlRA == -1) return dbRuecksetzStatus.ErrorByCheck;
        if (anzahlRA == 0) return dbRuecksetzStatus.ok;
        if (anzahlRastat80 != 0) return dbRuecksetzStatus.RAinSAP;
        return dbRuecksetzStatus.ok;
    }

    //TAPM-42 prüfen ob Arbeitsstunden schon nach SAP übertragen sind
    //die PROD_SAP Schnittstelle setzt DATUGORK Datum wenn Stunden übertragen sind
    public dbRuecksetzStatus pruefeAZ(int perskey, DateTime bermon)
    {
        int anzahlAZ = 0;
        int anzahlDatugork = 0;
        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT dbo.ARBZEIT.AZID, dbo.ARBZEIT.DATUGORK FROM dbo.ARBZEIT " + Config.Nolock + 
                                                       " INNER JOIN dbo.EINSBER " + Config.Nolock + " ON dbo.ARBZEIT.EBID = dbo.EINSBER.EBID " +
                                                       " WHERE dbo.EINSBER.PERSKEY = @PERSKEY AND dbo.EINSBER.BERMON = @BERMON AND dbo.EINSBER.EBSTAT = 40", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", perskey));
                    cmd.Parameters.Add(new SqlParameter("@BERMON", bermon));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            anzahlAZ++;
                            if (!rd.IsDBNull(1))
                                anzahlDatugork++;
                        }
                    }
                }
            }
            catch
            {
                anzahlAZ = -1;
            }
            finally { cnx.Close(); }
        }
        if (anzahlAZ == -1) return dbRuecksetzStatus.ErrorByCheck;
        if (anzahlAZ == 0) return dbRuecksetzStatus.AZkeine;
        if (anzahlDatugork != 0) return dbRuecksetzStatus.AZinSAP;
        return dbRuecksetzStatus.ok;
    }
    //TAPM-42 Prüfen ob AZM freigeschaltet ist
    //wir schicken RM (ResetMonat) für jeden MA
    //falls AZM Frei ist, dann bekommen wir positiven response
    //falls nicht ... wird error code 513 zurückgeliefert
    public bool pruefeAZM(string persnr, DateTime bermon, ref string fm)
    {
        string Response = "";
        string Firmenkennung = "";
        if( persnr.Length < 7 ) return false; //BAN 500062 FKZ + Persnr darf nicht weniger als 7 Zeichen sein
        string firmenkz = persnr.Substring(0, 2);
        AZMIVZDESLib.Crypt crypt = new AZMIVZDESLib.Crypt();
        using (SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("select Firmapers from x_con_fkz " + Config.Nolock + " where firmenkz= @FIRMAKZ", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@FIRMAKZ", firmenkz));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            Firmenkennung = (string)rd.GetValue(0); //erste parameter
                        }
                    }
                }
            }
            catch
            {
            }
            finally { cnx.Close(); }
        }
        //Request RM an AZM
        /*
        <Firmenkennung>;<PersNo>;<Password>;<Jahr>;<Monat>;<BefehlsKZ>;
        */
        try
        {
            string cRequest = Firmenkennung + ";" + persnr.Substring(2) + ";" + //BAN 500062 nur FKZ abschneiden
                ConfigurationManager.AppSettings["autoivz_password"].ToString() + ";" +
                bermon.Year.ToString() + ";" + bermon.Month.ToString() + ";" + "RM;";
            object oRequest = cRequest;
            Random r = new Random(4711);
            int key1 = r.Next(0, 32000);
            int key2 = r.Next(0, 32000);
            int Word1 = 0;
            int Word2 = 0;
            int Length = crypt.getCodedLength(ref oRequest) / 4;
            string codedRequest = key1.ToString() + "," + key2.ToString() + "," + Length.ToString();
            while (cRequest.Length > 0)
            {
                string tmp8 = "";
                if (cRequest.Length >= 8)
                {
                    tmp8 = cRequest.Substring(0, 8);
                    cRequest = cRequest.Substring(8);
                }
                else
                {
                    tmp8 = cRequest;
                    while (tmp8.Length < 8) tmp8 += " ";
                    cRequest = "";
                }
                object otmp8 = tmp8;
                crypt.code2(ref otmp8, key1, key2, out Word1, out Word2);
                codedRequest += "," + Word1.ToString() + "," + Word2.ToString();
            }
            string codedResponse = "";
            try
            {
                WebRequest request = WebRequest.Create(ConfigurationManager.AppSettings["autoivz_url"].ToString() + codedRequest);
                WebResponse response = request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                codedResponse = reader.ReadToEnd();
                reader.Close();
                response.Close();
            }
            catch
            {
                fm = "Fehler in Kommunikation mit AZM";
                return false;
            }
            if (codedResponse.Length > 0)
            {
                try
                {
                    key1 = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                    codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                    key2 = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                    codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                    Length = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                    codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                    int Pairs = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                    //codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                    int testPairs = (codedResponse.Length - codedResponse.Replace(",", "").Length + 1) / 2;
                    if (Pairs != testPairs)
                    {
                        //lies trotzdem weiter
                    }
                    codedResponse += ",";
                    while (codedResponse.Length > 0)
                    {
                        Word1 = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                        codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                        if (codedResponse.IndexOf(",") > 0)
                        {
                            Word2 = Convert.ToInt32(codedResponse.Substring(0, codedResponse.IndexOf(",")));
                            codedResponse = codedResponse.Substring(codedResponse.IndexOf(",") + 1);
                        }
                        Response += crypt.decode2(Word1, Word2, key1, key2);
                    }
                }
                catch
                {
                    fm = "Fehler in Kommunikation mit AZM";
                    return false;
                }
            }
        }
        catch
        {
            fm = "Fehler in Kommunikation mit AZM";
            return false;
        }
        if (Response.IndexOf(";") > 0)
        {
            /*
             <Firmenkennung>;<PersNo>;<Jahr>;<Monat>;<Fehlerkennung>; <Fehlertext>;
             */
            // Firmen Kennung
            Response = Response.Substring(Response.IndexOf(";") + 1);
            Response = Response.Substring(Response.IndexOf(";") + 1);
            Response = Response.Substring(Response.IndexOf(";") + 1);
            Response = Response.Substring(Response.IndexOf(";") + 1);
            string befehlskz = Response.Substring(0, Response.IndexOf(";"));
            Response = Response.Substring(Response.IndexOf(";") + 1);

            if (befehlskz == dbKG_AZM.AZMFehlerkennung)
            {
                if (!Response.Contains("Error 513"))
                    fm = Response.Substring(0, Response.IndexOf(","));
                return false;
            }
        }
        return true;
    }
    //TAPM-42 Rücksetzung durchführen
    //Bei Rücksetzung werden 4 TAbellen aktualisiert, Einsber, Arbzeit, Rakopf und Razeile
    //aus dem Grund soll verwenden wir SqlTransaction
    public bool genemigungRuecksetzen(int perskey, DateTime bermon, string mandant, bool UseNewHRInterface)
    {
        bool ret = false;
        SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString);
        cnx.Open();
        SqlTransaction tx = cnx.BeginTransaction();
        try
        {
            //TAPM-42 Update EB
            using (SqlCommand cmd = new SqlCommand("UPDATE EINSBER SET EBSTAT = 30, PDFSTATUS = null " + 
                "WHERE PERSKEY = @PERSKEY AND BERMON = @BERMON and EBSTAT=40", cnx, tx))
            {
                cmd.Parameters.Add(new SqlParameter("@PERSKEY", perskey));
                cmd.Parameters.Add(new SqlParameter("@BERMON", bermon));
                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }
            //TAPM-42 delete RAZEILE
            //using (SqlCommand cmd = new SqlCommand("DELETE FROM RAZEILE WHERE RAID IN (SELECT raid FROM RAKOPF WHERE ABRNR IN " +
            //    "(SELECT EBID FROM EINSBER " + Config.Nolock + " WHERE PERSKEY = @PERSKEY AND BERMON = @BERMON))", cnx, tx))
            if (UseNewHRInterface)
            {
                dbSapReise sapReisen = new dbSapReise(perskey, bermon, mandant);
                if (!sapReisen.DeleteAllTrips())
                {
                    Exception ex = new Exception("Fehler beim löschen der Reisen, PK = " + perskey.ToString() + 
                        " ,BERMON = " + bermon.ToShortDateString() + " ,MANDANT = " + mandant);
                    throw ex;
                }
            }
            else
            {
                using (SqlCommand cmd = new SqlCommand("DELETE FROM RAZEILE WHERE RAID IN (SELECT raid FROM RAKOPF WHERE " +
                "PERSKEY = @PERSKEY AND BERMON = @BERMON)", cnx, tx))
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", perskey));
                    cmd.Parameters.Add(new SqlParameter("@BERMON", bermon));
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
                //TAPM-42 delete RAKOPF
                using (SqlCommand cmd = new SqlCommand("DELETE FROM RAKOPF WHERE PERSKEY = @PERSKEY AND BERMON = @BERMON", cnx, tx))
                {
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", perskey));
                    cmd.Parameters.Add(new SqlParameter("@BERMON", bermon));
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                }
            }
            //TAPM-42 delete R & W aus Arbzeit
            //using (SqlCommand cmd = new SqlCommand("DELETE FROM ARBZEIT WHERE PERSKEY = @PERSKEY " +
            //    "AND KZAZ in ('R', 'W') AND BEGINN >= @BERMON and ENDE < @NEXTBERMON", cnx, tx))
            using (SqlCommand cmd = new SqlCommand("DELETE FROM ARBZEIT WHERE KZAZ in ('R', 'W') AND " +
                "EBID IN (SELECT EBID FROM EINSBER " + Config.Nolock + " WHERE PERSKEY = @PERSKEY AND BERMON = @BERMON)", cnx, tx))
            {
                cmd.Parameters.Add(new SqlParameter("@PERSKEY", perskey));
                cmd.Parameters.Add(new SqlParameter("@BERMON", bermon));
                // cmd.Parameters.Add(new SqlParameter("@NEXTBERMON", bermon.AddMonths(1)));
                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }
            //alles OK
            tx.Commit();
            ret = true;
        }
        catch
        {
            tx.Rollback();
        }
        finally { cnx.Close(); }
        return ret;
    }
    //TAPM-42 Ende
    public bool ruecksetzen()
    {
        bool ret = false;
        if (ebId <= 0)
            return ret;
        SqlConnection cnx = new SqlConnection(CurrentEnvironment.DbConnectionString);
        cnx.Open();
        SqlTransaction tx = cnx.BeginTransaction();
        try
        {
            // delete from RAAUSLAGE
            if (barAuslagen != null)
            {
                foreach (dbBarauslagen ba in barAuslagen)
                {
                    using (SqlCommand cmd = new SqlCommand("delete RAAUSLAGE where ebid = @EBID and " +
                        " RAKZ = @TYP and " + // Typ
                        " BETRAG = @CENTS and " + //CENT
                        " ANZAHL = @ANZ", cnx, tx))
                    {
                        SqlParameter sql = new SqlParameter("@EBID", ebId);
                        cmd.Parameters.Add(sql);
                        cmd.Parameters.Add(ba.Params.TYP);
                        cmd.Parameters.Add(ba.Params.CENTS);
                        cmd.Parameters.Add(ba.Params.ANZ);
                        cmd.ExecuteNonQuery();
                        cmd.Parameters.Remove(sql);
                        cmd.Parameters.Remove(ba.Params.TYP);
                        cmd.Parameters.Remove(ba.Params.CENTS);
                        cmd.Parameters.Remove(ba.Params.ANZ);
                    }
                }
            }
            //jetzt nur noch update von EINSBER
            using (SqlCommand cmd = new SqlCommand("update einsber set ebstat = 10 where ebid = @EBID", cnx, tx))
            {
                SqlParameter sql = new SqlParameter("@EBID", ebId);
                cmd.Parameters.Add(sql);
                cmd.ExecuteNonQuery();
                cmd.Parameters.Remove(sql);
            }
            //alles gut gelaufen
            tx.Commit();
            ret = true;
        }
        catch
        {
            tx.Rollback();
        }
        finally { cnx.Close(); }
        return ret;
    }
}
