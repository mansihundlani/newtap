//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbProjekt.cs
//
// Description  : DB-Zugriffe f�r Projekte
//
//=============== V1.2.0015 ===============================================
//
// Date         : 04.September 2013
// Author       : Joldic Dzevad
// Defect#      : 
//                SAP Connector ausgelagert in eigenes Projekt 
//
//=============== 1.0.0050 ================================================
//
// Date         : 15.Januar 2010
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
// Defect#      : BAN 500091
//                Lohnartenumstellung am TAP, neue LA ab 01.01.2010
//
//=============== V1.0.0047 ===============================================
//
// Date         : 13.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-44
//                Erweiterung der Pr�fung auf kontierbares PS-Element mit 
//                Erlaubnis zur Kostenkontierung "KONT"
// Defect#      : TAPM-45
//                B&I CarveOut
//
//=============== V1.0.0038 ===============================================
//
// Date         : 13.M�rz 2008
// Author       : Joldic Dzevad
// Defect#      : 5879
//                dbProjekt Konstruktor erweitert, der objekt kann man jetzt
//                mit dem Projekt ID erzeigen
//
// Date         : 28.Februar 2008
// Author       : Joldic Dzevad
// Defect#      : 5672
//                dbProjektAZModell Konstruktor erweitert, nun kann man 
//                AZModell von Projekt object auslesen und nicht von der DB
//
//=============== V1.0.0037 ===============================================
//
// Date         : 29.Jaenner 2008
// Author       : Georg Nebehay
// Defect#      : 5700
//                Verwendung des SAP-Caches eingebaut.
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0032 ---------------------------------------------------
//
// Date         : 02.Agust 2007
// Author       : Adam Kiefer
// Defect#      : 4427
//                Projekt bearbeiten
//
//--------------- V1.0.0002 --------------------------------------------------- 
//
// Date         : 29. Oktober 2006
// Author       : EW
// Defect#      : 3437
//                Ermittlung der korrekten INTF_ID 
//
// ----------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{

    public class dbProjektParams
    {
        public SqlParameter PROJID = new SqlParameter("@PROJID", int.MinValue);
        public SqlParameter BAUID = new SqlParameter("@BAUID", int.MinValue);
        public SqlParameter KTOBJ = new SqlParameter("@KTOBJ", (string)"");
        public SqlParameter NAME = new SqlParameter("@NAME", (string)"");
        public SqlParameter BESCHREIBUNG = new SqlParameter("@BESCHREIBUNG", (string)"");
        public SqlParameter MLPERSKEY = new SqlParameter("@MLPERSKEY", int.MinValue);
        public SqlParameter SEGPKT = new SqlParameter("@SEGPKT", (string)"");
        public SqlParameter SEGPKTPROZ = new SqlParameter("@SEGPKTPROZ", int.MinValue);
        public SqlParameter PROJAZMID = new SqlParameter("@PROJAZMID", int.MinValue);
        public SqlParameter LAFAKTOR = new SqlParameter("@LAFAKTOR", float.MinValue);
        public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
        public SqlParameter VALID = new SqlParameter("@VALID", ParamVal.Date0);
        public ArrayList List = new ArrayList();

        public dbProjektParams()
        {
            List.Add(PROJID);
            List.Add(BAUID);
            List.Add(KTOBJ);
            List.Add(NAME);
            List.Add(BESCHREIBUNG);
            List.Add(MLPERSKEY);
            List.Add(SEGPKT);
            List.Add(SEGPKTPROZ);
            List.Add(PROJAZMID);
            List.Add(LAFAKTOR);
            List.Add(MANDANT);
            List.Add(VALID);
            ParamVal.SetDefaultValues(List);
        }
    }

    /// <summary>
    /// Summary description for dbProjekt
    /// </summary>
    public class dbProjekt
    {
        public dbBaustelle Baustelle;
        public dbProjektParams Params = new dbProjektParams();
        public ArrayList ProjektAusZulagen = new ArrayList();
        public dbProjektAZModell AZModell;
        public AuftragTyp auftragtyp;

        public bool AllowUpdate = false;
        private int lBerichtsMonat = 0; ///im Format yyyymm
        public int BerichtsMonat
        {
            get { return lBerichtsMonat; }
            set
            {
                lBerichtsMonat = value;
                lMBerichte = null;
            }
        }

        private ArrayList lMBerichte = null;
        public ArrayList MBerichte
        {
            get
            {
                if (lMBerichte == null)
                {
                    dbMontBer m = new dbMontBer(this, null);
                    lMBerichte = m.SelectAllByProjekt(lBerichtsMonat);
                }
                return lMBerichte;
            }
            set
            {
                lMBerichte = value;
            }
        }

        public dbProjekt(dbBaustelle dbb)
        {
            Baustelle = dbb;
            AZModell = new dbProjektAZModell(this);
        }

        public dbProjekt(dbBaustelle dbb, int ProjektID)
        {
            Baustelle = dbb;
            if (ProjektID > 0)
            {
                Params.PROJID.Value = ProjektID;
                Select();
            }
            AZModell = new dbProjektAZModell(this);
        }
  
        // Defect #5879 Beginn
        public dbProjekt(int ProjektID)
        {
            if (ProjektID > 0)
            {
                Params.PROJID.Value = ProjektID;
                Select();
            }
        }//Defect #5879 Ende

        public bool Insert()
        {
            Params.PROJID.Value = Baustelle.Bearbeiter.Commons.GetNextID(11, "Auftragseinsatz");
            ParamVal.InsertValid(Params.List);
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("sp_TM_BauprojektInsert", cnx)) // Defect 5436, using eingef�hrt
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        Params.MANDANT.Value = Baustelle.Bearbeiter.Params.MANDANT.Value;
                        foreach (SqlParameter s in Params.List)
                            cmd.Parameters.Add(s);
                        int nRecs = cmd.ExecuteNonQuery();
                        foreach (SqlParameter s in Params.List)
                            cmd.Parameters.Remove(s);
                        if (AllowUpdate = (nRecs > 0))
                        {
                            // Beginn #4427 - Projekt bearbeiten
                            foreach (dbProjektAusZul az in ProjektAusZulagen)
                            {
                                if (!az.Deleted)
                                    az.Insert();
                            }
                            // Ende #4427
                            AZModell.Update();
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return AllowUpdate;
        }
        public bool ExistProjName(string strName)
        {
            bool isNameExist = false;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("select Count(*) from bauprojekt " + Config.Nolock + " where Name='" + strName + "'", cnx)) // Defect 5436
                    {
                        using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
                        {
                            while (rd.Read())
                            {
                                if ((int)rd.GetValue(0) > 0)
                                    isNameExist = true;
                                else
                                    isNameExist = false;
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return isNameExist;
        }

        public bool Update()
        {
            ParamVal.InsertValid(Params.List);
            if (!AllowUpdate)
                Insert();
            else
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        using (SqlCommand cmd = new SqlCommand("sp_TM_BauprojektUpdate", cnx)) // Defect 5436
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            foreach (SqlParameter s in Params.List)
                                cmd.Parameters.Add(s);
                            int nRecs = cmd.ExecuteNonQuery();
                            foreach (SqlParameter s in Params.List)
                                cmd.Parameters.Remove(s);
                            AllowUpdate = (nRecs > 0);
                            if (AllowUpdate = (nRecs > 0))
                            {
                                foreach (dbProjektAusZul az in ProjektAusZulagen) az.Save();
                                AZModell.Update();
                            }
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            return AllowUpdate;
        }

        public bool Select()
        {
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("sp_TM_BauprojektSelect", cnx)) // Defect 5436
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(Params.PROJID);
                        using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
                        {
                            cmd.Parameters.Remove(Params.PROJID);
                            ParamVal.SetDefaultValues(Params.List);
                            while (rd.Read())
                            {
                                AllowUpdate = true;
                                if (!rd.IsDBNull(0)) Params.PROJID.Value = rd.GetValue(0);
                                if (!rd.IsDBNull(1)) Params.BAUID.Value = rd.GetValue(1);
                                if (!rd.IsDBNull(2)) Params.KTOBJ.Value = rd.GetValue(2);
                                if (!rd.IsDBNull(3)) Params.NAME.Value = rd.GetValue(3);
                                if (!rd.IsDBNull(4)) Params.BESCHREIBUNG.Value = dbText.GetText(rd, 4);
                                if (!rd.IsDBNull(5)) Params.MLPERSKEY.Value = rd.GetValue(5);
                                if (!rd.IsDBNull(6)) Params.SEGPKT.Value = rd.GetValue(6);
                                if (!rd.IsDBNull(7)) Params.SEGPKTPROZ.Value = rd.GetValue(7);
                                if (!rd.IsDBNull(8)) Params.PROJAZMID.Value = rd.GetValue(8);
                                if (!rd.IsDBNull(9)) Params.LAFAKTOR.Value = rd.GetValue(9);
                                if (!rd.IsDBNull(10)) Params.MANDANT.Value = rd.GetValue(10);
                                if (!rd.IsDBNull(11)) Params.VALID.Value = rd.GetValue(11);
                                dbProjektAusZul az = new dbProjektAusZul(this);
                                ProjektAusZulagen = az.SelectAll();
                                AZModell = new dbProjektAZModell(this);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return AllowUpdate;
        }

        // Defect 5436, Code wird nicht verwendet
        //public ArrayList SelectAll()
        //{
        //    return SelectAll(0, false);
        //}

        //public ArrayList SelectAll(int MLPerskey)
        //{
        //    return SelectAll(MLPerskey, false);
        //}

        //public ArrayList SelectAll(bool nurOffene)
        //{
        //    return SelectAll(0, nurOffene);
        //}

        //public ArrayList SelectAll(int mlPerskey, bool nurOffene)
        //{
        //    ArrayList al = new ArrayList();
        //    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        //    {
        //        try
        //        {
        //            string sql = "Select PROJID,BAUID,KTOBJ,NAME,BESCHREIBUNG,MLPERSKEY,SEGPKT,SEGPKTPROZ,PROJAZMID, VALID from Bauprojekt where MANDANT = '"+Baustelle.Bearbeiter.Params.MANDANT.Value.ToString()+"' ";
        //            if (mlPerskey > 0)
        //                sql += " and MLPERSKEY = @MLPERSKEY ";
        //            cnx.Open();
        //            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
        //            {
        //              if (mlPerskey > 0)
        //                cmd.Parameters.Add(Params.MLPERSKEY);
        //              using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
        //              {
        //                if (mlPerskey > 0)
        //                  cmd.Parameters.Remove(Params.MLPERSKEY);
        //                while (rd.Read())
        //                {//Reamrk: verwende hier nicht ParamVal.DataReader2Params weil Beschreibung vom Typ Text
        //                  AllowUpdate = true;
        //                  dbProjekt p = new dbProjekt(Baustelle);
        //                  ParamVal.SetDefaultValues(p.Params.List);
        //                  if (!rd.IsDBNull(0)) p.Params.PROJID.Value = rd.GetValue(0);
        //                  if (!rd.IsDBNull(1)) p.Params.BAUID.Value = rd.GetValue(1);
        //                  if (!rd.IsDBNull(2)) p.Params.KTOBJ.Value = rd.GetValue(2);
        //                  if (!rd.IsDBNull(3)) p.Params.NAME.Value = rd.GetValue(3);
        //                  if (!rd.IsDBNull(4)) p.Params.BESCHREIBUNG.Value = dbText.GetText(rd, 4);
        //                  if (!rd.IsDBNull(5)) p.Params.MLPERSKEY.Value = rd.GetValue(5);
        //                  if (!rd.IsDBNull(6)) p.Params.SEGPKT.Value = rd.GetValue(6);
        //                  //if (!rd.IsDBNull(7)) 
        //                  p.Params.SEGPKTPROZ.Value = 100;
        //                  if (!rd.IsDBNull(8)) p.Params.PROJAZMID.Value = rd.GetValue(8);
        //                  if (!rd.IsDBNull(9)) p.Params.LAFAKTOR.Value = rd.GetValue(9);
        //                  dbProjektAusZul az = new dbProjektAusZul(p);
        //                  p.ProjektAusZulagen = az.SelectAll();
        //                  p.AZModell = new dbProjektAZModell(p);
        //                  if ((!nurOffene) || (p.KontierbarInSAP())) al.Add(p);
        //                  else al.Add(p);
        //                }
        //              }
        //            }
        //        }
        //        catch (Exception ex) { throw ex; }
        //        finally { cnx.Close(); }
        //    }
        //    return al;
        //}

        /// <summary>
        /// Enth�lt Call auf RFC
        /// </summary>
        /// <returns>true: KTOBJ ist Kontierbar</returns>
        public bool KontierbarInSAP()
        {
            //hier kann SAP �berpr�fung ausgeschaltet werden
            //return true;
            return CheckSAP();
        }



        public bool CheckSAP()
        {
            //Defect 5700
            //GN 29.1.2008
            //Abh�ngig von Konfigurationsparameter SAP Cache verwenden

            if (ConfigurationManager.AppSettings["NoSAPUsage"] != null)
            {
                auftragtyp = new AuftragTyp("", "");
                return true;
            }
            
            if (ConfigurationManager.AppSettings["UseSAPCache"] == "true")
            {
                return CheckSAP_Cached();
            }
            else return CheckSAP_Uncached();

        }

        public bool CheckSAP_Cached()
        {
            //Cache-Instanz holen
            SAPCache cache = SAPCache.GetInstance();

            //Cache-Abfrage durchf�hrer
            //TAPM-45 - Cacheobj bekommt Mandant prefix, damit man SAP Kontos aus 2 Verschiedene Systeme
            //oder 2 verschiedene Mandanten nicht verwechseln
            //InfoObject obj = cache.Query(Params.KTOBJ.Value.ToString());
            string Mandant = Params.MANDANT.Value.ToString();
            try
            {
                if (Mandant == "")
                    Mandant = Baustelle.Bearbeiter.Params.MANDANT.Value.ToString();
            }
            catch
            {
                Mandant = "Mx";
            }
            InfoObject obj = cache.Query(Mandant + '$' + Params.KTOBJ.Value.ToString());
            //TAPM-45 - Ende
            //Daten aus dem Cacheobjekt �benehmen
            Params.KTOBJ.Value = obj.Ktobj;
            auftragtyp = new AuftragTyp(obj.Autyp, obj.Objid);

            //Bebuchbarkeitsstatus zur�ckgeben
            return (obj.Bebuchbar);

        }

        public bool CheckSAP_Uncached()
        {
            //string Kont = "";
            string connStr = ConfigurationManager.AppSettings["SAPConnectionString"];
            //string Belkz = ""; //TAPM-44 - ist SAP Nummer Kontierbar

            //TAPM-45 ist ein SAPConnectionStringMx in Web.Config definiert, dann wird diese f�r
            //SAP Connection verwendet. Default ist SAPConnectionString.
            if (ConfigurationManager.AppSettings["SAPConnectionString" + Params.MANDANT.Value.ToString()] != null)
                connStr = ConfigurationManager.AppSettings["SAPConnectionString" + Params.MANDANT.Value.ToString()];

            string Err = "";
            string Ktobj = "";
            string Inact = "";
            string Autyp = "";
            string Objid = "";
            string Belkz = "";

            SAPconnector.SAPcheck.GetKontoInfo(connStr, Params.KTOBJ.Value.ToString().ToUpper(), ref Err, ref Ktobj, ref Inact, ref Autyp, ref Objid, ref Belkz);
            Params.KTOBJ.Value = Ktobj;
            bool kont = true;
            if (Objid == "PR" && Belkz == "")
                kont = false;
            return (Inact == "") && (Err == "00") && kont;
            //TAP_SAPProxy SapCon = new TAP_SAPProxy();
            //SapCon.Connection = SAP.Connector.SAPConnectionPool.GetConnectionFromPool(connStr);
            //SapCon.Connection.Open();
            //string Err = "";
            //SIE_SSA_CS_KONT_TAPTable retTable = new SIE_SSA_CS_KONT_TAPTable();
            //try
            //{
            //    SapCon.Sie_Ssa_Cs_Check_Kont_Objects(Params.KTOBJ.Value.ToString().ToUpper(), out Err, ref retTable);
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            //finally
            //{
            //    SapCon.Connection.Close();
            //    SAP.Connector.SAPConnectionPool.ReturnConnection(SapCon.Connection);
            //}
            //if (retTable.Count > 1)
            //{
            //    Exception ex = new Exception("dbProjekt::CheckSAP:Eindeutigkeit bei Kont-Objekt nicht gegeben!");
            //    throw ex;
            //}
            //Params.NAME.Value = "";
            //Params.KTOBJ.Value = "";
            //foreach (SIE_SSA_CS_KONT_TAP x in retTable)
            //{
            //    //Params.NAME.Value = x.Arktx;
            //    Params.KTOBJ.Value = x.Ktobj;
            //    Kont = x.Inact;
            //    auftragtyp = new AuftragTyp(x.Autyp, x.Objid);
            //    Belkz = x.Belkz;//TAPM-44 - ist SAP Nummer Kontierbar
            //}


            //return ((Kont == "") && (Err == "00") && (Belkz != ""));
        }
        private string lINTF_ID = "";
        public string INTF_ID
        {
            get
            {
                if (ConfigurationManager.AppSettings["NoSAPUsage"] != null) return "0";

                // Beginn Defect # 3437: Ermitteln der INTF_ID
                if (auftragtyp.AuTyp == "NULL" && auftragtyp.ObjID == "GK")
                    lINTF_ID = "10";
                else if (auftragtyp.AuTyp == "00" && auftragtyp.ObjID == "PR")  // PSP - Elemente
                    lINTF_ID = "20";
                else if (auftragtyp.AuTyp == "00" && auftragtyp.ObjID == "VB")  // VBP's: Vertriebsbelegeauftr�ge 
                    lINTF_ID = "30";
                else if (auftragtyp.AuTyp == "01" && auftragtyp.ObjID == "OR")  // Kontierbarer Auftrag: CO-Innenauftr�ge
                    lINTF_ID = "40";
                else if (auftragtyp.AuTyp == "10" && auftragtyp.ObjID == "OR")  // Kontierbarer Auftrag: Fertigungsauftr�ge (EWW)
                    lINTF_ID = "41";
                else if (auftragtyp.AuTyp == "30" && auftragtyp.ObjID == "OR")  // CS - Serviceauftr�ge
                    lINTF_ID = "42";
                else if (auftragtyp.AuTyp == "00" && auftragtyp.ObjID == "KS")
                    lINTF_ID = "50";
                else
                    lINTF_ID = "";
                // Ende Defect # 3437

                return lINTF_ID;
            }
        }

        // Defect 5436, Code wird nicht verwendet
        //public void listObsoleteProjekte(string mandt)
        //{
        //    string ktobj_save = Params.KTOBJ.Value.ToString();
        //    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        //    {
        //        try
        //        {
        //            ktobj_save = Params.KTOBJ.Value.ToString();
        //            cnx.Open();
        //            string sql = "Select PROJID,BAUID,KTOBJ,NAME,BESCHREIBUNG,MLPERSKEY, MANDANT, VALID from Bauprojekt where MANDANT = '" + mandt + "' ";
        //            using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
        //            {
        //              using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
        //              {
        //                ParamVal.SetDefaultValues(Params.List);
        //                while (rd.Read())
        //                {
        //                  if (!rd.IsDBNull(0)) Params.PROJID.Value = rd.GetValue(0);
        //                  if (!rd.IsDBNull(1)) Params.BAUID.Value = rd.GetValue(1);
        //                  if (!rd.IsDBNull(2)) Params.KTOBJ.Value = rd.GetValue(2);
        //                  if (!rd.IsDBNull(3)) Params.NAME.Value = rd.GetValue(3);
        //                  if (Params.KTOBJ.Value.ToString() != "")
        //                  {
        //                    if (!CheckSAP())
        //                    {
        //                      string obsolete_ktobj = Params.KTOBJ.Value.ToString();
        //                    }
        //                  }
        //                }
        //              }
        //            }
        //        }
        //        catch (Exception ex) { Params.KTOBJ.Value = ktobj_save;}
        //        finally { Params.KTOBJ.Value = ktobj_save; cnx.Close(); }
        //    }
        //}
    }

    public class AuftragTyp
    {
        public string AuTyp = "";
        public string ObjID = "";
        public AuftragTyp(string autyp, string objid)
        {
            AuTyp = autyp;
            ObjID = objid;
        }
    }
    public class dbProjektAusZulParams
    {
        public SqlParameter PROJID = new SqlParameter("@PROJID", int.MinValue);
        public SqlParameter LOHNART = new SqlParameter("@LOHNART", (string)"");
        public SqlParameter LOHNARTTXT = new SqlParameter("@LOHNART", (string)"");
        public ArrayList List = new ArrayList();

        public dbProjektAusZulParams()
        {
            List.Add(PROJID);
            List.Add(LOHNART);
            List.Add(LOHNARTTXT);
            ParamVal.SetDefaultValues(List);
        }
    }

    public class dbProjektAusZul
    {
        /// <summary>
        /// AllowUpdate == False : no current row in DB: in Save() it'll be inserted when Deleted == False
        /// AllowUpdate == True  : current Row in DB: in Save() it'll be deleted when Deleted == True
        /// </summary>
        public bool AllowUpdate = false;
        public bool Deleted = false;
        public dbProjekt Projekt;
        public dbProjektAusZulParams Params = new dbProjektAusZulParams();

        public dbProjektAusZul(dbProjekt Proj)
        {
            Projekt = Proj;
            Params.PROJID.Value = Projekt.Params.PROJID.Value;
        }
        public dbProjektAusZul(dbProjekt Proj, string Lohnart)
        {
            Projekt = Proj;
            Params.PROJID.Value = Projekt.Params.PROJID.Value;
            Params.LOHNART.Value = Lohnart;
        }

        public bool Insert()
        {
            Params.PROJID.Value = Projekt.Params.PROJID.Value;
            ParamVal.InsertValid(Params.List);
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("Insert into BAUPROJEKT_AUSZUL " + Config.Rowlock + " (PROJID, LOHNART) VALUES(@PROJID,@LOHNART)", cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(Params.PROJID);
                        cmd.Parameters.Add(Params.LOHNART);
                        int nRecs = cmd.ExecuteNonQuery();
                        cmd.Parameters.Remove(Params.PROJID);
                        cmd.Parameters.Remove(Params.LOHNART);
                        AllowUpdate = (nRecs > 0);
                        Deleted = false;
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return AllowUpdate;
        }

        public ArrayList SelectAll()
        {
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    //using (SqlCommand cmd = new SqlCommand("Select LOHNART, LOHNARTTXT from Y_Lohnart2 " + Config.Nolock + " where LOHNART in (Select Lohnart from Bauprojekt_Auszul " + Config.Nolock + " where Projid = @PROJID)", cnx)) // Defect 5436
                    using (SqlCommand cmd = new SqlCommand("Select LOHNART, LOHNARTTXT from Y_Lohnart3 " + Config.Nolock + 
                        " where LOHNART in (Select Lohnart from Bauprojekt_Auszul " + Config.Nolock + " where Projid = @PROJID) AND " + 
                        " MANDANT = @MANDANT AND STATUS = 20", cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(new SqlParameter("@PROJID", Projekt.Params.PROJID.Value));
                        cmd.Parameters.Add(new SqlParameter("@MANDANT", Projekt.Params.MANDANT.Value));
                        //cmd.Parameters.Add(Projekt.Params.PROJID);
                        using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
                        {
                            //cmd.Parameters.Remove(Projekt.Params.PROJID);
                            cmd.Parameters.Clear();
                            while (rd.Read())
                            {
                                AllowUpdate = true;
                                dbProjektAusZul p = new dbProjektAusZul(Projekt);
                                ParamVal.SetDefaultValues(p.Params.List);
                                p.Params.PROJID.Value = Params.PROJID.Value;
                                p.Params.LOHNART.Value = rd.GetValue(0);
                                p.Params.LOHNARTTXT.Value = rd.GetValue(1);
                                p.AllowUpdate = true;
                                p.Deleted = false;
                                al.Add(p);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return al;
        }

        public bool Delete()
        {
            ParamVal.InsertValid(Params.List);
            if (AllowUpdate)
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        // Defect 5725, Config.Rowlock eingef�hrt
                        using (SqlCommand cmd = new SqlCommand("Delete from BAUPROJEKT_AUSZUL " + Config.Rowlock + " where PROJID = @PROJID and LOHNART = @LOHNART", cnx)) // Defect 5436
                        {
                            cmd.Parameters.Add(Params.PROJID);
                            cmd.Parameters.Add(Params.LOHNART);
                            int nRecs = cmd.ExecuteNonQuery();
                            cmd.Parameters.Remove(Params.PROJID);
                            cmd.Parameters.Remove(Params.LOHNART);
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            return AllowUpdate;
        }

        public bool Save()
        {
            if (!AllowUpdate)
            {
                if (!Deleted) return Insert();
            }
            else
            {
                if (Deleted) return Delete();
            }
            // :) nix zu tun - return a smile
            return true;
        }
    }

    public class dbProjektAZModellParams
    {
        public SqlParameter PROJAZMID = new SqlParameter("@PROJAZMID", int.MinValue);
        public SqlParameter TAG = new SqlParameter("@TAG", int.MinValue);
        public SqlParameter VON = new SqlParameter("@VON", ParamVal.Date0);
        public SqlParameter BIS = new SqlParameter("@BIS", ParamVal.Date0);
        public ArrayList List = new ArrayList();
        public dbProjektAZModellParams()
        {
            List.Add(PROJAZMID);
            List.Add(TAG);
            List.Add(VON);
            List.Add(BIS);
            ParamVal.SetDefaultValues(List);
        }
    }

    public class dbProjektAZModell
    {
        public const Int16 Montag = 1;
        public const Int16 Dienstag = 2;
        public const Int16 Mittwoch = 3;
        public const Int16 Donnerstag = 4;
        public const Int16 Freitag = 5;
        public const Int16 Samstag = 6;
        public const Int16 Sonntag = 0;

        public dbProjekt Projekt;
        public bool AllowUpdate = false;
        public bool Exists
        {
            get
            {
                foreach (dbProjektAZModellParams azp in Tage)
                    if ((Convert.ToDateTime(azp.VON.Value).Ticks != ParamVal.Date0.Ticks) | (Convert.ToDateTime(azp.BIS.Value).Ticks != ParamVal.Date0.Ticks)) return true;
                return false;
            }
        }

        public ArrayList Tage = new ArrayList();

        public dbProjektAZModell(dbProjekt Proj)
        {
            Projekt = Proj;
            for (int i = Sonntag; i <= Samstag; i++)
            {
                dbProjektAZModellParams p = new dbProjektAZModellParams();
                p.PROJAZMID.Value = Projekt.Params.PROJID.Value;
                p.TAG.Value = i;
                Tage.Add(p);
            }
            Select();
        }
        // Defect #5672 neues Konstruktor
        public dbProjektAZModell(dbProjekt Proj, bool readAZModelfromDB)
        {
            Projekt = Proj;
            if (readAZModelfromDB)
            {
                for (int i = Sonntag; i <= Samstag; i++)
                {
                    dbProjektAZModellParams p = new dbProjektAZModellParams();
                    p.PROJAZMID.Value = Projekt.Params.PROJID.Value;
                    p.TAG.Value = i;
                    Tage.Add(p);
                }
                Select();
            }
            else
                for (int i = Sonntag; i <= Samstag; i++)
                {
                    dbProjektAZModellParams p = new dbProjektAZModellParams();
                    dbProjektAZModellParams p2 = Projekt.AZModell.Tage[i] as dbProjektAZModellParams;
                    p.PROJAZMID.Value = p2.PROJAZMID.Value;
                    p.TAG.Value = i;
                    p.BIS.Value = p2.BIS.Value;
                    p.VON.Value = p2.VON.Value;
                    Tage.Add(p);
                }
        }

        private bool Select()
        {
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    using (SqlCommand cmd = new SqlCommand("Select PROJAZMID, TAG, VON, BIS from BAUPROJEKT_AZMODELL " + Config.Nolock + " where Projazmid = @PROJID order by TAG asc", cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(Projekt.Params.PROJID);
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Remove(Projekt.Params.PROJID);
                            while (rd.Read())
                            {
                                AllowUpdate = true;
                                ParamVal.DataReader2Params(rd, (Tage[rd.GetInt32(1)] as dbProjektAZModellParams).List);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return AllowUpdate;
        }

        public bool Update()
        {
            if (AllowUpdate)
                Delete();
            for (int i = Sonntag; i <= Samstag; i++)
            {
                dbProjektAZModellParams p = (dbProjektAZModellParams)Tage[i];
                p.PROJAZMID.Value = Projekt.Params.PROJID.Value;
                ParamVal.InsertValid(p.List);
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        // Defect 5725, Config.Rowlock eingef�hrt
                        using (SqlCommand cmd = new SqlCommand("Insert Into BAUPROJEKT_AZMODELL " + Config.Rowlock + " (PROJAZMID, TAG, VON, BIS) VALUES (@PROJAZMID, @TAG,@VON, @BIS)", cnx)) // Defect 5436
                        {
                            foreach (SqlParameter s in p.List) cmd.Parameters.Add(s);
                            int nRecs = cmd.ExecuteNonQuery();
                            foreach (SqlParameter s in p.List) cmd.Parameters.Remove(s);
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            }
            return AllowUpdate;
        }

        public bool Delete()
        {
            if (AllowUpdate)
            {
                for (int i = Sonntag; i <= Samstag; i++)
                {
                    dbProjektAZModellParams p = (dbProjektAZModellParams)Tage[i];
                    ParamVal.InsertValid(p.List);
                }
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        // Defect 5725, Config.Rowlock eingef�hrt
                        using (SqlCommand cmd = new SqlCommand("Delete from BAUPROJEKT_AZMODELL " + Config.Rowlock + " where Projazmid = @PROJID", cnx)) // Defect 5436
                        {
                            cmd.Parameters.Add(Projekt.Params.PROJID);
                            int nRecs = cmd.ExecuteNonQuery();
                            cmd.Parameters.Remove(Projekt.Params.PROJID);
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            }
            return AllowUpdate;
        }

    }
}