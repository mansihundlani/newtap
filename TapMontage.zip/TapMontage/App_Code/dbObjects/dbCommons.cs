//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbCommons.cs
//
// Description  : Datenbankzugriffe - Funktionen zur Bef�llung
//                d.GUI-Objekte (ComboBox, listen, ...)
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2013
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//                
//=============== 1.0.0050 ================================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
// Defect#      : BAN 500091
//                Lohnartenumstellung am TAP, neue LA ab 01.01.2010
//
//=============== V1.0.0047 ===============================================
//
// Date         : 11.Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-42
//                Berichtsmonat f�rs R�cksetzmaske
//
//=============== V1.0.0042 ===============================================
//
// Date         : 24.Juni 2008
// Author       : Joldic Dzevad
// Defect#      : MC49359
//                Ortsangabe bei Inlandsreisen ist Mussfeld
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
// Date         : 10.J�nner 2008
// Author       : Joldic Dzevad
// Defect#      : 5747
//                Kombinationsfeld "AnzBerichtsmonat" korrigiert 
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0032 -------------------------------------------------------------------------
//
// Date         : 9.August 2007
// Author       : Georg Nebehay
// Defect#      : 4945, 5254, 5313
//                Bei der Eigenschaft GK_Auftrag wurde ein zu simples SQL-Skript verwendet. Dieses lud
//                alle GK-Auftr�ge, die dem Mandanten zugeordnet waren. Jetzt wird auch noch eingeschr�nkt
//                auf KG-Auftr�ge, die der Kostenstelle des Mitarbeiters zugeordnet sind.
//
//--------------- V1.0.0028 -------------------------------------------------------------------------
//
// Date         : 13.Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4099
//                Anzeige ab Monat der ganzt�gigen Absenzen
//
//--------------- V1.0.0028 -------------------------------------------------------------------------
//
// Date         : 30.Mai 2007
// Author       : Adam Kiefer
// Defect#      : 4079
//                Liste aller zu genehmigenden Mitarbeiter
//
//--------------- V1.0.0027 -------------------------------------------------------------------------
//
// Date         : 14. Mai 2007
// Author       : GN
// Defect#      : 4931
//                Neue Liste Mitfahrt
//
// -------------- V1.0.0023 -------------------------------------------------------------------------
//
// Date         : 20.M�rz 2007
// Author       : GN
// Defect#      : 4801
//                Deadlocks beim Genehmigen:
//                Beim Setzen der Leistungsarten ergibt sich gelegentlich eine Deadlocksituation. Diese wurde durch ein
//                applikationsseitiges MutEx behoben.
//
// -------------- V1.0.0022 -------------------------------------------------------------------------
//
// Date         : 21.Februar 2007
// Author       : WP
// Defect#      : 4655
//                Anzeige EB und RA, neues DropDown AnzBerichtsmonat, 
//
// -------------- V1.0.0020 -------------------------------------------------------------------------
//
// Date         : 27.J�nner 2007
// Author       : Gebhardt Caleb
// Defect#      : 4312
//                Logik, die es erm�glicht Beginn- und Ende-Absenzen bei Krankheiten
//                und Unfall zu erfassen.
//                Programmcode ist auskommentiert f. V1.0.0020 (funktioniert aber und kann wieder
//                bei Bedarf aktiviert werden) 
//
//---------------------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.Misc;

namespace TapMontage.dbObjects
{

    public class ValuePair
    {
        public string Text;
        public string Value;

        public ValuePair()
        {
            Text = "";
            Value = "";
        }
        public ValuePair(string text, string value)
        {
            Text = text;
            Value = value;
        }
    }

    /// <summary>
    /// Summary description for dbCommons
    /// </summary>
    public class dbCommons
    {

        public dbBearbeiter Bearbeiter;

        public dbCommons(dbBearbeiter Bearb)
        {
            Bearbeiter = Bearb;
        }

        //Defect 4801
        //20.03.2007
        //Deadlocks beim Genehmigen
        //Folgendes Objekt wird f�rs Locken verwendet. Durch die statische Deklarierung dieses Objekts
        //wird ein applikationsweiter Lock erm�glicht.
        private static object myLock = new object();
        public int GetNextID(int NrBandArt, string Bemerk)
        {
            string name = Bearbeiter.Params.NACHNAME.Value.ToString();

            int iRet = -1;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    //Defect 4801
                    //20.03.2007
                    //Deadlocks beim Genehmigen
                    //Folgender Lock behebt den m�glichen Deadlock beim Holen einer ID
                    lock (myLock)
                    {
                        cnx.Open();
                        // Defect 5725, Config.Rowlock eingef�hrt
                        using (SqlCommand cmd = new SqlCommand("Select AKT from MNDGLOBAL " + Config.Rowlock + " where MANDANT = '" + Bearbeiter.Params.MANDANT.Value + "' and NRBANDART =" + NrBandArt.ToString(), cnx)) // Defect 5436, using eingef�hrt
                        {
                            cmd.Transaction = cnx.BeginTransaction(IsolationLevel.Serializable);
                            System.Diagnostics.Debug.WriteLine(DateTime.Now + ": " + name + " Execute Read");
                            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                            {
                                if (!rd.Read())
                                {
                                    Exception ex = new Exception("dbIDFetcher::getNextID: No columns found for mandant, nrbandart, Bemerk: " + Bearbeiter.Params.MANDANT.Value + "," + NrBandArt.ToString() + "," + Bemerk);
                                    throw ex;
                                }
                                iRet = rd.GetInt32(0);
                                iRet++;
                                rd.Close();
                            }
                            cmd.CommandText = "Update MNDGLOBAL " + Config.Rowlock + " set AKT = AKT+1 where MANDANT = '" + Bearbeiter.Params.MANDANT.Value + "' and NRBANDART =" + NrBandArt.ToString();
                            cmd.ExecuteNonQuery();
                            cmd.Transaction.Commit();
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally { cnx.Close(); }
            }
            return iRet;
        }
        //BAN 500059 - Wenn man x Nummernstrecken braucht, dann kann �ber diese Funktion aktuelles ID geholt
        //und neues AKT ID auf AKT + x gesetzt
        public int GetNextxIDs(int NrBandArt, string Bemerk, int Anzahl)
        {
            string name = Bearbeiter.Params.NACHNAME.Value.ToString();

            int iRet = -1;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    //Defect 4801
                    //20.03.2007
                    //Deadlocks beim Genehmigen
                    //Folgender Lock behebt den m�glichen Deadlock beim Holen einer ID
                    lock (myLock)
                    {
                        cnx.Open();
                        // Defect 5725, Config.Rowlock eingef�hrt
                        using (SqlCommand cmd = new SqlCommand("Select AKT from MNDGLOBAL " + Config.Rowlock + " where MANDANT = '" + Bearbeiter.Params.MANDANT.Value + "' and NRBANDART =" + NrBandArt.ToString(), cnx)) // Defect 5436, using eingef�hrt
                        {
                            cmd.Transaction = cnx.BeginTransaction(IsolationLevel.Serializable);
                            System.Diagnostics.Debug.WriteLine(DateTime.Now + ": " + name + " Execute Read");
                            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                            {
                                if (!rd.Read())
                                {
                                    Exception ex = new Exception("dbIDFetcher::getNextID: No columns found for mandant, nrbandart, Bemerk: " + Bearbeiter.Params.MANDANT.Value + "," + NrBandArt.ToString() + "," + Bemerk);
                                    throw ex;
                                }
                                iRet = rd.GetInt32(0);
                                //iRet++;
                                rd.Close();
                            }
                            cmd.CommandText = "Update MNDGLOBAL " + Config.Rowlock + " set AKT = @AKT where MANDANT = '" + Bearbeiter.Params.MANDANT.Value + "' and NRBANDART =" + NrBandArt.ToString();
                            cmd.Parameters.Add(new SqlParameter("@AKT", iRet+Anzahl));
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            cmd.Transaction.Commit();
                            iRet++;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally { cnx.Close(); }
            }
            return iRet;
        }

        public string vpGetText(ArrayList vpList, string Value)
        {
            foreach (ValuePair vp in vpList)
                if (vp.Value.ToString() == Value) return vp.Text;
            return "";
        }

        public ArrayList vpSelect(string SQL)
        {
            ArrayList al = new ArrayList();
            ValuePair vp;
            //select
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand(SQL, cnx)) // Defect 5436
                    {
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            while (rd.Read())
                            {
                                vp = new ValuePair();
                                if ((!rd.IsDBNull(0)) && (!rd.IsDBNull(1)))
                                {
                                    vp.Text = rd.GetString(0);
                                    vp.Value = rd.GetString(1);
                                    al.Add(vp);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }

            return al;
        }

        // Beginn Defect 5725, wird nicht verwendet
        //private ArrayList lLohnarten = null;
        //public ArrayList Lohnarten
        //{
        //  get
        //  {
        //    if (lLohnarten == null)
        //    {
        //      lLohnarten = new ArrayList();
        //      lLohnarten = vpSelect("dfdhj");
        //    }
        //    return lLohnarten;
        //  }
        //  set
        //  {
        //    lLohnarten = value;
        //  }
        //}
        // Ende Defect 5725

        private ArrayList lBaustellenstati = null;
        public ArrayList Baustellenstati
        {
            get
            {
                if (lBaustellenstati == null)
                {
                    lBaustellenstati = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lBaustellenstati = vpSelect("select baustatustext, CAST(baustatid as varchar(100)) from y_baustat " + Config.Nolock);
                }
                return lBaustellenstati;
            }
            set
            {
                lBaustellenstati = value;
            }
        }

        private ArrayList lLaender = null;
        public ArrayList Laender
        {
            get
            {
                if (lLaender == null)
                {
                    lLaender = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lLaender = vpSelect("select RAKZTXT, RAKZ from y_RaKZ " + Config.Nolock + " where RAKZID='LKZ' and status=20 and RAKZTXT='Oesterreich' union all select RAKZTXT, RAKZ from y_RaKZ " + Config.Nolock + " where RAKZID='LKZ' and status=20 and RAKZTXT not in (select RAKZTXT from y_RaKZ " + Config.Nolock + " where RAKZID='LKZ' and status=20 and RAKZTXT='Oesterreich')");
                }
                return lLaender;
            }
            set
            {
                lLaender = value;
            }
        }

        private ArrayList lBaustellenoffen = null;
        public ArrayList Baustellenoffen
        {
            get
            {
                if (lBaustellenoffen == null)
                {
                    lBaustellenoffen = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lBaustellenoffen = vpSelect("select NAME, CAST(BAUID as varchar(100)) from BAUSTELLE " + Config.Nolock + " where MANDANT = '" + Bearbeiter.Mandant.MANDANT + "' and BAUSTAT = 0 order by NAME");
                }
                return lBaustellenoffen;
            }
            set
            {
                lBaustellenoffen = value;
            }
        }

        private ArrayList lBaustellenMitAZM = null;
        public ArrayList BaustellenMitAZM
        {
            get
            {
                if (lBaustellenMitAZM == null)
                {
                    lBaustellenMitAZM = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lBaustellenMitAZM = vpSelect("select b.NAME, CAST(b.BAUID as varchar(100)) from BAUSTELLE b " + Config.Nolock + ", BAUPROJEKT p " + Config.Nolock + ", BAUPROJEKT_AZMODELL a " + Config.Nolock + " where b.BAUID = p.BAUID and p.Projid = a.PROJAZMID and a.VON <> '1900-01-01 00:00:00.000' and a.BIS <> '1900-01-01 00:00:00.000' and b.MANDANT = '" + Bearbeiter.Mandant.MANDANT + "' and BAUSTAT = 0 group by b.Bauid, b.Name order by b.NAME");
                }
                return lBaustellenMitAZM;
            }
            set
            {
                lBaustellenMitAZM = value;
            }
        }

        private ArrayList lAlleBaustellen = null;
        public ArrayList AlleBaustellen
        {
            get
            {
                if (lAlleBaustellen == null)
                {
                    lAlleBaustellen = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lAlleBaustellen = vpSelect("select NAME, CAST(BAUID as varchar(100)) from BAUSTELLE " + Config.Nolock + " where MANDANT = '" + Bearbeiter.Mandant.MANDANT + "' order by NAME");
                }
                return lAlleBaustellen;
            }
            set
            {
                lAlleBaustellen = value;
            }
        }

        private ArrayList lBaustellenNr = null;
        public ArrayList BaustellenNr
        {
            get
            {
                if (lBaustellenNr == null)
                {
                    lBaustellenNr = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lBaustellenNr = vpSelect("select BAUNR, CAST(BAUID as varchar(100)) from BAUSTELLE " + Config.Nolock + " where MANDANT = '" + Bearbeiter.Mandant.MANDANT + "' order by BAUNR");
                }
                return lBaustellenNr;
            }
            set
            {
                lBaustellenNr = value;
            }
        }

        private ArrayList lBerichtsmonat = null;
        public ArrayList Berichtsmonat
        {
            get
            {
                if (lBerichtsmonat == null)
                {
                    lBerichtsmonat = new ArrayList();
                    // CG - 3 Monate zur�ck zur Auswahl erstellen, defect # 4193
                    // zum besseren testen damit die vergangenheit noch genehmigbar bleibt...
                    if (ConfigurationManager.AppSettings["AnzGenMonate10"] != null)
                    {
                        lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-10).Month.ToString() + "/" + DateTime.Now.AddMonths(-10).Year.ToString(), DateTime.Now.AddMonths(-10).ToShortDateString()));
                        lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-9).Month.ToString() + "/" + DateTime.Now.AddMonths(-9).Year.ToString(), DateTime.Now.AddMonths(-9).ToShortDateString()));
                        lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-8).Month.ToString() + "/" + DateTime.Now.AddMonths(-8).Year.ToString(), DateTime.Now.AddMonths(-8).ToShortDateString()));
                        lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-7).Month.ToString() + "/" + DateTime.Now.AddMonths(-7).Year.ToString(), DateTime.Now.AddMonths(-7).ToShortDateString()));
                        lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-6).Month.ToString() + "/" + DateTime.Now.AddMonths(-6).Year.ToString(), DateTime.Now.AddMonths(-6).ToShortDateString()));
                        lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-5).Month.ToString() + "/" + DateTime.Now.AddMonths(-5).Year.ToString(), DateTime.Now.AddMonths(-5).ToShortDateString()));
                        lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-4).Month.ToString() + "/" + DateTime.Now.AddMonths(-4).Year.ToString(), DateTime.Now.AddMonths(-4).ToShortDateString()));
                    }

                    lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-3).Month.ToString() + "/" + DateTime.Now.AddMonths(-3).Year.ToString(), DateTime.Now.AddMonths(-3).ToShortDateString()));
                    lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-2).Month.ToString() + "/" + DateTime.Now.AddMonths(-2).Year.ToString(), DateTime.Now.AddMonths(-2).ToShortDateString()));
                    lBerichtsmonat.Add(new ValuePair(DateTime.Now.AddMonths(-1).Month.ToString() + "/" + DateTime.Now.AddMonths(-1).Year.ToString(), DateTime.Now.AddMonths(-1).ToShortDateString()));
                    lBerichtsmonat.Add(new ValuePair(DateTime.Now.Month.ToString() + "/" + DateTime.Now.Year.ToString(), DateTime.Now.ToShortDateString()));
                }
                return lBerichtsmonat;
            }
            set
            {
                lBerichtsmonat = value;
            }
        }

        // Beginn #4079 - Liste aller zu genehmigenden Mitarbeiter
        private ArrayList lStatusFilter = null;
        public ArrayList StatusFilter
        {
            get
            {
                if (lStatusFilter == null)
                {
                    lStatusFilter = new ArrayList();
                    lStatusFilter.Add(new ValuePair("Alle", "alle"));
                    lStatusFilter.Add(new ValuePair("Fehlt", "fehlt"));
                    lStatusFilter.Add(new ValuePair("Genehmigt", "genehmigt"));
                    lStatusFilter.Add(new ValuePair("Kontrollieren", "kontrollieren"));
                }
                return lStatusFilter;
            }
            set
            {
                lStatusFilter = value;
            }
        }
        // Ende #4079

        // Beginn CR 4655
        // Auswahlliste Berichtsmonate bef�llen f�r Anzeige EB und RA,
        // beginnend mit J�nner 2007
        private ArrayList lAnzBerichtsmonat = null;
        public ArrayList AnzBerichtsmonat
        {
            get
            {
                if (lAnzBerichtsmonat == null)
                {
                    lAnzBerichtsmonat = new ArrayList();
                    // Beging Defect #5747
                    DateTime dt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                    while (lAnzBerichtsmonat.Count < 12) // letzten 12 Monaten
                    {
                        lAnzBerichtsmonat.Insert(0, new ValuePair(dt.Month.ToString() + "/" +
                                                            dt.Year.ToString(),
                                                            dt.ToShortDateString()));
                        dt = dt.AddMonths(-1);
                    }
                    // Ende Defect #5747

                    // Eintr�ge werden ab 01/2007 erzeugt
                    /*
                    for (int year = 2007; year <= DateTime.Now.Year; year++)
                    {
                      for (int month = 1; month <= DateTime.Now.Month; month++)
                      {
                        DateTime curDate = new DateTime(year, month, 01);
                        lAnzBerichtsmonat.Add(new ValuePair(curDate.Month.ToString() + "/" +
                                                            curDate.Year.ToString(),
                                                            curDate.ToShortDateString()));
                      }
                    }
                     */
                }
                return lAnzBerichtsmonat;
            }
            set
            {
                lAnzBerichtsmonat = value;
            }
        }
        // Ende CR 4655

        // Beginn TAPM-42
        // Auswahlliste Berichtsmonate bef�llen f�rs R�cksetzen (nur letzte 2 Monate)
        private ArrayList lRuecksetzenBerichtsmonat = null;
        public ArrayList RuecksetzenBerichtsmonat
        {
            get
            {
                if (lRuecksetzenBerichtsmonat == null)
                {
                    lRuecksetzenBerichtsmonat = new ArrayList();
                    // Beging Defect #5747
                    DateTime dt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                    while (lRuecksetzenBerichtsmonat.Count < 2) // letzten 12 Monaten
                    {
                        lRuecksetzenBerichtsmonat.Insert(0, new ValuePair(dt.Month.ToString() + "/" +
                                                            dt.Year.ToString(),
                                                            dt.ToShortDateString()));
                        dt = dt.AddMonths(-1);
                    }
                }
                return lRuecksetzenBerichtsmonat;
            }
            set
            {
                lRuecksetzenBerichtsmonat = value;
            }
        }
        // Ende TAPM-42

        private ArrayList lGK_Auftrag = null;

        /*Gibt eine Liste von GK_Auftr�gen zur�ck, die dem Mitarbeiter �ber die Kostenstelle zugeordnet sind*/
        //Defect 4945,5254, 5313 falsche GK-AuftrAgsnummern
        public ArrayList GK_Auftrag
        {
            get
            {
                if (lGK_Auftrag == null)
                {
                    lGK_Auftrag = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lGK_Auftrag = vpSelect("SELECT BEMERKUNG, AUFTRNR FROM Y_AUFTRNRS a " + Config.Nolock + " JOIN y_tabnumkz t " + Config.Nolock + " on(t.tabkztxt = a.auftrnr and t.mandant = a.mandant) JOIN BEARBTECH b " + Config.Nolock + " on (substring(tabid, 3, 4) = b.kst) where t.status = 20 AND t.MANDANT = '" + Bearbeiter.Mandant.MANDANT + "' and perskey = " + Bearbeiter.Params.PERSKEY.Value);
                }
                return lGK_Auftrag;
            }
            set
            {
                lGK_Auftrag = value;
            }
        }

        private ArrayList lGTAbsenzID = null;
        public ArrayList GTAbsenzID
        {
            get
            {
                if (lGTAbsenzID == null)
                {
                    lGTAbsenzID = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt, Code wird aber nicht verwendet
                    // Defect 5771, Config.Nolock eingef�hrt, Code wird aber nicht verwendet
                    lGTAbsenzID = vpSelect("Select GTABSENZTXT+' ('+CAST(GTAbsenzID as VARCHAR(50))+')',CAST(GTAbsenzID as VARCHAR(50)) from Y_GTABSENZ " + Config.Nolock + " where Status = 20");
                }
                return lGTAbsenzID;
            }
            set
            {
                lGTAbsenzID = value;
            }
        }

        private ArrayList lGTAbsenze = null;
        public ArrayList GTAbsenze
        {
            get
            {
                if (lGTAbsenze == null)
                {
                    lGTAbsenze = new ArrayList();
                    //lGTAbsenze = vpSelect("Select GTABSENZTXT+' ('+CAST(GTAbsenzID as VARCHAR(50))+')',CAST(GTAbsenzID as VARCHAR(50)) from Y_GTABSENZ where Status = 20 and GTABSENZTXT not like '%Beginn%' and  GTABSENZTXT not like '%Ende%' order by GTABSENZTXT");
                    // Defect       : 4312: Logik, die es erm�glicht Begin- und Ende-Absenzen bei Krankheiten und Unfall zu erfassen.
                    //              : Programmcode ist auskommentiert f.V1.0.0020 (funktioniert aber und kann wiede beim Bedarf aktiviert werden)
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lGTAbsenze = vpSelect("Select GTABSENZTXT+' ('+CAST(GTAbsenzID as VARCHAR(50))+')',CAST(GTAbsenzID as VARCHAR(50)) from Y_GTABSENZ " + Config.Nolock + " where Status = 20 order by GTABSENZTXT");
                    // Defect 4099, GTAbsenzID Krankheit (210), Unfall (220) nicht zur Auswahl anbieten
                    //lGTAbsenze = vpSelect("Select GTABSENZTXT+' ('+CAST(GTAbsenzID as VARCHAR(50))+')',CAST(GTAbsenzID as VARCHAR(50)) from Y_GTABSENZ where Status = 20 and GTABSENZid not in (210,220) order by GTABSENZTXT");
                }
                return lGTAbsenze;
            }
            set
            {
                lGTAbsenze = value;
            }
        }

        private ArrayList lStandorte = null;
        public ArrayList Standorte
        {
            get
            {
                if (lStandorte == null)
                {
                    lStandorte = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lStandorte = vpSelect("Select NAME1, CAST(STDID as varchar(100)) From Standort " + Config.Nolock + " where MANDANT ='" + Bearbeiter.Params.MANDANT.Value + "'");
                }
                return lStandorte;
            }
            set
            {
                lStandorte = value;
            }
        }

        private ArrayList lSTDAbsenzID = null;
        public ArrayList STDAbsenzID
        {
            get
            {
                if (lSTDAbsenzID == null)
                {
                    lSTDAbsenzID = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lSTDAbsenzID = vpSelect("Select STDABSENZTXT+' ('+CAST(STDABSENZID as VARCHAR(50))+')',CAST(STDABSENZID as VARCHAR(50)) from Y_STDABSENZ " + Config.Nolock + " where Status = 20");
                }
                return lSTDAbsenzID;
            }
            set
            {
                lSTDAbsenzID = value;
            }
        }

        private ArrayList lVerkehrsmittel = null;
        public ArrayList Verkehrsmittel
        {
            get
            {
                if (lVerkehrsmittel == null)
                {
                    lVerkehrsmittel = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lVerkehrsmittel = vpSelect("select RAKZTXT, RAKZ from y_rakz " + Config.Nolock + " where rakzid='VM' and Status = 20 order by RAKZ");
                }
                return lVerkehrsmittel;
            }
            set
            {
                lVerkehrsmittel = value;
            }
        }

        private ArrayList lBereitstellungsarten = null;
        public ArrayList Bereitstellungsarten
        {
            get
            {
                if (lBereitstellungsarten == null)
                {
                    lBereitstellungsarten = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Rowlock eingef�hrt
                    lBereitstellungsarten = vpSelect("select RAKZTXT, RAKZ from y_rakz " + Config.Nolock + " where rakzid='B' and Status = 20 order by RAKZ");
                }
                return lBereitstellungsarten;
            }
            set
            {
                lBereitstellungsarten = value;
            }
        }

        private ArrayList lAuslagenarten = null;
        public ArrayList Auslagenarten
        {
            get
            {
                if (lAuslagenarten == null)
                {
                    lAuslagenarten = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lAuslagenarten = vpSelect("select RAKZTXT, RAKZ from y_rakz " + Config.Nolock + " where rakzid='AAI' and Status = 20 order by RAKZ");
                }
                return lAuslagenarten;
            }
            set
            {
                lAuslagenarten = value;
            }
        }

        private ArrayList lProjekt_AusZulagen = null;
        public ArrayList Projekt_AusZulagen
        {
            get
            {
                if (lProjekt_AusZulagen == null)
                {
                    lProjekt_AusZulagen = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    //lProjekt_AusZulagen = vpSelect("Select LOHNARTTXT+'('+LOHNART+')', LOHNART from Y_LOHNART2 " + Config.Nolock + " where Status = 20 order by LOHNARTTXT");
                    lProjekt_AusZulagen = vpSelect("Select LOHNARTTXT+'('+LOHNART+')', LOHNART from Y_LOHNART3 " + Config.Nolock + " where Status = 20 AND MANDANT = '" + Bearbeiter.Params.MANDANT.Value.ToString() + "' order by LOHNARTTXT");
                }
                return lProjekt_AusZulagen;
            }
            set
            {
                lProjekt_AusZulagen = value;
            }
        }

        private ArrayList lProjekte_Kaufmann = null;
        public ArrayList Projekte_Kaufmann
        {
            get
            {
                if (lProjekte_Kaufmann == null)
                {
                    lProjekte_Kaufmann = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lProjekte_Kaufmann = vpSelect("Select NAME, CAST(PROJID as VARCHAR(10)) from BAUPROJEKT " + Config.Nolock + " where mandant = '" + Bearbeiter.Mandant.MANDANT + "' order by name, ktobj");
                }
                return lProjekte_Kaufmann;
            }
            set
            {
                lProjekte_Kaufmann = value;
            }
        }

        private ArrayList lProjekteKO_Kaufmann = null;
        public ArrayList ProjekteKO_Kaufmann
        {
            get
            {
                if (lProjekteKO_Kaufmann == null)
                {
                    lProjekteKO_Kaufmann = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lProjekteKO_Kaufmann = vpSelect("Select KTOBJ, CAST(PROJID as VARCHAR(10)) from BAUPROJEKT " + Config.Nolock + " where mandant = '" + Bearbeiter.Mandant.MANDANT + "' order by name, ktobj");
                }
                return lProjekteKO_Kaufmann;
            }
            set
            {
                lProjekteKO_Kaufmann = value;
            }
        }

        private ArrayList lProjekte_Montageleiter = null;
        public ArrayList Projekte_Montageleiter
        {
            get
            {
                if (lProjekte_Montageleiter == null)
                {
                    lProjekte_Montageleiter = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt, Code wird aber nicht verwendet
                    // Defect 5771, Config.Nolock eingef�hrt, Code wird aber nicht verwendet
                    lProjekte_Montageleiter = vpSelect("Select NAME+' ('+KTOBJ+')', CAST(PROJID as VARCHAR(10)) from BAUPROJEKT " + Config.Nolock + " where MLPerskey = " + Bearbeiter.Params.PERSKEY.Value.ToString() + " and mandant = '" + Bearbeiter.Mandant.MANDANT + "' order by name, ktobj");
                }
                return lProjekte_Montageleiter;
            }
            set
            {
                lProjekte_Montageleiter = value;
            }
        }

        private ArrayList lMitarbeiter_Alle = null;
        public ArrayList Mitarbeiter_Alle
        {
            get
            {
                if (lMitarbeiter_Alle == null)
                {
                    lMitarbeiter_Alle = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lMitarbeiter_Alle = vpSelect("select Nachname+', '+Vorname+' (P:'+PERSNR+' K:'+ bearbtech.kst +')' as CTEXT, CAST(BEARBEIT.PERSKEY as VARCHAR(10))as CVALUE from BEARBEIT " + Config.Nolock + ", bearbtech " + Config.Nolock + " where Status = 20 and Mandant = '" + Bearbeiter.Mandant.MANDANT + "' and bearbtech.perskey = BEARBEIT.perskey order by Nachname, Vorname, Persnr");
                }
                return lMitarbeiter_Alle;
            }
            set
            {
                lMitarbeiter_Alle = value;
            }
        }

        private ArrayList lMitarbeiter_Sicht_Montageleiter = null;
        public ArrayList Mitarbeiter_Sicht_Montageleiter
        {
            get
            {
                if (lMitarbeiter_Sicht_Montageleiter == null)
                {
                    lMitarbeiter_Sicht_Montageleiter = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt, Code wird aber nicht verwendet
                    // Defect 5771, Config.Nolock eingef�hrt, Code wird aber nicht verwendet
                    lMitarbeiter_Sicht_Montageleiter = vpSelect("select Nachname+', '+Vorname+' ('+PERSNR+')' as CTEXT, CAST(PERSKEY as VARCHAR(10)) as CVALUE from BEARBEIT " + Config.Nolock + " where Status = 20 and Mandant = '" + Bearbeiter.Mandant.MANDANT + "' order by Nachname, Vorname, Persnr");
                }
                return lMitarbeiter_Sicht_Montageleiter;
            }
            set
            {
                lMitarbeiter_Sicht_Montageleiter = value;
            }
        }

        private ArrayList lLeistungsart = null;
        public ArrayList Leistungsart
        {
            get
            {
                if (lLeistungsart == null)
                {
                    lLeistungsart = new ArrayList();
                    string[] la = new string[] { "%", "4240%", "4240%", "2240%", "1240%", "%", "3240%", "3240%" };
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    lLeistungsart = vpSelect("select Leistart+' '+Leistarttxt, Leistart from y_Leistart " + Config.Nolock + " where status = 20 and Leistart like '" + la[Convert.ToInt32((Int16)Bearbeiter.TechParams.SOZSTELL.Value)] + "' and kost like (Select '%'+KST from BearbTech " + Config.Nolock + " where Perskey = " + Bearbeiter.Params.PERSKEY.Value.ToString() + ")");
                }
                return lLeistungsart;
            }
            set
            {
                lLeistungsart = value;
            }
        }

        //BAN 500059 Beginn
        private ArrayList lReisenTaetigkeiten = null;
        public ArrayList ReisenTaetigkeiten
        {
            get
            {
                if (lReisenTaetigkeiten == null)
                {
                    lReisenTaetigkeiten = new ArrayList();
                    lReisenTaetigkeiten = vpSelect("select RAKZTXT, RAKZ from y_rakz " + Config.Nolock + " where rakzid='RAM' and Status = 20 order by RAKZ");
                }
                return lReisenTaetigkeiten;
            }
            set
            {
                lReisenTaetigkeiten = value;
            }
        }
        //BAN 500059 Ende
        public DropDownList DDL(DropDownList d, string SelectedValue, ArrayList ListofValuePairs)
        {
            d.Items.Clear();
            foreach (ValuePair vp in ListofValuePairs)
            {
                d.Items.Add(new ListItem(vp.Text, vp.Value));
                if (vp.Value == SelectedValue) d.SelectedIndex = d.Items.Count - 1;
            }
            return d;
        }

        public DropDownList DDL2(DropDownList d, string SelectedValue, ArrayList ListofValuePairs, bool? kvOption)
        {
            d.Items.Clear();
            foreach (ValuePair vp in ListofValuePairs)
            {
                if (vp.Text.StartsWith("Freizeitoption lt. KV") && (kvOption == null || kvOption == false))
                    continue;
                d.Items.Add(new ListItem(vp.Text, vp.Value));
                if (vp.Value == SelectedValue)
                    d.SelectedIndex = d.Items.Count - 1;
            }
            return d;
        }

        private ArrayList SEGLohnarten()
        {
            ArrayList al = new ArrayList();
            string strSEGLohnarten = "";
            strSEGLohnarten = ConfigurationManager.AppSettings["SEGLohnarten"].ToString();
            while (strSEGLohnarten.Length > 0)
            {
                al.Add(strSEGLohnarten.Substring(0, strSEGLohnarten.IndexOf(";")));
                strSEGLohnarten = strSEGLohnarten.Substring(strSEGLohnarten.IndexOf(";") + 1);
            }
            return al;
        }
        private ArrayList lSEGPunkte = null;
        public ArrayList SEGPunkte
        {
            get
            {
                if (lSEGPunkte == null)
                {
                    ArrayList SEGLA = SEGLohnarten();
                    ArrayList AlleSEGLohnarten = new ArrayList();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    //AlleSEGLohnarten = vpSelect("select LOHNARTTXT+' ('+LOHNART+')' as CTEXT, LOHNART as CVALUE from y_lohnart2 " + Config.Nolock + " order by LOHNARTTXT");
                    AlleSEGLohnarten = vpSelect("select LOHNARTTXT+' ('+LOHNART+')' as CTEXT, LOHNART as CVALUE from y_lohnart3 " + Config.Nolock + " where MANDANT = '" + Bearbeiter.Params.MANDANT.Value.ToString() + "' and status = 20 order by LOHNARTTXT");
                    lSEGPunkte = new ArrayList();
                    //for (int i = 0; i <= 7; i++)
                    foreach (ValuePair v in AlleSEGLohnarten)
                        foreach (string s in SEGLA)
                            if (v.Value == s)
                                lSEGPunkte.Add(new ValuePair(v.Text, v.Value));
                }
                return lSEGPunkte;
            }
            set
            {
                lSEGPunkte = value;
            }
        }

        // Beginn CR 4655
        // Auswahlliste Mitarbeiter Status bef�llen f�r Selektion EB und RA 
        private ArrayList lMAStatus = null;
        public ArrayList MAStatus
        {
            get
            {
                if (lMAStatus == null)
                {
                    lMAStatus = new ArrayList();
                    lMAStatus.Add(new ValuePair("Aktive", "20"));
                    lMAStatus.Add(new ValuePair("Inaktive", "40"));
                    //lMAStatus.Add(new ValuePair("Alle", "20, 40"));
                }
                return lMAStatus;
            }
            set
            {
                lMAStatus = value;
            }
        }
        // Ende CR 4655


        //CR 4931
        //GN 14.5.2007 neue Liste
        //Beginn
        private ArrayList lAnzMitfahrer = null;
        public ArrayList AnzMitfahrer
        {
            get
            {
                if (lAnzMitfahrer == null)
                {
                    lAnzMitfahrer = new ArrayList();
                    lAnzMitfahrer.Add(new ValuePair("0", "0"));

                    string configString = ConfigurationManager.AppSettings["AnzMitfahrer"];
                    if (configString != null)
                    {
                        try
                        {
                            int configNumber = Int16.Parse(configString);

                            //Erzeugt Eintr�ge von 1 bis configNumber
                            for (int i = 1; i <= configNumber; i++)
                            {
                                string s = i.ToString();
                                lAnzMitfahrer.Add(new ValuePair(s, s));
                            }

                        }
                        catch (Exception) { }
                    }

                }
                return lAnzMitfahrer;
            }
        }
        // Ende CR 4931

        // Beginn Defect 4099:
        // Auswahlliste Anzeige ab Monat f�r ganzt�gige Absenzen bef�llen
        // default: Berichtsmonat - 1
        private ArrayList lAbsenzMonat = null;
        public ArrayList AbsenzMonat
        {
            get
            {
                if (lAbsenzMonat == null)
                {
                    lAbsenzMonat = new ArrayList();
                    DateTime dtEnd = DateTime.Now;
                    DateTime dtCur = new DateTime(2006, 09, 01);

                    while (dtCur.Year != dtEnd.Year ||
                          dtCur.Month != dtEnd.Month)
                    {
                        dtCur = dtCur.AddMonths(1);
                        lAbsenzMonat.Add(new ValuePair(dtCur.Month.ToString() + "/" +
                                                       dtCur.Year.ToString(),
                                                       dtCur.ToShortDateString()));
                    }
                }
                return lAbsenzMonat;
            }
            set
            {
                lAbsenzMonat = value;
            }
        }
        // Ende Defect 4099
        //MC49359 - Beginn - Select alle PLZ und Ort aus dbo.Reiseziel
        private ArrayList lAlleOrtschaften = null;
        public ArrayList AlleOrtschaften
        {
            get
            {
                if (lAlleOrtschaften == null)
                {
                    ArrayList ReiseZiel = new ArrayList();
                    ReiseZiel = vpSelect("select Postleitzahl as CTEXT, Ortschaftsname as CVALUE from reiseziel");
                    lAlleOrtschaften = new ArrayList();
                    foreach (ValuePair v in ReiseZiel)
                    {
                        lAlleOrtschaften.Add(new ValuePair(v.Text + " - " + v.Value, v.Text + "|" + v.Value));
                    }
                }
                return lAlleOrtschaften;
            }
        }
    }   //MC49359 - Ende
}
