//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbRaZeile.cs
//
// Description  : DB-Zugriffe f�r Reisezeilen und K�pfe
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== V1.0.0049 ===============================================
//
// Date         : 08.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAF 530023 
//                BERMON hinzugef�gt
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0034 ===============================================
//
// Date         : 27.August 2007
// Author       : Norbert Krizek
// Defect#      : 5363 
//                Update von bereits in SAP eingetragenen Reisezeilen aus Vormonat
//                pr�fung ob reisezeilen auch innerhalb des berichtsmonats liegen
//
//--------------- V1.0.0032 --------------------------------------------------- *
// Date         : 2. August 2007
// Author       : NK
// Defect#      : 5335
//                Servererror bei genehmigung hr. Ryba monat 07
//                test f�r exception
// 
//--------------- V1.0.0027 --------------------------------------------------------------------------------
//
// Date         : 16. M�rz 2007
// Author       : GN
// Defect#      : 4931
//                Neues Feld 'Anzahl Mitfahrer'
//
//--------------- V1.0.0023 --------------------------------------------------------------------------------
//
// Date         : 12. M�rz 2007
// Author       : GN
// Defect#      : 4791
//
// Bei einem Mitarbeiter kam keine Teilabrechnung am Monatsanfang. 
// Ursache war falsche Sortierung der Daten aus der DB.
// Nun wird explizit nach RAID sortiert.
//
//
// Date         : 6. M�rz 2007
// Author       : GN
// Defect#      : 4710
// 
// Aus noch ungekl�rten Ursachen wird die RAID der Zeile manchmal 0.
// Wenn die Zeile eingef�gt wird, schaltet ein Trigger, der einen Fehler wirft.
// Im RaKopf ist aber sowieso die richtige ID vorhanden, darum wird einfach die genommen.
//
//--------------- V1.0.0022 --------------------------------------------------------------------------------
//
// Date         : 24. Februar 2007
// Author       : GN
// Defect#      : 4625
//                Wir haben in der Datenbank f�r Berichtsmonat J�nner ca. 800 R/W Zeilen ohne Leistungsart.
//                Transaktionsthema
//
// --------------------------------------------------------------------------------------------------------


using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{

    public class dbRaZeile_Params
    {
        public SqlParameter RAID = new SqlParameter("@RAID", int.MinValue);
        public SqlParameter LFDNR = new SqlParameter("@LFDNR", int.MinValue);
        public SqlParameter ZNR = new SqlParameter("@ZNR", (string)"");
        public SqlParameter ZEILENKZ = new SqlParameter("@ZEILENKZ", (string)"");
        public SqlParameter VERKEHRSMITTEL = new SqlParameter("@VERKEHRSMITTEL", (string)"");
        public SqlParameter DAT = new SqlParameter("@DAT", ParamVal.Date0);
        public SqlParameter AB = new SqlParameter("@AB", ParamVal.Date0);
        public SqlParameter AN = new SqlParameter("@AN", ParamVal.Date0);
        public SqlParameter LKZ = new SqlParameter("@LKZ", (string)"");
        public SqlParameter REISEART = new SqlParameter("@REISEART", (string)"");
        public SqlParameter BEREITST = new SqlParameter("@BEREITST", (string)"");
        public SqlParameter AUSLART = new SqlParameter("@AUSLART", (string)"");
        public SqlParameter ANZNAECHTE = new SqlParameter("@ANZNAECHTE", (string)"");
        public SqlParameter BETRAG = new SqlParameter("@BETRAG", (string)"");
        public SqlParameter WAEHR = new SqlParameter("@WAEHR", (string)"");
        public SqlParameter AUSLBEMERK = new SqlParameter("@AUSLBEMERK", (string)"");
        public SqlParameter PROZ = new SqlParameter("@PROZ", (string)"");
        public SqlParameter BESCHREIB = new SqlParameter("@BESCHREIB", (string)"");
        public SqlParameter ZWECK = new SqlParameter("@ZWECK", (string)"");
        public SqlParameter ABORT = new SqlParameter("@ABORT", (string)"");
        public SqlParameter ANORT = new SqlParameter("@ANORT", (string)"");
        public SqlParameter ABKM = new SqlParameter("@ABKM", (string)"");
        public SqlParameter GEFKM = new SqlParameter("@GEFKM", (string)"");
        public SqlParameter SCHWERGP = new SqlParameter("@SCHWERGP", (string)"");
        public SqlParameter MWST = new SqlParameter("@MWST", (string)"");
        public SqlParameter VERMBETRAG = new SqlParameter("@VERMBETRAG", (string)"");
        public SqlParameter VERMWAEHR = new SqlParameter("@VERMWAEHR", (string)"");
        public SqlParameter VERMSONST = new SqlParameter("@VERMSONST", (string)"");
        public SqlParameter DATLA = new SqlParameter("@DATLA", ParamVal.Date0);
        public SqlParameter AENPERSKEY = new SqlParameter("@AENPERSKEY", int.MinValue);
        public SqlParameter DATNEU = new SqlParameter("@DATNEU", ParamVal.Date0);
        public SqlParameter INTF_ID = new SqlParameter("@INTF_ID", Int16.MinValue);
        public SqlParameter ABID = new SqlParameter("@ABID", (string)""); // B-BauID oder S-STDID
        public SqlParameter ANID = new SqlParameter("@ANID", (string)"");// B-BauID oder S-STDID
        public SqlParameter EBID = new SqlParameter("@EBID", int.MinValue);
        public SqlParameter RAKZTXT = new SqlParameter("@RAKZTXT", (string)""); //Text zum Verkehrsmittel
        public SqlParameter BSTXT = new SqlParameter("@BSTXT", (string)""); //Text zur Breitstellung
        public SqlParameter MITFAHRER = new SqlParameter("@MITFAHRER", Int32.MinValue); //CR 4931 Feld hinzugef�gt

        public ArrayList List = new ArrayList();
        public dbRaZeile_Params()
        {
            List.Add(RAID);
            List.Add(LFDNR);
            List.Add(ZNR);
            List.Add(ZEILENKZ);
            List.Add(VERKEHRSMITTEL);
            List.Add(DAT);
            List.Add(AB);
            List.Add(AN);
            List.Add(LKZ);
            List.Add(REISEART);
            List.Add(BEREITST);
            List.Add(AUSLART);
            List.Add(ANZNAECHTE);
            List.Add(BETRAG);
            List.Add(WAEHR);
            List.Add(AUSLBEMERK);
            List.Add(PROZ);
            List.Add(BESCHREIB);
            List.Add(ZWECK);
            List.Add(ABORT);
            List.Add(ANORT);
            List.Add(ABKM);
            List.Add(GEFKM);
            List.Add(SCHWERGP);
            List.Add(MWST);
            List.Add(VERMBETRAG);
            List.Add(VERMWAEHR);
            List.Add(VERMSONST);
            List.Add(DATLA);
            List.Add(AENPERSKEY);
            List.Add(DATNEU);
            List.Add(INTF_ID);
            List.Add(ABID);
            List.Add(ANID);
            List.Add(RAKZTXT);
            List.Add(BSTXT);
            List.Add(EBID);
            List.Add(MITFAHRER); //CR 4931 Feld hinzugef�gt
            ParamVal.SetDefaultValues(List);
        }
    }

    public class dbRaKopf_Params
    {
        public SqlParameter RAID = new SqlParameter("@RAID", int.MinValue);
        public SqlParameter ABRNR = new SqlParameter("@ABRNR", int.MinValue);	 //EBID
        public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
        public SqlParameter STATUS = new SqlParameter("@STATUS", (string)"");
        public SqlParameter ART = new SqlParameter("@ART", (string)"");
        public SqlParameter HAUPTREISE = new SqlParameter("@HAUPTREISE", (string)"");
        public SqlParameter WAGENTYPE = new SqlParameter("@WAGENTYPE", (string)"");
        public SqlParameter POLKZ = new SqlParameter("@POLKZ", (string)"");
        public SqlParameter HUBRAUM = new SqlParameter("@HUBRAUM", (string)"");
        public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", int.MinValue);
        public SqlParameter FIRMA = new SqlParameter("@FIRMA", (string)"");
        public SqlParameter PERSNR = new SqlParameter("@PERSNR", (string)"");
        public SqlParameter NAME = new SqlParameter("@NAME", (string)"");
        public SqlParameter VORNAME = new SqlParameter("@VORNAME", (string)"");
        public SqlParameter BEARBEITER = new SqlParameter("@BEARBEITER", (string)"");
        public SqlParameter BEARBDAT = new SqlParameter("@BEARBDAT", ParamVal.Date0);
        public SqlParameter TEXT = new SqlParameter("@TEXT", (string)"");
        public SqlParameter STANDORT = new SqlParameter("@STANDORT", (string)"");
        public SqlParameter DSTBER = new SqlParameter("@DSTBER", (string)"");
        public SqlParameter DATLASRV = new SqlParameter("@DATLASRV", ParamVal.Date0);
        public SqlParameter DATLA = new SqlParameter("@DATLA", ParamVal.Date0);
        public SqlParameter AENPERSKEY = new SqlParameter("@AENPERSKEY", int.MinValue);
        public SqlParameter DATNEU = new SqlParameter("@DATNEU", ParamVal.Date0);
        public SqlParameter RASTAT = new SqlParameter("@RASTAT", Int16.MinValue);
        public SqlParameter VORGESKEY = new SqlParameter("@VORGESKEY", Int16.MinValue);
        public SqlParameter RAHIST = new SqlParameter("@RAHIST", (string)"");
        public SqlParameter REGION = new SqlParameter("@REGION", (string)"");
        public SqlParameter KURSFREMDW = new SqlParameter("@KURSFREMDW", float.MinValue);
        public SqlParameter KURSEIGENW = new SqlParameter("@KURSEIGENW", float.MinValue);
        public SqlParameter VGPERSKEY = new SqlParameter("@VGPERSKEY", int.MinValue);
        public SqlParameter BERMON = new SqlParameter("@BERMON", ParamVal.Date0);//BAF 530023 BERMON hinzugef�gt
        public ArrayList List = new ArrayList();
        public dbRaKopf_Params()
        {
            List.Add(RAID);
            List.Add(ABRNR);
            List.Add(MANDANT);
            List.Add(STATUS);
            List.Add(ART);
            List.Add(HAUPTREISE);
            List.Add(WAGENTYPE);
            List.Add(POLKZ);
            List.Add(HUBRAUM);
            List.Add(PERSKEY);
            List.Add(FIRMA);
            List.Add(PERSNR);
            List.Add(NAME);
            List.Add(VORNAME);
            List.Add(BEARBEITER);
            List.Add(BEARBDAT);
            List.Add(TEXT);
            List.Add(STANDORT);
            List.Add(DSTBER);
            List.Add(DATLASRV);
            List.Add(DATLA);
            List.Add(AENPERSKEY);
            List.Add(DATNEU);
            List.Add(RASTAT);
            List.Add(VORGESKEY);
            List.Add(RAHIST);
            List.Add(REGION);
            List.Add(KURSFREMDW);
            List.Add(KURSEIGENW);
            List.Add(VGPERSKEY);
            List.Add(BERMON); //BAF 530023 BERMON hinzugef�gt
            ParamVal.SetDefaultValues(List);
        }
    }

    public class dbRaKopf
    {
        public enum RaStati { KeinStatus = 0, InArbeit = 10, Freigegeben = 30 /* BAN 500059 */, Genehmigt = 40, Uebertragen = 80 };
        public dbKG_Reise Reise;
        public RaStati RaStat
        {
            get
            {
                return (RaStati)(int)Params.RASTAT.Value;
            }
            set
            {
                Params.RASTAT.Value = (int)value;
            }
        }
        public dbBearbeiter Bearbeiter;
        public dbRaKopf_Params Params = new dbRaKopf_Params();
        public ArrayList Zeilen = new ArrayList();
        private int lBerichtsmonat = 0;
        public DateTime MinDatum;
        public DateTime MaxDatum;
        public bool AllowUpdate = false;
        public bool Deleted = false;
        public int lfdnr = 1;
        public int Berichtsmonat
        {
            get { return lBerichtsmonat; }
            set
            {
                lBerichtsmonat = value;
                int Year = Convert.ToInt32(Math.Truncate((double)lBerichtsmonat / 100));
                int Month = Convert.ToInt32(((double)lBerichtsmonat) - Year * 100);
                DateTime rd = DateTime.Now;
                rd = rd.AddDays(-rd.Day + 1);
                rd = rd.AddMonths(-rd.Month + Month);
                rd = rd.AddYears(-rd.Year + Year);
                MinDatum = Convert.ToDateTime(rd.ToShortDateString() + " 00:00:00");
                rd = MinDatum.AddMonths(1).AddSeconds(-1);
                MaxDatum = Convert.ToDateTime(rd.ToShortDateString() + " 23:59:59");
                Params.BERMON.Value = MinDatum;
            }
        }
        public dbRaKopf(dbBearbeiter bearb, int BerichtsMonat, dbKG_Reise reise)
        {
            Bearbeiter = bearb;
            Berichtsmonat = BerichtsMonat;
            Reise = reise;
        }
        #region SQLStrings
        // Defect 5725, Config.Rowlock eingef�hrt
        // Defect 5771, Config.Nolock eingef�hrt
        private string sqlSelectRA =
            //@"select k.RAID as RAID,LFDNR,ZNR,ZEILENKZ,VERKEHRSMITTEL,DAT,AB,AN,LKZ,REISEART,BEREITST,AUSLART,ANZNAECHTE,BETRAG,WAEHR,AUSLBEMERK,PROZ,BESCHREIB,ZWECK,ABORT,ANORT,ABKM,GEFKM,SCHWERGP,MWST,VERMBETRAG,VERMWAEHR,VERMSONST,k.DATLA as DATLA,k.AENPERSKEY as AENPERSKEY,k.DATNEU as DATNEU,INTF_ID, v.RAKZTXT as RAKZTXT, ABID, ANID, EBID  from razeile, rakopf k, y_rakz v where  dat >= @VONDATUM and dat <= @BISDATUM and k.perskey = @PERSKEY and k.raid = razeile.raid and v.RAKZID = 'VM' and v.RAKZ = razeile.VERKEHRSMITTEL";
            // Defect# 4791: Bei einem Mitarbeiter kam keine Teilabrechnung am Monatsanfang. ursache war falsche Sortierung  der Daten aus der DB.Nun wird explizit nach RAID sortiert.
            //GN 12.03.2007
            //@"select k.RAID as RAID,LFDNR,ZNR,ZEILENKZ,VERKEHRSMITTEL,DAT,AB,AN,LKZ,REISEART,BEREITST,AUSLART,ANZNAECHTE,BETRAG,WAEHR,AUSLBEMERK,PROZ,BESCHREIB,ZWECK,ABORT,ANORT,ABKM,GEFKM,SCHWERGP,MWST,VERMBETRAG,VERMWAEHR,VERMSONST,k.DATLA as DATLA,k.AENPERSKEY as AENPERSKEY,k.DATNEU as DATNEU,INTF_ID, v1.RAKZTXT as RAKZTXT, v2.RAKZTXT as BSTXT, ABID, ANID, EBID from razeile " + Config.Nolock + ", rakopf k " + Config.Nolock + ", y_rakz v1 " + Config.Nolock + ", y_rakz v2 " + Config.Nolock + " where dat >= @VONDATUM and dat <= @BISDATUM and k.perskey = @PERSKEY and k.raid = razeile.raid and v1.RAKZID = 'VM' and v1.RAKZ = razeile.VERKEHRSMITTEL and v2.RAKZID = 'B' and v2.RAKZ = razeile.BEREITST ORDER BY RAID, EBID"; //31.01.07 GN wegen fehlender Teilabrechnung hinzugef�gt
            @"select k.RAID as RAID,LFDNR,ZNR,ZEILENKZ,VERKEHRSMITTEL,DAT,AB,AN,LKZ,REISEART,BEREITST,AUSLART,ANZNAECHTE,BETRAG,WAEHR,AUSLBEMERK,PROZ,BESCHREIB,ZWECK,ABORT,ANORT,ABKM,GEFKM,SCHWERGP,MWST,VERMBETRAG,VERMWAEHR,VERMSONST,k.DATLA as DATLA,k.AENPERSKEY as AENPERSKEY,k.DATNEU as DATNEU,INTF_ID, v1.RAKZTXT as RAKZTXT, v2.RAKZTXT as BSTXT, ABID, ANID, EBID from razeile " + Config.Nolock + ", rakopf k " + Config.Nolock + ", y_rakz v1 " + Config.Nolock + ", y_rakz v2 " + Config.Nolock + " where k.bermon = @BERMON and k.perskey = @PERSKEY and k.raid = razeile.raid and v1.RAKZID = 'VM' and v1.RAKZ = razeile.VERKEHRSMITTEL and v2.RAKZID = 'B' and v2.RAKZ = razeile.BEREITST ORDER BY RAID, EBID"; //BAF 530023 BERMON hinzugef�gt
        private string sqlSelectRAKOPF =
            //@"select RAID,ABRNR,MANDANT,STATUS,ART,HAUPTREISE,WAGENTYPE,POLKZ,HUBRAUM,PERSKEY,FIRMA,PERSNR,NAME,VORNAME,BEARBEITER,BEARBDAT,TEXT,STANDORT,DSTBER,DATLASRV,DATLA,AENPERSKEY,DATNEU,RASTAT,VORGESKEY,RAHIST,REGION,KURSFREMDW,KURSEIGENW,VGPERSKEY from RAKOPF " + Config.Nolock + " where RAID = @RAID";
            @"select RAID,ABRNR,MANDANT,STATUS,ART,HAUPTREISE,WAGENTYPE,POLKZ,HUBRAUM,PERSKEY,FIRMA,PERSNR,NAME,VORNAME,BEARBEITER,BEARBDAT,TEXT,STANDORT,DSTBER,DATLASRV,DATLA,AENPERSKEY,DATNEU,RASTAT,VORGESKEY,RAHIST,REGION,KURSFREMDW,KURSEIGENW,VGPERSKEY,BERMON from RAKOPF " + Config.Nolock + " where RAID = @RAID";
        private string sqlInsertRAKOPF =
            //@"insert into RAKOPF " + Config.Rowlock + " (RAID,ABRNR,MANDANT,STATUS,ART,HAUPTREISE,WAGENTYPE,POLKZ,HUBRAUM,PERSKEY,FIRMA,PERSNR,NAME,VORNAME,BEARBEITER,BEARBDAT,TEXT,STANDORT,DSTBER,DATLASRV,DATLA,AENPERSKEY,DATNEU,RASTAT,VORGESKEY,RAHIST,REGION,KURSFREMDW,KURSEIGENW,VGPERSKEY) VALUES (@RAID,@ABRNR,@MANDANT,@STATUS,@ART,@HAUPTREISE,@WAGENTYPE,@POLKZ,@HUBRAUM,@PERSKEY,@FIRMA,@PERSNR,@NAME,@VORNAME,@BEARBEITER,@BEARBDAT,@TEXT,@STANDORT,@DSTBER,@DATLASRV,@DATLA,@AENPERSKEY,@DATNEU,@RASTAT,@VORGESKEY,@RAHIST,@REGION,@KURSFREMDW,@KURSEIGENW,@VGPERSKEY)";
            @"insert into RAKOPF " + Config.Rowlock + " (RAID,ABRNR,MANDANT,STATUS,ART,HAUPTREISE,WAGENTYPE,POLKZ,HUBRAUM,PERSKEY,FIRMA,PERSNR,NAME,VORNAME,BEARBEITER,BEARBDAT,TEXT,STANDORT,DSTBER,DATLASRV,DATLA,AENPERSKEY,DATNEU,RASTAT,VORGESKEY,RAHIST,REGION,KURSFREMDW,KURSEIGENW,VGPERSKEY,BERMON) VALUES (@RAID,@ABRNR,@MANDANT,@STATUS,@ART,@HAUPTREISE,@WAGENTYPE,@POLKZ,@HUBRAUM,@PERSKEY,@FIRMA,@PERSNR,@NAME,@VORNAME,@BEARBEITER,@BEARBDAT,@TEXT,@STANDORT,@DSTBER,@DATLASRV,@DATLA,@AENPERSKEY,@DATNEU,@RASTAT,@VORGESKEY,@RAHIST,@REGION,@KURSFREMDW,@KURSEIGENW,@VGPERSKEY,@BERMON)";
        private string sqlUpdateRAKOPF =
            //@"Update RAKOPF " + Config.Rowlock + " set ABRNR  = @ABRNR,MANDANT  = @MANDANT,STATUS  = @STATUS,ART  = @ART,HAUPTREISE  = @HAUPTREISE,WAGENTYPE  = @WAGENTYPE,POLKZ  = @POLKZ,HUBRAUM  = @HUBRAUM,PERSKEY  = @PERSKEY,FIRMA  = @FIRMA,PERSNR  = @PERSNR,NAME  = @NAME,VORNAME  = @VORNAME,BEARBEITER  = @BEARBEITER,BEARBDAT  = @BEARBDAT,TEXT  = @TEXT,STANDORT  = @STANDORT,DSTBER  = @DSTBER,DATLASRV  = @DATLASRV,DATLA  = @DATLA,AENPERSKEY  = @AENPERSKEY,DATNEU  = @DATNEU,RASTAT  = @RASTAT,VORGESKEY  = @VORGESKEY,RAHIST  = @RAHIST,REGION  = @REGION,KURSFREMDW  = @KURSFREMDW,KURSEIGENW  = @KURSEIGENW,VGPERSKEY  = @VGPERSKEY where RAID = @RAID";
            @"Update RAKOPF " + Config.Rowlock + " set ABRNR  = @ABRNR,MANDANT  = @MANDANT,STATUS  = @STATUS,ART  = @ART,HAUPTREISE  = @HAUPTREISE,WAGENTYPE  = @WAGENTYPE,POLKZ  = @POLKZ,HUBRAUM  = @HUBRAUM,PERSKEY  = @PERSKEY,FIRMA  = @FIRMA,PERSNR  = @PERSNR,NAME  = @NAME,VORNAME  = @VORNAME,BEARBEITER  = @BEARBEITER,BEARBDAT  = @BEARBDAT,TEXT  = @TEXT,STANDORT  = @STANDORT,DSTBER  = @DSTBER,DATLASRV  = @DATLASRV,DATLA  = @DATLA,AENPERSKEY  = @AENPERSKEY,DATNEU  = @DATNEU,RASTAT  = @RASTAT,VORGESKEY  = @VORGESKEY,RAHIST  = @RAHIST,REGION  = @REGION,KURSFREMDW  = @KURSFREMDW,KURSEIGENW  = @KURSEIGENW,VGPERSKEY  = @VGPERSKEY, BERMON = @BERMON where RAID = @RAID";
        private string sqlDeleteRAKOPF =
            @"Delete from RAKOPF " + Config.Rowlock + " where RAID = @RAID";

        #endregion
        public ArrayList SelectAll()
        {
            ArrayList al = new ArrayList();
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlSelectRA, cnx)) // Defect 5436, using eingef�hrt
                    {
                        //SqlParameter von = new SqlParameter("@VONDATUM", MinDatum);
                        //SqlParameter bis = new SqlParameter("@BISDATUM", MaxDatum);
                        //SqlParameter perskey = new SqlParameter("@PERSKEY", Bearbeiter.Params.PERSKEY.Value);
                        //cmd.Parameters.Add(von);
                        //cmd.Parameters.Add(bis);
                        //cmd.Parameters.Add(perskey);
                        cmd.Parameters.Add(new SqlParameter("@BERMON", MinDatum));
                        cmd.Parameters.Add(new SqlParameter("@PERSKEY", Bearbeiter.Params.PERSKEY.Value));
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Clear();
                            dbRaKopf rk = null;
                            while (rd.Read())
                            {
                                if (rk == null) rk = new dbRaKopf(Bearbeiter, Berichtsmonat, Reise);
                                if ((int)rk.Params.RAID.Value != rd.GetInt32(0))
                                {
                                    if ((int)rk.Params.RAID.Value > 0)
                                    {
                                        al.Add(rk);
                                        rk = new dbRaKopf(Bearbeiter, Berichtsmonat, Reise);
                                    }
                                    rk.Params.RAID.Value = rd.GetInt32(0);
                                    rk.SelectRakopf();
                                }
                                //bugsy
                                Reise.Zeilen.Add(new dbKG_ReiseZeile(Reise, null));
                                dbRaZeile rz = new dbRaZeile(this, (dbKG_ReiseZeile)Reise.Zeilen[Reise.Zeilen.Count - 1]);
                                (Reise.Zeilen[Reise.Zeilen.Count - 1] as dbKG_ReiseZeile).Zeile = rz;
                                ParamVal.DataReader2Params(rd, rz.Params.List);
                                if (rz.Params.ZEILENKZ.Value.ToString() == "")
                                    rz.Params.ZEILENKZ.Value = "L";
                                rz.AllowUpdate = true;
                                if ((int)rz.Params.LFDNR.Value > lfdnr) lfdnr = (int)rz.Params.LFDNR.Value;
                                rk.Zeilen.Add(rz);
                                AllowUpdate = true;
                            }
                            if (rk != null) al.Add(rk);
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return al;
        }
        private bool SelectRakopf()
        {
            AllowUpdate = false;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlSelectRAKOPF, cnx)) // Defect 5436
                    {
                        cmd.Parameters.Add(Params.RAID);
                        using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
                        {
                            cmd.Parameters.Remove(Params.RAID);
                            while (rd.Read())
                            {
                                ParamVal.DataReader2Params(rd, Params.List);
                                AllowUpdate = true;
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return AllowUpdate;
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren
        public void Save()
        {
            Save(null);
        }


        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        public void Save(SqlTransaction tx)
        {
            // defect 5363 beginn: pr�fung ob reisezeilen auch innerhalb des berichtsmonats liegen
            int ber_jahr = Convert.ToInt16(this.Berichtsmonat.ToString().Substring(0, 4));
            int ber_monat = Convert.ToInt16(this.Berichtsmonat.ToString().Substring(4, 2));

            DateTime r_von_nextday = this.Reise.Von.AddDays(1);
            DateTime r_von_prevday = this.Reise.Von.AddDays(-1);
            DateTime r_von = this.Reise.Von;
            DateTime r_bis_nextday = this.Reise.Bis.AddDays(1);
            DateTime r_bis_prevday = this.Reise.Bis.AddDays(-1);
            DateTime r_bis = this.Reise.Bis;
            // wir pr�fen, ob dea von oder bis im monat liegt, auch einen tag vor oder nach dem monat
            // das ist jetzt ein tag im vormonat
            if ((r_von_nextday.Month == ber_monat) && (r_von_nextday.Year == ber_jahr) && (r_von_nextday.Day == 1))
            {
                r_von = r_von_nextday;
            }
            // das ist jetzt ein tag im n�chten monat
            if ((r_von_prevday.Month == ber_monat) && (r_von_prevday.Year == ber_jahr) && (r_von.Day == 1))
            {
                r_von = r_von_prevday;
            }


            // loop �ber die zeilen                            
            foreach (dbKG_ReiseZeile z in this.Reise.Zeilen) // war vorher this.Zeilen bring aber ne eception sporadisch ???
            {
                DateTime z_ab_nextday = z.Ab.AddDays(1);
                DateTime z_ab_prevday = z.Ab.AddDays(-1);
                DateTime z_ab = z.Ab;
                // wir pr�fen, ob der von oder bis im monat liegt, auch einen tag vor oder nach dem monat
                // das ist jetzt ein tag im vormonat
                if ((z_ab_nextday.Month == ber_monat) && (z_ab_nextday.Year == ber_jahr) && (z_ab_nextday.Day == 1))
                {
                    z_ab = z_ab_nextday;
                }
                // das ist jetzt ein tag im n�chten monat
                if ((z_ab_prevday.Month == ber_monat) && (z_ab_prevday.Year == ber_jahr) && (z.Ab.Day == 1))
                {
                    z_ab = z_ab_prevday;
                }
                DateTime z_an_nextday = z.An.AddDays(1);
                DateTime z_an_prevday = z.An.AddDays(-1);
                DateTime z_an = z.An;
                // wir pr�fen, ob das von oder bis im monat liegt, auch einen tag vor oder nach dem monat
                // das ist jetzt ein tag im vormonat
                if ((z_an_nextday.Month == ber_monat) && (z_an_nextday.Year == ber_jahr) && (z_an_nextday.Day == 1))
                {
                    z_an = z_an_nextday;
                }
                // das ist jetzt ein tag im n�chten monat
                if ((z_an_prevday.Month == ber_monat) && (z_an_prevday.Year == ber_jahr) && (z.An.Day == 1))
                {
                    z_an = z_an_prevday;
                }
                //DateTime z_an_nextday = z.An.AddDays(1);
                //DateTime z_an_prevday = z.An.AddDays(-1);
                //DateTime z_ReiseTag = z.ReiseTag;
                // jetzt sind die tage aus dem vor un folgemonat bereinigt, jetzt pr�fen wir das auf aktuelle monat
                if ((
                      ((z.Typ == dbKG_ReiseZeilenTyp.Hinfahrt)
                         || (z.Typ == dbKG_ReiseZeilenTyp.Rueckfahrt)
                         || (z.Typ == dbKG_ReiseZeilenTyp.StandortWechsel)
                         || (z.Typ == dbKG_ReiseZeilenTyp.Teilabrechnung)
                      )
                      &&
                      (((z_an.Month != ber_monat) || (z_an.Year != ber_jahr))
                          || ((z_an.Month != ber_monat) || (z_an.Year != ber_jahr))
                      )
                      &&
                      (((z_ab.Month != ber_monat) || (z_ab.Year != ber_jahr))
                          || ((z_ab.Month != ber_monat) || (z_ab.Year != ber_jahr))
                      )
                    )
                    ||
                    ((z.Typ == dbKG_ReiseZeilenTyp.Belegzeile)
                      &&
                      ((z.ReiseTag.Month != ber_monat) || (z.ReiseTag.Year != ber_jahr))
                    )
                   )
                {
                    // da ist was faul im staate reisen...wir werfen ne exception...
                    Exception ex2 = new Exception("dbRaZeile::Save: Reisemonat falsch: Reise.Berichtsmonat = " + this.Berichtsmonat.ToString()
                        + ", Typ = " + z.Typ.ToString()
                        + ", ReiseZeile.Ab = " + z.Ab.ToString()
                        + ", ReiseZeile.An = " + z.An.ToString()
                        + ", ReiseZeile.ReiseTag = " + z.ReiseTag.ToString()
                        )
                        ;
                    throw ex2; // wir schwirren mal ab...defect 5363

                }
            }
            // defect 5363 ende
            if (AllowUpdate)
            {
                if (Deleted) Delete(tx);
                else Update(tx);
            }
            else
            {
                if (!Deleted) Insert(tx);
            }
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.

        private void Insert(SqlTransaction tx)
        {

            bool inTransaction = tx != null;

            Params.RAID.Value = Bearbeiter.Commons.GetNextID(16, "Reiseabrechnung");
            SqlConnection cnx = null;
            if (!inTransaction)
            {
                cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                cnx.Open();
            }
            else cnx = tx.Connection;

            using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sqlInsertRAKOPF, cnx, tx) : new SqlCommand(sqlInsertRAKOPF, cnx)) // Defect 5436
            {
                foreach (SqlParameter s in Params.List) cmd.Parameters.Add(s);
                AllowUpdate = (cmd.ExecuteNonQuery() > 0);
                foreach (SqlParameter s in Params.List) cmd.Parameters.Remove(s);
                lfdnr = 1;
                foreach (dbKG_ReiseZeile z in Zeilen)
                    z.Zeile.Save(tx);

                if (!inTransaction) cnx.Close();
            }
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        private void Update(SqlTransaction tx)
        {

            bool inTransaction = tx != null;

            SqlConnection cnx = null;
            try
            {

                if (!inTransaction)
                {
                    cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                    cnx.Open();
                }
                else cnx = tx.Connection;


                foreach (dbRaZeile z in Zeilen) z.Deleted = true; //erst mal alle Zeile l�schen
                foreach (dbRaZeile z in Zeilen) z.Save(tx);
                foreach (dbRaZeile z in Zeilen) z.Deleted = false; //f�rs wiedereinf�gen

                using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sqlUpdateRAKOPF, cnx, tx) : new SqlCommand(sqlUpdateRAKOPF, cnx)) // Defect 5436
                {
                    foreach (SqlParameter s in Params.List) cmd.Parameters.Add(s);
                    AllowUpdate = (cmd.ExecuteNonQuery() > 0);
                    foreach (SqlParameter s in Params.List) cmd.Parameters.Remove(s);
                    lfdnr = 1;

                    foreach (dbRaZeile z in Zeilen)
                    {
                        //Defect 4710
                        //GN 6.3.2007 RAID wird 0
                        //Aus noch ungekl�rten Ursachen wird die RAID der Zeile manchmal 0.
                        //Wenn die Zeile eingef�gt wird, schaltet ein Trigger, der einen Fwehler wirft
                        //Im RaKopf ist aber sowieso die richtige id vorhanden, darum wird einfach die genommen.
                        if (z.RaKopf.Params.RAID.Value.ToString() == "0")
                        {
                            z.RaKopf.Params.RAID.Value = this.Params.RAID.Value;
                            z.Params.RAID.Value = this.Params.RAID.Value;
                        }
                        z.Save(tx);
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { if (!inTransaction)cnx.Close(); }

        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        private void Delete(SqlTransaction tx)
        {
            bool inTransaction = tx != null;

            SqlConnection cnx = null;
            try
            {

                if (!inTransaction)
                {
                    cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                    cnx.Open();
                }
                else cnx = tx.Connection;

                foreach (dbRaZeile z in Zeilen) z.Deleted = true;
                foreach (dbRaZeile z in Zeilen) z.Save(tx);
                /*int lfdnr = 0;
                foreach ( dbKG_ReiseZeile z in Zeilen)
                {
                    dbRaZeile rz = new dbRaZeile(this, z);
                    rz.Params.RAID = this.Params.RAID;
                    rz.Params.LFDNR.Value = ++lfdnr;
                    rz.AllowUpdate = true;
                    rz.Deleted = true;
                    rz.Save(tx);
                }*/
                using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sqlDeleteRAKOPF, cnx, tx) : new SqlCommand(sqlDeleteRAKOPF, cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(Params.RAID);
                    AllowUpdate = (cmd.ExecuteNonQuery() > 0);
                    cmd.Parameters.Remove(Params.RAID);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { if (!inTransaction) cnx.Close(); }
        }


    }

    public class dbRaZeile
    {
        public bool AllowUpdate = false;
        public bool Deleted = false;
        public dbRaKopf RaKopf;
        public dbRaZeile_Params Params = new dbRaZeile_Params();
        public dbKG_ReiseZeile Zeile;
        public dbRaZeile(dbRaKopf raKopf, dbKG_ReiseZeile zeile)
        {
            RaKopf = raKopf;
            Zeile = zeile;
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren

        public void Save()
        {
            Save(null);
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.

        public void Save(SqlTransaction tx)
        {
            if (AllowUpdate)
            {
                if (Deleted) Delete(tx);
                else Update(tx);
            }
            else
            {
                if (!Deleted) Insert(tx);
            }
        }
        #region SQlStrings
        // Insert und Update wegen String-Truncate als Stored Procedures
        //        private string sqlInsertRAZEILE = @"Insert into RAZEILE (RAID,LFDNR,ZNR,ZEILENKZ,VERKEHRSMITTEL,DAT,AB,AN,LKZ,REISEART,BEREITST,AUSLART,ANZNAECHTE,BETRAG,WAEHR,AUSLBEMERK,PROZ,BESCHREIB,ZWECK,ABORT,ANORT,ABKM,GEFKM,SCHWERGP,MWST,VERMBETRAG,VERMWAEHR,VERMSONST,DATLA,AENPERSKEY,DATNEU,INTF_ID, ABID, ANID, EBID) VALUES(@RAID,@LFDNR,@ZNR,@ZEILENKZ,@VERKEHRSMITTEL,@DAT,@AB,@AN,@LKZ,@REISEART,@BEREITST,@AUSLART,@ANZNAECHTE,@BETRAG,@WAEHR,@AUSLBEMERK,@PROZ,@BESCHREIB,@ZWECK,@ABORT,@ANORT,@ABKM,@GEFKM,@SCHWERGP,@MWST,@VERMBETRAG,@VERMWAEHR,@VERMSONST,@DATLA,@AENPERSKEY,@DATNEU,@INTF_ID,@ABID, @ANID, @EBID)";
        //        private string sqlUpdateRAZEILE = @"update RAZEILE set ZNR=@ZNR,ZEILENKZ=@ZEILENKZ,VERKEHRSMITTEL=@VERKEHRSMITTEL,DAT=@DAT,AB=@AB,AN=@AN,LKZ=@LKZ,REISEART=@REISEART,BEREITST=@BEREITST,AUSLART=@AUSLART,ANZNAECHTE=@ANZNAECHTE,BETRAG=@BETRAG,WAEHR=@WAEHR,AUSLBEMERK=@AUSLBEMERK,PROZ=@PROZ,BESCHREIB=@BESCHREIB,ZWECK=@ZWECK,ABORT=@ABORT,ANORT=@ANORT,ABKM=@ABKM,GEFKM=@GEFKM,SCHWERGP=@SCHWERGP,MWST=@MWST,VERMBETRAG=@VERMBETRAG,VERMWAEHR=@VERMWAEHR,VERMSONST=@VERMSONST,DATLA=@DATLA,AENPERSKEY=@AENPERSKEY,DATNEU=@DATNEU,INTF_ID=@INTF_ID,ABID=@ABID, ANID=@ANID,EBID=@EBID where RAID=@RAID and LFDNR=@LFDNR";
        // Defect 5725, Config.Rowlock eingef�hrt
        private string sqlDeleteRAZEILE = @"delete from RAZEILE " + Config.Rowlock + " where RAID=@RAID and LFDNR=@LFDNR";
        #endregion

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        private void Insert(SqlTransaction tx)
        {

            bool inTransaction = tx != null;

            SqlConnection cnx = null;
            try
            {

                if (!inTransaction)
                {
                    cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                    cnx.Open();
                }
                else cnx = tx.Connection;

                Params.RAID.Value = RaKopf.Params.RAID.Value;
                Params.LFDNR.Value = RaKopf.lfdnr;
                Params.ZNR.Value = RaKopf.lfdnr.ToString();
                RaKopf.lfdnr++;
                Params.ZEILENKZ.Value = dbKG_ReiseZeilenKZ.GetKZ(Zeile.Typ);
                if (dbKG_ReiseZeilenKZ.GetKZ(Zeile.Typ) == "L")
                    Params.ZEILENKZ.Value = DBNull.Value;


                string sql = "sp_TM_RazeileInsert";
                using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    foreach (SqlParameter s in Params.List)
                    {
                        if (s.ParameterName != "@RAKZTXT" && s.ParameterName != "@BSTXT") cmd.Parameters.Add(s);
                    }
                    AllowUpdate = (cmd.ExecuteNonQuery() > 0);
                    foreach (SqlParameter s in Params.List)
                    {
                        if (s.ParameterName != "@RAKZTXT" && s.ParameterName != "@BSTXT") cmd.Parameters.Remove(s);
                    }
                }
            }
            catch (Exception ex) { throw ex; }
            finally { if (!inTransaction) cnx.Close(); }

        }
        /// <summary>
        /// preserved for future reuse, remove ex to reuse it
        /// </summary>
        private void Update(SqlTransaction tx)
        {
            Exception ex2 = new Exception("dbRaZeile::Update: Invalid call, Update may not be called!");
            //throw ex2; // mal einfach nix machen...defect 5335 
            return; // mal einfach nix machen..defect 5335 .
        }
        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.

        private void Delete(SqlTransaction tx)
        {

            bool inTransaction = tx != null;

            SqlConnection cnx = null;
            try
            {

                if (!inTransaction)
                {
                    cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                    cnx.Open();
                }
                else cnx = tx.Connection;
                using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sqlDeleteRAZEILE, cnx, tx) : new SqlCommand(sqlDeleteRAZEILE, cnx)) // Defect 5436
                {
                    cmd.Parameters.Add(Params.RAID);
                    cmd.Parameters.Add(Params.LFDNR);
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Remove(Params.RAID);
                    cmd.Parameters.Remove(Params.LFDNR);
                    AllowUpdate = false;
                }
            }
            catch (Exception ex) { throw ex; }
            finally { if (!inTransaction)cnx.Close(); }

        }
    }
}