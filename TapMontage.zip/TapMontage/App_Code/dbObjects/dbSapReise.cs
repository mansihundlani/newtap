﻿//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbSapReise.cs
//
// Description  : Verbindung zwischen TAP und SAP Reisen
//
//=============== V1.2.0000 ===============================================
//
// Date         : 25.Februar 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530031 
//                Fehler beim löschen von TAP Reisen, wenn EB geändert wird
//
//=============== 1.0.0050 ================================================
//
// Date         : 16.September 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=========================================================================
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.SqlClient;
using TapMontage.dbObjects;
using Tap.Schnittstellen.TAP_RA;

/// <summary>
/// Zusammenfassungsbeschreibung für dbSapReise
/// </summary>
public class dbSapReise
{
    private int Perskey;
    private DateTime Bermon;
    private string Mandant;

	public dbSapReise()
	{
        Perskey = 0;
        Bermon = ParamVal.Date0;
        Mandant = "";
	}
	public dbSapReise(int perskey, DateTime bermon, string mandant)
	{
		//
		// TODO: Konstruktorlogik hier hinzufügen
		//
        Perskey = perskey;
        Bermon = bermon;
        Mandant = mandant;
	}

    public bool DeleteAllTrips()
    {
        bool ret = false;
        if (Perskey == 0 || Bermon == ParamVal.Date0 || Mandant == "")
            return ret;

        string raids = "";
        ArrayList lraids = new ArrayList();

        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            cnx.Open();
            SqlTransaction tx = cnx.BeginTransaction();
            try
            {
                using (SqlCommand cmd = new SqlCommand("SELECT RAKOPF.RAID, SAP_REISE.SAP_STATUS FROM RAKOPF " + Config.Nolock +
                    " LEFT JOIN SAP_REISE " + Config.Nolock + " ON RAKOPF.RAID = SAP_REISE.RAID " +
                    "WHERE (RAKOPF.BERMON = @BERMON) AND (RAKOPF.PERSKEY = @PERSKEY)", cnx, tx))
                {
                    cmd.Parameters.Add(new SqlParameter("@BERMON", Bermon));
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", Perskey));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            if (!rd.IsDBNull(1))
                            {
                                int status = 0;
                                try
                                {
                                    status = Convert.ToInt32(rd.GetString(1));
                                }
                                catch { }
                                if (status > 41) return false;
                            }
                            if (raids.Length > 0)
                                raids += ",";
                            raids += rd.GetInt32(0).ToString();
                            if (!rd.IsDBNull(1))
                                lraids.Add(rd.GetInt32(0).ToString());
                        }
                        rd.Close();
                    }
                }

                if (raids.Length == 0)
                    return true;
                RFCReise rfc = new RFCReise();
                foreach (string s in lraids)
                {
                    RueckgabeAnClient rueck = rfc.DeleteTripFromSAP(this.Perskey, this.Mandant, s);
                    if (rueck.SapReisennummer.Trim('0').Length != 0)
                        return false;
                }
                /*using (SqlCommand cmd = new SqlCommand("DELETE FROM SAP_REISE " + Config.Rowlock + " WHERE RAID IN (" + raids + ")", cnx, tx))
                {
                    cmd.ExecuteNonQuery();
                }*/
                using (SqlCommand cmd = new SqlCommand("DELETE FROM RAKOPF " + Config.Rowlock + " WHERE RAID IN (" + raids + ")", cnx, tx))
                {
                    cmd.ExecuteNonQuery();
                }
                using (SqlCommand cmd = new SqlCommand("DELETE FROM RAZEILE " + Config.Rowlock + " WHERE RAID IN (" + raids + ")", cnx, tx))
                {
                    cmd.ExecuteNonQuery();
                }
                tx.Commit();
                ret = true;
            }
            catch
            {
                tx.Rollback();
                ret = false;
            }
            finally
            {
                cnx.Close();
            }
        }
        return ret;
    }

    public ArrayList GetTapReisen()
    {
        ArrayList ret = new ArrayList();
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT R.RAID, R.RASTAT, R.RAHIST, S.SAP_STATUS FROM RAKOPF R " + Config.Nolock +
                    " LEFT OUTER JOIN SAP_REISE S " + Config.Nolock + " ON S.RAID = R.RAID " +
                    "WHERE R.BERMON = @BERMON AND R.PERSKEY = @PERSKEY ORDER BY R.RAID", cnx ))
                //using (SqlCommand cmd = new SqlCommand("SELECT RAID, RASTAT FROM RAKOPF " + Config.Nolock +
                //    "WHERE BERMON = @BERMON AND PERSKEY = @PERSKEY", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@BERMON", Bermon));
                    cmd.Parameters.Add(new SqlParameter("@PERSKEY", Perskey));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            //ret.Add(rd.GetInt32(0).ToString() + "," + rd.GetInt16(1).ToString());// + (rd.IsDBNull(2) ? ",0":rd.GetString(2)));
                            ret.Add(rd.GetInt32(0).ToString() + "," + rd.GetInt16(1).ToString() + "," + (rd.IsDBNull(2) ? " " : rd.GetString(2)) + "," + (rd.IsDBNull(3) ? "0" : rd.GetString(3)));
                        }
                        rd.Close();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                cnx.Close();
            }
        }
        return ret;
    }
    public void SapReise(int raid, ref string sapnummer)
    {
        sapnummer = "0000000000";
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
            try
            {
                cnx.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT SAP_NUMMER FROM SAP_REISE " + Config.Nolock +
                    "WHERE RAID = @RAID", cnx))
                {
                    cmd.Parameters.Add(new SqlParameter("@RAID", raid));
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        cmd.Parameters.Clear();
                        while (rd.Read())
                        {
                            if (!rd.IsDBNull(0))
                                sapnummer = rd.GetString(0);
                        }
                        rd.Close();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                cnx.Close();
            }
        }
    }
    public string ApproveAllTrips(SqlTransaction tx)
    {
        string ret = "";
        SqlConnection cnx = tx.Connection;
        try
        {
            ArrayList raids = GetTapReisen();
            RFCReise rfc = new RFCReise();
            foreach (string s in raids)
            {
                string[] split = s.Split(',');
                if (Convert.ToInt16(split[1]) < 80)
                {
                    string sql = "UPDATE RAKOPF " + Config.Rowlock + " SET RASTAT = 80 WHERE RAID = " + split[0];
                    SqlCommand cmd = new SqlCommand(sql, cnx, tx);
                    cmd.ExecuteNonQuery();
                    RueckgabeAnClient rueck = rfc.SendTripToSAP(this.Perskey, this.Mandant, split[0], true);
                    if (rueck.SapReisennummer.Trim('0').Length == 0)
                    {
                        ret = rueck.SapReturn.Length > 0 ? rueck.SapReturn : rueck.TapReturn;
                        break;
                    }
                }
            }
            //jeztz sind alle reisen in SAP genehmigt
        }
        catch (Exception e)
        {
            ret = e.Message;
        }
        return ret;
    }
}
