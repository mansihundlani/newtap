//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbKG_TAG.cs
//
// Description  : Tag
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{
    /// <summary>
    /// Kontzrollansicht eines Tages
    /// </summary>
    public class dbKG_Tag
    {
        private int lTag = 0;
        public ArrayList EBerichte = new ArrayList();
        public int Tag
        {
            set
            {
                lTag = value;
                foreach (dbMontBer mb in Monat.Monteur.MBerichte)
                {
                    //if ((mb.ErsterTag <= lTag) & (mb.LetzterTag >= lTag))
                    EBerichte.Add(new dbKG_EB(mb, lTag));
                }
                // mb0 enth�lt GT-Absenzen und 0-Tage
                dbMontBer mb0 = new dbMontBer(new dbProjekt(new dbBaustelle(Monat.Monteur)), Monat.Monteur);
                mb0.BerichtsMonat = Monat.Monteur.BerichtsMonat;
                mb0.Select();
                EBerichte.Add(new dbKG_EB(mb0, lTag));
            }
            get
            {
                return lTag;
            }
        }
        public dbKG_Monat Monat;
        public dbKG_Tag(dbKG_Monat monat, int iTag)
        {
            Monat = monat;
            Tag = iTag;
        }
        /// <summary>
        /// Summe <b>produktive</b> NormStunden, enth�lt nicht: �berstunden, GK, STD-Absenzen, Reisezeit
        /// </summary>
        public double NormStunden
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte) 
                    foreach (object obj in e.ArbZeit)
                        if (obj is dbKG_AZTag)
                        {
                            dbKG_AZTag t = (dbKG_AZTag)obj;
                            if (!t.istGK) x += t.NormStunden;
                        }
                return x;
            }
        }
        /// <summary>
        /// Summe <b>produktive</b> NormStunden, enth�lt auch STD-Absenzen
        /// </summary>
        public double NormStundenMitSTDAbsenzen
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte)
                    foreach (object obj in e.ArbZeit)
                    {
                        if (obj is dbKG_AZTag)
                        {
                            dbKG_AZTag t = (dbKG_AZTag)obj;
                            if (!t.istGK) x += t.NormStunden;
                        }
                        if (obj is dbKG_AZTagSTDAbsenz)
                        {
                            dbKG_AZTagSTDAbsenz t = (dbKG_AZTagSTDAbsenz)obj;
                            x += t.NormStunden;
                        }
                    }
                return x;
            }
        }

        /// <summary>
        /// Summe <b>produktive</b> 50% �berstunden, enth�lt nicht GK und Reisezeit
        /// </summary>
        public double UE50
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte)
                    foreach (object obj in e.ArbZeit)
                        if (obj is dbKG_AZTag)
                        {
                            dbKG_AZTag t = (dbKG_AZTag)obj;
                            if (!t.istGK) x += t.UE50;
                        }
                return x;
            }
        }
        /// <summary>
        /// Summe <b>produktive</b> 100% �berstunden, enth�lt nicht GK und Reisezeit
        /// </summary>
        public double UE100
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte)
                    foreach (object obj in e.ArbZeit)
                        if (obj is dbKG_AZTag)
                        {
                            dbKG_AZTag t = (dbKG_AZTag)obj;
                            if (!t.istGK) x += t.UE100;
                        }
                return x;
            }
        }
        /// <summary>
        /// Summe <b>GK-Normstunden</b>, ohne �berstunden, Produktive,...
        /// </summary>
        public double GNormStunden
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte)
                    foreach (object obj in e.ArbZeit)
                        if (obj is dbKG_AZTag)
                        {
                            dbKG_AZTag t = (dbKG_AZTag)obj;
                            if (t.istGK) x += t.NormStunden;
                        }
                return x;
            }
        }
        /// <summary>
        /// Summe <b>GK-50%-�berstunden</b>, sonst nix
        /// </summary>
        public double GUE50
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte)
                    foreach (object obj in e.ArbZeit)
                        if (obj is dbKG_AZTag)
                        {
                            dbKG_AZTag t = (dbKG_AZTag)obj;
                            if (t.istGK) x += t.UE50;
                        }
                return x;
            }
        }
        /// <summary>
        /// Summe <b>GK-100%-�berstunden</b>, sonst nix
        /// </summary>
        public double GUE100
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte)
                    foreach (object obj in e.ArbZeit)
                        if (obj is dbKG_AZTag)
                        {
                            dbKG_AZTag t = (dbKG_AZTag)obj;
                            if (t.istGK) x += t.UE100;
                        }
                return x;
            }
        }
        /// <summary>
        /// Summe <b>GK-Stunden</b> Summe(NormStunden, 50, 100) der GK-Zeiten
        /// </summary>
        public double GK
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte)
                    foreach (object obj in e.ArbZeit)
                        if (obj is dbKG_AZTag)
                        {
                            dbKG_AZTag t = (dbKG_AZTag)obj;
                            if (t.istGK) x += t.GK;
                        }
                return x;
            }
        }
        /// <summary>
        /// Summe <b>NormStunden</b> bei STD-Absenz (kann nur innerhalb der NormAZ liegen, d.h keine 50% usw...)
        /// </summary>
        public double StdAbsenz
        {
            get
            {
                double x = 0;
                foreach (dbKG_EB e in EBerichte)
                    foreach (object obj in e.ArbZeit)
                        if (obj is dbKG_AZTagSTDAbsenz)
                        {
                            dbKG_AZTagSTDAbsenz t = (dbKG_AZTagSTDAbsenz)obj;
                            x += t.NormStunden;
                        }
                return x;
            }
        }
        /// <summary>
        /// ganzt�gige Absenz
        /// </summary>
        public bool GTAbsenz
        {
            get
            {
                if (Monat.Monteur.MBerichte.Count > 0)
                    return ((Monat.Monteur.MBerichte[0] as dbMontBer).Tage[Tag - 1] as dbArbTag).GTAbsenz;
                else
                    return false;
            }
        }
        public DateTime TagesDatum
        {
            get
            {
                return Monat.MinDatum.AddDays(Tag - 1);
            }
        }
    }
}