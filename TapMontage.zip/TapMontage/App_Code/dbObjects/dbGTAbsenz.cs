//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbGTAbsenz.cs
//
// Description  : Ganzt�gige Absenzen
//
//=============== V1.0.0038 ===============================================
//
// Date         : 11.Maerz 2008
// Author       : Frantisek Sabol
// Defect#      : 5921
//                Exception w�hrend Verwaltung von GT Absenzen
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0029 ===============================================
//
// Date         : 12.Juli 2007
// Author       : Wolfgang Patrman
// Defect#      : 5234
//                TagMin auf 1900 gesetzt, damit alle Absenzen in Liste
//
//=============== V1.0.0028 ===============================================
//
// Date         : 13.Juni 2007
// Author       : Wolfgang Patrman
// Defect#      : 4099
//                Update Funktionalit�t f�r ganzt�gige Absenzen erg�nzt
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{

  /// <summary>
  /// Summary description for dbGTAbsenz
  /// </summary>

  public class dbGTA_KALTAGParams
  {
    public SqlParameter DATUM = new SqlParameter("@DATUM", ParamVal.Date0);
    public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", int.MinValue);
    public SqlParameter ABGABEKZ = new SqlParameter("@ABGABEKZ", int.MinValue);
    public SqlParameter MLMOKZ = new SqlParameter("@MLMOKZ", int.MinValue);
    public SqlParameter MLABKZ = new SqlParameter("@MLABKZ", int.MinValue);
    public SqlParameter GTABSENZID = new SqlParameter("@GTABSENZID", Int16.MinValue);
    public SqlParameter DATABGLKZ = new SqlParameter("@DATABGLKZ", (string)"");
    public SqlParameter DATLASRV = new SqlParameter("@DATLASRV", ParamVal.Date0);
    public SqlParameter DATLA = new SqlParameter("@DATLA", ParamVal.Date0);
    public SqlParameter AENPERSKEY = new SqlParameter("@AENPERSKEY", int.MinValue);
    public SqlParameter DATNEU = new SqlParameter("@DATNEU", ParamVal.Date0);
    public SqlParameter GTABSENZTXT = new SqlParameter("@GTABSENZTXT", (string)"");
    public SqlParameter MINDAT = new SqlParameter("@MINDAT", ParamVal.Date0);
    public SqlParameter MAXDAT = new SqlParameter("@MAXDAT", ParamVal.Date0);
    public ArrayList List = new ArrayList();

    public dbGTA_KALTAGParams()
    {
      List.Add(DATUM);
      List.Add(PERSKEY);
      List.Add(ABGABEKZ);
      List.Add(MLMOKZ);
      List.Add(MLABKZ);
      List.Add(GTABSENZID);
      List.Add(DATABGLKZ);
      List.Add(DATLASRV);
      List.Add(DATLA);
      List.Add(AENPERSKEY);
      List.Add(DATNEU);
      List.Add(GTABSENZTXT);
      List.Add(MINDAT);
      List.Add(MAXDAT);
      ParamVal.SetDefaultValues(List);
    }
  }

  public class dbGTAbsenz
  {
    public dbGTA_KALTAGParams Params = new dbGTA_KALTAGParams();

    public bool AllowUpdate = false;
    public bool Deleted = false;
    public bool AllowInsert = false; // Defect 4099, Flag ob neuer Datensetz eingef�gt werden soll

    dbBearbeiter Monteur;
    public DateTime TagesDatum;
    public DateTime TagMin;
    public DateTime TagMax;

    // Defect 4099
    public const int gtKrankheit = 210;
    public const int gtKrankheit_begin = 212;
    public const int gtKrankheit_ende = 214;

    public const int gtUnfall = 220;
    public const int gtUnfall_begin = 222;
    public const int gtUnfall_ende = 224;
    // Ende Defect 4099
    
    // Defect 5921
    public const string gtKrankheit_ende_txt = "Krankheit Ende (214)";
    public const string gtUnfall_ende_txt = "Unfall Ende (224)";
    // Ende Defect 5921

    public dbGTAbsenz(dbBearbeiter monteur)
    {
      Monteur = monteur;
      TagesDatum = DateTime.Now;

      int iMonth = Int32.Parse(TagesDatum.Month.ToString());
      int iYear = Int32.Parse(TagesDatum.Year.ToString());

      int iMinMonth = 0;
      int iMinYear = 0;
      int iMaxMonth = 0;
      int iMaxYear = 0;

      if (iMonth == 1)
      {
        iMinMonth = 12;
        iMinYear = iYear - 1;
      }
      else
      {
        iMinMonth = iMonth - 1;
        iMinYear = iYear;
      }
      if (iMonth == 12)
      {
        iMaxMonth = 1;
        iMaxYear = iYear + 1;
      }
      else
      {
        iMaxMonth = iMonth + 1;
        iMaxYear = iYear;
      }

      TagMin = TagMin.AddYears(iMinYear - 1);
      TagMin = TagMin.AddMonths(iMinMonth - 3);

      TagMin = ParamVal.Date0; // Defect 5234, Alle Absenzen selektieren

      TagMax = TagMax.AddYears(iMaxYear - 1);
      TagMax = TagMax.AddMonths(iMaxMonth);
    }

    // Defect 5725, Config.Rowlock eingef�hrt
    // Defect 5771, Config.Nolock eingef�hrt
    // private string SQL_Select_Tag_KALTAG = @"Select DATUM,PERSKEY,ABGABEKZ,MLMOKZ,MLABKZ,y.GTABSENZID as GTABSENZID,DATABGLKZ,DATLASRV,k.DATLA,k.AENPERSKEY,k.DATNEU,GTABSENZTXT from KALTAG k " + Config.Rowlock + ", Y_GTABSENZ y " + Config.Rowlock + " where PERSKEY = @PERSKEY and DATUM > @MINDAT and y.GTABSENZID = k.GTABSENZID";
    private string SQL_Select_Tag_KALTAG = @"Select DATUM,PERSKEY,ABGABEKZ,MLMOKZ,MLABKZ,y.GTABSENZID as GTABSENZID,DATABGLKZ,DATLASRV,k.DATLA,k.AENPERSKEY,k.DATNEU,GTABSENZTXT from KALTAG k " + Config.Rowlock + ", Y_GTABSENZ y " + Config.Nolock + " where PERSKEY = @PERSKEY and DATUM > @MINDAT and y.GTABSENZID = k.GTABSENZID"; // Defect 5771
    
    public ArrayList Select()
    {
      ArrayList al = new ArrayList();
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          dbGTA_KALTAGParams lParams = new dbGTA_KALTAGParams();
          lParams.MINDAT.Value = TagMin;
          lParams.MAXDAT.Value = TagMax;
          lParams.PERSKEY.Value = Monteur.Params.PERSKEY.Value;
          cnx.Open();
          using (SqlCommand cmd = new SqlCommand(SQL_Select_Tag_KALTAG, cnx)) // Defect 5436, using eingef�hrt
          {
            cmd.Parameters.Add(lParams.MINDAT);
            //cmd.Parameters.Add(lParams.MAXDAT);
            cmd.Parameters.Add(lParams.PERSKEY);
            using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
            {
              cmd.Parameters.Remove(lParams.MINDAT);
              //cmd.Parameters.Remove(lParams.MAXDAT);
              cmd.Parameters.Remove(lParams.PERSKEY);
              while (rd.Read())
              {
                dbGTAbsenz gt = new dbGTAbsenz(Monteur);
                gt.Params = new dbGTA_KALTAGParams();
                ParamVal.DataReader2Params(rd, gt.Params.List);
                gt.AllowUpdate = false; // Defect 4099, auf false ge�ndert
                al.Add(gt);
              }
            }
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return al;
    }

    private bool Insert()
    {
      string sql = "sp_TM_KaltagGTAInsert";
      ParamVal.InsertValid(Params.List);
      Params.PERSKEY.Value = Monteur.Params.PERSKEY.Value;
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
          {
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter s in Params.List) cmd.Parameters.Add(s);
            int nRecs = cmd.ExecuteNonQuery();
            AllowUpdate = nRecs > 0;
            foreach (SqlParameter s in Params.List) cmd.Parameters.Remove(s);
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return AllowUpdate;
    }

    // Beginn Defect 4099
    // Update erg�nzt
    private bool Update()
    {
      string sql = "sp_TM_KaltagGTAUpdate";
      ParamVal.InsertValid(Params.List);
      Params.PERSKEY.Value = Monteur.Params.PERSKEY.Value;
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
          {
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter s in Params.List)
            {
              cmd.Parameters.Add(s);
            }
            int nRecs = cmd.ExecuteNonQuery();
            AllowUpdate = nRecs > 0;
            foreach (SqlParameter s in Params.List) cmd.Parameters.Remove(s);
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return AllowUpdate;
    }
    // Ende Defect 4099

    /// <summary>
    /// L�scht eine GTAbsenz aus der DB wenn Deleted = true
    /// </summary>
    /// <returns></returns>
    private bool Delete()
    {
      // Defect 5725, Config.Rowlock eingef�hrt
      string sql = "Delete from KALTAG " + Config.Rowlock + " where PERSKEY = @PERSKEY and DATUM = @DATUM";
      using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
      {
        try
        {
          cnx.Open();
          using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
          {
            cmd.Parameters.Add(Params.PERSKEY);
            cmd.Parameters.Add(Params.DATUM);
            cmd.ExecuteNonQuery();
            AllowUpdate = false;
            cmd.Parameters.Remove(Params.PERSKEY);
            cmd.Parameters.Remove(Params.DATUM);
          }
        }
        catch (Exception ex) { throw ex; }
        finally { cnx.Close(); }
      }
      return AllowUpdate;
    }

    // Beginn Defect 4099
    // Update erg�nzt
    public void Save()
    {
      if (Deleted)
      {
        Delete();
      }
      else
      {
        if (AllowInsert) // Defect 4099
        {
          Insert();
        }
        else
        {
          if (AllowUpdate)
          {
            Update();
          }
        }
      }
      AllowInsert = false;
      AllowUpdate = false;
    }
    // Ende Defect 4099
  }
}
