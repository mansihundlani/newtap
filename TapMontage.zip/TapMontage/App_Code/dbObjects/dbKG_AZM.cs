//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbKG_AZM.cs
//
// Description  : Zugriff AZM Datenbank
//
//=============== V1.2.0016 ===============================================
//
// Date         : 14.Oktober 2013
// Author       : Joldic Dzevad
// Defect#      : BA1-500392
//                KV Option
//                
//=============== V1.2.0006 ===============================================
//
// Date         : 16.August 2010
// Author       : Joldic Dzevad
// Defect#      : BAF 530042
//                Verwenden von AZMKalenderTage statt st�ndige AZM abfragen
//
//=============== 1.0.0050 ================================================
//
// Date         : 06.Oktober 2009
// Author       : Joldic Dzevad
// Defect#      : BAN 500059
//                Anbindung an die neue SAP HR Schnittstelle
//
//=============== V1.0.0047 ===============================================
//
// Date         : 11. Februar 2009
// Author       : Joldic Dzevad
// Defect#      : TAPM-41
//                Rufbereitschaft �ber Mitternacht
//
//=============== V1.0.0044 ===============================================
//
// Date         : 26. August 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-20
//                Rufbereitschaft
//
//=============== V1.0.0041 ===============================================
//
// Date         : 26.Mai 2008
// Author       : Joldic Dzevad
// Defect#      : 6043
//                Zulagen::Run-time Fehler (B&I) ZA durch ganzen Monat 
//
//=============== V1.0.0038 ===============================================
//
// Date         : 19.M�rz 2008
// Author       : Joldic Dzevad
// Defect#      : 5940
//                Zulage bei ZA ganzt�gig bei B&I (MG) 
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.J�nner 2008
// Author       : Joldic Dzevad
// Defect#      : 5620
//                Korrektur f�r AUTOIVZ �bertragung von stundenweise Absenzen
//                Korrektur der Zeitstempeln ist nicht mehr notwendig. 
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//--------------- V1.0.0028 -----------------------------------------------------------
//
// Date         : 21. Juni 2007
// Author       : Caleb Gebhardt 
// Defect#      : 4300, 4947
//
// Die Reisezeit innerhalb der Normalarbeitszeit muss in der Summe der 
// Normalstunde (in der Anzeige "Kontrolle & Genehmigung - Arbeitszeiten")
// dazugerechnet werden. 
//
//--------------- V1.0.0027 -----------------------------------------------------------
//
// Date         : 24. Mai 2007
// Author       : Georg Nebehay
// Defect#      : 5107
//
// Mandantenspezifisches Abschalten der �berleitung nach AZM von Fremdmitarbeitern eingebaut
//
//--------------- V1.0.0025 -----------------------------------------------------------
//
// Date         : 24. April 2007
// Author       : CG
// Defect#      : 4993
//
// Auswertung/Behandlung des Monatstatus (AZM-R�ckgabewert bei d. EB-Genehmigung):
// Dispo-wert 0 (Monat notReadyfordispo) bzw. 2 (Dispo bereits freigegeben).  
// Setfreigabe - Befehl nicht mehr ben�tigt.
//
//--------------- V1.0.0024 -----------------------------------------------------------
//
// Date         : 13. April 2007
// Author       : Gebhardt Caleb
// Defect#      : 4916
//                Mehrarbeit bis Mitternacht: falscher Stempel am n�chsten Tag generiert
//
//--------------- V1.0.0022 -----------------------------------------------------------
//
// Date         : 23. Februar 2007
// Author       : CL 
// Defect#      : 4513, 4661
//                Ge�nderte Dateien: dbKG_AZM.cs
//                Aus-/Zulagen mit Wert 0 werden nicht an AZM gesendet
//
//--------------- V1.0.0020 -----------------------------------------------------------
//
// Date         : 22. J�nner 2007
// Author       : Gebhardt Caleb
// Defect#      : 3777
//                Ge�nderte Dateien: dbKG_AZM.cs
//                Wenn ein MA �ber den ganzen Monat GT-Absent war, d�rfen keine Zulagen zum 
//                AZM abgeschickt werden
//
//--------------- V1.0.0020 -----------------------------------------------------------
//
// Date         : 23. J�nner 2007
// Author       : CL
// Defect#      : 4380
//                Ge�nderte Dateien: dbKG_AZM.cs
//                Gleiche Zulagen-Lohnarten m�ssen vor dem Absenden an AZM summiert werden.
//                AZM �berschreibt die vorherigen Eintr�ge
//
//--------------- V1.0.0020 -----------------------------------------------------------
//
// Date         : 27. J�nner 2007
// Author       : Gebhardt Caleb
// Defect#      : 4312
//                Ge�nderte Dateien: dbKG_AZM.cs
//                Logik, die es erm�glicht Beginn- und Ende-Absenzen bei Krankheiten
//                und Unfall zu erfassen.
//                Programmcode ist auskommentiert f. V1.0.0020 (funktioniert aber und kann wieder
//                bei Bedarf aktiviert werden) 
//
//--------------- V1.0.0018 -----------------------------------------------------------
//
// Date         : 10. J�nner 2007
// Author       : Nebehay Georg
// Defect#      : 4232
//                Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland
//
//--------------- V1.0.0017 -----------------------------------------------------------
//
// Date         : 5. J�nner 2007
// Author       : GN
// Defect#      : 3979
//                Ge�nderte Dateien: dbKG_AZM.cs
//
//--------------- V1.0.0016 -----------------------------------------------------------
//
// Date         : 2.J�nner 2007
// Author       : GN
// Defect#      : 3806
//                Mehrarbeitsstempel wurden falsch an AZM gesendet
//
//
// Date         : 10.Dezember 2006
// Author       : GN
// Defect#      : 3941
//                Analog zu dem Problem in der Fr�h wurde ein Stempel bei NAZ-Ende zu viel an AZM gesendet.
//                - Dieser wird nun nicht mehr gesendet.
//
//--------------- V1.0.0015 -----------------------------------------------------------
//
// Date         : 07.Dezember 2006
// Author       : GN
// Defect#      : 3941
//                Es wurde ein Stempel bei NAZ-Ende zu viel an AZM gesendet.
//
//--------------- V1.0.0009 -----------------------------------------------------------
//
// Date         : 15.November 2006
// Author       : CG
// Defect#      : 3671
//                Stundenweise Absenz wurde nicht korrekt an AZM gesendet
//
//-------------------------------------------------------------------------------------

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.Misc;

namespace TapMontage.dbObjects
{
    /// <summary>
    /// Summary description for dbKG_AZM
    /// </summary>
    public class dbKG_AZM
    {
        public bool UseNewHRInterface = false;
        public System.Web.UI.Page page;
        public dbKG_Monat KGMonat = null;
        public dbKG_AZMDispo AZMDispo = null;
        public string ErrorMsg = "";
        public bool bNextMonat = false;//endet die letzte Arbeitszeit im n�chsten Monat?
        public bool NextKommunication = true;


        // CG - Defect#  4993: Monatstatus nach der Setfreigabe- oder Setgenehmigung-Request 
        //Allgemeine statische Funktionen und Datentypen f. Dispo-Wert und ihre Behandlung
        public static string AZMFehlerkennung = "F";
        public enum dbKG_MonatstatusTyp { NotReadyforDispo = 0, ReadyforDispo = 1, DispoReleased = 2, DispoApproved = 3, statusunknown = -1 };
        public enum dbKG_FreigabeTyp { FreigabeTage = 0, FreigabeGenehmigung = 1 };
        public enum dbKG_FuncRetTyp { OK = 0, NOK = 1 };

        public enum dbKG_AUTOIVZRequestTyp { getsaldenkz = 0, 
                                             Tagfreigabekz = 1, 
                                             Taggenehmigungkz = 2, 
                                             getdispokz = 3, 
                                             setdispokz = 4, 
                                             setlohnartenkz = 5,
                                             checkdispo = 6,
                                             ResetMonth= 7,
                                             Requestunknown = -1
                                            };
 
        public static string GetRequestTyp(dbKG_AUTOIVZRequestTyp typ)
        {
            string[] sRequest = new string[] { "GS", "SF", "SG", "GD", "SD", "SL", "CD", "RM"};
            return sRequest[(int)typ];
        }         

        public static string SetRequestTyp(dbKG_AUTOIVZRequestTyp typ)
        {
            dbKG_AUTOIVZRequestTyp index = typ;
            return GetRequestTyp(typ) + ";";
        }


        public static string SetFreigabeKennung(dbKG_FreigabeTyp typ)
        {
            string[] sFreigabe = new string[] { "F", "G"};
            return sFreigabe[(int)typ] + ";";

        }
        // Ende Defect# 4993
 
        public void Tage()
        {
            dbKG_AZMTag t;
            bNextMonat = false; //endet die letzte Arbeitszeit im n�chsten Monat?
            foreach (dbKG_EB eb in (KGMonat.Tage[KGMonat.Tage.Count - 1] as dbKG_Tag).EBerichte) {
                for (int i = 0; i < eb.ArbZeit.Count; i++) {
                    if(eb.ArbZeit[i] is dbKG_AZTag) {
                        dbKG_AZTag at = (dbKG_AZTag)eb.ArbZeit[i];
                        if (at.Gehen.Day == (KGMonat.Tage[KGMonat.Tage.Count - 1] as dbKG_Tag).TagesDatum.AddDays(1).Day)
                            bNextMonat = true;
                    }

                    // Date         : 15.November 2006
                    // Author       : CG
                    // Defect#      : 3941 Stundenweise Absenz wurde nicht korrekt an AZM gesendet
                    else if (eb.ArbZeit[i] is dbKG_AZTagSTDAbsenz)
                    {
                        dbKG_AZTagSTDAbsenz at = (dbKG_AZTagSTDAbsenz)eb.ArbZeit[i];
                        if (at.Gehen.Day == (KGMonat.Tage[KGMonat.Tage.Count - 1] as dbKG_Tag).TagesDatum.AddDays(1).Day)
                            bNextMonat = true;
                    }
                }
            }
            for (int i = KGMonat.MinDatum.Day; i <= KGMonat.MaxDatum.Day; i++)
            {
                t = new dbKG_AZMTag(this, KGMonat.MinDatum.AddDays(i - 1), false, false, this.UseNewHRInterface);
                AnzTage.Add(t);
            }
            if (bNextMonat)
                AnzTage.Add(new dbKG_AZMTag(this, KGMonat.MaxDatum.AddDays(1), false, false, this.UseNewHRInterface));
        }
        public ArrayList AnzTage = new ArrayList();
        public dbKG_AZM(dbKG_Monat kgMonat, System.Web.UI.Page pAge, bool useNewHRInterface)
        {
            page = pAge;
            KGMonat = kgMonat;
            UseNewHRInterface = useNewHRInterface;
            Tage();

            if (ConfigurationManager.AppSettings["NoAZMUsage"] == null && KGMonat.UseAzm) //Defect 5107 GN if-Abfrage auf KGMonat.UseAzm erweitert
            {
                if (ResetMonth() == dbKG_FuncRetTyp.OK)
                {
                    Send2Azm();
                }
            }
        }

      // Defect 5436, Code wird nicht verwendet
        //public string XXSelectFirmenkennung(string firmenkz)
        //{
        //    string Firmenkennung = "";
        //    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        //    {
        //        try
        //        {
        //            cnx.Open();
        //            using (SqlCommand cmd = new SqlCommand("select Firmapers from x_con_fkz where firmenkz= @FIRMAKZ", cnx)) // Defect 5436, using eingef�hrt
        //            {
        //              cmd.Parameters.Add(new SqlParameter("@FIRMAKZ", firmenkz));
        //              using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436
        //              {
        //                while (rd.Read())
        //                {
        //                  Firmenkennung = (string)rd.GetValue(0);
        //                }
        //              }
        //            }
        //        }
        //        catch (Exception ex) { throw ex; }
        //        finally { cnx.Close(); }
        //    }
        //    return Firmenkennung;
        //}

        private string Allgemeines(int AddMonths)
        {
            string Allgemein = "";
            Allgemein = ((dbKG_EB)((dbKG_Tag)KGMonat.Tage[0]).EBerichte[0]).MBericht.Bearbeiter.Firmenkennung;
            Allgemein += ";";
            //Persnummer
            Allgemein += ((dbKG_EB)((dbKG_Tag)KGMonat.Tage[0]).EBerichte[0]).MBericht.Bearbeiter.Params.PERSNR.Value.ToString().Substring(2);
            Allgemein += ";";
            //Password
            Allgemein += //"EMONT.Test";
                         ConfigurationManager.AppSettings["autoivz_password"].ToString();
            
            Allgemein += ";";
            //Jahr
            Allgemein += KGMonat.MinDatum.AddMonths(AddMonths).Year.ToString();
            Allgemein += ";";
            //Monat
            Allgemein += KGMonat.MinDatum.AddMonths(AddMonths).Month.ToString();
            Allgemein += ";";
            return Allgemein;
        }

        #region Strings-Def. f�r parsen von Response:
        // Fehler
        string Err = "";

        // Firmen Kennung
        string fkz = "";
        // Personal Nummer
        string persnr = "";
        // Jahr
        string jahr = "";
        // Monat
        string monat = "";
        // BefehlsKZ
        string befehlskz = "";
        // Status Vormonat
        string statvormonat = "";
        // Status aktuelle Monat
        string stataktmonat = "";
        // anzahl �bertragenen tage
        string tageanz = "";
        // Tagesdatum
        string tagesdatum = "";
        // KZ f�r tag-status
        string kz = "";
        // BS_TagStatus aus der AZM-Tabelle BS_berechneteSalden 
        string bstagstatus = "";
        // Freigabestatus des Tages in AZM 
        string freigabestatus = "";
        // Soll 
        string soll = "";
        // Ist 
        string ist = "";
        // mehrarbeit 50 
        string mehrarbeit50 = "";
        // mehrarbeit 100 
        string mehrarbeit100 = "";
        // Tagessaldo 
        string tsaldo = "";
        // Geasamtsaldo 
        string gsaldo = "";

        // Monatstatus: Autoivz-R�ckgabewert nach der
        // Setfreigabe- Befehl 
        //int Monatstatus_freigabe = (int)dbKG_AUTOIVZRequestTyp.Requestunknown;

        // Monatstatus: Autoivz-R�ckgabewert nach der
        // Setgenehmigung- Befehl 
        //int Monatstatus_genehmigung = (int)dbKG_AUTOIVZRequestTyp.Requestunknown;


        #endregion

        public void Send2Azm()
        {
            // bool NoGAZObergr = true; 
            ArrayList AZRequests = new ArrayList();
            ArrayList GTRequests = new ArrayList();

            AutoIVZ ivz = new AutoIVZ(page);
            AutoIVZ ivzGT = new AutoIVZ(page);
            AutoIVZ ivzGS = new AutoIVZ(page);
            string Allgemein = Allgemeines(0);
            foreach (dbKG_AZMTag azt in AnzTage)
                if (azt.TagesDatum.Month == KGMonat.MinDatum.Month)
                {
                    if (azt.GTAbsenz)
                        GTRequests.Add(azt.RequestA);
                    else
                        AZRequests.Add(azt.RequestS);
                }

            for (int k = AZRequests.Count - 1; k >= 0; k--)
                if ((AZRequests[k] as string) == "") AZRequests.RemoveAt(k);

            #region GT-Absenzen
            if (GTRequests.Count > 0)
            {
                // Zusammenst�ckeln des Requeststrings
                string strGT = "";
                string ResponseGT = "";
                int iAnzTageGT = 0;
                GTRequests.Sort();
                for (int i = 0; i < GTRequests.Count; i++)
                {
                    if (GTRequests[i].ToString() != "")
                    {
                        iAnzTageGT++;
                    }

                }
                strGT = Allgemein;
                //BefehlsKZ
                //GTAbsenz: KZ = "A"
                strGT += "A";
                strGT += ";Y;";
                // Anzahl Tage
                strGT += iAnzTageGT.ToString();
                strGT += ";";
                for (int i = 0; i < GTRequests.Count; i++)
                {
                    if (GTRequests[i].ToString() != "")
                    {
                        strGT += GTRequests[i].ToString();
                    }

                }
                strGT = strGT.Substring(0, strGT.Length - 1);

                ivzGT.Request = strGT;
                ivzGT.SendRequest();
                //Auslesen der Response
                ResponseGT = ivzGT.Response;

                if (ResponseGT.IndexOf(";") > 0)
                {
                    // Firmen Kennung
                    fkz = ResponseGT.Substring(0, ResponseGT.IndexOf(";"));
                    ResponseGT = ResponseGT.Substring(ResponseGT.IndexOf(";") + 1);
                    // Personal Nummer
                    persnr = ResponseGT.Substring(0, ResponseGT.IndexOf(";"));
                    ResponseGT = ResponseGT.Substring(ResponseGT.IndexOf(";") + 1);
                    // Jahr
                    jahr = ResponseGT.Substring(0, ResponseGT.IndexOf(";"));
                    ResponseGT = ResponseGT.Substring(ResponseGT.IndexOf(";") + 1);
                    // Monat
                    monat = ResponseGT.Substring(0, ResponseGT.IndexOf(";"));
                    ResponseGT = ResponseGT.Substring(ResponseGT.IndexOf(";") + 1);
                    // BefehlsKZ
                    befehlskz = ResponseGT.Substring(0, ResponseGT.IndexOf(";"));
                    ResponseGT = ResponseGT.Substring(ResponseGT.IndexOf(";") + 1);
                    if (befehlskz == AZMFehlerkennung)
                    {
                        Err = ResponseGT.Substring(0, ResponseGT.IndexOf(","));
                        Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::Send2Azm:GT-Absenzen:" + Err);
                        Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrGTAbsenz.ToString() +
                                                              "\r\ndbKG_AZM::Send2Azm:GT-Absenzen: "+ 
                                                              "\r\nMessage:\r\n" +ex.Message + 
                                                              "\r\nStackTrace\r\n" + ex.StackTrace);

                        LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:GT-Absenzen:\r\nSource:\r\n" + ex.Source + "\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, MessageIDs.AutoIVZCommErrGTAbsenz, page);
                        // throw ex;
                        throw ExtendedExc;
                    }
                }
            }
            #endregion

            #region Zeitstempel
            if (AZRequests.Count > 0)
            {
                // Zusammenst�ckeln des Requeststrings
                string Zstempel = "";
                string ResponseZS = "";
                int iAnzTage = 0;
                for (int i = 0; i < AZRequests.Count; i++)
                {
                    if (AZRequests[i].ToString() != "")
                    {
                        iAnzTage++;
                    }

                }
                Zstempel = Allgemein;
                //BefehlsKZ
                //Zeitstempel: KZ = "S"
                Zstempel += "S";
                Zstempel += ";";
                //Delete
                Zstempel += "Y";
                Zstempel += ";";
                // Anzahl Tage
                Zstempel += iAnzTage.ToString();
                Zstempel += ";";
                for (int i = 0; i < AZRequests.Count; i++)
                {
                    if (AZRequests[i].ToString() != "")
                    {
                        Zstempel += AZRequests[i].ToString();
                    }

                }
                Zstempel = Zstempel.Substring(0, Zstempel.Length - 1);

                ivz.Request = Zstempel;
                ivz.SendRequest();
                //Auslesen der Response
                ResponseZS = ivz.Response;
                if (ResponseZS.IndexOf(";") > 0)
                {
                    // Firmen Kennung
                    fkz = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                    ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                    // Personal Nummer
                    persnr = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                    ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                    // Jahr
                    jahr = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                    ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                    // Monat
                    monat = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                    ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                    // BefehlsKZ
                    befehlskz = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                    ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                    if (befehlskz == AZMFehlerkennung)
                    {
                        Err = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                        if (Err.Contains("GAZ-Obergr."))
                        {
                            //NoGAZObergr = false;
                            ErrorMsg = Err;
                            LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Warnung, "dbKG_AZM::Send2Azm:Zeitstempel:\r\nMessage:\r\n" + Err, MessageIDs.AutoIVZCommWarningZeitstempel, page);
                        }
                        else
                        {
                            Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::Send2Azm:Zeitstempel:" + Err);
                            Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrZeitstempel.ToString() +
                                                                  "\r\ndbKG_AZM::Send2Azm:Zeitstempel: "+
                                                                  "\r\nMessage:\r\n" + ex.Message +
                                                                  "\r\nStackTrace\r\n" + ex.StackTrace);
                            LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:Zeitstempel:\r\nSource:\r\n" + ex.Source + "\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, MessageIDs.AutoIVZCommErrZeitstempel, page);
                                //throw ex;
                            throw ExtendedExc;
                        }
                    }
                    else
                    {
                        ErrorMsg = "";
                    }
                }
            }
            if (bNextMonat)
            {
                string nmAZRequest = "";
                foreach (dbKG_AZMTag azt in AnzTage)
                    if (azt.TagesDatum.Month == KGMonat.MaxDatum.AddDays(1).Month)
                            nmAZRequest = azt.RequestS;
                // Zusammenst�ckeln des Requeststrings
                string Zstempel = "";
                string ResponseZS = "";
                Zstempel = Allgemeines(1);
                //BefehlsKZ
                //Zeitstempel: KZ = "S"
                Zstempel += "S";
                Zstempel += ";";
                //Delete
                Zstempel += "Y";
                Zstempel += ";";
                // Anzahl Tage
                Zstempel += "1;" + nmAZRequest;
                Zstempel = Zstempel.Substring(0, Zstempel.Length - 1);
                ivz.Request = Zstempel;
                if (nmAZRequest != "")
                {
                    ivz.SendRequest();
                    //Auslesen der Response
                    ResponseZS = ivz.Response;
                    if (ResponseZS.IndexOf(";") > 0)
                    {
                        // Firmen Kennung
                        fkz = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                        ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                        // Personal Nummer
                        persnr = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                        ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                        // Jahr
                        jahr = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                        ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                        // Monat
                        monat = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                        ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                        // BefehlsKZ
                        befehlskz = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                        ResponseZS = ResponseZS.Substring(ResponseZS.IndexOf(";") + 1);
                        if (befehlskz == AZMFehlerkennung)
                        {
                            Err = ResponseZS.Substring(0, ResponseZS.IndexOf(";"));
                            if (Err.Contains("GAZ-Obergr."))
                            {
                                //NoGAZObergr = false;
                                ErrorMsg = Err;
                                LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Warnung, "dbKG_AZM::Send2Azm:Zeitstempel:bNextMonat:\r\nMessage:\r\n" + Err, MessageIDs.AutoIVZCommWarningZeitstempel, page);
                            }
                            else
                            {
                                Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::Send2Azm:Zeitstempel:bNextMonat:" + Err);
                                Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrZeitstempel.ToString() +
                                                                      "\r\ndbKG_AZM::Send2Azm:Zeitstempel:bNextMonat: " +
                                                                      "\r\nMessage:\r\n" + ex.Message + 
                                                                      "\r\nStackTrace\r\n" + ex.StackTrace);
                                LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:Zeitstempel:bNextMonat:\r\nSource:\r\n" + ex.Source + "\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, MessageIDs.AutoIVZCommErrZeitstempel, page);
                                //throw ex;
                                throw ExtendedExc;
                            }
                        }
                        else
                        {
                            ErrorMsg = "";
                        }
                    }
                }
            }
            #endregion

            #region Aufruf Gsaldo KZ: GS
            //if (NoGAZObergr)
            //{
            string GSaldo = "";
            string ResponseGS = "";
            GSaldo = Allgemein;
            GSaldo += "GS";
            GSaldo += ";";
            /////////////////////////////////////////////////////
            if (GSaldo.Length > 0)
            {

                // Kommunikation mit AZM
                ivzGS.Request = GSaldo;
                ivzGS.SendRequest();
                ResponseGS = ivzGS.Response;

                //Auslesen der Response
                if (ResponseGS.IndexOf(";") > 0)
                {
                    // Firmen Kennung
                    fkz = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                    ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                    // Personal Nummer
                    persnr = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                    ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                    // Jahr
                    jahr = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                    ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                    // Monat
                    monat = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                    ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                    // BefehlsKZ
                    befehlskz = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                    ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                    if (befehlskz == AZMFehlerkennung)
                    {
                        Err = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                        Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::Send2Azm:Gsaldo:" + Err);
                        Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrGsaldo.ToString() +
                                                              "\r\ndbKG_AZM::Send2Azm:Gsaldo: " + 
                                                              "\r\nMessage:\r\n" + ex.Message + 
                                                              "\r\nStackTrace\r\n" + ex.StackTrace);

                        LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:Gsaldo:\r\nSource:\r\n" + ex.Source + "\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, MessageIDs.AutoIVZCommErrGsaldo, page);
                        //throw ex;
                        throw ExtendedExc;
                    }
                    else
                    {
                        if (ResponseGS.IndexOf(",") > 0)
                        {
                            // Status Vormonat
                            statvormonat = ResponseGS.Substring(0, ResponseGS.IndexOf(","));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(",") + 1);
                        }

                        // Status aktuelle Monat
                        stataktmonat = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                        // anzahl �bertragenen tage
                        tageanz = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);

                    }

                    while (ResponseGS.Length > 0)
                    {
                        // Tagesdatum
                        tagesdatum = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                        //ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                        if (Convert.ToDateTime(tagesdatum).Month == KGMonat.MinDatum.Month)
                        {
                            //AKTUELLE MONAT LESEN
                            /////////////////////////////////////////////////                        
                            foreach (dbKG_AZMTag azt in AnzTage)
                            {
                                if (ResponseGS.IndexOf(";") > 0)
                                {
                                    tagesdatum = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                                    if (Convert.ToDateTime(tagesdatum).Ticks == azt.TagesDatum.Ticks)
                                    {
                                        //Defect 3979
                                        //GN 5.1.2007
                                        //Fehler bei AZM-Kommunikation bei untermontigen Eintritten
                                        //Folgender Block wurde in die if-Schleife vershoben, da nicht alle Tage
                                        //von AZM gesendet werden wenn utnermonatig eingetreten.
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                                        // KZ f�r tag-status
                                        kz = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                                        // BS_TagStatus aus der AZM-Tabelle BS_berechneteSalden 
                                        bstagstatus = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                                        // Freigabestatus des Tages in AZM 
                                        freigabestatus = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);

                                        // Soll 
                                        azt.ASoll = Convert.ToDouble(ResponseGS.Substring(0, ResponseGS.IndexOf(";")));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                                        // Ist 
                                        azt.AIst = Convert.ToDouble(ResponseGS.Substring(0, ResponseGS.IndexOf(";")));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                                        // mehrarbeit 50 
                                        azt.AUe50 = Convert.ToDouble(ResponseGS.Substring(0, ResponseGS.IndexOf(";")));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                                        // mehrarbeit 100 
                                        azt.AUe100 = Convert.ToDouble(ResponseGS.Substring(0, ResponseGS.IndexOf(";")));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                                        // Tagessaldo 
                                        azt.ATSaldo = Convert.ToDouble(ResponseGS.Substring(0, ResponseGS.IndexOf(";")));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                                        // Geasamtsaldo 
                                        azt.AGSaldo = Convert.ToDouble(ResponseGS.Substring(0, ResponseGS.IndexOf(";")));
                                        ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);

                                        // Defect# 3979 Break- Anweisung engef�gt:
                                        // wenn tag gefunden, dann n�cchste aus dem Response holen. Damit kann der ganze ResponseString
                                        // abgearbeitet werden
                                        //
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            //VORMONAT LESEN u./od. weiter LESEN
                            /////////////////////////////////////////////////                        

                            tagesdatum = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // KZ f�r tag-status
                            kz = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // BS_TagStatus aus der AZM-Tabelle BS_berechneteSalden 
                            bstagstatus = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // Freigabestatus des Tages in AZM 
                            freigabestatus = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // Soll 
                            soll = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // Ist 
                            ist = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // mehrarbeit 50 
                            mehrarbeit50 = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // mehrarbeit 100 
                            mehrarbeit100 = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // Tagessaldo 
                            tsaldo = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                            // Geasamtsaldo 
                            gsaldo = ResponseGS.Substring(0, ResponseGS.IndexOf(";"));
                            ResponseGS = ResponseGS.Substring(ResponseGS.IndexOf(";") + 1);
                        }

                    }
                }
            }
            //}
            #endregion

        }

        // Defect# 4993
        // Setfreigabe wird nicht mehr ben�tigt.
        // Wenn nach SetGenehmigung ("SG") 
        // den Monatsstaus 0 ("Not ready for dispo") als R�ckgabewert erhalten wird, soll ein 
        // GetDispo z�ruckgeschickt werden. Autoivz antwortet mit einer R�ckgage des Fehlertextes 
        // (Fehlerursache � warum die Disposition nicht m�glich ist), welches dann im Klartext 
        // dem Benutzer angezeigt wird. 
        //  

        public dbKG_MonatstatusTyp CheckDispo(dbKG_AUTOIVZRequestTyp RequestCode)
        {
            /*
             *
             <Firmenkennung>;<PersNo>;<Password>;<Jahr>;<Monat>;<BefehlsKZ>; 
             <FreigabeGenehmigung>;[<FirmenkennungGenehmiger>; <PersNoGenehmiger>;
             <Genehmigungsdatumzeit>;]
             */
            AutoIVZ ivzReqst = new AutoIVZ(page);
            string Allgemein = Allgemeines(0);
            string Requeststr = "";
            string ivzResponse = "";
            string befehlskz =  "";
            string FreigabeKennung=  "";
            dbKG_MonatstatusTyp Monatstatus;
 
            Requeststr = Allgemein;
            Requeststr += SetRequestTyp(dbKG_AZM.dbKG_AUTOIVZRequestTyp.checkdispo);    // BefehlsKZ hinzuf�gen


            if (RequestCode == dbKG_AZM.dbKG_AUTOIVZRequestTyp.Tagfreigabekz)
            {
               FreigabeKennung = SetFreigabeKennung(dbKG_FreigabeTyp.FreigabeTage);
            }
            else if (RequestCode == dbKG_AZM.dbKG_AUTOIVZRequestTyp.Taggenehmigungkz)
            {
                FreigabeKennung = SetFreigabeKennung(dbKG_AZM.dbKG_FreigabeTyp.FreigabeGenehmigung);

            }
            Requeststr += FreigabeKennung;                                         // Freigabekennung G/F   
            Requeststr = Requeststr.Substring(0, Requeststr.Length - 1);
            DateTime d = DateTime.Now;
            string strDat = d.ToString("yyyyMMddHHmmss");
            Requeststr += ";" + KGMonat.Genehmiger.Firmenkennung + ";" 
                          + KGMonat.Genehmiger.Params.PERSNR.Value.ToString().Substring(2) + ";" 
                          + strDat + ";";
            ivzReqst.Request = Requeststr;
            ivzReqst.SendRequest();
            //Auslesen der Response
            ivzResponse = ivzReqst.Response;
            if (ivzResponse.IndexOf(";") > 0)
            {
              /*
                 <Firmenkennung>;<PersNo>;<Jahr>;<Monat>;<BefehlsKZ>; <Monatsstatus>; 
                */
  
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);
                befehlskz = ivzResponse.Substring(0, ivzResponse.IndexOf(";"));
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);

                if (befehlskz == AZMFehlerkennung)                    
                {
                    Err = ivzResponse.Substring(0, ivzResponse.IndexOf(";"));
                    Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::CheckDispo:" + Err);
                    Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrorCheckDispo.ToString() + "\r\nMessage:\r\n" + ex.Message);
                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::CheckDispo:\r\nSource:\r\n" + ex.Source + "\r\nMessage:\r\n" + 
                                                    ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, MessageIDs.AutoIVZCommErrorCheckDispo, page);
                    throw ExtendedExc;
                }

                Monatstatus = (dbKG_MonatstatusTyp)Convert.ToInt16(ivzResponse.Substring(0, ivzResponse.IndexOf(";")));
                if (RequestCode == dbKG_AZM.dbKG_AUTOIVZRequestTyp.Tagfreigabekz)
                {
                  //  Monatstatus_freigabe = (int)Monatstatus;
                }
                else if (RequestCode == dbKG_AZM.dbKG_AUTOIVZRequestTyp.Taggenehmigungkz)
                {
                  //  Monatstatus_genehmigung = (int)Monatstatus;
                    if (Monatstatus == dbKG_AZM.dbKG_MonatstatusTyp.DispoReleased)
                    {
                        // Monatstatus = 2: irgendwas ist scheif gelaufen, daher Dispo genehmigung erzwingen
                        Monatstatus = Taggenehmigung(true);
                       // Monatstatus_genehmigung = (int)Monatstatus;
                    }

                }
                return Monatstatus;
            }
            return dbKG_AZM.dbKG_MonatstatusTyp.statusunknown;
        }

        /* CG:  Defect# 4993
          Die neue AUTOIVZ- Funktion ResetMonth() l�scht f�r den angegebenen Mitarbeiter und Monat eine eventuell vorhandene 
          Disposition und den Monatssaldensatz und setzt die Genehmigung und Freigabe der Tage zur�ck 
         (analog R�cksetzen Zeitdaten in AZM Helpdesk) 
         */
        public dbKG_FuncRetTyp ResetMonth()
        {
            /*
             *
                <Firmenkennung>;<PersNo>;<Password>;<Jahr>;<Monat>;<BefehlsKZ>;            
             */
            AutoIVZ ivzReqst = new AutoIVZ(page);
            string Allgemein = Allgemeines(0);
            string Requeststr = "";
            string ivzResponse = "";
            string befehlskz =  "";
  
            Requeststr = Allgemein;
            Requeststr += SetRequestTyp(dbKG_AUTOIVZRequestTyp.ResetMonth);   
            ivzReqst.Request = Requeststr;
            ivzReqst.SendRequest();
            //Auslesen der Response
            ivzResponse = ivzReqst.Response;
            if (ivzResponse.IndexOf(";") > 0)
            {
                /*
                 <Firmenkennung>;<PersNo>;<Jahr>;<Monat>;<Fehlerkennung>; <Fehlertext>;
                 */
                // Firmen Kennung
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);
                befehlskz = ivzResponse.Substring(0, ivzResponse.IndexOf(";"));
                ivzResponse = ivzResponse.Substring(ivzResponse.IndexOf(";") + 1);

                if (befehlskz == AZMFehlerkennung)                    
                {
                    string Fehlertetxt = "Fehler in Kommunikation mit, AZM:" + 
                                         ivzResponse.Substring(0, ivzResponse.IndexOf(";"));
                    Exception Ex = new Exception("\r\nEVENT-ID: " + 
                                                 MessageIDs.AutoIVZCommErrorCheckDispo.ToString() + 
                                                 "\r\nMessage:\r\n" + Fehlertetxt
                                                );
                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, 
                                            "dbKG_AZM::ResetMonth:\r\nSource:\r\n" + Ex.Source +
                                            "\r\nMessage:\r\n" + Fehlertetxt + 
                                            "\r\nStackTrace\r\n" + Ex.StackTrace, 
                                            MessageIDs.AutoIVZCommErrorCheckDispo, 
                                            page
                                            );
                    throw Ex;
                }
            }
            return dbKG_AZM.dbKG_FuncRetTyp.OK;
        }

        public void Tagfreigabe()
        {
            AutoIVZ ivzSF = new AutoIVZ(page);
            string Allgemein = Allgemeines(0);
            string strSF = "";
            string ResponseSF = "";
            strSF = Allgemein;
            strSF += "SF";
            strSF += ";";
            //Tagliste
            foreach (dbKG_AZMTag azt in AnzTage)
            {
                if (azt.Zeiten.Count > 0)
                {
                    strSF += azt.TagesDatum.Day.ToString();
                    strSF += ",";
                }
                else
                {
                    strSF += azt.TagesDatum.Day.ToString();
                    strSF += ",";
                }
            }
            strSF = strSF.Substring(0, strSF.Length - 1);
            strSF += ";";

            ivzSF.Request = strSF;
            ivzSF.SendRequest();
            //Auslesen der Response
            ResponseSF = ivzSF.Response;
            if (ResponseSF.IndexOf(";") > 0)
            {
                // Firmen Kennung
                fkz = ResponseSF.Substring(0, ResponseSF.IndexOf(";"));
                ResponseSF = ResponseSF.Substring(ResponseSF.IndexOf(";") + 1);
                // Personal Nummer
                persnr = ResponseSF.Substring(0, ResponseSF.IndexOf(";"));
                ResponseSF = ResponseSF.Substring(ResponseSF.IndexOf(";") + 1);
                // Jahr
                jahr = ResponseSF.Substring(0, ResponseSF.IndexOf(";"));
                ResponseSF = ResponseSF.Substring(ResponseSF.IndexOf(";") + 1);
                // Monat
                monat = ResponseSF.Substring(0, ResponseSF.IndexOf(";"));
                ResponseSF = ResponseSF.Substring(ResponseSF.IndexOf(";") + 1);
                // BefehlsKZ
                befehlskz = ResponseSF.Substring(0, ResponseSF.IndexOf(";"));
                ResponseSF = ResponseSF.Substring(ResponseSF.IndexOf(";") + 1);
                if (befehlskz == AZMFehlerkennung)
                {
                    Err = ResponseSF.Substring(0, ResponseSF.IndexOf(";"));
                    Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::Tagfreigabe:" + Err);
                    Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrTagfreigabe.ToString() +
                                                          "\r\ndbKG_AZM::Send2Azm:Tagfreigabe: " +
                                                          "\r\nMessage:\r\n" + ex.Message +
                                                          "\r\nStackTrace\r\n" + ex.StackTrace);

                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:Tagfreigabe:\r\nSource:\r\n" + 
                                            ex.Source + "\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, 
                                            MessageIDs.AutoIVZCommErrTagfreigabe, page
                                            );
                    //throw ex;
                    throw ExtendedExc;
                }
                else
                {
                    // CG - Defect# 4993
                    int Monatstatus = (int)Convert.ToInt16(ResponseSF.Substring(0, ResponseSF.IndexOf(";")));
                    if (Monatstatus == (int)dbKG_AZM.dbKG_MonatstatusTyp.NotReadyforDispo)
                    {
                        int status = (int)CheckDispo(dbKG_AUTOIVZRequestTyp.Tagfreigabekz);
                    }   
                }
            }
        }

        public void Zulagen()
        {
            // CG - Begin Defect#3777: wenn ein MA �ber den ganzen Monat GT-Absent war,
            // darf keine Zulagen zum AZM abgeschickt werden
            //
            bool ZulagenAbschiken = false; 
            // end 
            // Beginn Defect 4380: Summierung der Lohnarten
            /*
             * Die einzelnen Zulagenzeilen werden auf gleiche Lohnarten durchsucht.
             * F�r jede vorkommende Lohnart wird eine Gesamtsumme gebildet.
             * Diese Gesamtsummen werden in den AZM-String eingetragen
             * und nach AZM versendet.
             * */
            Hashtable htSEG = new Hashtable();
            double dblTempSum = 0;
            // Teilende Defect 4380: Summierung der Lohnarten
            AutoIVZ ivzZUL = new AutoIVZ(page);
            string Allgemein = Allgemeines(0);
            string strZUL = "";
            string ResponseZUL = "";
            strZUL = Allgemein;
            strZUL += "SL";
            strZUL += ";";
            ArrayList auszulagen = new ArrayList();

            // Beginn Defect 4380: Summierung der Lohnarten
            if (KGMonat.SEGZulagen.Count > 0)
            {
                foreach (dbKG_SEGZulage seg in KGMonat.SEGZulagen)
                {
                    // Defect #5940 Beginn
                    // lohnart 9310 wird bei B&I als SEG Zulage behandelt
                    if (seg.lohnArt != "")
                    {
                        if (!htSEG.ContainsKey(seg.lohnArt))
                            htSEG.Add(seg.lohnArt, seg.AnzTage);
                    }
                    else
                    {   //Ende Defect #5940
                        /* Beginn Defect #4513, 4661: SEG-Zulagen mit Wert 0
                         * werden nicht ber�cksichtigt */
                        if (seg.BasisStunden > 0) // if (seg.Zulage > 0)
                        { // Ende Defect #4513, 4661
                            if (htSEG.ContainsKey(seg.SEGPKT))
                            {
                                dblTempSum = Convert.ToDouble(htSEG[seg.SEGPKT]);
                                dblTempSum += seg.BasisStunden; // dblTempSum += seg.Zulage;
                                htSEG.Remove(seg.SEGPKT);
                            }
                            else
                            {
                                dblTempSum = seg.BasisStunden; // dblTempSum = seg.Zulage;
                            }
                            htSEG.Add(seg.SEGPKT, dblTempSum);
                        } // Defect #4513, 4661
                    }
                }
            }
            // Teilende Defect 4380: Summierung der Lohnarten

            foreach (dbKG_AusZulProjekt azp in KGMonat.AusZulagenProjekte)
                foreach (dbKG_PMAusZulage az in azp.AusZulagen)
                {
                    /* Beginn Defect #4513, 4661: Aus-/Zulagen mit Wert 0
                     * werden nicht ber�cksichtigt */
                    if (az.Anzahl > 0)
                    { // Ende Defect #4513, 4661
                        bool found = false;
                        foreach (dbKG_PMAusZulage auszu in auszulagen)
                            if (auszu.Lohnart == az.Lohnart)
                            {
                                auszu.Anzahl += az.Anzahl;
                                found = true;
                                break;
                            }
                        if (!found) auszulagen.Add(az);
                    } // Defect #4513, 4661
                }

            if ((auszulagen.Count + htSEG.Count) > 0) // Defect #4513, 4661: Auch SEG-Zulagen ber�cksichtigen
            {
                foreach (dbKG_AZMTag azt in AnzTage)
                {
                    if( ((!azt.GTAbsenz) & (azt.Zeiten.Count > 0))
                        ||
                        //Defect #6043 - Die Zulagen string f�r B&I generieren auch keine AZ vorhanden sind - altersteilzeit
                        ( KGMonat.Genehmiger.Mandant.MANDANT == "MG" && GTAbsenzIDs.ZAganztaegig.CompareTo(azt.GTAbsenzID.ToString()) == 0 /* 120 = ZA*/ )
                      )
                    {
                        strZUL += "1;" + azt.TagesDatum.Day.ToString() + ";";
                        if (htSEG.Count > 0) // Defect #4513, 4661: Nur SEG-Werte > 0
                        {
                            // Beginn Defect 4380: Summierung der Lohnarten
                            // strZUL += Convert.ToInt32(auszulagen.Count + KGMonat.SEGZulagen.Count).ToString();
                            strZUL += Convert.ToInt32(auszulagen.Count + htSEG.Count).ToString();
                            // Teilende Defect 4380: Summierung der Lohnarten

                            // CG - begin �nderung: Defect#3777
                            ZulagenAbschiken = true;
                            // end 
                        }
                        else
                        {
                            strZUL += auszulagen.Count.ToString();
                            // GC - begin �nderung: Defect#3777
                            ZulagenAbschiken = true;
                            // end
                        }
                        foreach (dbKG_PMAusZulage az in auszulagen)
                            strZUL += ";" + az.Lohnart + ";" + Convert.ToInt32(az.Anzahl * 100).ToString();
                        // begin �nderung: Defect#3777
                        ZulagenAbschiken = ZulagenAbschiken || (auszulagen.Count > 0);
                        // end
                        break;
                    }
                }

                // begin �nderung: Defect#3777
                ZulagenAbschiken = ZulagenAbschiken || (htSEG.Count > 0); // Defect #4513, 4661: Nur SEG-Werte > 0
                if (ZulagenAbschiken == true)
                // end
                {
                    if (htSEG.Count > 0) // Defect #4513, 4661: Nur SEG-Werte > 0
                    {

                        strZUL += ";";
                        // Beginn Defect 4380: Summierung der Lohnarten
                        foreach (DictionaryEntry de in htSEG)
                        {
                            strZUL += de.Key + ";";
                            dblTempSum = Convert.ToDouble(de.Value);
                            strZUL += dblTempSum.ToString("N") + ";";
                        }

                        /*
                        foreach (dbKG_SEGZulage seg in KGMonat.SEGZulagen)
                        {
                            strZUL += seg.SEGPKT + ";";
                            strZUL += seg.BasisStunden.ToString("N") + ";";
                        }
                         * */
                        // Ende Defect 4380: Summierung der Lohnarten

                        strZUL = strZUL.Substring(0, strZUL.Length - 1);
                    }
                    ivzZUL.Request = strZUL + ";";
                    ivzZUL.SendRequest();
                    //Auslesen der Response
                    ResponseZUL = ivzZUL.Response;
                    if (ResponseZUL.IndexOf(";") > 0)
                    {
                        // Firmen Kennung
                        fkz = ResponseZUL.Substring(0, ResponseZUL.IndexOf(";"));
                        ResponseZUL = ResponseZUL.Substring(ResponseZUL.IndexOf(";") + 1);
                        // Personal Nummer
                        persnr = ResponseZUL.Substring(0, ResponseZUL.IndexOf(";"));
                        ResponseZUL = ResponseZUL.Substring(ResponseZUL.IndexOf(";") + 1);
                        // Jahr
                        jahr = ResponseZUL.Substring(0, ResponseZUL.IndexOf(";"));
                        ResponseZUL = ResponseZUL.Substring(ResponseZUL.IndexOf(";") + 1);
                        // Monat
                        monat = ResponseZUL.Substring(0, ResponseZUL.IndexOf(";"));
                        ResponseZUL = ResponseZUL.Substring(ResponseZUL.IndexOf(";") + 1);
                        // BefehlsKZ
                        befehlskz = ResponseZUL.Substring(0, ResponseZUL.IndexOf(";"));
                        ResponseZUL = ResponseZUL.Substring(ResponseZUL.IndexOf(";") + 1);
                        if (befehlskz == AZMFehlerkennung)
                        {
                            Err = ResponseZUL.Substring(0, ResponseZUL.IndexOf(";"));
                            Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::Zulagen:" + Err);
                            Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrZulagen.ToString() +
                                                                  "\r\ndbKG_AZM::Send2Azm:Zulagen: "+
                                                                  "\r\nMessage:\r\n" + ex.Message +
                                                                  "\r\nStackTrace\r\n" + ex.StackTrace);

                            LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:Zulagen:\r\nSource:\r\n" + ex.Source + "\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, MessageIDs.AutoIVZCommErrZulagen, page);
                            //throw ex;
                            throw ExtendedExc;
                        }
                        else
                        {
                            if (ResponseZUL != "" && ResponseZUL.IndexOf(";") > 0)
                                Err = ResponseZUL.Substring(0, ResponseZUL.IndexOf(";"));
                            if (befehlskz == "SL" && Err.Contains("Ung�ltige Lohnart(en) werden nicht�bernommen"))
                                NextKommunication = false;
                        }
                    }
                }
            }
        }

        // CG- Defect# 4993: programmkopf ge�ndert - 
        // public void Taggenehmigung() auf public dbKG_MonatstatusTyp Taggenehmigung(bool ForceReleaseDispo)
        // 
        //  ForceReleaseDispo - wenn True, die  Taggenehmigung() mu� die Monatstatus = 2 -Fehler beheben, 
        // d.h. Dispo genehmigung erzwingen
        //
        public dbKG_MonatstatusTyp Taggenehmigung(bool ForceReleaseDispo)
        {
            AutoIVZ ivzSG = new AutoIVZ(page);
            string Allgemein = Allgemeines(0);
            string strSG = "";
            string ResponseSG = "";
            string Fehlertext;
            int Monatstatus = (int)dbKG_AZM.dbKG_MonatstatusTyp.statusunknown;

            strSG = Allgemein;
            strSG += "SG";
            strSG += ";";
            //Tagliste
            foreach (dbKG_AZMTag azt in AnzTage)
            {
                if (azt.Zeiten.Count > 0)
                {
                    strSG += azt.TagesDatum.Day.ToString();
                    strSG += ",";
                }
                else
                {
                    strSG += azt.TagesDatum.Day.ToString();
                    strSG += ",";
                }
            }
            strSG = strSG.Substring(0, strSG.Length - 1);
            DateTime d = DateTime.Now;
            string strDat = d.ToString("yyyyMMddHHmmss");//d.Year.ToString() + d.Month.ToString() + d.Day.ToString() + d.Hour.ToString() + d.Minute.ToString() + d.Second.ToString();
            strSG += ";"+KGMonat.Genehmiger.Firmenkennung+";"+ KGMonat.Genehmiger.Params.PERSNR.Value.ToString().Substring(2) + ";" +strDat+ ";";
            ivzSG.Request = strSG;
            ivzSG.SendRequest();
            //Auslesen der Response
            ResponseSG = ivzSG.Response;
            if (ResponseSG.IndexOf(";") > 0)
            {
                // Firmen Kennung
                fkz = ResponseSG.Substring(0, ResponseSG.IndexOf(";"));
                ResponseSG = ResponseSG.Substring(ResponseSG.IndexOf(";") + 1);
                // Personal Nummer
                persnr = ResponseSG.Substring(0, ResponseSG.IndexOf(";"));
                ResponseSG = ResponseSG.Substring(ResponseSG.IndexOf(";") + 1);
                // Jahr
                jahr = ResponseSG.Substring(0, ResponseSG.IndexOf(";"));
                ResponseSG = ResponseSG.Substring(ResponseSG.IndexOf(";") + 1);
                // Monat
                monat = ResponseSG.Substring(0, ResponseSG.IndexOf(";"));
                ResponseSG = ResponseSG.Substring(ResponseSG.IndexOf(";") + 1);
                // BefehlsKZ
                befehlskz = ResponseSG.Substring(0, ResponseSG.IndexOf(";"));
                ResponseSG = ResponseSG.Substring(ResponseSG.IndexOf(";") + 1);
                if (befehlskz == AZMFehlerkennung)
                {
                    Err = ResponseSG.Substring(0, ResponseSG.IndexOf(";"));
                    Exception Ex;
                    if (ForceReleaseDispo == false)
                    {
                         Fehlertext = "\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrTaggenehmigung.ToString() +
                         "\r\ndbKG_AZM::Send2Azm:Taggenehmigung: \r\n" +
                         "Fehler in Kommunikation mit AZM dbKG_AZM::Taggenehmigung. AZM- Fehlertext:" + Err;
                        Ex = new Exception(Fehlertext);
                    }
                    else
                    {
                        // CG - Defect 4993
                        // die Dispo-Genehmigung hat doch nicht geklappt. Daher Programmabbruch
                        Fehlertext = "Fehler in Kommunikation mit AZM, Die Dispo kann nicht genehmigt werden." +
                                     "\r\nBitte wenden Sie sich an Ihren Anwendungsadministrator.\r\n AZM-Fehlertext:" + Err;
                                                     
                        Ex = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrorCheckDispo.ToString() +
                                           "\r\ndbKG_AZM::Send2Azm:Taggenehmigung:\r\n" + Fehlertext
                                          );
                    }
                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:Taggenehmigung:" +
                                            "\r\nFehlertext:\r\n" + Fehlertext + "\r\nSource:\r\n" + Ex.Source +
                                            "\r\nStackTrace\r\n" + Ex.StackTrace, 
                                            MessageIDs.AutoIVZCommErrTaggenehmigung, 
                                            page
                                            );
                    throw Ex;
                }
                else
                {
                    Monatstatus = Convert.ToInt16(ResponseSG.Substring(0, ResponseSG.IndexOf(";")));
                    if (Monatstatus == (int)dbKG_AZM.dbKG_MonatstatusTyp.DispoReleased)
                    {
                        if (ForceReleaseDispo == true)
                        {
                            // AZM - Zustand: Monatstatus immer noch 2 -> Dispo freigegeben
                            // Dispo konnte nicht genehmigt werden. AZM - Abschlu� nicht m�glich
                            // die Dispo-Genehmigung hat doch nicht geklappt. Daher Programmabbruch
                            Fehlertext = "EVENT-ID: " + MessageIDs.AutoIVZCommErrorCheckDispo.ToString() + 
                                         "\r\nFehler in Kommunikation mit AZM, Die Dispo kann nicht genehmigt werden." +
                                         "\r\nBitte wenden Sie sich an Ihren Anwendungsadministrator.";
                            LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, Fehlertext, MessageIDs.AutoIVZCommErrorCheckDispo, page);
                            Exception ex = new Exception(Fehlertext);
                            throw ex;
                        }
                    }
                
                }
            }
            return (dbKG_MonatstatusTyp) Monatstatus;
        }

        //Defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
        //             Dispodaten werden mit AutoIVZ-Schnittstelle von AZM gelesen.
        public void GetDispo()
        {
            AutoIVZ ivzGD = new AutoIVZ(page);
            string Allgemein = Allgemeines(0);
            string strGD = "";
            string ResponseGD = "";
            bool bContinueProcessing = true;
            int Monatstatus;
            strGD = Allgemein;
            strGD += "GD";
            strGD += ";";
            ivzGD.Request = strGD;
            ivzGD.SendRequest();
            //Auslesen der Response
            ResponseGD = ivzGD.Response;
            if (ResponseGD.IndexOf(";") > 0)
            {
                // Firmen Kennung
                fkz = ResponseGD.Substring(0, ResponseGD.IndexOf(";"));
                ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                // Personal Nummer
                persnr = ResponseGD.Substring(0, ResponseGD.IndexOf(";"));
                ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                // Jahr
                jahr = ResponseGD.Substring(0, ResponseGD.IndexOf(";"));
                ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                // Monat
                monat = ResponseGD.Substring(0, ResponseGD.IndexOf(";"));
                ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                // BefehlsKZ
                befehlskz = ResponseGD.Substring(0, ResponseGD.IndexOf(";"));
                ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);


                if (befehlskz == AZMFehlerkennung)
                {
                    Err = ResponseGD.Substring(0, ResponseGD.IndexOf(";"));
                    Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::GetDispo:" + Err);
                    Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrGetDispo.ToString() +
                                                          "\r\ndbKG_AZM::Send2Azm:GetDispo: " +
                                                          "\r\nMessage:\r\n" + ex.Message +
                                                          "\r\nStackTrace\r\n" + ex.StackTrace);

                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:GetDispo:\r\nSource:\r\n" + ex.Source + "\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, MessageIDs.AutoIVZCommErrGetDispo, page);
                    // throw ex;
                    throw ExtendedExc;
                }
                else 
                {
                    // CG - Defect# 4993
                    Monatstatus = Convert.ToInt16(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    if (Monatstatus == (int)dbKG_AZM.dbKG_MonatstatusTyp.NotReadyforDispo)
                    {
                        // Dispo = 0 - Hole den FehlerText 
                        Monatstatus = (int)CheckDispo(dbKG_AUTOIVZRequestTyp.Taggenehmigungkz);
                        bContinueProcessing = (Monatstatus == (int)dbKG_AZM.dbKG_MonatstatusTyp.ReadyforDispo);
                    } 
                }

                if (bContinueProcessing)
                {
                    int mstatus = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int anz = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int msoll = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int mist = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int m50 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int m100 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int steuerfrei100 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int mteilzeit = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int fez = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int topf1 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                    ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                    int topf2 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));

                    dbKG_AZMDispo AuslandsDispo = null;     // Defect 4232
                    // Defect 4232 neu beginn
                    if (anz == 2)
                    {
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int amsoll = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int amist = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int am50 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int am100 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int asteuerfrei100 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int amteilzeit = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int afez = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int atopf1 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));
                        ResponseGD = ResponseGD.Substring(ResponseGD.IndexOf(";") + 1);
                        int atopf2 = Convert.ToInt32(ResponseGD.Substring(0, ResponseGD.IndexOf(";")));

                        AuslandsDispo = new dbKG_AZMDispo(mstatus, anz, amsoll, amist, am50, am100, asteuerfrei100, amteilzeit, afez, atopf1, atopf2);   

                    }

                    AZMDispo = new dbKG_AZMDispo(mstatus, anz, msoll, mist, m50, m100, steuerfrei100, mteilzeit, fez, topf1, topf2);
                    AZMDispo.AuslandsDispo = AuslandsDispo;
                    // Defect 4232 ende neu
                }
            }
        }

        //Defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
        public void SetDispo(SetDispo setdispo)
        {
            AutoIVZ ivzSD = new AutoIVZ(page);
            string Allgemein = Allgemeines(0);
            string strSD = "";
            string ResponseSD = "";
            int Monatstatus;

            strSD = Allgemein;
            strSD += "SD;";
            //strSD += setdispo.Anzahl.ToString() + ";" + setdispo.mitG50.ToString() + ";" + setdispo.ohneG50.ToString() + ";" + setdispo.Zuschlag50.ToString() + ";0;0;0;" + setdispo.Steuerfrei100.ToString() + ";" + setdispo.MTeilzeit.ToString() + ";" + setdispo.FEZ.ToString() + ";0;0;0;" + setdispo.mitG100.ToString() + ";" + setdispo.ohneG100.ToString() + ";" + setdispo.Zuschlag100.ToString() + ";" + setdispo.Steuerfrei100.ToString() + ";" + setdispo.MTeilzeit.ToString() + ";" + setdispo.FEZ.ToString() + ";" + setdispo.FreigabeGenehm + ";";
//            strSD += setdispo.Anzahl.ToString() + ";" + setdispo.mitG50.ToString() + ";" + setdispo.ohneG50.ToString() + ";" + setdispo.Zuschlag50.ToString() + ";0;0;0;" + setdispo.Steuerfrei100.ToString() + ";" + setdispo.MTeilzeit.ToString() + ";" + setdispo.FEZ.ToString() + ";" + setdispo.FreigabeGenehm + ";";
            // Defect 4232 beginn  neu
            if (setdispo.AuslandsSetDispo != null) setdispo.Anzahl = 2;
            strSD += setdispo.Anzahl.ToString() + ";" + setdispo.mitG50.ToString() + ";" + setdispo.ohneG50.ToString() + ";" + setdispo.Zuschlag50.ToString() + ";" + setdispo.mitG100.ToString() + ";" + setdispo.ohneG100 + ";" + setdispo.Zuschlag100.ToString() + ";" + setdispo.Steuerfrei100.ToString() + ";" + setdispo.MTeilzeit.ToString() + ";" + setdispo.FEZ.ToString() + ";";
            if (setdispo.AuslandsSetDispo != null)
            {
                SetDispo old = setdispo;
                setdispo = setdispo.AuslandsSetDispo;
                strSD += setdispo.mitG50.ToString() + ";" + setdispo.ohneG50.ToString() + ";" + setdispo.Zuschlag50.ToString() + ";" + setdispo.mitG100.ToString() + ";" + setdispo.ohneG100 + ";" + setdispo.Zuschlag100.ToString() + ";" + setdispo.Steuerfrei100.ToString() + ";" + setdispo.MTeilzeit.ToString() + ";" + setdispo.FEZ.ToString() + ";";
                setdispo = old;

            }
            strSD += setdispo.FreigabeGenehm + ";";
            // Defect 4232 ende neu
            DateTime d = DateTime.Now;
            string strDat = d.ToString("yyyyMMddHHmmss");//d.Year.ToString() + d.Month.ToString() + d.Day.ToString() + d.Hour.ToString() + d.Minute.ToString() + d.Second.ToString();
            strSD += KGMonat.Genehmiger.Firmenkennung + ";" + KGMonat.Genehmiger.Params.PERSNR.Value.ToString().Substring(2) + ";" + strDat + ";";

            ivzSD.Request = strSD;
            ivzSD.SendRequest();
            //Auslesen der Response
            ResponseSD = ivzSD.Response;
            if (ResponseSD.IndexOf(";") > 0)
            {
                // Firmen Kennung
                fkz = ResponseSD.Substring(0, ResponseSD.IndexOf(";"));
                ResponseSD = ResponseSD.Substring(ResponseSD.IndexOf(";") + 1);
                // Personal Nummer
                persnr = ResponseSD.Substring(0, ResponseSD.IndexOf(";"));
                ResponseSD = ResponseSD.Substring(ResponseSD.IndexOf(";") + 1);
                // Jahr
                jahr = ResponseSD.Substring(0, ResponseSD.IndexOf(";"));
                ResponseSD = ResponseSD.Substring(ResponseSD.IndexOf(";") + 1);
                // Monat
                monat = ResponseSD.Substring(0, ResponseSD.IndexOf(";"));
                ResponseSD = ResponseSD.Substring(ResponseSD.IndexOf(";") + 1);
                // BefehlsKZ
                befehlskz = ResponseSD.Substring(0, ResponseSD.IndexOf(";"));
                ResponseSD = ResponseSD.Substring(ResponseSD.IndexOf(";") + 1);
                if (befehlskz == AZMFehlerkennung)
                {
                    Err = ResponseSD.Substring(0, ResponseSD.IndexOf(";"));
                    Exception ex = new Exception("Fehler in Kommunikation mit AZM dbKG_AZM::SetDispo:" + Err);
                    Exception ExtendedExc = new Exception("\r\nEVENT-ID: " + MessageIDs.AutoIVZCommErrSetDispo.ToString() +
                                                          "\r\ndbKG_AZM::Send2Azm:SetDispo: " +
                                                          "\r\nMessage:\r\n" + ex.Message +
                                                          "\r\nStackTrace\r\n" + ex.StackTrace);


                    LogWriter.WriteLogEntry(LogWriter.ErrorLevel.Fehler, "dbKG_AZM::Send2Azm:SetDispo:\r\nSource:\r\n" + ex.Source + "\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace\r\n" + ex.StackTrace, MessageIDs.AutoIVZCommErrSetDispo, page);
                    //throw ex;
                    throw ExtendedExc;
                }
                else
                {
                    // CG - Defect# 4993
                    Monatstatus = Convert.ToInt16(ResponseSD.Substring(0, ResponseSD.IndexOf(";")));
                    if ((int)Monatstatus == (int)dbKG_AZM.dbKG_MonatstatusTyp.NotReadyforDispo)
                    {
                        // Dispo = 0 - Hole den FehlerText 
                        Monatstatus = (int)CheckDispo(dbKG_AUTOIVZRequestTyp.Taggenehmigungkz);
                    }
                }
            }
        }
        public double ASoll
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMTag azt in AnzTage) x += azt.ASoll / 60;
                return x;
            }
        }
        public double AIst
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMTag azt in AnzTage) x += azt.AIst / 60;
                return x;
            }
        }
        public double ANorm
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMTag azt in AnzTage) x += azt.ANorm / 60;
                return x;
            }
        }

        public double AUe50
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMTag azt in AnzTage) x += azt.AUe50 / 60;
                return x;
            }
        }

        public double AUe100
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMTag azt in AnzTage) x += azt.AUe100 / 60;
                return x;
            }
        }

        public double DM50
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.M50) / 60;
                return x;
            }
        }

        public double DM100
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.M100) / 60;
                return x;
            }
        }

        public double DSteuerfrei100
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.Steuerfrei100) / 60;
                return x;
            }
        }

        public double DMTeilzeit
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.MTeilzeit) / 60;
                return x;
            }
        }

        public double DMSoll
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.MonatSoll) / 60;
                return x;
            }
        }

        public double DMIst
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.MonatIst) / 60;
                return x;
            }
        }

        public int DMStatus
        {
            get
            {
                return AZMDispo.MonatsStatus;
            }
        }

        //Defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
        // Defect 4232 beginn neu
        public double AuslDM50
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.AuslandsDispo.M50) / 60;
                return x;
            }
        }

        public double AuslDM100
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.AuslandsDispo.M100) / 60;
                return x;
            }
        }

        public double AuslDSteuerfrei100
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.AuslandsDispo.Steuerfrei100) / 60;
                return x;
            }
        }

        public double AuslDMTeilzeit
        {
            get
            {
                double x = 0;
                x = Convert.ToDouble(AZMDispo.AuslandsDispo.MTeilzeit) / 60;
                return x;
            }
        }
        // Defect 4232 ende neu
    }


    public class dbKG_AZMTag
    {
        public bool UseNewHRInterface = false;
        public dbKG_AZM AZM = null;
        public DateTime TagesDatum;
        public ArrayList Zeiten = null;
        public bool Morgens = false;
        public bool Abends = false;
        /// <summary>
        /// true: Mehrarbeit Morgens ist zul�ssig
        /// </summary>
        public bool MAMorgens
        {
            get
            {
                //BAF 530042 Beginn
                if (Kommen == ParamVal.Date0) return false;
                if (AZM.KGMonat.Monteur.AZMKalenderTage.ContainsKey(Kommen.Date))
                    return ((AZM.KGMonat.Monteur.MAMorgens(Kommen)) | ((Kommen.Ticks != ParamVal.Date0.Ticks) && (Kommen.Day != TagesDatum.Day)));
                else //BAF 530042 Ende
                    return ((AZM.KGMonat.Monteur.AZModell.MAMorgens(Kommen)) | ((Kommen.Ticks != ParamVal.Date0.Ticks) && (Kommen.Day != TagesDatum.Day)));
            }
        }

        public bool MAAbends
        {
            get
            {
                //BAF 530042 Beginn
                if (Gehen == ParamVal.Date0) return false;
                if (AZM.KGMonat.Monteur.AZMKalenderTage.ContainsKey(Gehen.Date))
                    return ((AZM.KGMonat.Monteur.MAAbends(Gehen)) | ((Gehen.Ticks != ParamVal.Date0.Ticks) && (Gehen.Day != TagesDatum.Day)));
                else //BAF 530042 Ende
                    return ((AZM.KGMonat.Monteur.AZModell.MAAbends(Gehen)) | ((Gehen.Ticks != ParamVal.Date0.Ticks) && (Gehen.Day != TagesDatum.Day)));
            }
        }
        public dbKG_AZMTag(dbKG_AZM azm, DateTime Tagesdatum, bool morgens, bool abends, bool useNewHRInterface)
        {
            Morgens = morgens;
            Abends = abends;
            AZM = azm;
            TagesDatum = Tagesdatum;
            this.UseNewHRInterface = useNewHRInterface;
            CollectData();
            //BAF 530042 Beginn
            if (AZM.KGMonat.Monteur.AZMKalenderTage.ContainsKey(TagesDatum))
            {
                if (AZM.KGMonat.Monteur.AZMKalenderTage[TagesDatum].AZ_Starres_Modell)
                {
                    Morgens = MAMorgens;
                    Abends = MAAbends;
                }
            }
            else //BAF 530042 Ende
            {
                if (Convert.ToBoolean(azm.KGMonat.Monteur.AZModell.Params.AZ_Starres_Modell.Value))
                {//Starres AZ-Modell Hakerln setzen!
                    Morgens = MAMorgens;
                    Abends = MAAbends;
                }
            }
        }
        //Tap-Daten
        public double TNormal
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMZeit z in Zeiten)
                    if (!z.IstReiseZeit && z.StdAbsID == "") // Defect #5620
                        x += z.NormStd;
                return x;
            }
        }

        public double T50
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMZeit z in Zeiten)
                    if (!z.IstReiseZeit)
                        x += z.Ue50;
                return x;
            }
        }

        public double T100
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMZeit z in Zeiten)
                    if (!z.IstReiseZeit)
                        x += z.Ue100;
                return x;
            }
        }
        public double TGNormal
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMZeit z in Zeiten)
                    x += z.GNormStd;
                return x;
            }
        }
        public double TG50
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMZeit z in Zeiten)
                    x += z.GUe50;
                return x;
            }
        }
        public double TG100
        {
            get
            {
                double x = 0;
                foreach (dbKG_AZMZeit z in Zeiten)
                    x += z.GUe100;
                return x;
            }
        }
        public double TStdAbsenz = 0;
        public double TSumme
        {
            get { return (TNormal + T50 + T100 + TGNormal + TG50 + TG100); }
        }
        public int lGTAbsenzID;
        public int GTAbsenzID
        {
            get
            {
                if (Zeiten.Count > 0)
                    lGTAbsenzID = ((dbKG_AZMZeit)Zeiten[0]).GTAbsenzID;
                return lGTAbsenzID;

            }
        }

        public int lGTAzmNR = 0;
        public int GTAzmNR
        {
            get
            {
                if (Zeiten.Count > 0)
                    lGTAzmNR = ((dbKG_AZMZeit)Zeiten[0]).GTAzmNR;
                return lGTAzmNR;

            }
        }

        public string lGTAbsenzText = "";
        public string GTAbsenzText
        {
            get
            {
                if (Zeiten.Count > 0)
                    if (GTAbsenz)
                        lGTAbsenzText = ((dbKG_AZMZeit)Zeiten[0]).GTAbsenzText;
                return lGTAbsenzText;

            }
        }
        public string lStdAbsenzText = "";
        public string StdAbsenzText
        {
            get
            {
                lStdAbsenzText = "";
                if (Zeiten.Count > 0)
                    foreach (dbKG_AZMZeit az in Zeiten)
                        if (az.StdAbsTxt != "")
                            lStdAbsenzText += az.StdAbsTxt + ",";
                if (lStdAbsenzText != "")
                    lStdAbsenzText = lStdAbsenzText.Substring(0, lStdAbsenzText.Length - 1);
                return lStdAbsenzText;
            }
        }

        public bool GTAbsenz
        {
            get { return (GTAbsenzID > 0); }
        }

        private DateTime lKommen = ParamVal.Date0;
        public DateTime Kommen
        {
            get
            {
                if (Zeiten.Count > 0)
                    if (!GTAbsenz)
                    {
                        ArrayList k = new ArrayList();
                        foreach (dbKG_AZMZeit az in Zeiten)
                            if (!az.IstReiseZeit)
                                k.Add(az.Kommen);

                        if (k.Count > 0)
                            lKommen = (DateTime)k[0];
                                                
                    }
                return lKommen;
            }
        }
        private DateTime lGehen = ParamVal.Date0;
        public DateTime Gehen
        {
            get
            {
                if (Zeiten.Count > 0)
                    if (!GTAbsenz)
                    {
                        ArrayList g = new ArrayList();
                        foreach (dbKG_AZMZeit az in Zeiten)
                            if (!az.IstReiseZeit)
                                g.Add(az.Gehen);
                        
                        if (g.Count > 0)
                            lGehen = (DateTime)g[g.Count-1];
                    }
                return lGehen;
            }
        }

        //AZM-Daten
        public string AStatus = "";
        public string ABemerk = "";
        public double ASoll = 0;
        public double AIst = 0;
        public double ANorm = 0;
        public double AUe50 = 0;
        public double AUe100 = 0;
        public double ATSaldo = 0;
        public double AGSaldo = 0;
        public double AGuthaben = 0;

        private StempelTyp StdAbsStempelTyp(string AbsID, bool Stempel1)
        {
            switch (AbsID)
            {
                case "10": //Pflegefrei
                    if (!Stempel1) return StempelTyp.GehenPflegefrei;
                    else return StempelTyp.KommenPflegefrei;
                case "30": //Krank
                    if (!Stempel1) return StempelTyp.GehenKrank;
                    else return StempelTyp.KommenKrank;
                case "40": //Unfall
                    if (!Stempel1) return StempelTyp.GehenUnfall;
                    else return StempelTyp.KommenKrank; //??? keine Ahnung, ob das zul�ssig ist
                case "60": //AusfallBetriebl
                    if (!Stempel1) return StempelTyp.GehenArbAusfallB;
                    else return StempelTyp.KommenArbAusfallB;
                case "70": //AusfallAu�erbertriebl
                    if (!Stempel1) return StempelTyp.GehenArbAusfallA;
                    else return StempelTyp.KommenArbAusfallA;
                case "90": //Ersatzruhe
                    if (!Stempel1) return StempelTyp.GehenErsatzruhe;
                    else return StempelTyp.KommenErsatzruhe;
                case "100": //Sonstiges
                    if (!Stempel1) return StempelTyp.GehenSonstig;
                    else return StempelTyp.KommenSonstig;
                case "110": //Zeitausgleich
                    if (!Stempel1) return StempelTyp.GehenZeitausgleich;
                    else return StempelTyp.KommenZeitausgleich;
                case "120": //Zeitausgleich
                    if (!Stempel1) return StempelTyp.GehenKVOption;
                    else return StempelTyp.KommenKVOption;
                default:
                    if (Stempel1) return StempelTyp.Kommen;
                    else return StempelTyp.Gehen;
            }
        }

        private enum StempelTyp { 
            Kommen = 4, 
            Gehen = 5, 
            KommenSonstig = 6,
            GehenSonstig = 7,
            BeginnMA = 8,
            EndeMA = 9,
            BeginnBereitschaft = 10,
            EndeBereitschaft = 11,
            KommenErsatzruhe = 12,
            GehenErsatzruhe = 13,
            KommenPflegefrei = 14,
            GehenPflegefrei = 15,
            KommenKrank = 16,
            GehenKrank = 17,
            //gibts kein KommenUnfall = 18 ?
            GehenUnfall = 19,
            KommenArbAusfallB = 20,
            GehenArbAusfallB = 21,
            KommenArbAusfallA = 22,
            GehenArbAusfallA = 23,
            // Logik f�r Stundenweiseabsenz
            GehenZeitausgleich = 98,
            KommenZeitausgleich = 99,
            GehenKVOption = 71,
            KommenKVOption = 70
        };

        public enum GTAbsenzStempelTyp
        {
            // CG - Defect 4312 Logik f. Ganzt�gige Absenzen:
            //
            gtKrankheit = 11,
            gtUrlaub = 12,
            gtUrlaubEigeneKosten = 13,
            gtParagraph8P8 = 14,
            gtTruppenuebung = 15,
            gtZAGanztaegig = 16,
            gtPflegefreistellung = 17,
            gtsonstigeAbwesenheit = 18,
            gtErsatzruhe = 19,
            gtKrankheitBeginn = 20,
            gtKrankheitEnde = 21,
            gtUnfallBeginn = 22,
            gtUnfallEnde = 23,
            gtUnfall = 24,
            gtKarenzurlaub = 25,
            gtPraesenzdienst = 26,
            gtWochenhilfe = 27,
            gtGeschaeftlichAbwesend = 28,
            gtSonderurlaubAusland = 29,
            gtArbeitsausfallbetrieblich = 30,
            gtArbeitsausfallAu�erbetr = 31,
            gtBetriebsrat = 32,
            gtGestzlFreizeit = 33,
            gtStudienurlaub = 34,
            gtJubilaeumstag = 37,
            gtKrankOhneAnspr = 38,
            gtKrankheitOABeginn = 39,
            gtKrankheitOAEnde = 40
        };

        public string gtAbsStempelTyp(string AbsID)
        {
            switch (AbsID)
            {
                // CG - Defect 4312: Logik f. Ganzt�gige Absenzen:
                //                   
                case "210": //Krankheit
                   return GTAbsenzStempelTyp.gtKrankheit.ToString();
                case "212": //Krankheit Beginn
                   return GTAbsenzStempelTyp.gtKrankheitBeginn.ToString();                    
                case "214": //Krankheit Ende
                    return GTAbsenzStempelTyp.gtKrankheitEnde.ToString();                    
                case "220": //Unfall
                    return GTAbsenzStempelTyp.gtUnfall.ToString();
                case "222": //Unfall Beginn
                    return GTAbsenzStempelTyp.gtUnfallBeginn.ToString();                    
                case "224": //Unfall Ende
                    return GTAbsenzStempelTyp.gtUnfallEnde.ToString();
                default:
                    return "";
            }
        }
        private class Stempel
        {
            public StempelTyp Typ;
            public DateTime Zeit;
            public Stempel(StempelTyp typ, DateTime zeit)
            {
                Typ = typ;
                Zeit = zeit;
            }
        }
        public bool GehenVomVortag = false;
        private void CollectData()
        {
            Zeiten = new ArrayList();
            foreach (dbKG_Tag t in AZM.KGMonat.Tage)
                if (t.TagesDatum.Day == TagesDatum.Day) TStdAbsenz += t.StdAbsenz;
            //Arbeitszeiten
            foreach (dbKG_Tag t in AZM.KGMonat.Tage)
               // Defect# 4916: Vergleich mit Monat erg�nzt
               if (t.TagesDatum.Day == TagesDatum.Day && t.TagesDatum.Month == TagesDatum.Month)
               // Ende 4916
                    foreach (dbKG_EB e in t.EBerichte)
                        foreach (object obj in e.ArbZeit)
                        {
                            if (obj is dbKG_AZTag)
                            {
                                dbKG_AZTag azt = (dbKG_AZTag)obj;
                                if (!azt.istGK)                 //CG: Defect 4300 - 13.Parameter versorgt
                                    //TAPM-20 14. Parameter versorgt - RB
                                    Zeiten.Add(new dbKG_AZMZeit(this, azt.Kommen, azt.Gehen, Convert.ToInt32(azt.NormStunden * 60), Convert.ToInt32(azt.UE50 * 60), Convert.ToInt32(azt.UE100 * 60), 0, 0, 0, azt.GTAbsenzID, azt.GTAzmNR, azt.Auftrag, false, dbArbZeit.ArbZeitType.alle, azt.Bereitschaft));
                                else
                                                                 //CG: Defect 4300 - 13. Parmater versorgt
                                    //TAPM-20 14. Parameter versorgt - RB
                                    Zeiten.Add(new dbKG_AZMZeit(this, azt.Kommen, azt.Gehen, 0, 0, 0, Convert.ToInt32(azt.NormStunden * 60), Convert.ToInt32(azt.UE50 * 60), Convert.ToInt32(azt.UE100 * 60), azt.GTAbsenzID, azt.GTAzmNR, azt.Auftrag, false, dbArbZeit.ArbZeitType.gk, azt.Bereitschaft));
                            }
                            //Defect 3671
                            //CG 13.11. 06
                            //Stundenweise Absenzen wurden nicht korrekt an AZM �bertragen
                            if (obj is dbKG_AZTagSTDAbsenz)
                            {
                                dbKG_AZTagSTDAbsenz azt = (dbKG_AZTagSTDAbsenz)obj;
                                // Zeiten.Add(new dbKG_AZMZeit(this, azt.Gehen, azt.Kommen, azt.StdAbsID, azt.StdAbsTxt));
                                // Defect #5620
                                Zeiten.Add(new dbKG_AZMZeit(this, azt.Gehen, azt.Kommen, azt.StdAbsID, azt.StdAbsTxt, Convert.ToInt32(azt.NormStunden * 60)));
                            }
                        }
            //Reisezeiten
            if (!UseNewHRInterface)
            {
                foreach (dbKG_Tag t in AZM.KGMonat.Tage)
                    if (t.TagesDatum.Day == TagesDatum.Day)
                        foreach (dbKG_EB e in t.EBerichte)
                            foreach (dbKG_AZReiseTag rat in e.ReiseZeit)
                                if (rat.AzmKommen.Ticks != ParamVal.Date0.Ticks)
                                    // Defect 4300: der 13. Parameter versogt - Dieser dient dazu die "W" - Stempel zu erkennen.
                                    // und daher die richtige Versorgung sehr wichtig f�r diesen Defect
                                    //TAPM-20 14. Parameter versorgt - RB
                                    Zeiten.Add(new dbKG_AZMZeit(this, rat.AzmKommen, rat.AzmGehen, Convert.ToInt32(rat.NormStunden * 60), Convert.ToInt32(rat.UE50 * 60), Convert.ToInt32(rat.UE100 * 60), 0, 0, 0, 0, 0, "", true, rat.Stempeltyp, false));
            }
            else
            {
                if (AZM.KGMonat.RZalsAZ != null)
                {
                    foreach (object o in AZM.KGMonat.RZalsAZ)
                    {
                        if (o is dbAZ_ARBZEITParams)
                        {
                            dbAZ_ARBZEITParams az = o as dbAZ_ARBZEITParams;
                            if (az.KZAZ.Value.ToString() == "W" && Convert.ToDateTime(az.DATUM.Value) == TagesDatum)
                                Zeiten.Add(new dbKG_AZMZeit(this, Convert.ToDateTime(az.BEGINN.Value), Convert.ToDateTime(az.ENDE.Value), Convert.ToInt32(az.NORMSTD.Value), 0, 0, 0, 0, 0, 0, 0, "", true, dbArbZeit.ArbZeitType.ReiseInDienstzeit, false));
                        }
                    }
                }
            }
            if (AZM.AnzTage != null)
                foreach (dbKG_AZMTag azmt in AZM.AnzTage)
                    if (azmt.TagesDatum.Day == TagesDatum.AddDays(-1).Day)
                        foreach (dbKG_AZMZeit azmz in azmt.Zeiten)
                            if ((azmz.Kommen.Day == TagesDatum.Day) | (azmz.Gehen.Day == TagesDatum.Day))
                            {
                                //TAPM-20 14. Parameter versorgt - RB
                                //Zeiten.Add(new dbKG_AZMZeit(this, azmz.Kommen, azmz.Gehen, 0, 0, 0, 0, 0, 0, 0, 0, "", true,dbArbZeit.ArbZeitType.ReiseVorherNachher, false));
                                //TAPM-41 RB Parameter richt versorgen
                                Zeiten.Add(new dbKG_AZMZeit(this, azmz.Kommen, azmz.Gehen, 0, 0, 0, 0, 0, 0, 0, 0, "", true, dbArbZeit.ArbZeitType.ReiseVorherNachher, azmz.Bereitschaft)); 
                                GehenVomVortag = true;
                            }
            dbKG_AZMZeitSort azs = new dbKG_AZMZeitSort(dbKG_AZMZeitSort.SortByEnum.kommen);
            Zeiten.Sort(azs);
        }

        public string RequestGS
        {
            get
            {
                string strDatenGS = "";
                //BefehlsKZ
                //Saldo: KZ = "GS"
                strDatenGS += "GS";
                strDatenGS += ";";
                return strDatenGS;
            }
        }
        public string RequestA
        {
            get
            {
                string strDatenA = "";

                if (GTAbsenz)
                {
                    // kalender Tag 
                    strDatenA = TagesDatum.Day.ToString();
                    // no defect - wegen sort, wenn der Tag < 10 ist, das 0 vor dem Tag schreiben
                    if (strDatenA.Length == 1)
                        strDatenA = strDatenA.Insert(0, "0");
                    strDatenA += ";;";
                    //noch zu kl�ren ????
                    strDatenA += "1";
                    strDatenA += ";";
                    strDatenA += GTAzmNR.ToString();
                        //weiter erg�nzen
                    strDatenA += ";;";
                }
                return strDatenA;
            }
        }

        //HACK: Das muss weg
        private void FehlerhafteZeitenKorrigieren()
        {

            ArrayList newList = new ArrayList();

            //L�sche doppelte Eintr�ge
            for (int i = 0; i < Zeiten.Count; i++) //�berpr�fe paarweise jede Zeit auf Gleichheit
            {

                dbKG_AZMZeit z1  = (dbKG_AZMZeit)Zeiten[i];

                bool takeit = true;

                for(int j = i + 1; j < Zeiten.Count; j++) //Nimm alle Zeiten nach i
                {
                    dbKG_AZMZeit z2 = (dbKG_AZMZeit)Zeiten[j];

                    if (z1.Kommen == z2.Kommen && z1.Gehen == z2.Gehen)
                    {
                        takeit = false;
                    }


                }

                if (takeit) newList.Add(z1);
            }

            Zeiten = newList;


        }

//SAG;30005;EMONT.Test;2006;6;S;Y;14;1;J;2;4;07:00;5;20:00;2;J;2;4;06:30;5;20:30;13;J;2;4;07:00;5;20:30;14;J;2;4;05:50;5;20:30;19;J;2;4;07:00;5;20:30;20;J;2;4;07:30;5;20:30;21;J;2;4;07:30;5;20:30;22;J;2;4;07:30;5;20:30;23;J;2;4;06:00;5;20:30;26;J;2;4;07:18;5;20:30;27;J;2;4;07:28;5;20:30;28;J;2;4;07:28;5;20:30;29;J;2;4;07:28;5;22:30;30;J;2;4;07:28;5;22:00
        public string RequestS
        {
            get
            {
                string strDatenZStempel = "";
                //ist ein Gehen-Stempel vom Vortag heute zu setzen?
                if (GehenVomVortag)
                    foreach (dbKG_AZMTag azmt in AZM.AnzTage)
                        if (azmt.TagesDatum.Day == TagesDatum.AddDays(-1).Day)
                        {
                            if (azmt.Abends) Abends = true;
                            if (azmt.Morgens) Morgens = true;
                        }
                if (Zeiten.Count > 0)
                {
                    // kalender Tag 
                    strDatenZStempel = TagesDatum.Day.ToString();
                    strDatenZStempel += ";";
                    // Ust -> �berstunden rechnen
                    strDatenZStempel += "N";

                    FehlerhafteZeitenKorrigieren();

                    ArrayList Spannen = new ArrayList();
                    foreach (dbKG_AZMZeit z in Zeiten)
                    {
                        ArrayList lz = new ArrayList();
                        //TAPM-20 AZM Stempel defieren
                        if (z.Bereitschaft)
                        {
                            lz.Add(new Stempel(StempelTyp.BeginnBereitschaft, z.Kommen));
                            lz.Add(new Stempel(StempelTyp.EndeBereitschaft, z.Gehen));
                        }
                        else
                        {
                            lz.Add(new Stempel(StdAbsStempelTyp(z.StdAbsID, true), z.Kommen));
                            lz.Add(new Stempel(StdAbsStempelTyp(z.StdAbsID, false), z.Gehen));
                        }
                        Spannen.Add(lz);
                    }
                    //Zeitausgleich Spannen eleminieren
                    bool SpannenMitZA = false;
                    for (int i = 0; i <= Spannen.Count - 1; i++)
                    {
                        //ArrayList sp = new ArrayList();
                        //sp.Add(Spannen[i]);
                        Stempel s0 = (Stempel)(Spannen[i] as ArrayList)[0];
                        Stempel s1 = (Stempel)(Spannen[i] as ArrayList)[1];
                        if ((s0.Typ == StempelTyp.KommenZeitausgleich) || (s1.Typ == StempelTyp.GehenZeitausgleich))
                        {
                            SpannenMitZA = true;
                            break;
                        }
                    }
                    if (SpannenMitZA)
                    {

                        ArrayList SpanenOhneZA = new ArrayList();
                        for (int i = 0; i <= Spannen.Count - 1; i++)
                        {
                            //Stempel s0 = (Stempel)(Spannen[i] as ArrayList)[(Spannen[i] as ArrayList).Count - 1];
                            //Stempel s1 = (Stempel)(Spannen[i + 1] as ArrayList)[0];
                            Stempel s0 = (Stempel)(Spannen[i] as ArrayList)[0];
                            Stempel s1 = (Stempel)(Spannen[i] as ArrayList)[1];
                            if ((s0.Typ != StempelTyp.KommenZeitausgleich) && (s1.Typ != StempelTyp.GehenZeitausgleich))
                            {
                                ArrayList lz = new ArrayList();
                                lz.Add(new Stempel(s0.Typ, s0.Zeit));
                                lz.Add(new Stempel(s1.Typ, s1.Zeit));
                                SpanenOhneZA.Add(lz);
                            }
                        }
                        Spannen = SpanenOhneZA;
                    }
                    for (int i = 0; i < Spannen.Count - 1; i++)
                    {
                        ArrayList list = Spannen[i] as ArrayList;
                        Stempel s0 = (Stempel)(list)[1]; //Das m�sste der zweite Stempel der i-ten Zeitspanne sein (GEHEN)
                        Stempel s1 = (Stempel)(Spannen[i + 1] as ArrayList)[0]; //Und das der erste Stempel der n�chstes Zeitspanne (KOMMEN)
                        if ((s0.Typ == StempelTyp.Gehen) && (s1.Typ == StempelTyp.Kommen))
                        {
                            if (s0.Zeit.Ticks == s1.Zeit.Ticks) //in diesem fall k�nnen wir zusammenfassen
                            {
                                s1.Zeit = //1
                                    ((Spannen[i] as ArrayList)[0] as Stempel).Zeit;
                                Spannen[i] = new ArrayList();
                            }
                        }
                        // Beging Defect #5620
                        /*
                        else
                        {
                            // wird nicht mehr ben�tigt weil AZM die gleiche korrektur macht
                            if (s0.Zeit.Ticks == s1.Zeit.Ticks) //in diesem Fall m�ssen wir die Zeiten trennen
                                s0.Zeit = s0.Zeit.AddMinutes(-1);
                        }
                        */
                        // Ende Defect #5620
                    }
                    //Mehrarbeit Morgens
                    if (Morgens)
                    {
                        for (int i = 0; i < Spannen.Count; i++)
                        {
                            ArrayList al = (ArrayList)Spannen[i];
                            if (al.Count > 0)
                            {
                                Stempel sk = (Stempel)al[0];
                                Stempel sg = (Stempel)al[al.Count - 1];
                                if (sk.Typ == StempelTyp.Kommen) //nicht f�r StdAbsenzen
                                {
                                    bool bgn = (sg.Zeit.Day != TagesDatum.Day); //kommen war am vortag
                                    //wenn NazBeginn = Date0 dann
                                    // kommen = beginn Mehrarbeit => Typ umsetzen
                                    DateTime NazBeginn = ParamVal.Date0;
                                    DateTime NazEnde = ParamVal.Date0;
                                    if (AZM.KGMonat.Monteur.AZMKalenderTage.ContainsKey(sk.Zeit.Date))
                                    {
                                        NazBeginn = AZM.KGMonat.Monteur.NazBeginn(sk.Zeit);
                                        NazEnde = AZM.KGMonat.Monteur.NazEnde(sg.Zeit);
                                    }
                                    else
                                    {
                                        NazBeginn = AZM.KGMonat.Monteur.AZModell.NazBeginn(sk.Zeit);
                                        NazEnde = AZM.KGMonat.Monteur.AZModell.NazEnde(sg.Zeit);
                                    }
                                    //if (bgn | (AZM.KGMonat.Monteur.AZModell.NazBeginn(sk.Zeit).Ticks == ParamVal.Date0.Ticks))
                                    if (bgn | (NazBeginn.Ticks == ParamVal.Date0.Ticks))
                                    {
                                        sk.Typ = StempelTyp.BeginnMA;
                                    }
                                    else
                                        if (sk.Zeit.Ticks < NazBeginn.Ticks)
                                        {
                                            ArrayList a2 = new ArrayList();
                                            //if (sg.Zeit.Ticks <= AZM.KGMonat.Monteur.AZModell.NazEnde(sg.Zeit).Ticks)
                                            if (sg.Zeit.Ticks <= NazEnde.Ticks)
                                            {
                                                a2.Add(new Stempel(StempelTyp.BeginnMA, sk.Zeit));
                                                a2.Add(sg);
                                            }
                                            else
                                            {
                                                a2.Add(sk);

                                                //3806 GN Folgende seltsame Zeile f�hrt zu falschen Mehrarbeitszeiten
                                                //a2.Add(new Stempel(StempelTyp.EndeMA, AZM.KGMonat.Monteur.AZModell.NazBeginn(sk.Zeit)));

                                                //Hier wird einfach die Gehen Zeit als Mehrarbeitsende verwendet und der Rest der Berechnung AZM �berlassen.
                                                // a2.Add(sg);
                                                a2.Add(new Stempel(StempelTyp.EndeMA, sg.Zeit));
                                            }
                                            Spannen[i] = a2;
                                        }
                                }
                            }
                        }
                    }
                    if (Abends)
                    {
                        for (int i = 0; i < Spannen.Count; i++)
                        {
                            ArrayList al = (ArrayList)Spannen[i];
                            if (al.Count > 0)
                            {
                                Stempel sk = (Stempel)al[0];
                                Stempel sg = (Stempel)al[al.Count - 1];
                                if (sg.Typ == StempelTyp.Gehen) //nicht f�r StdAbsenzen
                                {
                                    bool bkv = (sk.Zeit.Day != TagesDatum.Day); //kommen war am vortag
                                    //wenn NazEnde = Date0 dann
                                    //Gehen wird zu Ende Mehrarbeit => Typ umsetzen
                                    DateTime NazEnde = ParamVal.Date0;
                                    if (AZM.KGMonat.Monteur.AZMKalenderTage.ContainsKey(sg.Zeit.Date))
                                        NazEnde = AZM.KGMonat.Monteur.NazEnde(sg.Zeit);
                                    else
                                        NazEnde = AZM.KGMonat.Monteur.AZModell.NazEnde(sg.Zeit);

                                    //if (bkv | (AZM.KGMonat.Monteur.AZModell.NazEnde(sg.Zeit).Ticks == ParamVal.Date0.Ticks))
                                    if (bkv | (NazEnde.Ticks == ParamVal.Date0.Ticks))
                                    {//keine AZ f�r diesen Tag
                                        sg.Typ = StempelTyp.EndeMA;
                                    }
                                    else
                                        //if (sg.Zeit.Ticks > AZM.KGMonat.Monteur.AZModell.NazEnde(sg.Zeit).Ticks)
                                        if (sg.Zeit.Ticks > NazEnde.Ticks)
                                        {
                                            ArrayList a2 = new ArrayList();
                                            for (int j = 0; j < al.Count - 1; j++)
                                                a2.Add(al[j]);
                                            // Defect 3941
                                            // Analog zu dem Problem in der Fr�h wurde ein Stempel bei NAZ-Ende zu viel an AZM gesendet.
                                            // - dieser wird nun nicht mehr gesendet.
                                            a2.Add(new Stempel(StempelTyp.EndeMA, ((Stempel)al[1]).Zeit));
                                            //a2.Add(sg);
                                            if (a2.Count > 0)
                                            {
                                                for (int k = 0; k < a2.Count - 1; k++)
                                                {
                                                    Stempel skom = (Stempel)a2[0];
                                                    Stempel sbma = (Stempel)a2[k + 1];
                                                    if (skom.Zeit.Ticks == sbma.Zeit.Ticks) //in diesem Fall m�ssen wir die Zeiten trennen
                                                        sbma.Zeit = sbma.Zeit.AddMinutes(1);
                                                }
                                            }
                                            Spannen[i] = a2;
                                        }
                                }
                            }
                        }
                    }
                    string s = "";
                    int ianz = 0;
                    //TAPM-20 AUTOIVZ Schnitttelle anpassen
                    Stempel lastSt = null;
                    bool kommenAmVortag = false;
                    foreach (ArrayList al in Spannen)
                        foreach (Stempel st in al)
                            if (st.Zeit.Day == TagesDatum.Day)
                            {
                                if (lastSt == null || st.Zeit != lastSt.Zeit)
                                {
                                    ianz++;
                                    s += Convert.ToInt32(st.Typ).ToString() + ";";
                                    s += st.Zeit.ToShortTimeString() + ";";
                                    lastSt = st;
                                    if (kommenAmVortag &&
                                        st.Typ != StempelTyp.Gehen &&
                                        st.Typ != StempelTyp.EndeBereitschaft &&
                                        st.Typ != StempelTyp.EndeMA)
                                        kommenAmVortag = false;
                                }
                                else
                                {
                                    // zwei Stepmel zur gleichen Zeitpunk
                                    if ((lastSt.Typ == StempelTyp.Gehen && st.Typ == StempelTyp.Kommen) ||
                                        (lastSt.Typ == StempelTyp.GehenSonstig && st.Typ == StempelTyp.KommenSonstig) ||
                                        (lastSt.Typ == StempelTyp.GehenZeitausgleich && st.Typ == StempelTyp.KommenZeitausgleich) ||
                                        (lastSt.Typ == StempelTyp.GehenKVOption && st.Typ == StempelTyp.KommenKVOption) ||
                                        (lastSt.Typ == StempelTyp.GehenPflegefrei && st.Typ == StempelTyp.KommenPflegefrei) ||
                                        (lastSt.Typ == StempelTyp.GehenErsatzruhe && st.Typ == StempelTyp.KommenErsatzruhe) ||
                                        (lastSt.Typ == StempelTyp.EndeBereitschaft && st.Typ == StempelTyp.BeginnBereitschaft) ||
                                        (lastSt.Typ == StempelTyp.EndeMA && st.Typ == StempelTyp.BeginnMA) ||
                                        (lastSt.Typ == StempelTyp.GehenKrank && st.Typ == StempelTyp.KommenKrank) ||
                                        (lastSt.Typ == StempelTyp.GehenArbAusfallA && st.Typ == StempelTyp.KommenArbAusfallA) ||
                                        (lastSt.Typ == StempelTyp.GehenArbAusfallB && st.Typ == StempelTyp.KommenArbAusfallB))
                                    {
                                        //l�sche beide Stempel
                                        string tempS = Convert.ToInt32(lastSt.Typ).ToString() + ";" + lastSt.Zeit.ToShortTimeString() + ";";
                                        s = s.Remove(s.Length - tempS.Length, tempS.Length);
                                        ianz--;
                                        continue;
                                    }
                                    if (st.Typ == StempelTyp.BeginnBereitschaft ||
                                        st.Typ == StempelTyp.BeginnMA)
                                    {
                                        bool warMA = false;
                                        try
                                        {
                                            int i = Spannen.IndexOf(al);
                                            ArrayList last = (ArrayList)Spannen[--i];
                                            i = last.IndexOf(lastSt);
                                            Stempel stempel = (Stempel)last[--i];
                                            if (stempel.Typ == StempelTyp.BeginnMA ||
                                                stempel.Typ == StempelTyp.BeginnBereitschaft)
                                            {
                                                warMA = true;
                                            }
                                        }
                                        catch
                                        {
                                        }
                                        //ers�tzte letztes Stempel mit Beginnbereitschaft
                                        string tempS = Convert.ToInt32(lastSt.Typ).ToString() + ";" + lastSt.Zeit.ToShortTimeString() + ";";
                                        s = s.Remove(s.Length - tempS.Length, tempS.Length);
                                        if (lastSt.Typ == StempelTyp.GehenErsatzruhe ||
                                            lastSt.Typ == StempelTyp.GehenPflegefrei ||
                                            lastSt.Typ == StempelTyp.GehenSonstig ||
                                            lastSt.Typ == StempelTyp.GehenKVOption ||
                                            lastSt.Typ == StempelTyp.GehenZeitausgleich ||
                                            lastSt.Typ == StempelTyp.EndeMA ||
                                            lastSt.Typ == StempelTyp.EndeBereitschaft ||
                                            kommenAmVortag ||
                                            warMA)
                                        {
                                            //falls absenz ist, dann wird gehen gebraucht, allerdings m�ssen wir eine Minute abziehen
                                            //aber nicht wenn es mitternacht ist, in dem Fall bekommt das n�chste Stempel eine Minute dazu !!!!
                                            if (lastSt.Zeit.ToShortTimeString() != "00:00")
                                            {
                                                lastSt.Zeit = lastSt.Zeit.AddMinutes(-1);
                                            }
                                            else
                                            {
                                                st.Zeit = st.Zeit.AddMinutes(1);
                                            }
                                            s += Convert.ToInt32(lastSt.Typ).ToString() + ";";
                                            s += lastSt.Zeit.ToShortTimeString() + ";";
                                            ianz++;
                                        }
                                        s += Convert.ToInt32(st.Typ).ToString() + ";";
                                        s += st.Zeit.ToShortTimeString() + ";";
                                        lastSt = st;
                                        kommenAmVortag = false;
                                        continue;
                                    }
                                    if ((lastSt.Typ == StempelTyp.EndeBereitschaft || lastSt.Typ == StempelTyp.EndeMA) &&
                                        kommenAmVortag == false)
                                    {
                                        //kein kommen schreiben so lange keine Bereitschaft oder Mehrarbeit ist
                                        try
                                        {
                                            int i = al.IndexOf(st);
                                            Stempel next = (Stempel)al[++i];
                                            if (next.Typ == StempelTyp.EndeBereitschaft ||
                                                next.Typ == StempelTyp.EndeMA)
                                            {
                                                st.Zeit = st.Zeit.AddMinutes(1);
                                                s += Convert.ToInt32(st.Typ).ToString() + ";";
                                                s += st.Zeit.ToShortTimeString() + ";";
                                                ianz++;
                                                lastSt = st;
                                            }

                                        }
                                        catch { }
                                        continue;
                                    }
                                    //Am NAZ Ende ist Absenz danach geht es weiter mit AZ
                                    DateTime NazEnde = ParamVal.Date0;
                                    if (AZM.KGMonat.Monteur.AZMKalenderTage.ContainsKey(st.Zeit.Date))
                                        NazEnde = AZM.KGMonat.Monteur.NazEnde(st.Zeit);
                                    else
                                        NazEnde = AZM.KGMonat.Monteur.AZModell.NazEnde(st.Zeit);
                                    //if (lastSt.Zeit.Ticks == AZM.KGMonat.Monteur.AZModell.NazEnde(st.Zeit).Ticks)
                                    if (lastSt.Zeit.Ticks == NazEnde.Ticks)
                                    {
                                        if (lastSt.Typ == StempelTyp.GehenErsatzruhe ||
                                            lastSt.Typ == StempelTyp.GehenPflegefrei ||
                                            lastSt.Typ == StempelTyp.GehenSonstig ||
                                            lastSt.Typ == StempelTyp.GehenKVOption ||
                                            lastSt.Typ == StempelTyp.GehenZeitausgleich)
                                        {
                                            //gehen absenz um eine Minute reduzieren
                                            string tempS = Convert.ToInt32(lastSt.Typ).ToString() + ";" + lastSt.Zeit.ToShortTimeString() + ";";
                                            s = s.Remove(s.Length - tempS.Length, tempS.Length);
                                            lastSt.Zeit = lastSt.Zeit.AddMinutes(-1);
                                            s += Convert.ToInt32(lastSt.Typ).ToString() + ";";
                                            s += lastSt.Zeit.ToShortTimeString() + ";";
                                            st.Zeit = st.Zeit.AddMinutes(-1);
                                        }
                                    }
                                    if (kommenAmVortag &&
                                        (lastSt.Typ == StempelTyp.Gehen || lastSt.Typ == StempelTyp.EndeBereitschaft || lastSt.Typ == StempelTyp.EndeMA))
                                    {
                                        if (st.Typ == StempelTyp.KommenErsatzruhe ||
                                            st.Typ == StempelTyp.KommenPflegefrei ||
                                            st.Typ == StempelTyp.KommenSonstig ||
                                            st.Typ == StempelTyp.KommenKVOption)
                                        {
                                            st.Zeit = st.Zeit.AddMinutes(1);
                                        }
                                    }

                                    //ansonst
                                    kommenAmVortag = false;
                                    ianz++;
                                    s += Convert.ToInt32(st.Typ).ToString() + ";";
                                    s += st.Zeit.ToShortTimeString() + ";";
                                    lastSt = st;
                                }
                            }
                            else
                            {
                                //kommen am Vortag ?
                                if (st.Zeit.Day + 1 == TagesDatum.Day)
                                {
                                    if (st.Typ == StempelTyp.Kommen)
                                        kommenAmVortag = true;
                                }
                            }
                    strDatenZStempel += ";" + ianz.ToString() + ";" + s;
                }
                return strDatenZStempel;
            }
        }
    }

    public class dbKG_AZMZeitSort : IComparer
    {
        public enum SortByEnum { kommen, gehen };
        private SortByEnum SortBy = SortByEnum.kommen;
        public dbKG_AZMZeitSort(SortByEnum SortByWhat)
        {
            SortBy = SortByWhat;
        }
        int IComparer.Compare(object o1, object o2)
        {
            dbKG_AZMZeit a1 = (dbKG_AZMZeit)o1;
            dbKG_AZMZeit a2 = (dbKG_AZMZeit)o2;
            if (SortBy == SortByEnum.kommen)
                return a1.Kommen.CompareTo(a2.Kommen);
            else
                return a1.Gehen.CompareTo(a2.Gehen);
        }
    }

    public class dbKG_AZMZeit
    {
        public dbKG_AZMTag Tag = null;
        public DateTime Kommen;
        public DateTime Gehen;
        public int NormStd = 0;
        public int Ue50 = 0;
        public int Ue100 = 0;
        public int GNormStd = 0;
        public int GUe50 = 0;
        public int GUe100 = 0;
        public int GTAbsenzID = 0;
        public int GTAzmNR = 0;
        public string GTAbsenzText = "";
        public string StdAbsID = "";
        public string StdAbsTxt = "";
        public bool IstReiseZeit = true;
        public bool Bereitschaft = false; //TAPM-20 neues Parameter
        public dbArbZeit.ArbZeitType ReiseTyp = dbArbZeit.ArbZeitType.alle;         // CG: Defect 4300, 4947
                                                                                    // Merkvariable f�r Stempeltyp, f. diesen Defekt wichtig ist
                                                                                    // Reise w�hrend der Dienstzeit
        // Defect 4300, 4947 - Konstruktion um Parameter Stempeltyp erweitert
        public dbKG_AZMZeit(dbKG_AZMTag tag, DateTime kommen, DateTime gehen, int n, int u50, int u100,int gNorm, int g50, int g100, int gtabsenzid,int gtazmnr, string gtabsenztext, bool istreisezeit, dbArbZeit.ArbZeitType Stempeltyp, bool bereitschaft)
        {
            Tag = tag;
            Kommen = kommen;
            Gehen = gehen;
            NormStd = n;
            Ue50 = u50;
            Ue100 = u100;
            GNormStd = gNorm;
            GUe50 = g50;
            GUe100 = g100;
            GTAbsenzID = gtabsenzid;
            GTAzmNR = gtazmnr;
            GTAbsenzText = gtabsenztext;
            IstReiseZeit = istreisezeit;
            ReiseTyp = Stempeltyp;                  // CG:Defect 4300, 4947
            Bereitschaft = bereitschaft; //TAPM-20 Rufbereitschaft
        }
        // public dbKG_AZMZeit(dbKG_AZMTag tag, DateTime kommen, DateTime gehen, string stdAbsID, string stdabstxt)
        // Defect #5620 Begin
        public dbKG_AZMZeit(dbKG_AZMTag tag, DateTime kommen, DateTime gehen, string stdAbsID, string stdabstxt, int n)
        {
            Tag = tag;
            Kommen = kommen;
            Gehen = gehen;
            StdAbsID = stdAbsID;
            StdAbsTxt = stdabstxt;
            IstReiseZeit = false;
            if( StdAbsID != "110")
                NormStd = n;
        }
        // Defect #5620 Ende

    }
    //Defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    public class dbKG_AZMDispo
    {
        public int MonatsStatus = 0;
        public int Anzahl = 0;
        public int MonatSoll = 0;
        public int MonatIst = 0;
        public int M50 = 0;
        public int M100 = 0;
        public int Steuerfrei100 = 0;
        public int MTeilzeit = 0;
        public int FEZ = 0; //Feiertagszuschlag
        public int Topf1 = 0; // Monatsendsaldo aus GAZ vor Dispo.
        public int Topf2 = 0; // Monatsendsaldo aus Mehrarbeit vor Dispo.
        public dbKG_AZMDispo AuslandsDispo;     // Defect 4232 neu

        public dbKG_AZMDispo(int monatsstatus, int anzahl, int monatsoll, int monatist, int m50, int m100, int steuerfrei100, int mteilzeit, int fez, int topf1, int topf2)
        {
            MonatsStatus = monatsstatus;
            Anzahl = anzahl;
            MonatSoll = monatsoll;
            MonatIst = monatist;
            M50 = m50;
            M100 = m100;
            Steuerfrei100 = steuerfrei100;
            MTeilzeit = mteilzeit;
            FEZ = fez;
            Topf1 = topf1;
            Topf2 = topf2;
        }

    }
    //Defect 4232: Anzeige des Dispo-Schirmes f�r Mitarbeiter im Ausland.
    public class SetDispo
    {
        public int Anzahl = 0;
        public int mitG50 = 0;
        public int mitG100 = 0;
        public int ohneG50 = 0;
        public int ohneG100 = 0;
        public int Zuschlag50 = 0;
        public int Zuschlag100 = 0;
        public int Steuerfrei100 = 0;
        public int MTeilzeit = 0;
        public int FEZ = 0; //Feiertagszuschlag
        public string FreigabeGenehm = ""; //Freigabegenehmigung
        public SetDispo AuslandsSetDispo;       // Defect 4232 neu

        public SetDispo(int anzahl, int mitg50, int mitg100, int ohneg50, int ohneg100, int zuschlag50, int zuschlag100, int steuerfrei100, int mteilzeit, int fez, string freigabegenehm)
        {
            Anzahl = anzahl;
            mitG50 = mitg50;
            mitG100 = mitg100;
            ohneG50 = ohneg50;
            ohneG100 = ohneg100;
            Zuschlag50 = zuschlag50;
            Zuschlag100 = zuschlag100;
            Steuerfrei100 = steuerfrei100;
            MTeilzeit = mteilzeit;
            FEZ = fez;
            FreigabeGenehm = freigabegenehm;
        }
    }

}