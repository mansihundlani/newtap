//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbMeldungen.cs
//
// Description  : DB-Zugriffe f�r UserMeldungen
//
//=============== 1.0.0045 ================================================
//
// Date         : 22.September 2008
// Author       : Joldic Dzevad
// Defect#      : TAPM-22
//                Erfasse benachrichtigen wenn EB durch Genehmiger ge�ndert ist
//
//=============== V1.0.0044 ===============================================
//
// Date         : 13.August 2008
// Author       : Frantisek Sabol
// Defect#      : 6076/TAPM-22
//                Erfasser benachrichtigen wenn EB durch Genehmiger ge�ndert ist
//                Init Module 
//
//-----------------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.SqlClient;


/// <summary>
/// Summary description for dbMeldungen
/// </summary>
namespace TapMontage.dbObjects
{
    public class dbMeldungen
    {
        //static variable, weil sie im ganzen system bekannt werden muss
        private static DateTime deleteTime = DateTime.Now.AddMonths(-3);
 
        public dbMeldungen()
        {
            
        }


        public void doLog(int ebid, int perskey_genehmiger)
        {
            //bei online Support return einschalten, damit unsere �nderung nicht protokoliert wird
            //return;
            int erfasser_perskey = getErfasser(ebid);
            string mandant = getMandant(ebid);

            if (erfasser_perskey == perskey_genehmiger)
            {
                // log nicht notwendig weil der selbe person ist
                return;
            }
            // if record already exists then update it
            if (ebidExists(ebid))
            {
                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        using (SqlCommand cmd = new SqlCommand(" UPDATE KEYUSER_MELDUNGEN " + Config.Rowlock + 
                                                               " SET STATUS = 10, DATUM = @TODAY " +
                                                               " WHERE EBID=@EBID", cnx))
                        {
                            cmd.Parameters.Add(new SqlParameter("@TODAY", DateTime.Now));
                            cmd.Parameters.Add(new SqlParameter("@EBID", ebid));
                            int nRecs = cmd.ExecuteNonQuery();
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            }
            else // else insert new record
            {

                using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                {
                    try
                    {
                        cnx.Open();
                        using (SqlCommand cmd = new SqlCommand(" INSERT INTO KEYUSER_MELDUNGEN " + Config.Rowlock + " (EBID, MANDANT, PERSKEY_ERF, PERSKEY_GEN, DATUM, STATUS, TEXT)" +
                                                               " VALUES(@EBID, @MANDANT, @ERFASSER, @GEN_PERSKEY, @TODAY, 10, ' ')", cnx))
                        {
                            cmd.Parameters.Add(new SqlParameter("@EBID", ebid));
                            cmd.Parameters.Add(new SqlParameter("@MANDANT", mandant));
                            cmd.Parameters.Add(new SqlParameter("@ERFASSER", erfasser_perskey));
                            cmd.Parameters.Add(new SqlParameter("@GEN_PERSKEY", perskey_genehmiger));
                            cmd.Parameters.Add(new SqlParameter("@TODAY", DateTime.Now));
                            int nRecs = cmd.ExecuteNonQuery();
                        }
                    }
                    catch (Exception ex) { throw ex; }
                    finally { cnx.Close(); }
                }
            }

        }

        public int getErfasser(int ebid)
        {   
            int erfasser = 0;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT  b.MLPERSKEY " +
                                                           " FROM   EINSBER e, BAUPROJEKT b " + Config.Nolock +
                                                           " WHERE  e.EBID = @EBID AND e.PROJID = b.PROJID ", cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@EBID", ebid));

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();

                            while (rd.Read())
                            {
                                erfasser = rd.GetInt32(0);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return erfasser;

        }

        public string getMandant(int ebid)
        {
            string mandant = "";
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT  b.MANDANT " +
                                                           " FROM   EINSBER e, BAUPROJEKT b " + Config.Nolock +
                                                           " WHERE  e.EBID = @EBID AND e.PROJID = b.PROJID ", cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@EBID", ebid));

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();

                            while (rd.Read())
                            {
                                mandant = rd.GetString(0);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return mandant;

        }

        public bool ebidExists(int ebid)
        {
            int count = 0;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT count(*) " +
                                                           " FROM   KEYUSER_MELDUNGEN " + Config.Nolock +
                                                           " WHERE  EBID = @EBID ", cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@EBID", ebid));

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            cmd.Parameters.Clear();

                            while (rd.Read())
                            {
                                count = rd.GetInt32(0);
                            }
                        }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            return (count > 0);
        }

        public string getAnzahlGeaenderteEB(string login)
        {
            int count = 0;
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    using (SqlCommand cmd = new SqlCommand("update KEYUSER_MELDUNGEN " +
                                                           "set status = 20 where status = 10 " + 
                                                           "and perskey_erf = " + 
                                                           "(select perskey FROM BEARBEIT " + Config.Nolock +
                                                           "where belogin = @LOGIN) ", cnx))
                    {
                        cmd.Parameters.Add(new SqlParameter("@LOGIN", login));
                        count = cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
            switch (count)
            {
                case 0:
                    return "";
                    //break;
                case 1:
                    return "Ein Einsatzbericht ist durch Genehmiger ge�ndert worden";
                    //break;
                default :
                    return count.ToString() + " Einsatzberichte sind durch Genehmiger ge�ndert worden";
                    //break;
            }
            //return count > 0 ? "Sie haben " + count.ToString() + " ge�nderte EB(s)" : "";
        }

        public void deleteOldMessages(bool testApp)
        {
            DateTime dt = DateTime.Now;
            try
            {
                if (testApp)
                {
                    deleteTime = deleteTime.AddDays(-1);
                }
                if (dt.Day != deleteTime.Day)
                {
                    deleteTime = new DateTime(dt.Ticks).AddMonths(-3);
                    using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
                    {
                        try
                        {
                            cnx.Open();
                            using (SqlCommand cmd = new SqlCommand("delete from KEYUSER_MELDUNGEN where DATUM < @DATUM", cnx))
                            {
                                cmd.Parameters.Add(new SqlParameter("@DATUM", deleteTime));
                                int i = cmd.ExecuteNonQuery();
                                cmd.Parameters.Clear();
                            }
                        }
                        catch 
                        {
                            //do nothing
                        }
                        finally { cnx.Close(); }
                    }
                }
            }
            catch
            {
            }
        }
    }
        
}