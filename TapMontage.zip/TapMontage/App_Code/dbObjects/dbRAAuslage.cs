//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbRAAuslage.cs
//
// Description  : DB-Zugriffe f�r Auslagen
//
//=============== V1.0.0037 ===============================================
//
// Date         : 15.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0033 ===============================================
//
// Date         : 9. September 2007
// Author       : NK
// Defect#      : 5433, 5442
//                order by sollte eindeutig sein, auch wenn datum gleuch ist
//                
//=============== V1.0.0022 ===============================================
//
// Date         : 24. Februar 2007
// Author       : GN
// Defect#      : 4625
//                Wir haben in der Datenbank f�r Berichtsmonat J�nner ca. 800 R/W Zeilen ohne Leistungsart.
//                Transaktionsthema
//
//=============== V1.0.0017 ===============================================
//
// Date         : 05. J�nner 2007
// Author       : GN
// Defect#      : 3993, 3996 
//                Richtiges Speichern von Betrag und Anzahl von Auslagen
//
//=============== V1.0.0010 ===============================================
//
// Date         : 05. November 2006
// Author       : Georg Nebehay
// Defect#      : 3725
//                Sortierung der Reiseaulagen nach Datum
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for RAAuslage
/// </summary>
/// 
namespace TapMontage.dbObjects
{
    public class dbRAAuslageParams
    {
        public SqlParameter RAAUSLAGEID = new SqlParameter("@RAAUSLAGEID", Int32.MinValue);
        public SqlParameter EBID = new SqlParameter("@EBID", Int32.MinValue);
        public SqlParameter MANDANT = new SqlParameter("@MANDANT", (string)"");
        public SqlParameter PERSKEY = new SqlParameter("@PERSKEY", Int32.MinValue);
        public SqlParameter RAKZ = new SqlParameter("@RAKZ", (string)"");
        public SqlParameter DATUM = new SqlParameter("@DATUM", ParamVal.Date0);
        public SqlParameter ANZAHL = new SqlParameter("@ANZAHL", float.MinValue);
        public SqlParameter BETRAG = new SqlParameter("@BETRAG", float.MinValue);
        public ArrayList List = new ArrayList();

        public dbRAAuslageParams()
        {
            List.Add(RAAUSLAGEID);
            List.Add(EBID);
            List.Add(MANDANT);
            List.Add(PERSKEY);
            List.Add(RAKZ);
            List.Add(DATUM);
            List.Add(ANZAHL);
            List.Add(BETRAG);
            List = ParamVal.SetDefaultValues(List);
        }

    }

    public class dbRAAuslage
    {
        public dbRAAuslageParams Params = new dbRAAuslageParams();
        public dbMontBer MontBer;

        public dbRAAuslage(dbMontBer mber)
        {
            MontBer = mber;
            if (MontBer == null) MontBer = new dbMontBer(null, null);
        }

        /// <summary>
        /// Private Properties
        /// </summary>
        public bool AllowUpdate = false;
        public bool Deleted = false;
        public string RAKZText = "";

        public bool Gebucht = false; //to avoid duplicate Belegzeilen in Reiseabrechnung if eb is interrupted by another eb with a different Bauid: <Deutlish>

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren
        public bool Insert()
        {
            return Insert(null);
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        public bool Insert(SqlTransaction tx)
        {
            bool inTransaction = tx != null;
            //Params.RAAUSLAGEID.Value = MontBer.Bearbeiter.Commons.GetNextID(62, "RAAUSLAGEID");
            Params.RAAUSLAGEID.Value = SelectMaxId();
            Params.MANDANT.Value = MontBer.Params.MANDANT.Value;
            Params.PERSKEY.Value = MontBer.Params.PERSKEY.Value;
            Params.EBID.Value = MontBer.Params.EBID.Value;
            ParamVal.InsertValid(Params.List);
            SqlConnection cnx = null;
            try
            {
                if (!inTransaction)
                {
                    cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                    cnx.Open();
                }
                else cnx = tx.Connection;
                string sql = "sp_TM_RAuslageInsert";
                using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436, using eingef�hrt
                {
                  cmd.CommandType = CommandType.StoredProcedure;
                  foreach (SqlParameter s in Params.List)
                    cmd.Parameters.Add(s);
                  int nRecs = cmd.ExecuteNonQuery();
                  foreach (SqlParameter s in Params.List)
                    cmd.Parameters.Remove(s);
                  AllowUpdate = (nRecs > 0);
                }
            }
            catch (Exception ex) { throw ex; }
            finally { if(!inTransaction) cnx.Close(); }
            
            return AllowUpdate;
        }

      public int SelectMaxId()
      {
        int iRes = 0;
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
          try
          {
            cnx.Open();
            // Defect 5725, Config.Rowlock eingef�hrt
            using (SqlCommand cmd = new SqlCommand("select MAX(RAAUSLAGEID) as MaxId from RAAUSLAGE " + Config.Rowlock, cnx)) // Defect 5436
            {
              cmd.Parameters.Add(MontBer.Params.EBID);
              using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
              {
                cmd.Parameters.Remove(MontBer.Params.EBID);
                while (rd.Read())
                {
                  if (!rd.IsDBNull(0))
                    iRes = (int)rd.GetValue(0);
                  else
                    iRes = 0;
                }
              }
            }
          }
          catch (Exception ex) { throw ex; }
          finally { cnx.Close(); }
        }
        iRes++;
        return iRes;
      }

      public ArrayList SelectAllforEinsatzbericht()
      {
        ArrayList al = new ArrayList();
        using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
        {
          try
          {
            cnx.Open();
            // Defect 3725
            // Die Sortierung der Reiseauslagen erfolgt nach Datum
            // Defect 5433, 5442 order by sollte eindeutig sein, auch wenn datum gleich ist
            // Defect 5725, Config.Rowlock eingef�hrt
            // Defect 5771, Config.Nolock eingef�hrt
            using (SqlCommand cmd = new SqlCommand("Select RAAUSLAGEID, EBID, MANDANT, PERSKEY, y.RAKZ as RAKZ, DATUM, ANZAHL, BETRAG, y.RAKZTXT  From RAAUSLAGE " + Config.Nolock + ", Y_RAKZ y " + Config.Nolock + " where EBID = @EBID and y.RAKZ = RAAUSLAGE.RAKZ order by datum asc, RAAUSLAGEID asc", cnx)) // Defect 5436
            {
              cmd.Parameters.Add(MontBer.Params.EBID);
              using (SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.SequentialAccess)) // Defect 5436
              {
                cmd.Parameters.Remove(MontBer.Params.EBID);
                while (rd.Read())
                {
                  dbRAAuslage ra = new dbRAAuslage(MontBer);
                  ParamVal.SetDefaultValues(ra.Params.List);
                  ra.Params.RAAUSLAGEID.Value = rd.GetValue(0);
                  ra.Params.EBID.Value = MontBer.Params.EBID.Value;
                  ra.Params.MANDANT.Value = rd.GetValue(2);
                  ra.Params.PERSKEY.Value = rd.GetValue(3);
                  ra.Params.RAKZ.Value = rd.GetValue(4);
                  ra.Params.DATUM.Value = rd.GetValue(5);
                  // Beginn Defect # 3993, 3996: Speichern von Betrag und Anzahl f�r Auslagen
                  ra.Params.ANZAHL.Value = rd.GetValue(6);
                  ra.Params.BETRAG.Value = rd.GetValue(7);
                  // Ende Defect # 3993, 3996
                  ra.RAKZText = rd.GetString(8);
                  ra.AllowUpdate = true;
                  ra.Deleted = false;
                  al.Add(ra);
                }
              }
            }
          }
          catch (Exception ex) { throw ex; }
          finally { cnx.Close(); }
        }
        return al;
      }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren
        public bool Update()
        {
            return Update(null);
        }


        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        public bool Update(SqlTransaction tx)
        {
            bool inTransaction = tx != null;
            if (!AllowUpdate) return Insert(tx);
            else
            {
                ParamVal.InsertValid(Params.List);
                SqlConnection cnx = null;
                try
                {

                if (!inTransaction)
                {
                    cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                    cnx.Open();
                }
                else cnx = tx.Connection;
                string sql = "sp_TM_RAuslageUpdate";
                using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
                {
                  cmd.CommandType = CommandType.StoredProcedure;
                  foreach (SqlParameter s in Params.List)
                    cmd.Parameters.Add(s);
                  int nRecs = cmd.ExecuteNonQuery();
                  foreach (SqlParameter s in Params.List)
                    cmd.Parameters.Remove(s);
                  AllowUpdate = (nRecs > 0);
                  if (!AllowUpdate)
                  {
                    Exception ex = new Exception("dbRAAuslage::Update: Update failed!");
                    throw ex;
                  }
                }
                }
                catch (Exception ex) { throw ex; }
                finally { if(!inTransaction) cnx.Close(); }
            }
        
            return AllowUpdate;
        }


        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren
        public bool Delete()
        {
            return Delete(null);
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        public bool Delete(SqlTransaction tx)
        {
            bool inTransaction = tx != null;

            ParamVal.InsertValid(Params.List);
            if (AllowUpdate)
            {
                SqlConnection cnx = null;
                try
                {

                    if (!inTransaction)
                    {
                        cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString);
                        cnx.Open();
                    }
                    else cnx = tx.Connection;
                    // Defect 5725, Config.Rowlock eingef�hrt
                    string sql = "Delete from RAAUSLAGE " + Config.Rowlock + " where RAAUSLAGEID = @RAAUSLAGEID";
                    using (SqlCommand cmd = (inTransaction) ? new SqlCommand(sql, cnx, tx) : new SqlCommand(sql, cnx)) // Defect 5436
                    {
                      cmd.Parameters.Add(Params.RAAUSLAGEID);
                      int nRecs = cmd.ExecuteNonQuery();
                      cmd.Parameters.Remove(Params.RAAUSLAGEID);
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { if (!inTransaction)cnx.Close(); }
            }
            return AllowUpdate;
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Die parameterlose Methode wurde aufgehoben um Kompatibilit�t zu bewahren
        public void Save()
        {
            Save(null);
        }

        // Date         : 24.Februar 2007
        // Author       : GN
        // Defect#      : 4625: Diese Methode wurde neu eingef�hrt und �bernimmt die Funktionalit�t der parameterlosen
        //                Methode und f�hrt die Transaktion fort.
        public void Save(SqlTransaction tx)
        {
            if (AllowUpdate)
            {
                if (!Deleted) Update(tx);
                else Delete(tx);
            }
            else
            {
                if (!Deleted) Insert(tx);
                //else do_nothing();
            }
        }

        public ArrayList SelectAll()
        {
            ArrayList al = new ArrayList();
            return al;
        }

    }
}
