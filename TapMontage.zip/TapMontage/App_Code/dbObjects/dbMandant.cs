//=========================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbMandant.cs
//
// Description  : Definieren der Mandanten - Parameter, Festlegen des Mandanten
//
//=============== V1.0.0037 ===============================================
//
// Date         : 14.Jaenner 2008
// Author       : Wolfgang Patrman
// Defect#      : 5771
//                Die Variable 'Nolock' f�r lesende DB-Aufrufe verwenden
//
//=============== V1.0.0036 ===============================================
//
// Date         : 12.Dezember 2007
// Author       : Wolfgang Patrman
// Defect#      : 5725
//                Die Variable 'Rowlock' f�r DB-Aufrufe verwenden
//
//=============== V1.0.0035 ===============================================
//
// Date         : 23.November 2007
// Author       : Wolfgang Patrman
// Defect#      : 5436
//                Performancsteigerung/Speicheroptimierung durch Verwendung 
//                von using bei SqlDataReader, SqlCommand, SqlConnection
//
//=============== V1.0.0029 ===============================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=========================================================================

using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace TapMontage.dbObjects
{
    public class dbMandantAZModellParams
    {
        public SqlParameter MANDANT			  = new SqlParameter("@MANDANT",(string) "");
        public SqlParameter WOCHENTAG		  = new SqlParameter("@WOCHENTAG",Int16.MinValue);
        public SqlParameter UESTD50BEG1		  = new SqlParameter("@UESTD50BEG1",ParamVal.Date0);
        public SqlParameter UESTD50END1		  = new SqlParameter("@UESTD50END1",ParamVal.Date0);
        public SqlParameter UESTD50BEG2		  = new SqlParameter("@UESTD50BEG2",ParamVal.Date0);
        public SqlParameter UESTD50END2		  = new SqlParameter("@UESTD50END2",ParamVal.Date0);
        public SqlParameter UESTD100BEG1	  = new SqlParameter("@UESTD100BEG1",ParamVal.Date0);
        public SqlParameter UESTD100END1	  = new SqlParameter("@UESTD100END1",ParamVal.Date0);
        public SqlParameter UESTD100BEG2	  = new SqlParameter("@UESTD100BEG2",ParamVal.Date0);
        public SqlParameter UESTD100END2	  = new SqlParameter("@UESTD100END2",ParamVal.Date0);
        public SqlParameter PAUSE			  = new SqlParameter("@PAUSE",Int16.MinValue);
        public SqlParameter PAUSEAB			  = new SqlParameter("@PAUSEAB",Int16.MinValue);
        public SqlParameter TXT				  = new SqlParameter("@TXT",(string) "");
        public SqlParameter DATLA			  = new SqlParameter("@DATLA",ParamVal.Date0);
        public SqlParameter AENPERSKEY		  = new SqlParameter("@AENPERSKEY",int.MinValue);
        public SqlParameter DATNEU			  = new SqlParameter("@DATNEU",ParamVal.Date0);
        public SqlParameter STATUS			  = new SqlParameter("@STATUS",Int16.MinValue);
        public SqlParameter NAZBEG			  = new SqlParameter("@NAZBEG",ParamVal.Date0);
        public SqlParameter NAZEND			  = new SqlParameter("@NAZEND",ParamVal.Date0);
        public ArrayList List = new ArrayList();

        public dbMandantAZModellParams()
        {
            List.Add(MANDANT);
            List.Add(WOCHENTAG);
            List.Add(UESTD50BEG1);
            List.Add(UESTD50END1);
            List.Add(UESTD50BEG2);
            List.Add(UESTD50END2);
            List.Add(UESTD100BEG1);
            List.Add(UESTD100END1);
            List.Add(UESTD100BEG2);
            List.Add(UESTD100END2);
            List.Add(PAUSE);
            List.Add(PAUSEAB);
            List.Add(TXT);
            List.Add(DATLA);
            List.Add(AENPERSKEY);
            List.Add(DATNEU);
            List.Add(STATUS);
            List.Add(NAZBEG);
            List.Add(NAZEND);
            ParamVal.SetDefaultValues(List);
        }

    }

    public class dbMandantAZModellTag
    {
        public dbMandantAZModell azModell;
        public dbMandantAZModellParams Params = new dbMandantAZModellParams();
        public int Tag
        {
            get
            {
                return (int)Params.WOCHENTAG.Value;
            }
            set
            {
                Params.WOCHENTAG.Value = (Int16)value;
                Params.MANDANT.Value = azModell.Mandant.MANDANT;
                Select();
            }
        }
        public dbMandantAZModellTag(dbMandantAZModell azm, int iTag)
        {
            azModell = azm;
            Tag = iTag;
        }
        private void Select()
        {
            using (SqlConnection cnx = new SqlConnection(ConfigurationManager.ConnectionStrings["SissiConnectionString"].ConnectionString))
            {
                try
                {
                    cnx.Open();
                    // Defect 5725, Config.Rowlock eingef�hrt
                    // Defect 5771, Config.Nolock eingef�hrt
                    string sql = "select MANDANT,WOCHENTAG,UESTD50BEG1,UESTD50END1,UESTD50BEG2,UESTD50END2,UESTD100BEG1,UESTD100END1,UESTD100BEG2,UESTD100END2,PAUSE,PAUSEAB,TXT,DATLA,AENPERSKEY,DATNEU,STATUS,NAZBEG,NAZEND from Y_AZMODELL " + Config.Nolock + " where MANDANT = @MANDANT and WOCHENTAG = @WOCHENTAG";
                    using (SqlCommand cmd = new SqlCommand(sql, cnx)) // Defect 5436
                    {
                      cmd.Parameters.Add(Params.MANDANT);
                      cmd.Parameters.Add(Params.WOCHENTAG);
                      using (SqlDataReader rd = cmd.ExecuteReader()) // Defect 5436, using eingef�hrt
                      {
                        cmd.Parameters.Remove(Params.MANDANT);
                        cmd.Parameters.Remove(Params.WOCHENTAG);
                        while (rd.Read())
                        {
                          ParamVal.DataReader2Params(rd, Params.List);
                          foreach (SqlParameter s in Params.List)
                            if (s.Value == DBNull.Value) s.Value = ParamVal.Date0; //expecting some timestamps to be null
                        }
                        rd.Close();
                      }
                    }
                }
                catch (Exception ex) { throw ex; }
                finally { cnx.Close(); }
            }
        }
    }

    public class dbMandantAZModell
    {
        public dbMandant Mandant;
        private ArrayList lTage = null;
        public ArrayList Tage
        {
            get
            {
                if (lTage == null)
                {
                    lTage = SelectTage();
                }
                return lTage;
            }
            set { lTage = value; }
        }

        private ArrayList SelectTage()
        {
            ArrayList al = new ArrayList();
            for (int i = 1; i <= 7; i++)
                al.Add(new dbMandantAZModellTag(this, i));
            return al;
        }
        public dbMandantAZModell(dbMandant mand)
        {
            Mandant = mand;
        }

    }

    /// <summary>
    /// 
    /// </summary>
    public class dbMandant
    {

        public dbBearbeiter Bearbeiter;
        public string MANDANT
        {
            get { return ParamVal.GetParameter(Bearbeiter.Params.MANDANT); }
        }


        private dbMandantAZModell lAZModell = null;
        public dbMandantAZModell AZModell
        {
            get
            {
                if (lAZModell == null)
                {
                    lAZModell = new dbMandantAZModell(this);
                }
                return lAZModell;
            }
            set { lAZModell = value; }
        }

        public dbMandant(dbBearbeiter Bearb)
        {
            Bearbeiter = Bearb;
        }
    }
}