//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbParamVal.cs
//
// Description  : Definieren der Paramter f�r Value
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.Misc;

/// <summary>
/// Summary description for dbParamVal
/// </summary>
namespace TapMontage.dbObjects
{
    public static class ParamVal
    {
        /// <summary>
        /// Returns 01.01.1900 00:00:00.00
        /// </summary>
        public static DateTime Date0
        {
            get
            {
                DateTime rd = DateTime.Now;
                rd = rd.AddDays(-rd.Day + 1);
                rd = rd.AddMonths(-rd.Month + 1);
                rd = rd.AddYears(-rd.Year + 1900);
                rd = Convert.ToDateTime(rd.ToShortDateString() + " 00:00");
                return rd;
            }
        }

        public static object SetParameter(SqlParameter s, string Value)
        {
            switch (Type.GetTypeCode(s.Value.GetType()))
            {
                case TypeCode.DateTime:
                    s.Value = Convert.ToDateTime(Value);
                    break;
                case TypeCode.String:
                    s.Value = Value;
                    break;
                case TypeCode.Int16:
                    s.Value = (Int16)0;
                    if (RangeCheck.IsInteger(Value))
                        s.Value = Convert.ToInt16(Value);
                    break;
                case TypeCode.Int32:
                    s.Value = (Int32)0;
                    if (RangeCheck.IsInteger(Value))
                        s.Value = Convert.ToInt32(Value);
                    break;
                case TypeCode.Int64:
                    s.Value = (Int64)0;
                    if (RangeCheck.IsInteger(Value))
                        s.Value = Convert.ToInt64(Value);
                    break;
                case TypeCode.Decimal:
                    s.Value = (Decimal)0;
                    if (RangeCheck.IsNumeric(Value))
                        s.Value = Convert.ToSingle(Value);
                    break;
                case TypeCode.Double:
                    s.Value = (Double)0;
                    if (RangeCheck.IsNumeric(Value))
                        s.Value = Convert.ToSingle(Value);
                    break;
                case TypeCode.Single:
                    s.Value = (Single)0;
                    if (RangeCheck.IsNumeric(Value))
                        s.Value = Convert.ToSingle(Value);
                    break;
                case TypeCode.Boolean:
                    s.Value = Convert.ToBoolean(Value);
                    break;
                default:
                    Exception ex = new Exception("Invalid TypeCode - Extend ParamVal::SetParameter.TypeCode=" + s.Value.GetType().ToString());
                    throw ex;
            }
            return s.Value;
        }

        public static string GetParameter(SqlParameter s)
        {
            switch (Type.GetTypeCode(s.Value.GetType()))
            {
                case TypeCode.DateTime:
                    DateTime dt = Convert.ToDateTime(s.Value);
                    long dasDat = dt.Year * 1000 + dt.Month * 10 + dt.Day;
                    dt = Date0;
                    long minDat = dt.Year * 1000 + dt.Month * 10 + dt.Day;
                    if (dasDat > minDat)
                        return Convert.ToDateTime(s.Value).ToShortDateString();
                    else
                        return Convert.ToDateTime(s.Value).ToShortTimeString();
                case TypeCode.String:
                    return (string)s.Value;
                case TypeCode.Int16:
                case TypeCode.Int32:
                case TypeCode.Int64:
                    return s.Value.ToString();
                case TypeCode.Double:
                case TypeCode.Decimal:
                case TypeCode.Single:
                    return Convert.ToSingle(s.Value).ToString("N");
                case TypeCode.Boolean:
                    return Convert.ToBoolean(s.Value).ToString();
                case TypeCode.DBNull:
                    return "null";
                default:
                    Exception ex = new Exception("Invalid TypeCode - Extend ParamVal::GetParameter.TypeCode="+s.Value.GetType().ToString());
                    throw ex;
            }
        }

        public static bool InsertValid(ArrayList List)
        {
            foreach (SqlParameter s in List)
            {
                if (s == null)
                {
                    Exception ex = new Exception("ParamVal::InsertValid: Parameter is NULL");
                    throw ex;
                }
                if (s.ParameterName.Length == 0)
                {
                    Exception ex = new Exception("ParamVal::InsertValid: ParameterName is not set!");
                    throw ex;
                }
                if (s.Value == null)
                {
                    Exception ex = new Exception("ParamVal::InsertValid: Value is Null");
                    throw ex;
                }
            }
            return true;
        }

        public static ArrayList DataReader2Params(SqlDataReader rd, ArrayList al)
        {
            al = SetDefaultValues(al);
            for (int i = 0; i <= rd.FieldCount - 1; i++)
            {
                bool match = false;
                foreach (SqlParameter s in al)
                    if (s.ParameterName.Substring(1).ToUpper() == rd.GetName(i).ToUpper())
                    {
                        if (!rd.IsDBNull(i)) s.Value = rd.GetValue(i);
                        else s.Value = DBNull.Value;
                        match = true;
                        break;
                    }
                if (!match)
                {
                    Exception ex = new Exception("ParamVal::DataReade2Params: No parameter found for Row: " + rd.GetName(i));
                    throw ex;
                }
            }
            return al;
        }

        public static ArrayList SetDefaultValues(ArrayList Params)
        {
            foreach (SqlParameter s in Params)
            {
                if (s.Value != null)
                {
                    switch (Type.GetTypeCode(s.Value.GetType()))
                    {
                        case TypeCode.DateTime:
                            s.Value = Date0;
                            break;
                        case TypeCode.String:
                            s.Value = (string)"";
                            break;
                        case TypeCode.Int32:
                            s.Value = (int)0;
                            break;
                        case TypeCode.Int16:
                            s.Value = (Int16)0;
                            break;
                        case TypeCode.Int64:
                            s.Value = (Int64)0;
                            break;
                        case TypeCode.Decimal:
                            s.Value = (decimal)0;
                            break;
                        case TypeCode.Double:
                            s.Value = (double)0;
                            break;
                        case TypeCode.Single:
                            s.Value = (Single)0;
                            break;
                        case TypeCode.Boolean:
                            s.Value = (Boolean)false;
                            break;
                        case TypeCode.DBNull:
                            break;
                        default:
                            Exception ex = new Exception("ParamVal::SetDefaultValues: Please extend DataTypes with: " + s.Value.GetType().ToString());
                            throw ex;
                    }
                }
                else
                {
                    switch (s.DbType)
                    {
                        case System.Data.DbType.Int64:
                            s.Value = (Int64)0;
                            break;
                        case System.Data.DbType.Boolean:
                            s.Value = (Boolean)false;
                            break;
                        case System.Data.DbType.Decimal:
                            s.Value = (decimal)0;
                            break;
                        case System.Data.DbType.Double:
                            s.Value = (double)0;
                            break;
                        case System.Data.DbType.Int16:
                            s.Value = (Int16)0;
                            break;
                        case System.Data.DbType.Int32:
                            s.Value = (Int32)0;
                            break;
                        case System.Data.DbType.String:
                            s.Value = (string)"";
                            break;
                        case System.Data.DbType.Single:
                            s.Value = (Single)0;
                            break;
                        case System.Data.DbType.Date:
                        case System.Data.DbType.DateTime:
                            s.Value = Date0;
                            break;
                        default:
                            Exception ex = new Exception("ParamVal::SetDefaultValues: Please extend DbType with: " + s.DbType.ToString());
                            throw ex;
                    }

                }

            }
            return Params;
        }
    }
}

