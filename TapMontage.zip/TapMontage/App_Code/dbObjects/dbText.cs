//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : dbText.cs
//
// Description  : Text
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04. Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data.SqlClient;
using System.Text;

namespace TapMontage.dbObjects
{
    /// <summary>
    /// Summary description for dbText
    /// </summary>
    public static class dbText
    {
        /// <summary>
        /// Retrieve Content of a Text or NText Column
        /// SqlCommand must execute reader with CommandBehavior.SequentialAccess
        /// </summary>
        /// <param name="myReader"> contains current row</param>
        /// <param name="i">column index</param>
        /// <returns></returns>
        public static string GetText(SqlDataReader myReader, int i)
        {
            int bufferSize = 4096;
            byte[] outchar = new byte[bufferSize];
            outchar.Initialize();
            int retval;
            int startIndex = 0;
            string retString = "";

            startIndex = 0;
            retval = bufferSize;
            //continue reading while outbyte is completely filled
            while (retval == bufferSize)
            {
                try
                {
                    retval = (int)myReader.GetBytes(i, startIndex, outchar, 0, bufferSize);
                    startIndex += bufferSize;
                    retString += Encoding.UTF8.GetString(outchar, 0, retval);
                    //outchar.Initialize();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return retString;
        }

        public static string GetNText(SqlDataReader myReader, int i)
        {
            int bufferSize = 4096;
            byte[] outchar = new byte[bufferSize];
            outchar.Initialize();
            int retval;
            int startIndex = 0;
            string retString = "";

            startIndex = 0;
            retval = bufferSize;
            //continue reading while outbyte is completely filled
            while (retval == bufferSize)
            {
                try
                {
                    retval = (int)myReader.GetBytes(i, startIndex, outchar, 0, bufferSize);
                    startIndex += bufferSize;
                    retString += Encoding.Unicode.GetString(outchar, 0, retval);
                    //outchar.Initialize();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return retString;
        }
    }
}