//=============================================================================
//
// Projekt      : TAP_Montage
//
// File         : pdfReport.cs
//
// Description  : pdfReport
//
//=============== V1.0.0029 ===================================================
//
// Date         : 04.Juli 2007
// Author       : Julia Heuritsch
// Defect#      : 4179
//                Layout angepasst
//
//=============================================================================

using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TapMontage.dbObjects;
using Root.Reports;


namespace TapMontage.Pdf
{
    /// <summary>
    /// Summary description for pdfReports
    /// </summary>
    public static class pdfReports
    {
        /// <summary>
        /// Adds an object to the placeholder and stores the data for the pdf in Session["DisplayReport"] 
        /// </summary>
        /// <param name="page">System.Web.UI.Page to recieve the Session[DisplayReport]</param>
        /// <param name="height">height of object in px</param>
        /// <param name="width">width of object in px</param>
        public static HtmlGenericControl ShowMBericht(System.Web.UI.Page page, int width, int height)
        {
            HtmlGenericControl gcRep = new HtmlGenericControl();
            string appPath = page.Request.ApplicationPath;
            if (appPath == "/") appPath = "";
            gcRep.InnerHtml = "<object type=\"application/pdf\" width=\"" + width.ToString() + "px\" height=\"" + height.ToString() + "px\" data=\"" + appPath + "/allgemein/displaypdf.aspx\"></object>";
            MemoryStream stream = RT.StreamPDF(new pdfMBJournal((dbMontBer)page.Session["MBericht"]));
            byte[] bar = new byte[stream.Length];
            bar = stream.ToArray();
            page.Session["DisplayReport"] = bar;
            return gcRep;
        }

        private static string RandomFname(string prefix)
        {
            Random rand = new Random(DateTime.Now.Millisecond);
            return prefix + rand.Next().ToString() + ".pdf";
        }
        ///
        /// the following code is for use in a Page when using FileEventSuggestion 
        ///
        /*
        phPDF.Controls.Clear();
        HtmlGenericControl gc = new HtmlGenericControl();
        string fname = MapPath("~/");
        fname = pdfReports.FileEventSuggestion(dbev, Session.SessionID, MapPath("~/pdffiles/"));
        Session["deleteReport"] = MapPath("~/pdffiles/")+fname;
        gc.InnerHtml = "<object type=\"application/pdf\" data=\"" + "pdffiles/" + fname + "\"width=\"1024px\" height=\"800px\" >Sie ben�tigen den Acrobat Reader zu Anzeige der Datei.</object>";
        phPDF.Controls.Add(gc);
        
        public static string FileEventSuggestion(DBEvent dbev, string SessionID, string Path)
        {
            string fname = RandomFname("ev" + SessionID);
            Report rep = new pdfEventSuggestion(dbev);
            rep.Save(Path + fname);
            DeleteTimer dt = new DeleteTimer(Path + fname);
            return fname;
        }*/
    }

    //#region DeleteTimer
    /// <summary>
    /// obsolete, deletes a temporary file after 15 seconds
    /// </summary>
    //class DeleteTimer
    //{
    //    string fname;
    //    int t = 15000; //we'll wait 15 seconds, should be enough
    //    Timer timer;

    //    public DeleteTimer(string FileName)
    //    {
    //        fname = FileName;
    //        TimerCallback tcb = new TimerCallback(DeleteIt);
    //        timer = new Timer(tcb, fname, t, Timeout.Infinite);
    //    }

    //    public void DeleteIt(Object FileName)
    //    {
    //        try
    //        {
    //            File.Delete((string)FileName);
    //        }
    //        catch
    //        {
    //        }
    //    }
    //}
    //#endregion
}