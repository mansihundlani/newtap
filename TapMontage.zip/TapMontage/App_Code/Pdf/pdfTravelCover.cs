// ========================================================================
//
// Projekt		: TAP_Montage
//
// File         : pdfTravelCover.cs
//
// Description  : Reiseabrechnungsbeleg drucken
//
// =============== V1.0.0018 ==============================================
//
// Date         : 10. J�nner 2007
// Author       : Patrman Wolfgang
// Defect#      : 4203
//                zus�tzlich Firma andrucken
//
// ========================================================================

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

using TapMontage.dbObjects;
using Root.Reports;

/// <summary>
/// Summary description for pdfTravelCover
/// </summary>
public class pdfTravelCover : Report
{

    private dbBearbeiter monteur;
    private dbKG_Monat monat;
   

    public pdfTravelCover(dbBearbeiter monteur, dbKG_Monat monat)
    {
        this.monteur = monteur;
        this.monat = monat;
    }

    protected override void Create() {

        FontDef fd = new FontDef(this, FontDef.StandardFont.Helvetica);
        FontProp fp = new FontPropMM(fd, 4);

        string surname = monteur.Params.NACHNAME.Value.ToString();
        string givenname = monteur.Params.VORNAME.Value.ToString();
        string persNr = monteur.Params.PERSNR.Value.ToString();

        ArrayList l = monat.Rabrech.DBAbRech;

        foreach (dbRaKopf reise in l)
        {
            string raid = reise.Params.RAID.Value.ToString();
            string firma = reise.Params.FIRMA.Value.ToString(); // defect 4203

            page_Cur = new Root.Reports.Page(this);

            fp.bBold = true;

            int marginLeft = 50;

            int marginNext = 40;

            int y = 50;

            page_Cur.Add(marginLeft, y, new RepString(fp, "Reiseabrechung"));

            fp.bBold = false;

            y += 2 * marginNext;

            page_Cur.Add(marginLeft, y, new RepString(fp, "Nummer:"));
            y += marginNext;

            page_Cur.Add(marginLeft, y, new RepString(fp, "Name:"));
            y += marginNext;

            page_Cur.Add(marginLeft, y, new RepString(fp, "Pers.-Nr:"));
            
            // start defect 4203
			//	Firmenname war im bisherigen Ausdruck der Reiseabrechnung nicht vorgesehen und wird erg�nzt.
			//	Unterhalb der Personalnummer wird in einer eigenen Zeile der Firmenname angedruckt.

            // y += 2 * marginNext;
            y += marginNext;
            page_Cur.Add(marginLeft, y, new RepString(fp, "Firma:"));
            y += 2 * marginNext;
            // end defect 4203

            page_Cur.Add(marginLeft, y, new RepString(fp, DateTime.Now.ToShortDateString() + ", " + DateTime.Now.ToShortTimeString()));

            y = 50 + 2 * marginNext;

            marginLeft = 250;

            page_Cur.Add(marginLeft, y, new RepString(fp, raid));
            y += marginNext;

            page_Cur.Add(marginLeft, y, new RepString(fp, givenname + " " + surname));
            y += marginNext;

            page_Cur.Add(marginLeft, y, new RepString(fp, persNr.ToString()));
            y += marginNext;

            page_Cur.Add(marginLeft, y, new RepString(fp, firma.ToString())); // defect 4203
        }
    }
}
