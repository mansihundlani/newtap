﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;


public class CurrentEnvironment
{
    private static readonly string PORT_ENV_VARIABLE_NAME = "PORT";
    private static readonly string INSTANCE_GUID_ENV_VARIABLE_NAME = "INSTANCE_GUID";
    private static readonly string INSTANCE_INDEX_ENV_VARIABLE_NAME = "INSTANCE_INDEX";
    private static readonly string BOUND_SERVICES_ENV_VARIABLE_NAME = "VCAP_SERVICES";
    private static readonly string NOT_ON_CLOUD_FOUNDRY_MESSAGE = "Not running in cloud foundry.";

    /// <summary>
    /// static constructor to determine the state of the environment and set defaults 
    /// </summary>
    static CurrentEnvironment()
    {
        // Not on cloud foundry filling in the blanks.
        if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable(INSTANCE_GUID_ENV_VARIABLE_NAME)))
        {
            Environment.SetEnvironmentVariable(BOUND_SERVICES_ENV_VARIABLE_NAME, "{}");
            Environment.SetEnvironmentVariable(PORT_ENV_VARIABLE_NAME, NOT_ON_CLOUD_FOUNDRY_MESSAGE);
            Environment.SetEnvironmentVariable(INSTANCE_GUID_ENV_VARIABLE_NAME, NOT_ON_CLOUD_FOUNDRY_MESSAGE);
            Environment.SetEnvironmentVariable(INSTANCE_INDEX_ENV_VARIABLE_NAME, NOT_ON_CLOUD_FOUNDRY_MESSAGE);
        }

        // check to see if DB is bound, if so...what type
        // sql server first
        //user-provided
        if (BoundServices.GetValue("user-provided") != null) // sql server
        {
            DbEngine = DatabaseEngine.SqlServer;
            SqlConnectionStringBuilder sqlcsBuilder = new SqlConnectionStringBuilder();
            sqlcsBuilder.Add("Data Source", BoundServices["user-provided"][0]["credentials"]["host"].ToString() + "\\WIN-001" + ",1433");
            sqlcsBuilder.Add("User ID", BoundServices["user-provided"][0]["credentials"]["username"].ToString());
            sqlcsBuilder.Add("Password", BoundServices["user-provided"][0]["credentials"]["password"].ToString());
            sqlcsBuilder.Add("Initial Catalog", "TAPMontage");
            _connectionString = sqlcsBuilder.ToString(); 

           // SqlConnectionStringBuilder sqlcsbuilder = new SqlConnectionStringBuilder();
           // sqlcsbuilder.Add("Data Source", "MC0ZB0AC");
           ////sqlcsbuilder.Add("port", BoundServices["mssql -dev"][0]["credentials"]["port"].ToString());
           // sqlcsbuilder.Add("User ID", "sa");
           // sqlcsbuilder.Add("Password", "atos@123");
           // sqlcsbuilder.Add("Initial Catalog", "SISSI");
           // _connectionString = sqlcsbuilder.ToString();

        }
        else if (BoundServices.GetValue("p-mysql") != null)
        {
            DbEngine = DatabaseEngine.MySql;
            MySqlConnectionStringBuilder csbuilder = new MySqlConnectionStringBuilder();
            csbuilder.Add("server", BoundServices["p-mysql"][0]["credentials"]["hostname"].ToString());
            csbuilder.Add("port", BoundServices["p-mysql"][0]["credentials"]["port"].ToString());
            csbuilder.Add("uid", BoundServices["p-mysql"][0]["credentials"]["username"].ToString());
            csbuilder.Add("pwd", BoundServices["p-mysql"][0]["credentials"]["password"].ToString());
            csbuilder.Add("database", BoundServices["p-mysql"][0]["credentials"]["name"].ToString());
            _connectionString = csbuilder.ToString();
        }
        else
        {
            //DbEngine = DatabaseEngine.None;
            //DbEngine = DatabaseEngine.SqlServer;
            // _connectionString = "Data Source=MC0ZB0AC;Initial Catalog=SISSI; User ID=sa;Password=atos@123";
            //_connectionString = "Data Source=MC0XTEMC;Initial Catalog=Besan2;User ID=sa;Password=Root@123";

        }

    }

    /// <summary>
    /// Current server time.
    /// </summary>
    public static string CurrentTime
    {
        get { return DateTime.Now.ToString(); }
    }

    /// <summary>
    /// .NET runtime version
    /// </summary>
    public static string CLRVersion
    {
        get { return Environment.Version.ToString(); }
    }

    /// <summary>
    /// Uptime.  This method appears to be machine wide and specific to the container.
    /// </summary>
    public static string Uptime
    {
        get { return DateTime.Now.Subtract(TimeSpan.FromMilliseconds(Environment.TickCount)).ToString(); }
    }

    /// <summary>
    /// The local port the container is listening on
    /// </summary>
    public static string Port
    {
        get { return Environment.GetEnvironmentVariable(PORT_ENV_VARIABLE_NAME); }
    }

    /// <summary>
    /// The instance GUID Cloud Foundry assigned to this app instance.
    /// </summary>
    public static string InstanceID
    {
        get { return Environment.GetEnvironmentVariable(INSTANCE_GUID_ENV_VARIABLE_NAME); }
    }

    /// <summary>
    /// The zero based index assigned to this instance of the app.
    /// </summary>
    public static string InstanceIndex
    {
        get { return Environment.GetEnvironmentVariable(INSTANCE_INDEX_ENV_VARIABLE_NAME); }
    }

    public static JObject BoundServices
    {
        get { return JObject.Parse(Environment.GetEnvironmentVariable(BOUND_SERVICES_ENV_VARIABLE_NAME)); }
    }

    private static string _connectionString = string.Empty;
    /// <summary>
    /// Detect a bound service for database, no database found will return an empty string.  Currently only supports SQL Server
    /// </summary>
    public static string DbConnectionString
    {
        get { return _connectionString; }
    }

    /// <summary>
    /// Looks to see if the connection string could be found in a bound service.
    /// </summary>
    public static bool hasDbConnection
    {
        get { return DbEngine != DatabaseEngine.None ? true : false; }
    }

    /// <summary>
    /// Tells which DB engine was detected during app startup.
    /// </summary>
    public static DatabaseEngine DbEngine
    {
        get;
        set;
    }
    public enum DatabaseEngine
    {
        None = 0,
        SqlServer = 1,
        MySql = 2
    }
}

